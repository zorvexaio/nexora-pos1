# Rilmo Production Launch Pack v1.63.0

This pack separates **software-complete** controls from the credentials, vendor approvals, certificates, and production evidence that must be supplied at launch.

## Launch sequence
1. Provision PostgreSQL 18.x, Redis, object storage, ClamAV and monitoring.
2. Load secrets only through the deployment secret manager.
3. Run `python scripts/production_preflight.py` in the production environment.
4. Run `alembic upgrade head` and verify the migration head.
5. Run the PostgreSQL/RLS smoke and runtime-security gates.
6. Run backup + restore rehearsal and record RTO/RPO evidence.
7. Configure the contracted payment provider for the target jurisdiction and replay signed webhooks.
8. Configure tax/e-invoicing provider for the target jurisdiction.
9. Run staging T1–T20, load/concurrency, failover and DNS takeover tests.
10. Complete independent penetration testing and legal/compliance review.
11. Submit Apple App Store / Google Play builds according to the physical-vs-digital payment matrix.
12. Only then mark the market as `READY` in the Global Readiness Control Plane.

## Zero-paid-API AI policy
Production defaults to local Ollama. `AI_EXTERNAL_PROVIDER_ALLOWED=false` and `AI_PROVIDER=ollama` are required by preflight. External AI can only be enabled intentionally by changing policy and accepting the associated cost/data-transfer review.

## Card installment policy
Rilmo product pricing is authoritative. `CARD_INSTALLMENT_SAME_PRICE_ONLY=true` is required. Rilmo does not add interest, markup or an installment surcharge to the merchant product price. Any financing terms belong to the contracted payment/financing provider and must be legally reviewed for the market.

## Global readiness rule
A country is not `READY` merely because code exists. The readiness record must reference real legal/tax/payment/data-transfer/app-store evidence.
