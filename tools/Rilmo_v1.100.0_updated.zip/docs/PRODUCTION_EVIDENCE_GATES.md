# Production Evidence Gates

A local green build is not equivalent to production certification. Rilmo therefore keeps these evidence classes separate.

## Local / CI

- unit/integration tests with warnings treated as errors
- clean-install dependency check
- schema and migration audit
- route inventory and duplicate detection
- frontend security audit
- ASVS/API security static gate
- PostgreSQL RLS smoke in CI
- release hygiene and SHA-256 manifest

## Staging / External

- real PostgreSQL role/RLS evidence
- Redis failover and multi-instance rate-limit evidence
- real KYC provider flow and signed webhook evidence
- object storage encryption, lifecycle and malware-scan evidence
- payment provider sandbox evidence
- backup and restore rehearsal
- load/soak/concurrency and SLO evidence
- independent penetration test
- legal review of KVKK controller/processor roles, retention, special-category basis, disclosures and transfer mechanism

Promotion to production requires the applicable evidence artifacts to be attached to the release record. The software never fabricates a PASS for evidence that requires an external system.


## v1.62.0 release rule
A software PASS never substitutes for vendor, infrastructure, regulatory, store-review, or independent-security evidence. External gates remain explicitly open until their evidence artifacts are attached.
