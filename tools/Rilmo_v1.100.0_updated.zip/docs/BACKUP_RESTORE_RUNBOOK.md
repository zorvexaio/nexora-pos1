# Backup / Restore Runbook

1. Set `DATABASE_URL` to the production PostgreSQL endpoint.
2. Set `BACKUP_ENCRYPTION_KEY` from the secret manager; never commit it.
3. Run `scripts/backup_postgres.sh` to create an AES-256 encrypted compressed logical backup.
4. Store the resulting file in a separate encrypted backup location.
5. For a restore drill, use an isolated PostgreSQL instance and run `scripts/restore_postgres.sh <backup>`.
6. Run `alembic upgrade head`, application smoke tests, ledger balance checks, tenant isolation checks, and `/v1/ready`.
7. Record restore duration and recovered object counts as release evidence.

The production release gate is not closed by the existence of this script; a successful restore drill must be recorded.
