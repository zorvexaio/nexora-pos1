# Release Notes — v1.41.0

## Privacy boundary hardening

- KYC views use a dedicated safe serializer rather than the generic ORM serializer. External provider references are masked; provider metadata and raw provider-access references are never returned to tenant members.
- The identity verification URL is returned only to the user who initiated that verification session.
- Merchant tax IDs and private contact/address fields are masked for non-owner/admin views.
- Third-party provider identity documents remain outside Rilmo by default; Rilmo stores verification state and a provider reference only.

## Incident-response state machine

Privacy incidents now use explicit forward-only transitions: DETECTED → CONTAINED → ASSESSED → NOTIFICATION_PENDING → NOTIFIED → REMEDIATED → CLOSED. A notification decision is required before NOTIFIED, and remediation is required before CLOSED.

## Release reproducibility

- Added strict dependency/runtime drift audit.
- Added CycloneDX 1.6 SBOM generation.
- CI now runs environment audit and SBOM generation as release controls.
- Release provenance must include file hashes and dependency pins; local test results are not treated as evidence when the runtime is dependency-drifted.

## Security reference baseline

The application security baseline continues to map to OWASP ASVS 5.0.0 and OWASP API Security Top 10 2023, and now explicitly tracks OWASP Top 10:2025 categories including software supply-chain failures, software/data integrity failures, logging/alerting failures, and mishandling exceptional conditions.

For Turkey, the privacy transfer register and contract-governance controls are aligned to KVKK's current international-transfer framework and July 2026 guidance on standard-contract execution and submission.

- Added KVKK transfer governance evidence fields and compliance-only transfer route registry in migration `20260818_0041`.
- Added explicit runtime environment evidence and strict dependency drift gate; local sandbox drift is never treated as reproducibility proof.
