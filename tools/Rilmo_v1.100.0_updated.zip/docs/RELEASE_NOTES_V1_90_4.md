# Release 1.90.4

## OAuth security and concurrency hardening

- Hardened Google OAuth callback nonce validation so invalid nonce cookies are rejected before provider calls.
- Preserved explicit OAuth validation errors instead of converting them into generic upstream failures.
- Added atomic OAuth-state consumption to prevent concurrent callback replay races.
- Applied the same atomic state-consumption protection to merchant Google linking and public storefront customer Google OAuth.
- Added deep mocked OAuth regression coverage for success, invalid nonce, token failure, existing-account linking, and replay.
