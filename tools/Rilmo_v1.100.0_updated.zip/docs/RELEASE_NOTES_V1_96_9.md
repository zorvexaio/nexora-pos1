# Release Notes — v1.96.9

## Security closures

- Domain purchase idempotency is now tenant-scoped in both application lookup and the database uniqueness constraint. This prevents cross-tenant replay of a client-supplied idempotency key from returning another tenant's purchase record.
- OAuth refresh tokens are now bound to the application identified by the authenticated client credentials and the token's installation. Cross-client redemption is rejected.

## Verification

- OAuth, internal permission, role and payment regression suite: **12/12 PASS**.
- Domain purchase idempotency regression suite: **7/7 PASS**.
- Fresh SQLite Alembic migration smoke completed through head `20260908_0066`; PostgreSQL DDL path is explicit in migration 0066.

## Release boundary

This release contains local deterministic evidence only. Production/global certification still requires the external PostgreSQL/RLS, real provider, load/soak/failover, backup/restore and independent security evidence defined by the project gates.
