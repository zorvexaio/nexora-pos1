# v1.20.0 RBAC + Plan Entitlement Matrix

## Roles

| Role | Scope | Summary |
|---|---|---|
| owner | tenant | Full tenant permissions |
| admin | tenant | Full tenant permissions |
| staff | tenant | Operational catalog/order/inventory/customer/storefront/app/settings/billing access |
| viewer | tenant | Read-oriented catalog/order/inventory/finance access |

Core permission keys: `products.read`, `products.write`, `orders.read`, `orders.manage`, `orders.cancel`, `orders.refund`, `inventory.read`, `inventory.write`, `finance.read`, `finance.manage`, `customers.read`, `customers.write`, `customers.export`, `storefront.read`, `storefront.write`, `apps.manage`, `settings.manage`, `billing.manage`, `staff.manage`.

## Plan entitlements

| Feature | Starter $12 | Growth $30 | Scale $100 | Enforcement |
|---|---:|---:|---:|---|
| max_products | 50 | 500 | -1 | product creation |
| max_languages | 1 | 5 | 13 | locale/translation policy |
| coupons | true | true | true | checkout coupon use |
| abandoned_cart | false | true | true | campaign scan |
| sms_monthly | 0 | 100 | 2,000 | SMS delivery quota |
| advanced_analytics | false | true | true | analytics endpoints/UI |
| priority_support | false | true | true | support entitlement |
| api_access | false | false | true | API key creation/use |

## Authorization rule

A tenant operation is allowed only when both conditions pass:

1. the actor has the required RBAC permission; and
2. the tenant's active subscription grants the required entitlement.

Platform Super Admin capabilities are separate from tenant RBAC and are required for platform billing discounts and plan administration.
