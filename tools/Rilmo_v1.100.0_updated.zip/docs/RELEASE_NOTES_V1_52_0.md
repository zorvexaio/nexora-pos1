# Rilmo / Unified Global Commerce v1.52.0

## Workflow Webhook Reliability Closure

- Workflow WEBHOOK steps now create durable `WorkflowWebhookDelivery` records.
- Workflow steps remain `QUEUED` until the outbound request actually succeeds.
- Delivery uses the existing DNS-pinned, SSRF-hardened HTTPS transport.
- Retries and terminal failures are persisted; failed steps are marked `FAILED`.
- Delivery is tenant-isolated with PostgreSQL ENABLE + FORCE RLS.
- The worker now uses the canonical workflow executor instead of a divergent duplicate implementation.
- Release builder explicitly excludes internal patch-generation scripts.
