# Global World Readiness Control Plane — v1.60.0

This release introduces an executable launch-readiness control plane. It deliberately distinguishes **software readiness** from external legal/regulatory certification. A market cannot be marked READY by code alone.

## Markets modeled
- Turkey (TR): KVKK, payment-services/provider evidence, distance-sales/consumer review, e-invoicing.
- Saudi Arabia (SA): ZATCA e-invoicing, VAT, consumer-commerce review.
- European Union (EU): GDPR/legal review, DSA trader traceability where marketplace duties apply, VAT OSS/IOSS review, DPP review.
- United States (US): sales-tax nexus, state privacy, consumer policy review.
- United Kingdom (GB): UK GDPR/VAT/consumer review.

## App-store payment matrix
Apple and Google policies are modeled separately for physical goods and digital goods/services. The client and server must classify the SKU before selecting a payment rail.

Apple: physical goods/services consumed outside the app must use payment methods other than In-App Purchase; digital purchases remain subject to Apple’s in-app purchase rules and regional exceptions.

Google Play: physical goods/services are excluded from mandatory Play Billing; digital goods/services generally require Play Billing unless a documented regional exception applies.

## AI cost policy
Default production AI is internal Ollama only. External paid AI providers are disabled unless an operator explicitly enables the policy exception. Rules-only fallback remains available when the model service is unavailable.

## Card installment policy
Rilmo does not add a price delta for installments. The application exposes `price_delta_minor = 0` and treats installment financing as a provider/bank service. Any bank/provider fee remains outside Rilmo’s merchant item price and must be handled under the provider’s contract and applicable law.

## External evidence remains external
The system records evidence references, reviewer, verification time, and expiration. It does not claim that a market is legally certified merely because the software can represent the requirement.

Official references checked for this release (2026-08-19):
- Apple App Review Guidelines: https://developer.apple.com/app-store/review/guidelines/
- Google Play Payments policy: https://support.google.com/googleplay/android-developer/answer/10281818
- EU Digital Services Act Article 30 / marketplace traceability: https://eur-lex.europa.eu/legal-content/EN/ALL/?uri=CELEX:32022R2065
- ZATCA e-invoicing Phase 2: https://zatca.gov.sa/en/E-Invoicing/Introduction/Pages/Roll-out-phases.aspx
