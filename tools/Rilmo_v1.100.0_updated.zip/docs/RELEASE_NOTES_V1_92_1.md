# Unified Global Commerce v1.92.1

## Security hotfix — public domain verification

All public storefront data routes now require a verified custom domain before exposing merchant catalog or shipping data.

Protected routes include:
- `GET /v1/public/storefront/{hostname}`
- `GET /v1/public/storefront/{hostname}/shipping-methods`
- `GET /v1/public/products/{product_id}`

This closes an authorization inconsistency where an unverified Domain record could expose published storefront metadata before domain ownership verification.

Regression coverage added in `tests/test_v192_public_domain_verification.py`.

Verification evidence:
- 562/562 tests passed from the clean working tree after the fix.
- Security, schema, release-consistency, and structural release audits pass.
