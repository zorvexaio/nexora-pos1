# Unified Global Commerce v1.97.9 — Release Integrity Closure

- Synchronized current-release documentation with `VERSION`.
- Repaired legacy release-contract tests that had become stale after dynamic payment User-Agent and durable provider-tenant webhook routing hardening.
- Preserved the release-builder exclusion for internal `_apply_vXX.py` patch scripts and added exact regression coverage.
- Verified the release in four deterministic test batches: 863/863 passing.
- Verified release artifact, consistency, security, specification, schema, frontend, dependency, hygiene, and final structural gates.
- External PostgreSQL/RLS, real-provider, backup/restore, load/failover, and independent penetration-test evidence remain separate production gates.
