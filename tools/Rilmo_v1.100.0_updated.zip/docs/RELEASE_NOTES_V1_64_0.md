# Release Notes v1.64.0

- Release consistency gate prevents stale runtime/build versions and legacy payment User-Agent identifiers.
- Production preflight now requires HTTPS public/callback URLs, production object storage and ClamAV configuration, and APP_VERSION/VERSION consistency.
- Added release-surface regression tests.
- Removed historical release manifest files from the production artifact.
- Preserved local-only Ollama default and same-price card-installment policy.
