# Release Provenance — v1.18.2-staging-gate

This repository was reconstructed from the supplied v1.18.0 release ZIP on 2026-08-16.

The Git history is intentionally labeled as reconstructed provenance. It must not be represented
as the original development history of the project.

Current tag:

`v1.18.2-staging-gate`

Current commit:

See `git rev-parse v1.18.2-staging-gate` for the immutable commit ID of this tag.

The authoritative developer artifact is the exact Git commit plus its SHA-256 manifest.
Future changes must be made through normal commits and CI.

## Staging status

Real external staging evidence is **BLOCKED** until a public HTTPS deployment produces the
required evidence in `docs/STAGING_EVIDENCE_RECORD.md`. Local SQLite/PostgreSQL rehearsal is not
substituted for that evidence.
