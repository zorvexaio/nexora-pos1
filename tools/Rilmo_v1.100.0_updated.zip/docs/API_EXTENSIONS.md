# API Extensions — v1.9

These endpoints are intentionally outside the normative v1.8 P0 registry and are documented here as implementation extensions. They do not alter the normative contract.

| Method | Path | Purpose |
|---|---|---|
| GET | `/v1/orders` | Paginated merchant order list for dashboard operations |
| GET | `/v1/inventory` | Merchant inventory dashboard view |
| GET | `/v1/categories` | Merchant category listing |
| GET | `/v1/media` | Merchant media library listing |
| GET | `/v1/dashboard/summary` | Tenant dashboard KPI summary |
