# Security Baseline — OWASP Top 10:2025 + ASVS 5.0 + API Security Top 10:2023

This matrix is aligned to the current OWASP Top 10:2025 web-application risk categories, OWASP ASVS 5.0.0, and the API Security Top 10:2023. OWASP lists Broken Access Control, Security Misconfiguration, Software Supply Chain Failures, Cryptographic Failures, Injection, Insecure Design, Authentication Failures, Software/Data Integrity Failures, Security Logging & Alerting Failures, and Mishandling of Exceptional Conditions in the 2025 web-app list.

# Rilmo Security Verification Matrix — OWASP ASVS 5.0 + API Security Top 10 2023

This matrix is the engineering control map for the current release. It is not a penetration-test certificate.
OWASP ASVS 5.0.0 is the current stable ASVS baseline. The API layer is additionally reviewed against OWASP API Security Top 10 (2023).

## API Security Top 10

| Control | Rilmo implementation | Evidence gate |
|---|---|---|
| API1 BOLA | tenant membership + object tenant filters + RLS | pytest + PostgreSQL RLS smoke |
| API2 Broken Auth | server sessions, Argon2, MFA, recovery-code single use, session TTL | pytest security suite |
| API3 Property Auth | explicit serializers, privacy/KYC redaction, scoped app tokens | privacy + OAuth tests |
| API4 Resource Consumption | distributed rate limiting, body-size caps, upload caps, provider timeouts | rate-limit + request-size tests |
| API5 Function Auth | permission dependency and dedicated compliance-officer dependency | static security gate + tests |
| API6 Sensitive Flows | idempotency, payment serialization, KYC/payout gates, abuse throttles | financial invariants + abuse tests |
| API7 SSRF | outbound URL validation, DNS resolution checks, private/metadata target blocking | SSRF tests |
| API8 Misconfiguration | production startup guards, security headers, trusted hosts, mock-provider boundaries | security gate + startup tests |
| API9 Inventory | route registry audit + canonical schema audit + version consistency | release audit |
| API10 Unsafe API Consumption | provider allowlists, signed webhooks, timeouts, payload limits, isolated integrations | provider/webhook tests |

## ASVS 5.0 release posture

The release gate treats the following as mandatory baseline controls: input validation, output encoding, authentication/session integrity, authorization, secure configuration, cryptography/key separation, logging without secrets, SSRF defenses, file-upload scanning, dependency reproducibility, and CI evidence.

No control is marked “certified” solely from source inspection. External penetration testing, production infrastructure validation, provider validation, and legal review remain separate evidence classes.

## Privacy/KYC-specific controls

- Raw identity documents and raw biometric templates are outside Rilmo's default storage boundary.
- Support and merchant users receive status/operational metadata only.
- Exceptional access is case-bound, reason-bound, ticket-bound, time-limited, MFA-protected and audited.
- Compliance access does not create a Rilmo raw-document download endpoint.
- Privacy export excludes raw KYC material.
- Sensitive values are excluded from application logs by design.
