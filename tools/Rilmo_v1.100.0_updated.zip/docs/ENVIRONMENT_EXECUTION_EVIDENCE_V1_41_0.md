# Runtime Environment Evidence — v1.41.0

## Purpose

This document separates **release dependency intent** from the packages present in the execution sandbox used to validate the source tree.

## Release dependency contract

The authoritative runtime dependency contract is `requirements.txt`. CI installs that exact pinned set before running the release gates.

## Local execution sandbox

The local sandbox used for this build has a pre-existing Python environment that does not exactly match `requirements.txt`, and outbound package installation is unavailable because external package index resolution is blocked in this environment.

The strict `scripts/environment_audit.py` gate intentionally reports this drift instead of silently accepting it.

## What was independently validated in this sandbox

- 206/206 application tests pass with warnings treated as errors.
- Security gate passes.
- Structural specification audit passes.
- Canonical schema mapping audit passes.
- Frontend/PWA/CSP audit passes.
- Final release structural audit passes.
- Source formatting audit passes.
- Full Alembic upgrade to `20260818_0041` passes.
- Live runtime storefront/cart/order/payment smoke passes.
- The release artifact contains the exact pinned dependency contract and a generated CycloneDX SBOM.

## CI requirement

A CI runner with network/package-cache access must install the exact pinned requirements and pass `scripts/environment_audit.py` before a production release is promoted. A local sandbox with dependency drift must never be treated as equivalent evidence.
