# Release Notes — Unified Global Commerce v1.46.0

## Security and serialization
- Replaced per-route generic ORM serializers with one canonical schema-aware serializer.
- Added fail-closed structural detection for hashes, secrets, encrypted values, credentials, tokens, API/private keys, biometric/raw-document markers, passport and selfie fields.
- Added repository-wide model traversal tests so future sensitive columns fail CI unless covered by the serializer policy.
- Kept `token_prefix` as an explicit non-secret display exception.

## Observability
- Replaced silent Paddle subscription date parsing failures with safe structured warning logs.
- Logs record event/tenant context, value type/length and a SHA-256 diagnostic digest; the raw provider value is never logged.

## Release governance
- Release evidence now derives its date from the current UTC execution date.
- Implementation status distinguishes CI-only production-style gates from evidence that requires real staging/production infrastructure.
- Release-version tests no longer freeze a previous patch version.
