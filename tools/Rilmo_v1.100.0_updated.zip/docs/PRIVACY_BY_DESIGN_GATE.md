# Rilmo Privacy by Design Gate

A feature cannot enter production unless its design records answers to all of the following:

1. Data required.
2. Purpose.
3. Minimization alternative considered.
4. Storage location.
5. Retention period.
6. Roles and services with access.
7. Third-party recipients.
8. International transfer assessment.
9. Lawful basis / consent decision.
10. User correction/deletion path.
11. Breach impact and containment path.

## Mandatory implementation rules

- KYC raw identity documents and raw biometric templates are not persisted in Rilmo by default.
- Support, merchant admins and platform super admins have no raw-KYC read route.
- Exceptional access requires a compliance role, MFA, a specific case, purpose, ticket reference, short time window and an immutable audit event.
- Logs must never contain document numbers, document images, biometric material, raw KYC payloads or provider secrets.
- OAuth connected apps must use explicit least-privilege scopes and support revocation.
- Privacy incidents are tracked per jurisdiction so notification deadlines are not hardcoded globally.
- International transfers require an explicit processor, destination, mechanism and contract reference in the transfer register before production enablement.
