# Deep Audit — v1.34.0

This release was reviewed for authorization, tenant isolation, Host header handling, OTP storage, subscription activation, domain registration sequencing, public-store leakage, review authenticity, report escalation, SEO routing, frontend syntax, and migration integrity.

## High-value controls
1. Production merchant activation is blocked until merchant profile, phone, Google identity, platform verification and minimum trust score requirements are satisfied.
2. SaaS subscriptions remain pending until the external billing provider confirms payment in production.
3. Domain purchases remain `PENDING_PAYMENT`; registrar registration is deliberately deferred until payment capture.
4. Dynamic Host Trust accepts only configured platform hosts or verified Domain rows; no `*` wildcard is used in production.
5. Customer store reviews are separate from merchant reviews and can require completed-order proof.
6. OTPs are hashed at rest. Provider delivery does not persist plaintext codes in the Outbox.
7. Platform Trust Center endpoints require platform-admin MFA.
8. Abuse reports are rate-limited and escalated for human review rather than blindly auto-banning customers can be wrong; suspension remains an explicit privileged admin action.

## External credentials intentionally deferred
Google, SMS, Paddle, registrar API, object storage, SMTP, WhatsApp, and AI secrets are configuration inputs only. They must be injected at deployment time through environment variables or a secret manager.

## Verification result
175 tests passed, compile checks passed, and the custom-domain storefront root/product/robots/sitemap path was exercised through the application test client.
