# Unified Global Commerce v1.74.0

## Production deployment contract closure

- Removed duplicate `AI_ENABLED` entries from `docker-compose.production.yml`.
- Production API and worker services now require core legal metadata, public base URL, explicit host/proxy allowlists, and S3 credentials at Compose interpolation time.
- Local Compose version defaults are synchronized with `VERSION`.
- No provider, jurisdictional, security-test, or external infrastructure evidence is represented as complete unless it was actually executed.
