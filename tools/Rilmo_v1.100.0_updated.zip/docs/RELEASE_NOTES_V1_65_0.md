# v1.65.0 — Merchant Trust & Buyer Protection

- KYB fields and mandatory business verification before storefront publication.
- Payment account configuration is pending-only until provider onboarding/verification enables charges and payouts.
- Customer cancellation before merchant acceptance can trigger an idempotent provider void/refund and records a buyer-protection issue.
- Order issues provide a tenant-scoped channel for customer/merchant resolution and escalation.
- Raw KYB evidence is never stored; only a verification reference hash is retained.
