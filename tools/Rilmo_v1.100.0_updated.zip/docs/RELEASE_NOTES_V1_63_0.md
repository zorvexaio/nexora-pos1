# Release Notes v1.63.0

- Adds fail-closed `scripts/production_preflight.py`.
- Adds `docs/PRODUCTION_LAUNCH_PACK_V1_63.md`.
- Adds `docs/EXTERNAL_EVIDENCE_REGISTER_V1_63.md`.
- Adds a dedicated GitHub Actions production-preflight workflow using repository/environment secrets.
- Makes release version consistent across `VERSION`, `.env.example`, Compose defaults and README.
- Keeps local Ollama as default zero-paid-API AI mode.
- Keeps Rilmo card-installment price delta at zero.
- Adds regression coverage for the new production-launch contract.
