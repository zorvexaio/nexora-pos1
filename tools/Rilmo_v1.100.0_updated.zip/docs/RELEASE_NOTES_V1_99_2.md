# v1.99.3 — Customer Intelligence & Currency-Safe RFM

## Product depth
- Added merchant customer-intelligence analytics with deterministic RFM-style segments.
- Added repeat-customer rate and top-customer ranking.
- Monetary metrics remain partitioned by currency; no fabricated FX conversion is performed.
- Successful/completed refunds reduce customer net spend only when their currency matches the originating order currency.
- Currency mismatches are excluded and reported as an integrity signal.

## Verification
- Customer-intelligence + event-driven automation regression suite: 6/6 PASS.
- Full release gates are run during artifact construction.
