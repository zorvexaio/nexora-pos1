# v1.68.0 — Governed AI Agent Architecture

## Delivered

- Tenant-scoped AI policy and daily usage accounting.
- Customer/merchant/platform role separation with allowlisted read tools.
- AI is proposal-only: no payment, refund, cancellation, price, shipping-charge, inventory-write, KYC, raw-payment, credential or secret tools.
- Internal Ollama remains the zero-paid-API default; external AI remains opt-in at platform policy level.
- Deterministic rules fallback remains available when AI is disabled, unavailable or unconfigured.
- External providers cannot receive personal/order context unless both platform and tenant privacy flags permit it.
- Policy changes and Agent executions are audit logged.

## Migration

`20260820_0056_governed_ai_agents` follows `20260820_0055`.
