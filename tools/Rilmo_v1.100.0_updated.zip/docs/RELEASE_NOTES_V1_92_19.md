# Unified Global Commerce v1.92.19

## Toolchain hardening

- Updated the development/test `pytest` pin to `9.1.1`, the current stable release verified on PyPI as of August 2026.
- Kept `pytest-asyncio` at `1.4.0`, the current stable release verified on PyPI.
- Application runtime dependencies are unchanged.
- No database migration is introduced; canonical Alembic head remains `20260822_0064`.
- The CI migration-head assertion remains revision-agnostic and cannot silently drift to an old hard-coded revision.

## Verification boundary

- The release workspace cannot download packages because outbound package-network access is disabled, so this environment cannot independently reinstall and execute the suite under `pytest 9.1.1`.
- The existing v1.92.17 application suite evidence remains valid for unchanged runtime code; CI must install the new development pins before claiming the refreshed toolchain as fully executed.
