# Unified Global Commerce — v1.95.2

## Security closure
- Added a PostgreSQL RLS closure migration for sensitive tenant-scoped customer-account, merchant-trust, domain-commerce, and buyer-protection tables.
- `order_issues` and `order_issue_messages` are now explicitly covered by tenant `ENABLE + FORCE RLS` policies.
- Removed the architectural dependency on a silently ignored RLS setup failure for the buyer-protection conversation path by reasserting the policy in the new migration.
- Customer session resolution now binds the PostgreSQL tenant context **before** reading the tenant-scoped session row.

## Evidence integrity
- Kept local verification claims separate from external PostgreSQL/runtime evidence.
- Full production certification remains blocked until a real PostgreSQL role/RLS smoke test and provider sandbox evidence are executed.
