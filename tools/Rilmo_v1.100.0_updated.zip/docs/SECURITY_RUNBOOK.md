# P0 Security Runbook — v1.8

## Controls implemented in the repository

- Server-side sessions: hashed bearer tokens, idle timeout, absolute lifetime, logout revocation.
- Browser CSRF boundary: cookie-authenticated mutations require CSRF token + trusted Origin.
- Authentication rate limits: register, login, password-reset request/confirm use PostgreSQL/SQLite-backed counters.
- Webhook HMAC verification is performed on the raw request body before JSON parsing.
- Domain verification uses single-use expiring token hashes and blocks reserved hostnames.
- SSRF policy rejects non-http(s), loopback, private/link-local, metadata targets and validates resolved DNS targets.
- Upload policy rejects active content and oversized payloads before promotion.
- Audit JSON is canonicalized and append-only at the application contract level.
- RLS hardening migration enables and forces RLS on tenant-scoped tables.
- Ledger rows are protected from runtime UPDATE/DELETE by PostgreSQL privilege revocation.
- Outbox worker uses bounded attempts, backoff and DLQ semantics.

## Staging requirements still external to this archive

1. Verify PostgreSQL role ownership/BYPASSRLS and RLS policies with real credentials.
2. Run Paddle MoR subscription sandbox with real signature and replay scenarios, plus iyzico/PayTR merchant-owned payment webhooks.
3. Exercise DNS verification/takeover tests against a controlled domain.
4. Run object storage malware/polyglot/size tests against the deployment storage provider.
5. Execute backup/restore drill and measure SLOs under representative load.
6. Execute T1–T20 regression suite in CI/staging.

## RLS Bypass Rule

Never use a client-settable GUC as an authorization bypass. `app.worker` and `app.allow_unscoped_ingest` are deprecated. Tenant workers must iterate tenant IDs and call `SET LOCAL app.current_tenant` inside each transaction. Unresolved provider webhooks must enter `provider_ingest_events` quarantine and be resolved later.
