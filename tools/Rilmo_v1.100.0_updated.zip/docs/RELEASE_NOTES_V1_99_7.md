# v1.99.7 — Experiment Outcome Intelligence

Adds durable experiment observations, idempotent outcome capture, and variant-level experiment results with tenant isolation and PostgreSQL FORCE RLS.

Evidence:
- Focused experiment tests: 3/3 PASS
- Observation rows are bound to durable assignments.
- Duplicate subject/metric observations are rejected idempotently.
- Result reporting is variant-separated and bounded by a selectable time window.
- No cross-currency aggregation is introduced by experiment reporting.
