# KYC / Identity Data Boundary

Rilmo stores verification metadata only: provider, verification reference, status, risk state and timestamps. Raw passport/ID images, selfie images and biometric templates are not stored in Rilmo by default.

The frontend never receives raw KYC material. Support and merchant-facing APIs expose only status and masked operational identifiers.

Exceptional human access is not an "admin can view everything" capability. It is a short-lived compliance grant tied to one merchant, one verification, one review case, one reason and one ticket. The grant itself is audited. The underlying identity material remains with the contracted KYC provider.
