# Deep Security Audit — v1.32.0

This release was reviewed against OWASP API Security Top 10 and OWASP ASVS 5.0 principles.

## Closed in this release

1. MFA bypass at login: fixed with a single-use, expiring login challenge.
2. Distributed password spraying: login throttling now combines IP and account identity.
3. Secret-key coupling: application secret encryption now supports a dedicated encryption key.
4. Production wildcard CORS/host configuration: rejected at startup.
5. Insecure public base URL in production: rejected at startup.
6. Chunked request-body limit bypass: actual ASGI request stream is capped.

## Residual production controls

No software can honestly guarantee that a system is impossible to compromise. Production still requires independent penetration testing, infrastructure hardening, secret management, egress controls, WAF/DDoS protection, database/RLS verification on PostgreSQL, backup/restore testing, dependency scanning, and continuous monitoring.
