# Unified Global Commerce v1.92.20

## Security dependency refresh

- Upgraded `cryptography` from 49.0.0 to 50.0.0.
- This closes CVE-2026-69247, which affects `cryptography` versions >=44.0.0 and <50.0.0.
- The dependency remains explicitly pinned for reproducible builds.
- No application schema migration is introduced.
- Existing SSRF, tenant-isolation, payment, webhook, and release-control hardening is retained.

## Verification rule

The release must not be considered fully certified until CI installs the pinned dependency set and executes the complete test/security/release gates under that environment.
