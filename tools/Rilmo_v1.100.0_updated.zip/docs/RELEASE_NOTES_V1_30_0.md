# Release Notes — v1.30.0

v1.30.0 is the Growth + AI expansion built on the verified Unified Global Commerce v1.20.0 SaaS architecture.

## Highlights

- AI product copy generation, SEO copy and merchant assistant.
- Optional AI reranking for natural-language storefront search.
- Live merchant and platform analytics.
- WhatsApp channel, webhooks, transactional automation and opt-in abandoned carts.
- Landing-page CMS with safe public rendering.
- Affiliate attribution and commission lifecycle.
- Read-only support impersonation.
- Monthly platform KPI reporting.
- Responsive PWA merchant console and mobile-first storefront.

## Compatibility

Existing v1.20.0 SaaS billing, merchant-owned checkout, inventory, tax, shipping, loyalty, reviews, support, apps/OAuth and security controls remain in place.

## Verification

- 162 tests passing.
- 173 unique API method/path declarations.
- 138 ORM tables / 74 structurally tenant-scoped RLS tables.
- Clean migration upgrade/downgrade/re-upgrade.
- Release, frontend, specification and schema audits passing.
- Seeded Uvicorn local smoke test passing.

## Production configuration still required

Real payment provider credentials, PostgreSQL/RLS staging evidence, Redis/object storage, Meta WhatsApp Business verification and approved templates, OpenAI credentials/budget policy, backup/restore, load testing, DNS/domain verification and legal/accounting approvals must be completed in the actual deployment environment.
