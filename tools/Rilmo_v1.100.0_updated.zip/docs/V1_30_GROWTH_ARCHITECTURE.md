# Unified Global Commerce v1.30.0 — Growth Architecture

## Goal

v1.30.0 turns the verified SaaS commerce kernel into a modern commerce operating system without replacing the existing tenant, billing, checkout, inventory, tax, app, support or security foundations.

## Product layers

```text
Merchant Console
  ├─ Catalog / Orders / Inventory / Customers
  ├─ AI Studio / Assistant / Intent-aware Search
  ├─ WhatsApp / Landing Pages / Affiliate
  └─ Analytics / Support / Apps / Billing / Security

Public Storefront
  ├─ Mobile-first responsive UI
  ├─ Catalog + localized search
  ├─ Live behavioral events
  └─ Guest cart / checkout

Application Core
  ├─ FastAPI routes + tenant isolation
  ├─ Session/RBAC/MFA controls
  ├─ Outbox worker + automation
  └─ Audit trail

Data Layer
  ├─ PostgreSQL production target
  ├─ Redis runtime target
  ├─ Object storage abstraction
  └─ Alembic migration contract
```

## AI

### Product content

`POST /v1/ai/products/{product_id}/generate` builds a bounded product prompt containing only merchant-supplied facts, requests structured JSON from the configured Responses API provider, validates the JSON shape, records the generation and optionally applies the safe fields back to the catalog. When no provider key is configured, a deterministic local copy engine keeps the UI useful instead of returning fake provider success.

### Merchant assistant

`POST /v1/ai/assistant` receives a bounded question and a tenant-scoped catalog sample. The model is explicitly instructed not to invent order, policy or catalog facts. Without a provider key, token-overlap recommendations remain available.

### Intent-aware search

The storefront search endpoint uses the hybrid search service. Exact lexical matches remain first-class, translated fields participate when a locale is supplied, and an optional AI reranker can rank a bounded candidate set for natural-language intent. This is deliberately an AI reranking layer rather than a claim of a hosted vector database or embeddings index.

## WhatsApp Commerce

Tenant tokens and app secrets are encrypted at rest. Webhook verification uses the Meta challenge/verify-token flow and inbound webhook signatures are checked with HMAC-SHA256 whenever an app secret is configured.

Business-initiated messages in production require an approved template name. Development can use plain text for smoke testing. Order-confirmed, shipped and abandoned-cart automations are emitted by the outbox worker so the HTTP request path is not responsible for external delivery.

## Live analytics

The storefront emits an allow-listed event taxonomy. Visitor identity is stored only as a hash. Merchant live view is scoped to one tenant; platform live view aggregates active merchants without exposing raw visitor identifiers.

## Landing pages

Landing pages are tenant-scoped, slug-constrained, editable, publishable and SEO-aware. The public HTML route escapes every user-controlled field before rendering.

## Affiliate attribution

The flow is:

```text
Affiliate link → hashed/guest visitor → referral → cart/order → payment capture → commission approval
```

The partner code cookie is issued on the actual redirect response, eliminating the common bug where a cookie is accidentally written to an unused response object.

## Impersonation

Platform support can issue a short-lived, read-only merchant session with a mandatory reason. The session carries an explicit impersonator identity and the common authentication dependency blocks POST/PATCH/PUT/DELETE mutations. Ending the session revokes the session and closes the audit record.

## External systems

The code intentionally keeps provider settings injectable. Production requires actual provider credentials and approvals. No provider success is faked in production mode.

## Validation

The release was validated with the existing 162-test suite, release/frontend/spec/schema audits, clean SQLite migration upgrade/downgrade/re-upgrade, a seeded Uvicorn runtime smoke test, and the route registry contract.
