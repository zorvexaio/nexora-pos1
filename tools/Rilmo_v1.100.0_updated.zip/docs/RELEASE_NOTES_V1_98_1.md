# Unified Global Commerce v1.98.1

## Inventory location integrity

- Checkout no longer silently selects the first inventory row when a variant exists at multiple inventory locations.
- Checkout accepts `inventory_location_id`; ambiguous physical inventory now fails closed with `INVENTORY_LOCATION_REQUIRED`.
- An explicitly requested checkout inventory location must contain the variant inventory row; otherwise checkout returns `INVENTORY_LOCATION_INVALID`.
- Inventory reservation now accepts `location_id` and binds that location into the idempotency request hash.
- Reservation now fails closed when a variant has multiple inventory locations and no location was supplied.
- Existing location-aware inventory adjustment protection remains intact.

## Evidence

- Added `tests/test_v1981_inventory_location_integrity.py` for the new contract and regression guards.
- Version: `1.98.1`.
