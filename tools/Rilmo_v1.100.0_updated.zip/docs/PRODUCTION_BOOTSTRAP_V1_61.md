# Production Bootstrap v1.61

1. Copy `.env.example` to an untracked production secret store/template.
2. Generate `SECRET_KEY`, `ENCRYPTION_KEY`, and `WEBHOOK_SECRET` with `python scripts/generate_production_secrets.py`.
3. Configure PostgreSQL, Redis, object storage, SMTP, KYC, OAuth, payment and market-specific credentials.
4. Keep `AI_PROVIDER=ollama` and `AI_EXTERNAL_PROVIDER_ALLOWED=false` if zero paid AI API spend is required.
5. Keep `CARD_INSTALLMENT_SAME_PRICE_ONLY=true`.
6. Keep `MEDIA_SCAN_REQUIRED=true` in production; ClamAV is internal-only.
7. Run `alembic upgrade head` before starting API/worker.
8. Run the full test suite and release hygiene gate.
9. Run backup/restore rehearsal and load/SLO tests in staging.
10. Obtain independent security testing and market-specific legal/payment approvals before public launch.

The repository provides infrastructure wiring and fail-closed validation, but credentials, contracts, licenses and regulatory approvals remain deployment-time inputs.
