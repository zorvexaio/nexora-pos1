# v1.99.8 — Migration Chain & Workflow Idempotency Hardening

## Critical fixes
- Corrected Alembic migration `20260909_0071_workflow_event_source.py` to reference the real revision `20260909_0070` instead of the non-existent `0070`.
- Preserved the durable workflow source-event uniqueness constraint.
- Added regression coverage for the complete 0070 → 0071 → 0072 migration chain.
- Strengthened workflow event processing regression coverage against duplicate queue emission and recursive `workflow.run.queued` triggering.

## Verification
- Targeted workflow/migration regression suite: 32/32 passed.
- Full-suite execution was started but the current execution environment timed out before completion; no full-suite PASS claim is made for this release.
