# External Evidence Register v1.63.0

| Gate | Required evidence | Status in source release |
|---|---|---|
| Production PostgreSQL/RLS | Deployed service-role privileges, FORCE RLS, tenant isolation smoke | EXTERNAL |
| Payment provider | Contracted account, signed webhook replay, capture/refund/reconciliation evidence | EXTERNAL |
| Tax/e-invoicing | Market-specific provider certification/credentials | EXTERNAL |
| DNS | Production ownership and takeover test | EXTERNAL |
| Malware | Real malicious corpus + object-storage lifecycle evidence | EXTERNAL |
| Load/SLO | Deployed topology load, concurrency, latency, failover | EXTERNAL |
| DR | Backup restore rehearsal with measured RTO/RPO | EXTERNAL |
| Pentest | Independent third-party security assessment | EXTERNAL |
| Privacy/legal | Controller/processor mapping, notices, DPA/subprocessors, jurisdiction review | EXTERNAL |
| Apple | App review/approval for each submitted build and market | EXTERNAL |
| Google | Play review/approval for each submitted build and market | EXTERNAL |

Do not change `EXTERNAL` to `PASS` without evidence attached to the release record.
