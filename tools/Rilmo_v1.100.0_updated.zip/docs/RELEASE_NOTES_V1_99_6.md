# v1.99.6 — Merchant Decision Action Lifecycle

## Purpose
Persist high-value merchant decisions so recommendations can be accepted, dismissed, completed, and measured without mutating commerce data automatically.

## Changes
- Added `merchant_decision_actions` with tenant isolation and durable decision keys.
- Added lifecycle states: `OPEN -> ACCEPTED -> COMPLETED` and `OPEN/ACCEPTED -> DISMISSED`.
- Terminal states cannot be reopened through the API.
- Added expected vs actual impact fields and outcome notes.
- Added tenant-scoped list/create/update APIs.
- Creation is race-safe through a nested transaction and unique `(tenant_id, decision_key)` constraint.
- Updates lock the action row with `FOR UPDATE`.
- All mutations create audit events.
- PostgreSQL ENABLE + FORCE RLS is included in migration 0072.

## Safety
The lifecycle records decisions and outcomes; it does not automatically alter prices, payments, inventory, orders, or customer data.
