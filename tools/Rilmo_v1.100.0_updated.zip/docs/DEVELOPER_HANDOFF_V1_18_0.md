# Developer Handoff — Unified Global Commerce v1.18.0

## Release purpose
This artifact is the clean engineering release candidate. It removes local runtime artifacts and carries only source, migrations, tests, scripts, deployment config, and current release evidence.

## Verified
- `pytest -q -W error`: 152 passed.
- Alembic 0029 upgrade/downgrade/re-upgrade: PASS.
- Route registry: 172 unique METHOD+PATH declarations.
- Schema: 83/83 canonical v1.8 tables mapped.
- RLS structural audit: 74 tenant-scoped tables.
- i18n: 13 locales / 77 shared keys.
- Release hygiene: no `.db`, `.sqlite*`, `.pyc`, `__pycache__`, `.pytest_cache`, or developer runtime state.

## Important implementation facts
- SQLAlchemy is the runtime ORM. `prisma/schema.prisma` is only a documentation/schema mirror.
- `MockProvider` exists only for automated tests and is rejected outside `ENVIRONMENT=test`.
- PayTR refund uses the provider's documented refund endpoint and HMAC token construction. PayTR cancellation/void is intentionally reported as unsupported because the documented flow finalizes payment through the callback; do not convert that into a fake provider success.
- Shipping uses a concrete `FlatRateCarrier` and a concrete `ConfiguredCarrier` for deployment-supplied provider API maps. Named carrier codes are configuration aliases, not proof of production credentials or certification.

## External staging gates
Do not mark these as PASS until evidence is attached:
- Postgres production RLS/privileges
- Stripe/Tabby/Tamara/iyzico/PayTR sandbox flows and webhook replay
- GİB/e-Fatura onboarding/certification
- Turkish carrier credentials and real shipment lifecycle
- DNS takeover
- ClamAV + malicious corpus
- backup/restore
- load/SLO
- deployed T1-T20
