# Local Release Evidence — v1.55.0

Date: 2026-08-19

## Verified locally
- `pytest -q -W error`: **268 passed**
- `final_release_audit.py`: PASS
- `spec_audit.py`: PASS — 185 ORM tables, 88 RLS tables, 296 unique route declarations
- `spec_schema_audit.py`: PASS — 83/83 canonical schema tables mapped
- `frontend_audit.py`: PASS
- Node syntax checks for frontend entrypoints: PASS
- `security_gate.py`: PASS
- `dependency_audit.py`: PASS
- `regulatory_readiness_audit.py`: PASS — 16/16
- Alembic `upgrade head -> downgrade base -> upgrade head`: PASS on SQLite
- `live_runtime_gate.py`: PASS — storefront/order/payment smoke path
- SBOM generated from the release tree

## Environment-dependent gates not claimed locally
- Production PostgreSQL role/privilege and live RLS evidence
- Real iyzico/PayTR/Paddle sandbox and webhook replay evidence
- Production DNS ownership/takeover test
- Real ClamAV/object-storage malicious corpus lifecycle evidence
- Load/concurrency/SLO/failover evidence
- Deployed T1–T20 regression evidence
- Independent penetration test / external security assessment
- Jurisdiction-specific legal/controller-processor review
- Official EU DPP Registry onboarding/conformance evidence

These are intentionally not converted into local PASS results.
