# v1.70.0 — Fail-Closed AI + Global Production Hardening

## Delivered

- All merchant AI entry points are tenant-policy and quota governed.
- Product-copy generation cannot call an AI provider when tenant AI is disabled; it falls back deterministically to rules-only generation.
- Merchant assistant now uses the governed Merchant Agent path instead of the legacy ungoverned assistant path.
- Public Customer AI excludes order payment status, order totals and other financial fields from model context; it retains only order-tracking information needed for support.
- External AI providers never receive internal product database identifiers by default.
- Merchant recommendations returned by AI are constrained to tenant-owned catalog identifiers.
- Customer-facing AI search reranking is controlled by the Customer Agent policy and daily quota.
- A deny-by-default read-only Agent Tool Registry is now the explicit capability boundary.
- AI quota row creation is concurrency-safe against duplicate daily rows.
- Migration `20260820_0056` no longer suppresses PostgreSQL RLS errors; PostgreSQL RLS setup is fail-closed while non-PostgreSQL test databases skip PostgreSQL-specific DDL intentionally.
- AI is now fail-closed at the application configuration layer (`AI_ENABLED=false`).
- Ollama/model-init services are explicitly isolated behind the optional `ai` Compose profile; disabling AI therefore does not require model download or model-serving containers.
- AI policy bootstrap is race-safe when multiple first requests create the tenant policy concurrently.
- Test configuration explicitly enables AI only for AI integration coverage; production defaults remain disabled.

## Global readiness controls

The platform continues to distinguish software readiness from external certification. Current engineering controls are aligned to current public reference points including ISO 3166 country codes, ISO 4217 currency codes, ISO 639 language codes, RFC 9457 problem-detail conventions, WCAG 2.2, PCI DSS v4.0.1, GDPR transfer controls/SCCs, and NIST AI RMF / Generative AI Profile. These references do not constitute legal certification.

## Verification

- Governed AI suite: **9+ passed**.
- AI security/regression suites: **13 passed** in the execution environment.
- Python compile gate: **PASS**.
- Static release/security/schema/frontend/regulatory gates: **PASS** after artifact cleanup.
- Complete production-grade validation still requires the external staging/evidence gates listed in `docs/PRODUCTION_EVIDENCE_GATES.md`.
