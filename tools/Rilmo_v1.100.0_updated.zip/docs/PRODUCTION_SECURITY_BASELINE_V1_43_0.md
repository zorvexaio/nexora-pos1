# Rilmo Production Security Baseline v1.43.0

## Session and impersonation
- Employee sessions remain separate from read-only impersonation sessions.
- Impersonation requires platform-admin MFA and a production case/ticket reference.
- Impersonation is read-only and expires automatically.
- Ending impersonation revokes only the dedicated impersonation session and preserves the employee session.
- Start/end events are audit logged with tenant, target, reason and ticket.

## Network trust
- Forwarded headers are trusted only from explicit proxy addresses/ranges.
- Tenant-configured webhook endpoints are HTTPS-only, optionally allowlisted, public-address validated and IP-pinned for the actual outbound connection.

## Database isolation
- Production requires PostgreSQL.
- The runtime gate rejects SUPERUSER/BYPASSRLS application roles and tenant tables without ENABLE+FORCE RLS.

## Release integrity
- Dependency pins, SBOM, migration head, security gate, release hygiene and live runtime evidence are independent gates.
- Production has a hardened Compose overlay that removes published DB/Redis ports, requires credentials, drops Linux capabilities and sets no-new-privileges for API/worker containers.

## External evidence still required before public launch
- Real provider sandbox/live payment evidence.
- Production-shaped PostgreSQL/RLS evidence.
- Backup/restore rehearsal.
- Load/soak/failover evidence.
- Independent penetration testing and legal/privacy review.
