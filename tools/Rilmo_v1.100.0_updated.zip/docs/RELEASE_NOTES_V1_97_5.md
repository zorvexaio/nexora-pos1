# Unified Global Commerce v1.97.5

## Deep financial-state hardening

- Hardened replay handling for provider capture events.
- A replayed capture reference is now observationally idempotent: it recomputes durable capture totals before deriving the payment state.
- A replay of a partial capture can no longer incorrectly promote the payment intent to `CAPTURED`.
- Added a defensive invariant: recorded provider captures exceeding the immutable payment intent amount are treated as financial-state corruption rather than silently accepted.
- Added regression coverage for the replay/state-promotion boundary.

## Evidence

- Payment concurrency guard + iyzico webhook regression suite: 13/13 PASS.
- Full production-readiness status remains evidence-bounded: PostgreSQL/RLS concurrency, real provider E2E, load/failover, and backup/restore still require their respective staging environments.
