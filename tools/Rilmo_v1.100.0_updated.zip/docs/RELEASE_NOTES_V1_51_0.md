# Rilmo / Unified Global Commerce v1.51.0

## Global Control Plane
- AI Agent Governance: scoped agent profiles, per-agent rate limiting, idempotency, immutable action audits, and public policy disclosure without secrets.
- UCP checkout completion can bind to an explicit agent identity and requires an `Idempotency-Key` when agent credentials are used.
- Data residency control plane: explicit home region, approved regions, residency mode, and cross-border transfer basis.
- Financial reconciliation: period-based reconciliation of payment captures against double-entry ledger totals and per-payment journal references, with mismatch records.
- Tenant-owned RLS applied at migration time with ENABLE + FORCE ROW LEVEL SECURITY.
- Control-plane health endpoint exposes safe operational counters without secrets.

## Safety
- New controls are fail-closed and tenant-scoped.
- No public Agent policy endpoint exposes credentials, access tokens, or secrets.
- Reconciliation is deterministic and idempotent for the same tenant/period/currency.
