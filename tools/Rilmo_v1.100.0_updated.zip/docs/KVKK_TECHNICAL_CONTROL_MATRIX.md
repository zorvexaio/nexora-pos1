# KVKK Technical Control Matrix

| Control | Rilmo enforcement |
|---|---|
| Data minimization | Metadata-only KYC boundary; raw documents not persisted by default |
| Special-category protection | Separate KYC path, provider boundary, no generic API serialization |
| Least privilege | Permission-based tenant access + dedicated compliance-officer role |
| Exceptional access | Case-bound time-limited access grant + audit event |
| International transfers | Privacy transfer register with destination/mechanism/contract reference |
| Data subject rights | Privacy center + access/rectification/erasure/restriction/objection/portability request pipeline |
| Breach response | Privacy incident model with jurisdiction-aware notification due date |
| Logging | Sensitive field deny-list and hashed network identifiers for privacy events |
| Connected apps | Explicit OAuth scopes, installation view, last-used timestamp, revoke endpoint |
| Authentication | MFA required for platform compliance role |


## Current international-transfer execution control (July 2026)

Rilmo must not mark a cross-border processor route as production-approved merely because a “DPA” exists. The transfer register must identify the applicable KVKK mechanism, the contract/reference, signatory authority evidence, signature completion, and regulatory notification evidence where required. The KVKK public notice dated 27 July 2026 states that standard contracts must be signed by authorized representatives and that supporting evidence of signatory authority is part of the submission package. The system therefore treats transfer approval as a governance gate, not a documentation checkbox.
