# Unified Global Commerce Platform Specification
## Engineering Blueprint v1.7 — Deep Consistency, Security & Launch Closure

> **Status:** Final engineering baseline for P0 implementation — v1.7 is the normative launch baseline and supersedes conflicting v1.6 wording by closing remaining schema, security, transaction, billing, tenancy, and launch-stack inconsistencies.
> **Target:** Global multi-tenant SaaS commerce platform, Arabic-first at launch (+ English/Turkish), expanding globally
> **Architecture:** Modular Monolith + Event-Driven Async Processing (Starter Stack permitted at launch — see §55.1)
> **Primary DB:** PostgreSQL
> **ORM:** Prisma (+ PgBouncer once load requires it — see §55.1)
> **Cache/Queue:** Redis + BullMQ (Postgres-based outbox + rate-limit counters acceptable at launch — see §55.1, §34.1)
> **Search:** Postgres Full-Text Search at launch → Meilisearch / provider abstraction at scale
> **Storage:** R2/S3 + CDN
> **Payments:** Stripe Connect (merchant commerce, §64.2) + Stripe Billing (platform subscription, §64.1) — explicitly separated
> **Security boundary:** Application authorization + PostgreSQL RLS + explicit Platform Admin domain (§64.11)
> **Consistency:** Strong for financial/critical state; eventual for derived systems
>
> **v1.7 core change:** §64 is retained and hardened; §66 adds the normative deep-audit corrections and earlier sections are aligned so P0 is internally consistent, executable, and launchable without inventing critical architecture decisions. It preserves executable SQL DDL + invariants for every feature moved into P0 and adds the remaining security, transaction, and operational closures: Billing/Plans/Entitlements, Wishlist/Reviews/Q&A, Coupon concurrency, Order Tracking, Domain Provisioning, Merchant Onboarding, Storefront Publishing State, Platform Admin domain, API Endpoint Inventory, Canonical Event Catalog, and Transaction Boundary Matrix. This closes all 10 critical gaps identified by independent review; nothing in P0 scope requires the implementation team to invent architecture decisions.

---

# 0. Executive Position

هذه الوثيقة هي النسخة التنفيذية النهائية المبنية على v1.1. وهي لا تستبدل المعمارية السابقة؛ بل تحولها إلى:

1. **P0 Database Schema**
2. **Relationships / Foreign Keys**
3. **Indexes and Constraints**
4. **RLS Strategy**
5. **Money / Ledger / Inventory invariants**
6. **API and idempotency contracts**
7. **Outbox / webhook / DLQ contracts**
8. **P0 implementation checklist**
9. **Executable acceptance criteria**
10. **Release Gates**
11. **Definition of Done**

المبدأ الحاكم:

```text
Source of Truth
      ↓
Domain Invariants
      ↓
Transactional Mutation
      ↓
Outbox
      ↓
Async Workers
      ↓
Derived Systems
```

ولا يجوز بناء P1/P2 على حساب سلامة P0.

---

# 1. Architecture Principles

## 1.1 Core Principles

- PostgreSQL هو مصدر الحقيقة للبيانات التجارية والمالية الحرجة.
- Redis ليس مصدر الحقيقة للمال أو المخزون أو الحالات الدائمة.
- Financial records append-only.
- Money يستخدم integer minor units مع currency explicit.
- Tenant isolation خاصية للنظام كله، وليس مجرد `tenant_id`.
- Modular Monolith أولاً.
- Microservices فقط عند وجود bottleneck أو boundary تشغيلي واضح.
- Idempotency لكل mutation غير idempotent بطبيعتها.
- Search / Cache / Analytics قابلة لإعادة البناء.
- جميع العمليات الحرجة لها Acceptance Criteria قابلة للاختبار.
- لا توجد ثقة في totals أو tenant IDs القادمة من العميل.
- External provider state eventually consistent مع reconciliation داخلي.

## 1.2 Control Plane / Data Plane

```text
CONTROL PLANE
- Tenants
- Users / Memberships
- Plans / Billing
- Entitlements
- Feature Flags
- Domains
- Compliance
- Audit
- KYC/KYB
- Platform configuration

DATA PLANE
- Storefronts
- Catalog
- Pricing
- Cart
- Checkout
- Orders
- Payments
- Inventory
- Customers
- Shipping
- Returns
```

لا تمنح عمليات Control Plane وصولاً ضمنياً إلى Data Plane.

---

# 2. Source of Truth Matrix

| Domain | Source of Truth | Consistency | Derived |
|---|---|---|---|
| Tenant/Auth | PostgreSQL | Strong | Sessions |
| Orders | PostgreSQL | Strong | Search/Analytics |
| Inventory | PostgreSQL | Strong | Redis cache |
| Ledger | Journal Lines in PostgreSQL | Strong | Balance projections |
| Payments | Internal payment records + provider | Strong internal / eventual external | Reconciliation |
| Catalog | PostgreSQL | Strong internal / eventual index | Search |
| Cart | Redis for guest; PostgreSQL for persistent | Transactional | Cache |
| Search | Provider index | Eventual | Rebuildable |
| Media metadata | PostgreSQL | Strong | CDN/object storage |
| Media bytes | R2/S3 | Strong object persistence / eventual CDN | CDN |
| Outbox | PostgreSQL | Strong persistence | Queue |
| Analytics | Aggregated/OLAP | Eventual | Dashboard cache |
| Notifications | Queue/provider | Eventual | Delivery status |

---

# 3. P0 Domain Model

## 3.1 Identity / Tenant

```text
User
Tenant
TenantMembership
Role
Permission
RolePermission
Session
MFAFactor
RecoveryCode
AuditEvent
```

## 3.2 Commerce

```text
Storefront
Domain
Product
ProductTranslation
ProductVariant
ProductOption
ProductOptionValue
ProductVariantOptionValue
Category
ProductCategory
ProductMedia
ProductSEO
Price
PriceList
Promotion
Coupon
DiscountApplication
```

## 3.3 Customer / Cart / Order

```text
Customer
CustomerAddress
Cart
CartItem
Order
OrderItem
OrderAddress
OrderStatusHistory
```

## 3.4 Payments / Finance

```text
PaymentIntent
PaymentAttempt
PaymentCapture
Refund
ProviderEvent
ReconciliationRecord
LedgerAccount
JournalEntry
JournalLine
Settlement
Payout
FinancialTransaction
```

## 3.5 Inventory

```text
InventoryLocation
InventoryItem
InventoryReservation
InventoryAdjustment
```

## 3.5.1 P0 Commercial/Operational Entities

```text
RecoveryCode
PriceList
ProductSEO
ShippingMethod
TaxRate
MerchantPaymentAccount
InventoryAdjustment
ReconciliationRecord
Settlement
Payout
FinancialTransaction
ConsentRecord
CouponRedemption
DiscountApplication
OrderTrackingReference
```

## 3.6 Infrastructure

```text
IdempotencyKey
OutboxEvent
DeadLetterEvent
WebhookEvent
MediaAsset
TaxJurisdiction
TaxClass
TaxLine
TaxCalculation
```

---

# 4. PostgreSQL Schema — P0

> الأسماء التالية هي canonical logical schema. يمكن تعديل أسماء Prisma models، لكن لا يجوز تغيير العلاقات أو invariants دون مراجعة معمارية.

## 4.1 Tenants

```sql
CREATE TABLE tenants (
  id UUID PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  status TEXT NOT NULL,
  default_currency CHAR(3) NOT NULL,
  default_locale TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

Allowed status:

```text
PROVISIONING
ACTIVE
SUSPENDED
CLOSED
```

Indexes:

```sql
CREATE INDEX idx_tenants_status ON tenants(status);
CREATE INDEX idx_tenants_created_at ON tenants(created_at);
```

---

# 5. Users / Memberships / RBAC

## 5.1 Users

```sql
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email CITEXT NOT NULL UNIQUE,
  password_hash TEXT,
  display_name TEXT,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 5.2 Membership

```sql
CREATE TABLE tenant_memberships (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  user_id UUID NOT NULL REFERENCES users(id),
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id)
);
```

```sql
CREATE INDEX idx_memberships_tenant ON tenant_memberships(tenant_id);
CREATE INDEX idx_memberships_user ON tenant_memberships(user_id);
```

## 5.3 Roles

```sql
CREATE TABLE roles (
  id UUID PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id),
  name TEXT NOT NULL,
  system_role BOOLEAN NOT NULL DEFAULT false,
  UNIQUE (tenant_id, name)
);
```

## 5.4 Permissions

```sql
CREATE TABLE permissions (
  id UUID PRIMARY KEY,
  code TEXT NOT NULL UNIQUE
);
```

## 5.5 Role Permissions

```sql
CREATE TABLE role_permissions (
  role_id UUID NOT NULL REFERENCES roles(id),
  permission_id UUID NOT NULL REFERENCES permissions(id),
  PRIMARY KEY (role_id, permission_id)
);
```

Required baseline permissions:

```text
products.read
products.write
orders.read
orders.manage
orders.cancel
orders.refund
inventory.read
inventory.write
finance.read
finance.manage
customers.read
customers.export
settings.manage
billing.manage
staff.manage
```

---

# 6. Session / MFA

```sql
CREATE TABLE sessions (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  tenant_id UUID REFERENCES tenants(id),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_tenant ON sessions(tenant_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);
```

MFA:

```sql
CREATE TABLE mfa_factors (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  type TEXT NOT NULL,
  secret_encrypted TEXT,
  credential_id TEXT,
  enabled BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

Privileged platform accounts MUST require MFA.

---

# 6.1 Password Reset Tokens

Password reset is a security-critical flow and therefore part of the P0 identity foundation.

```sql
CREATE TABLE password_reset_tokens (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_password_reset_user
ON password_reset_tokens(user_id);

CREATE INDEX idx_password_reset_expiry
ON password_reset_tokens(expires_at);
```

Rules:

```text
[ ] Token is stored only as a cryptographic hash
[ ] Token is single-use
[ ] Token expires after a short fixed TTL
[ ] Used/expired tokens are rejected
[ ] Successful reset revokes other active sessions
[ ] Reset email uses transactional email provider
```


# 7. Storefront / Domains

```sql
CREATE TABLE storefronts (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  slug TEXT NOT NULL,
  default_locale TEXT NOT NULL,
  default_currency CHAR(3) NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);

CREATE INDEX idx_storefronts_tenant ON storefronts(tenant_id);
```

```sql
CREATE TABLE domains (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  storefront_id UUID NOT NULL REFERENCES storefronts(id),
  hostname CITEXT NOT NULL UNIQUE,
  verified_at TIMESTAMPTZ,
  is_primary BOOLEAN NOT NULL DEFAULT false
);

CREATE INDEX idx_domains_tenant ON domains(tenant_id);
CREATE INDEX idx_domains_storefront ON domains(storefront_id);
```

---

# 8. Catalog

## 8.1 Products

```sql
CREATE TABLE products (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  storefront_id UUID REFERENCES storefronts(id),
  slug TEXT NOT NULL,
  status TEXT NOT NULL,
  product_type TEXT NOT NULL,
  deleted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

Slug uniqueness (excluding soft-deleted products):

```sql
CREATE UNIQUE INDEX uq_products_tenant_slug_active
ON products(tenant_id, slug)
WHERE deleted_at IS NULL;
```

Indexes:

```sql
CREATE INDEX idx_products_tenant_status
ON products(tenant_id, status);

CREATE INDEX idx_products_tenant_updated
ON products(tenant_id, updated_at);

CREATE INDEX idx_products_not_deleted
ON products(tenant_id, status)
WHERE deleted_at IS NULL;
```

Products may use soft delete. Orders and financial records MUST NOT.

## 8.2 Product translations

```sql
CREATE TABLE product_translations (
  id UUID PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES products(id),
  locale TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  seo_title TEXT,
  seo_description TEXT,
  UNIQUE(product_id, locale)
);
```

## 8.3 Options

```sql
CREATE TABLE product_options (
  id UUID PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES products(id),
  name TEXT NOT NULL,
  position INT NOT NULL DEFAULT 0,
  UNIQUE(product_id, name)
);

CREATE TABLE product_option_values (
  id UUID PRIMARY KEY,
  option_id UUID NOT NULL REFERENCES product_options(id),
  value TEXT NOT NULL,
  position INT NOT NULL DEFAULT 0,
  UNIQUE(option_id, value)
);
```

## 8.4 Variants

```sql
CREATE TABLE product_variants (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  product_id UUID NOT NULL REFERENCES products(id),
  sku TEXT NOT NULL,
  barcode TEXT,
  price_amount_minor BIGINT NOT NULL,
  cost_amount_minor BIGINT,
  currency CHAR(3) NOT NULL,
  weight_grams BIGINT,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, sku),
  CHECK(price_amount_minor >= 0),
  CHECK(cost_amount_minor IS NULL OR cost_amount_minor >= 0),
  CHECK(status IN ('DRAFT', 'ACTIVE', 'INACTIVE'))
);
```

Variant option values:

```sql
CREATE TABLE product_variant_option_values (
  variant_id UUID NOT NULL REFERENCES product_variants(id),
  option_value_id UUID NOT NULL REFERENCES product_option_values(id),
  PRIMARY KEY (variant_id, option_value_id)
);
```

---

# 9. Categories / Media / SEO

```sql
CREATE TABLE categories (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  parent_id UUID REFERENCES categories(id),
  slug TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, slug)
);
```

```sql
CREATE TABLE product_categories (
  product_id UUID NOT NULL REFERENCES products(id),
  category_id UUID NOT NULL REFERENCES categories(id),
  PRIMARY KEY(product_id, category_id)
);
```

Media:

```sql
CREATE TABLE media_assets (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  storage_key TEXT NOT NULL UNIQUE,
  mime_type TEXT NOT NULL,
  size_bytes BIGINT NOT NULL,
  width INT,
  height INT,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_media_tenant ON media_assets(tenant_id);
```

Product-to-media relationship:

```sql
CREATE TABLE product_media (
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  product_id UUID NOT NULL REFERENCES products(id),
  media_asset_id UUID NOT NULL REFERENCES media_assets(id),
  position INT NOT NULL DEFAULT 0,
  alt_text TEXT,
  PRIMARY KEY(product_id, media_asset_id),
  UNIQUE(product_id, position),
  CHECK(position >= 0)
);

CREATE INDEX idx_product_media_tenant_product
ON product_media(tenant_id, product_id, position);
```

`tenant_id` is populated and validated transactionally; RLS MUST prevent cross-tenant product/media associations.

---

# 10. Money / Currency

Canonical model:

```text
amount_minor: BIGINT
currency: ISO-4217
```

Do not use floating point.

Currency exponent MUST come from currency metadata, not hardcoded assumption:

```text
USD = 2
EUR = 2
TRY = 2
JPY = 0
```

Every monetary record must carry explicit currency.

Money arithmetic:

```text
subtotal
+ tax
+ shipping
+ fees
- discounts
= total
```

All monetary calculations must be deterministic.

---

# 11. Pricing

Required logical entities:

```text
prices
price_lists
market_prices
promotions
coupons
discount_applications
```

Price:

```sql
CREATE TABLE prices (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  variant_id UUID NOT NULL REFERENCES product_variants(id),
  amount_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  valid_from TIMESTAMPTZ,
  valid_to TIMESTAMPTZ,
  CHECK(amount_minor >= 0)
);

CREATE INDEX idx_prices_variant_currency
ON prices(tenant_id, variant_id, currency);
```

Pricing engine must be deterministic and server-authoritative.

---

# 11.1 Promotions / Coupons — P0 Pricing Schema

Promotions and coupons are part of the deterministic pricing domain and therefore receive an explicit P0 schema rather than remaining checklist-only.

```sql
CREATE TABLE promotions (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  status TEXT NOT NULL,
  discount_type TEXT NOT NULL,
  value_minor BIGINT,
  percentage_bps INT,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  usage_limit BIGINT,
  usage_count BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK(status IN ('DRAFT', 'ACTIVE', 'PAUSED', 'EXPIRED')),
  CHECK(discount_type IN ('FIXED', 'PERCENTAGE')),
  CHECK(value_minor IS NULL OR value_minor >= 0),
  CHECK(percentage_bps IS NULL OR (percentage_bps >= 0 AND percentage_bps <= 10000)),
  CHECK(usage_limit IS NULL OR usage_limit > 0),
  CHECK(usage_count >= 0)
);

CREATE INDEX idx_promotions_tenant_status
ON promotions(tenant_id, status);

CREATE TABLE coupons (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  promotion_id UUID NOT NULL REFERENCES promotions(id),
  code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  usage_limit BIGINT,
  usage_count BIGINT NOT NULL DEFAULT 0,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, code),
  CHECK(status IN ('ACTIVE', 'PAUSED', 'EXPIRED')),
  CHECK(usage_limit IS NULL OR usage_limit > 0),
  CHECK(usage_count >= 0)
);

CREATE INDEX idx_coupons_tenant_promotion
ON coupons(tenant_id, promotion_id);
```

Coupon usage MUST be concurrency-safe and idempotent; promotion evaluation MUST remain deterministic for identical inputs.

---

# 12. Customers / Addresses

```sql
CREATE TABLE customers (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  email CITEXT,
  phone TEXT,
  first_name TEXT,
  last_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_customers_tenant_email
ON customers(tenant_id, email);

CREATE INDEX idx_customers_tenant_phone
ON customers(tenant_id, phone);
```

```sql
CREATE TABLE customer_addresses (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  customer_id UUID NOT NULL REFERENCES customers(id),
  country_code CHAR(2) NOT NULL,
  region TEXT,
  city TEXT,
  postal_code TEXT,
  address_line1 TEXT NOT NULL,
  address_line2 TEXT,
  type TEXT NOT NULL DEFAULT 'SHIPPING',
  CHECK(type IN ('BILLING', 'SHIPPING'))
);

CREATE INDEX idx_customer_addresses_customer
ON customer_addresses(tenant_id, customer_id);
```

---

# 13. Cart / Checkout

Persistent cart:

```sql
CREATE TABLE carts (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  customer_id UUID REFERENCES customers(id),
  status TEXT NOT NULL,
  currency CHAR(3) NOT NULL,
  version BIGINT NOT NULL DEFAULT 0,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_carts_tenant_customer
ON carts(tenant_id, customer_id);
```

```sql
CREATE TABLE cart_items (
  id UUID PRIMARY KEY,
  cart_id UUID NOT NULL REFERENCES carts(id),
  variant_id UUID NOT NULL REFERENCES product_variants(id),
  quantity BIGINT NOT NULL,
  unit_price_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  CHECK(quantity > 0),
  CHECK(unit_price_minor >= 0)
);
```

Guest cart may use Redis with TTL, but checkout must revalidate all state against PostgreSQL.

---

# 14. Orders

```sql
CREATE TABLE orders (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  storefront_id UUID REFERENCES storefronts(id),
  customer_id UUID REFERENCES customers(id),
  order_number TEXT NOT NULL,
  status TEXT NOT NULL,
  payment_status TEXT NOT NULL,
  fulfillment_status TEXT NOT NULL,
  risk_status TEXT NOT NULL,
  customer_email_snapshot TEXT,
  currency CHAR(3) NOT NULL,
  subtotal_minor BIGINT NOT NULL,
  discount_minor BIGINT NOT NULL DEFAULT 0,
  shipping_minor BIGINT NOT NULL DEFAULT 0,
  tax_minor BIGINT NOT NULL DEFAULT 0,
  fee_minor BIGINT NOT NULL DEFAULT 0,
  total_minor BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, order_number),
  CHECK(subtotal_minor >= 0),
  CHECK(discount_minor >= 0),
  CHECK(shipping_minor >= 0),
  CHECK(tax_minor >= 0),
  CHECK(fee_minor >= 0),
  CHECK(total_minor >= 0)
);
```

Critical domain invariant:

```text
total =
subtotal
+ tax
+ shipping
+ fees
- discounts
```

Do not rely on SQL CHECK alone; implement the invariant in the Domain Service inside the transaction.

---

# 15. Order Items

```sql
CREATE TABLE order_items (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  order_id UUID NOT NULL REFERENCES orders(id),
  variant_id UUID REFERENCES product_variants(id),
  sku_snapshot TEXT NOT NULL,
  title_snapshot TEXT NOT NULL,
  quantity BIGINT NOT NULL,
  unit_price_minor BIGINT NOT NULL,
  discount_minor BIGINT NOT NULL DEFAULT 0,
  tax_minor BIGINT NOT NULL DEFAULT 0,
  total_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  CHECK(quantity > 0)
);

CREATE INDEX idx_order_items_order
ON order_items(tenant_id, order_id);

CREATE INDEX idx_order_items_variant
ON order_items(tenant_id, variant_id);
```

Order items store snapshots so future product changes cannot rewrite historical orders.

---

# 15.1 Order Address Snapshots

Order shipping and billing addresses are immutable historical snapshots and must not be rewritten from the customer's address book.

```sql
CREATE TABLE order_addresses (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  order_id UUID NOT NULL REFERENCES orders(id),
  type TEXT NOT NULL,
  recipient_name TEXT,
  phone TEXT,
  country_code CHAR(2) NOT NULL,
  region TEXT,
  city TEXT,
  postal_code TEXT,
  address_line1 TEXT NOT NULL,
  address_line2 TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(order_id, type),
  CHECK(type IN ('BILLING', 'SHIPPING'))
);

CREATE INDEX idx_order_addresses_tenant_order
ON order_addresses(tenant_id, order_id);
```

Rules:

```text
[ ] Exactly one BILLING snapshot per order when billing address is required
[ ] Exactly one SHIPPING snapshot per shippable order
[ ] Snapshot is immutable after order confirmation
[ ] Customer address-book edits never rewrite historical order addresses
```


# 16. Order State Machines

## Order

```text
DRAFT
PENDING_PAYMENT
CONFIRMED
PROCESSING
ON_HOLD
CANCEL_REQUESTED
CANCELLED
PARTIALLY_FULFILLED
FULFILLED
SHIPPED
DELIVERED
```

## Payment

```text
PENDING
AUTHORIZED
CAPTURED
FAILED
PARTIALLY_REFUNDED
REFUNDED
VOIDED
```

## Fulfillment

```text
UNFULFILLED
PARTIALLY_FULFILLED
FULFILLED
SHIPPED
DELIVERED
```

## Return

```text
NONE
REQUESTED
APPROVED
IN_TRANSIT
RECEIVED
INSPECTING
APPROVED_FOR_REFUND
REFUNDED
EXCHANGED
REJECTED
```

## Risk

```text
NOT_REVIEWED
LOW_RISK
REVIEW
BLOCKED
APPROVED
```

Transitions MUST be enforced by Domain Services.

Examples:

```text
CANCELLED → SHIPPED = forbidden
REFUNDED → PENDING_PAYMENT = forbidden
DELIVERED → PENDING_PAYMENT = forbidden
```

---

# 17. Order Status History

```sql
CREATE TABLE order_status_history (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  order_id UUID NOT NULL REFERENCES orders(id),
  state_type TEXT NOT NULL,
  from_state TEXT,
  to_state TEXT NOT NULL,
  actor_id UUID REFERENCES users(id),
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_order_history_order
ON order_status_history(tenant_id, order_id, created_at);
```

---

# 18. Inventory

## Locations

```sql
CREATE TABLE inventory_locations (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, name)
);
```

## Inventory Items

```sql
CREATE TABLE inventory_items (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  variant_id UUID NOT NULL REFERENCES product_variants(id),
  location_id UUID NOT NULL REFERENCES inventory_locations(id),
  on_hand BIGINT NOT NULL DEFAULT 0,
  reserved BIGINT NOT NULL DEFAULT 0,
  committed BIGINT NOT NULL DEFAULT 0,
  available BIGINT NOT NULL DEFAULT 0,
  version BIGINT NOT NULL DEFAULT 0,
  UNIQUE(tenant_id, variant_id, location_id),
  CHECK(on_hand >= 0),
  CHECK(reserved >= 0),
  CHECK(committed >= 0),
  CHECK(available >= 0),
  CHECK(available = on_hand - reserved - committed),
  CHECK(reserved + committed <= on_hand)
);

CREATE INDEX idx_inventory_variant
ON inventory_items(tenant_id, variant_id);

CREATE INDEX idx_inventory_location
ON inventory_items(tenant_id, location_id);
```

## Reservations

```sql
CREATE TABLE inventory_reservations (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  inventory_item_id UUID NOT NULL REFERENCES inventory_items(id),
  order_id UUID NOT NULL REFERENCES orders(id),
  quantity BIGINT NOT NULL,
  status TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK(quantity > 0)
);

CREATE INDEX idx_reservations_expiry
ON inventory_reservations(tenant_id, status, expires_at);

CREATE INDEX idx_reservations_order
ON inventory_reservations(tenant_id, order_id);
```

Reservation transaction:

```sql
BEGIN;

SELECT *
FROM inventory_items
WHERE id = $1
  AND tenant_id = $2
FOR UPDATE;

-- validate available >= requested quantity

UPDATE inventory_items
SET available = available - $quantity,
    reserved = reserved + $quantity,
    version = version + 1
WHERE id = $id
  AND available >= $quantity;

INSERT INTO inventory_reservations (...);

COMMIT;
```

For high-concurrency worker allocation, `SKIP LOCKED` may be used where the business semantics permit it. It must not replace correctness checks.

---

# 19. Payments

```sql
CREATE TABLE payment_intents (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  order_id UUID NOT NULL REFERENCES orders(id),
  provider TEXT NOT NULL,
  provider_payment_id TEXT,
  amount_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_payment_intents_order
ON payment_intents(tenant_id, order_id);

CREATE INDEX idx_payment_provider_reference
ON payment_intents(provider, provider_payment_id);
```

Payment attempts:

```sql
CREATE TABLE payment_attempts (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  payment_intent_id UUID NOT NULL REFERENCES payment_intents(id),
  provider_attempt_id TEXT,
  status TEXT NOT NULL,
  error_code TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

Captures:

```sql
CREATE TABLE payment_captures (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  payment_intent_id UUID NOT NULL REFERENCES payment_intents(id),
  amount_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  provider_capture_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK(amount_minor > 0)
);
```

Refunds:

```sql
CREATE TABLE refunds (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  order_id UUID NOT NULL REFERENCES orders(id),
  payment_intent_id UUID NOT NULL REFERENCES payment_intents(id),
  amount_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  status TEXT NOT NULL,
  provider_refund_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK(amount_minor > 0)
);
```

Invariant:

```text
total refunded <= total captured
```

This must be checked transactionally.

---

# 19.1 Payment Reference Uniqueness & Financial Guards — P0

```sql
CREATE UNIQUE INDEX uq_payment_provider_payment
  ON payment_intents(provider, provider_payment_id)
  WHERE provider_payment_id IS NOT NULL;

CREATE UNIQUE INDEX uq_payment_provider_capture
  ON payment_captures(tenant_id, provider_capture_id)
  WHERE provider_capture_id IS NOT NULL;

CREATE UNIQUE INDEX uq_refund_provider_reference
  ON refunds(tenant_id, provider_refund_id)
  WHERE provider_refund_id IS NOT NULL;
```

Required transactional invariants:

```text
sum(payment_captures.amount_minor) <= payment_intents.amount_minor
sum(refunds.amount_minor) <= sum(payment_captures.amount_minor)
all rows in one payment intent share the same currency
provider references and endpoint idempotency keys are unique for each business effect
```

The transaction MUST lock the payment intent before accepting a capture or refund.

# 20. Payment Provider Contract

```typescript
interface PaymentProvider {
  authorize(input: PaymentIntent): Promise<AuthorizationResult>;
  capture(paymentIntentId: string, amount?: Money): Promise<CaptureResult>;
  void(paymentIntentId: string): Promise<VoidResult>;
  refund(paymentId: string, amount: Money): Promise<RefundResult>;
  getStatus(paymentIntentId: string): Promise<PaymentStatus>;
  handleWebhook(
    rawPayload: string,
    signature: string
  ): Promise<ProviderEvent>;
}
```

External payment state is never assumed to be identical to internal state. Reconciliation is mandatory.

---

# 21. Webhooks / Idempotency

## Provider Events

```sql
CREATE TABLE webhook_events (
  id UUID PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id),
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  payload JSONB NOT NULL,
  status TEXT NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ,
  UNIQUE(provider, provider_event_id)
);
```

Webhook flow:

```text
Receive
 ↓
Verify signature
 ↓
Persist raw event
 ↓
Deduplicate
 ↓
Process transaction
 ↓
Write outbox
 ↓
Ack
```

Never perform business mutation before durable persistence and signature verification.

---

# 22. Idempotency

```sql
CREATE TABLE idempotency_keys (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  actor_id UUID,
  endpoint TEXT NOT NULL,
  key TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  response_status INT,
  response_body JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  UNIQUE(tenant_id, endpoint, key)
);
```

Rules:

```text
same tenant + endpoint + key + same request hash
→ return original result

same key + different request hash
→ HTTP 409

expired key
→ may be reused according to documented retention policy
```

Required mutations:

```text
POST /orders
POST /payments/*
POST /refunds
POST /shipments/*
POST /inventory/reserve
POST /imports
POST /provisioning
```

---

# 23. Financial Ledger

## Accounts

```sql
CREATE TABLE ledger_accounts (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  account_type TEXT NOT NULL,
  currency CHAR(3),
  UNIQUE(tenant_id, code)
);
```

## Journal Entries

```sql
CREATE TABLE journal_entries (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  currency CHAR(3) NOT NULL,
  reference_type TEXT NOT NULL,
  reference_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  reversal_of UUID REFERENCES journal_entries(id)
);

CREATE INDEX idx_journal_reference
ON journal_entries(tenant_id, reference_type, reference_id);
```

## Journal Lines

```sql
CREATE TABLE journal_lines (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  journal_entry_id UUID NOT NULL REFERENCES journal_entries(id),
  account_id UUID NOT NULL REFERENCES ledger_accounts(id),
  debit_minor BIGINT NOT NULL DEFAULT 0,
  credit_minor BIGINT NOT NULL DEFAULT 0,
  currency CHAR(3) NOT NULL,
  fx_rate NUMERIC,
  fx_source TEXT,
  fx_timestamp TIMESTAMPTZ,
  CHECK(debit_minor >= 0),
  CHECK(credit_minor >= 0),
  CHECK(
    (debit_minor > 0 AND credit_minor = 0)
    OR
    (credit_minor > 0 AND debit_minor = 0)
  )
);
```

Journal invariant:

```text
SUM(debits) = SUM(credits)
```

The invariant is enforced in the Journal Service within the same DB transaction. Historical lines cannot be updated or deleted.

Corrections use reversal entries.

---

# 23.1 Ledger Database Immutability

Application-level immutability is not sufficient. Production DB permissions must also prevent historical ledger mutation.

Required database policy:

```text
journal_entries:
  INSERT = application ledger role
  SELECT = read/reporting roles
  UPDATE = DENIED
  DELETE = DENIED

journal_lines:
  INSERT = application ledger role
  SELECT = read/reporting roles
  UPDATE = DENIED
  DELETE = DENIED
```

Corrections are performed only by creating a new reversal journal entry.

Operational requirement:

```text
[ ] Ledger tables are owned by a non-application migration/DB owner role
[ ] Application runtime role has no UPDATE/DELETE privileges
[ ] Reconciliation can rebuild balances from journal lines
```


# 24. Outbox

```sql
CREATE TABLE outbox_events (
  id UUID PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id),
  aggregate_type TEXT NOT NULL,
  aggregate_id UUID NOT NULL,
  event_type TEXT NOT NULL,
  schema_version INT NOT NULL DEFAULT 1,
  payload JSONB NOT NULL,
  correlation_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ,
  attempt_count INT NOT NULL DEFAULT 0,
  next_attempt_at TIMESTAMPTZ,
  last_error TEXT,
  status TEXT NOT NULL
);

CREATE INDEX idx_outbox_pending
ON outbox_events(status, next_attempt_at, created_at);

CREATE INDEX idx_outbox_tenant
ON outbox_events(tenant_id, created_at);
```

Pattern:

```text
BEGIN
  mutate business state
  insert outbox event
COMMIT
```

Delivery:

```text
at-least-once
+
idempotent consumers
+
retry
+
DLQ
+
replay
```

---

# 25. Dead Letter Queue

```sql
CREATE TABLE dead_letter_events (
  id UUID PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id),
  source_event_id UUID,
  event_type TEXT NOT NULL,
  payload JSONB NOT NULL,
  failure_reason TEXT NOT NULL,
  attempt_count INT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ
);
```

Never silently discard a failed critical event.

---

# 26. Audit Log

```sql
CREATE TABLE audit_events (
  id UUID PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id),
  actor_id UUID REFERENCES users(id),
  action TEXT NOT NULL,
  resource_type TEXT,
  resource_id UUID,
  target_tenant_id UUID REFERENCES tenants(id),
  ip_address INET,
  user_agent TEXT,
  metadata JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_tenant_time
ON audit_events(tenant_id, created_at);

CREATE INDEX idx_audit_actor_time
ON audit_events(actor_id, created_at);
```

Audit events are append-only.

---

# 26.1 Audit Event Hardening — Normative P0

Security-sensitive audit records MUST carry explicit request/correlation and before/after context:

```sql
ALTER TABLE audit_events
  ADD COLUMN request_id UUID,
  ADD COLUMN correlation_id UUID,
  ADD COLUMN before_data JSONB,
  ADD COLUMN after_data JSONB;

REVOKE UPDATE, DELETE ON audit_events FROM app_runtime;
```

Mandatory semantic fields:

```text
actor identity
action
resource
tenant_id or explicit platform scope
request_id
correlation_id
before_data / after_data where applicable
created_at
```

# 27. Tax Contract

P0 foundation:

```text
TaxJurisdiction
TaxClass
TaxLine
TaxCalculation
TaxProvider
TaxCalculationContext
```

```typescript
interface TaxProvider {
  calculate(
    context: TaxCalculationContext
  ): Promise<TaxCalculationResult>;
}
```

Inputs:

```text
merchant location / registration
customer location
shipping destination
product tax class
price inclusivity
currency
```

P1 expands:

```text
VAT
GST
Sales Tax
Nexus
Cross-border duties
External tax providers
```

---

# 27.1 Tax Schema — P0 Foundation

The P0 tax layer defines the stable data model and provider contract. Full country-specific tax coverage may remain P1.

```sql
CREATE TABLE tax_jurisdictions (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  country_code CHAR(2) NOT NULL,
  region_code TEXT,
  city TEXT,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  UNIQUE(tenant_id, country_code, region_code, city)
);

CREATE INDEX idx_tax_jurisdictions_tenant
ON tax_jurisdictions(tenant_id);

CREATE TABLE tax_classes (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  UNIQUE(tenant_id, code)
);

CREATE INDEX idx_tax_classes_tenant
ON tax_classes(tenant_id);

CREATE TABLE tax_calculations (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  order_id UUID REFERENCES orders(id),
  currency CHAR(3) NOT NULL,
  provider TEXT,
  provider_reference TEXT,
  subtotal_minor BIGINT NOT NULL,
  tax_total_minor BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, id)
);

CREATE INDEX idx_tax_calculations_order
ON tax_calculations(tenant_id, order_id);

CREATE TABLE tax_lines (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  tax_calculation_id UUID NOT NULL REFERENCES tax_calculations(id),
  jurisdiction_id UUID REFERENCES tax_jurisdictions(id),
  tax_class_id UUID REFERENCES tax_classes(id),
  taxable_amount_minor BIGINT NOT NULL,
  tax_amount_minor BIGINT NOT NULL,
  rate_bps INT,
  currency CHAR(3) NOT NULL,
  CHECK(taxable_amount_minor >= 0),
  CHECK(tax_amount_minor >= 0),
  CHECK(rate_bps IS NULL OR (rate_bps >= 0 AND rate_bps <= 10000))
);

CREATE INDEX idx_tax_lines_calculation
ON tax_lines(tenant_id, tax_calculation_id);
```

Tax invariants:

```text
[ ] Sum(tax_lines.tax_amount_minor) = tax_calculations.tax_total_minor
[ ] All tax lines in one calculation use the same currency
[ ] Tax calculation input is reproducible/auditable
[ ] Provider reference is retained when an external provider is used
```


# 28. Media Pipeline

```text
Upload
 ↓
MIME validation
 ↓
Size validation
 ↓
Malware scan where applicable
 ↓
Metadata extraction
 ↓
Resize
 ↓
WebP/AVIF
 ↓
R2/S3
 ↓
CDN
```

Variants:

```text
thumbnail
small
medium
large
original
```

Storefront:

```text
srcset
lazy loading
width/height
cache headers
blur placeholder where appropriate
```

---

# 29. Tenant Isolation — Complete System Boundary

Tenant isolation MUST cover:

```text
PostgreSQL RLS
Application authorization
Repository scopes
Redis keys
BullMQ job payloads
Search filters/index namespaces
Storage paths
Logs
Events
Analytics
Domains
Webhook routing
```

Redis:

```text
products:list:{tenant_id}:{locale}:{version}
session:{tenant_id}:{session_id}
rate_limit:{tenant_id}:{endpoint}:{key}
```

Storage:

```text
{tenant_id}/products/{product_id}/...
```

Queue payload MUST contain tenant context.

Never trust:

```text
X-Tenant-ID
tenant_id from request body
tenant_id from query parameter
```

as the authority for access.

---

# 30. RLS Strategy

Example:

```sql
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation_orders
ON orders
USING (
  tenant_id = current_setting(
    'app.current_tenant',
    true
  )::uuid
);
```

Application transaction:

```sql
BEGIN;

SET LOCAL app.current_tenant = 'TENANT_UUID';

-- tenant-scoped queries

COMMIT;
```

Important:

- `SET LOCAL` must be applied in the same transaction/session context.
- Connection pooling must not leak tenant context.
- RLS is defense boundary, not substitute for authorization.
- Repository filters remain mandatory.
- CI MUST test cross-tenant access.

---

# 30.1 RLS Coverage Matrix

RLS is mandatory for every tenant-scoped business table.

| Table Group | RLS | Required tenant column |
|---|---|---|
| tenants | CONTROL-PLANE policy | id / membership |
| storefronts | P0 | tenant_id |
| domains | P0 | tenant_id |
| products | P0 | tenant_id |
| product_variants | P0 | tenant_id |
| product_media | P0 | tenant_id |
| categories | P0 | tenant_id |
| customers | P0 | tenant_id |
| carts | P0 | tenant_id |
| orders | P0 | tenant_id |
| order_items | P0 | tenant_id |
| order_addresses | P0 | tenant_id |
| payments | P0 | tenant_id |
| refunds | P0 | tenant_id |
| inventory | P0 | tenant_id |
| tax | P0 | tenant_id |
| ledger | P0 | tenant_id |
| outbox | P0 | tenant_id |
| audit | P0 | tenant_id |
| idempotency | P0 | tenant_id |

Policy rules:

```text
[ ] ENABLE ROW LEVEL SECURITY on tenant-scoped tables
[ ] FORCE ROW LEVEL SECURITY where application roles could otherwise bypass policy
[ ] Application DB role must not own tenant-scoped tables in production
[ ] Application role must not have BYPASSRLS
[ ] SET LOCAL app.current_tenant is required for tenant-scoped transactions
```

Composite tenant-integrity relationships must also be enforced where a child can reference records belonging to different tenants. Prefer composite foreign keys `(tenant_id, id)` on high-risk cross-tenant relationships, or equivalent database constraints/triggers where appropriate.

Example:

```sql
ALTER TABLE product_media
  ADD CONSTRAINT fk_product_media_product_tenant
  FOREIGN KEY (tenant_id, product_id)
  REFERENCES products(tenant_id, id);

ALTER TABLE product_media
  ADD CONSTRAINT fk_product_media_media_tenant
  FOREIGN KEY (tenant_id, media_asset_id)
  REFERENCES media_assets(tenant_id, id);
```


# 31. Index Strategy

Every high-volume tenant-scoped table requires tenant-aware indexes.

Typical patterns:

```text
(tenant_id, created_at)
(tenant_id, status)
(tenant_id, updated_at)
(tenant_id, foreign_key)
```

Do not create indexes blindly. Validate them with query plans and production-like data.

Critical indexes:

```text
orders(tenant_id, order_number)
orders(tenant_id, status, created_at)
order_items(tenant_id, order_id)
products(tenant_id, slug)
products(tenant_id, status)
variants(tenant_id, sku)
inventory(tenant_id, variant_id, location_id)
reservations(tenant_id, status, expires_at)
payments(tenant_id, order_id)
refunds(tenant_id, order_id)
outbox(status, next_attempt_at, created_at)
audit(tenant_id, created_at)
```

---

# 32. Prisma / PostgreSQL Rules

Prisma remains the ORM.

Required:

```text
Prisma
 ↓
PgBouncer / Managed Pool
 ↓
PostgreSQL
```

Operational controls:

```text
bounded connection pool
statement timeout
idle transaction timeout
slow query monitoring
EXPLAIN/ANALYZE for critical queries
tenant-aware composite indexes
```

Prisma is not considered a blocker. Replace it only if measured evidence proves a real bottleneck.

---

# 33. Migration Strategy

Use Expand / Contract.

```text
1. Add compatible schema
2. Deploy backward-compatible application
3. Backfill asynchronously
4. Validate
5. Switch reads/writes
6. Remove old schema later
```

Forbidden:

```text
destructive migration
+
application that still depends on old schema
```

Every production migration must have:

```text
migration test
rollback/recovery procedure
backup verification
performance impact review
```

---

# 34. API Standards

Base:

```text
/v1/...
```

Requirements:

```text
JSON
ISO-8601 timestamps
ISO-4217 currency
pagination
request_id
correlation_id
consistent error envelope
authenticated tenant context
```

Error:

```json
{
  "error": {
    "code": "INVENTORY_INSUFFICIENT",
    "message": "Insufficient inventory",
    "request_id": "..."
  }
}
```

Tenant context MUST originate from trusted authentication/domain resolution.

---

# 34.1 Rate Limiting Contract — P0

Rate limiting is applied at multiple scopes:

```text
IP
User
Tenant
API key / App
Endpoint
Authentication surface
Webhook surface
```

Baseline dimensions:

```text
limit
burst
window
scope
priority
Retry-After
```

Response:

```http
HTTP/1.1 429 Too Many Requests
Retry-After: 12
```

Example policy:

```text
/auth/login           IP + user
/api/v1/orders        tenant + actor
/api/v1/search        tenant + IP
/public/storefront    tenant + IP
/webhooks             provider + endpoint
```

Plan-aware limits may later be attached to Entitlements.

Requirements (Amended v1.7 — launch stack is explicitly PostgreSQL-first):

```text
Starter Stack (launch, no Redis):
[ ] PostgreSQL-backed counters — table `rate_limit_counters(scope_key, window_start, count)`
    with `UPSERT ... ON CONFLICT DO UPDATE count = count + 1` for atomic increment
[ ] TTL simulated via window_start + periodic cleanup job (same worker used for outbox polling)
[ ] No cross-tenant key collision — scope_key MUST be prefixed by tenant_id/IP/route composite
[ ] 429 response contract (same as below)
[ ] Alert on abnormal tenant/IP abuse via structured log threshold (no Prometheus required at launch)

Scale Stack (15+ tenants or measured contention on rate_limit_counters):
[ ] Redis-backed counters (atomic INCR + EXPIRE)
[ ] Atomic increment/check
[ ] TTL on counters
[ ] No cross-tenant key collision
[ ] 429 response contract
[ ] Alert on abnormal tenant/IP abuse via Prometheus/Grafana
```

**Explicit resolution:** §55.1 permits launching without Redis; this section previously assumed Redis unconditionally, creating a contradiction. The PostgreSQL-backed counter above satisfies the same contract (atomic, TTL-bound, tenant-isolated) and MUST be swapped for Redis only when the upgrade trigger in §55.1 fires — not before.


# 34.2 HTTP Security Baseline — P0

Required security headers:

```text
Strict-Transport-Security
Content-Security-Policy
X-Content-Type-Options: nosniff
Referrer-Policy
Permissions-Policy
Frame-Ancestors via CSP
```

Session cookie requirements:

```text
Secure
HttpOnly
SameSite=Lax or Strict as flow permits
```

CSP MUST be designed around the actual Next.js/application architecture and third-party integrations. Avoid unsafe wildcard policies.

SRI is not mandatory for every asset; use it where externally hosted static resources and integrity guarantees make it appropriate.

# 34.3 Initial SLO Baseline — P0

The final production SLO numbers must be approved before Gate D. Initial targets:

```text
Availability:        >= 99.9%
API p95 latency:     <= 500 ms for normal authenticated CRUD
Checkout p95:        <= 800 ms excluding external provider latency
Webhook processing:  <= 30 s median, <= 2 min p95
Queue lag:           <= 60 s for normal priority queues
5xx rate:            < 0.5%
```

Provider-dependent checkout and webhook timings must be tracked separately from internal service latency.


# 35. P1 Global Platform

P1 includes:

```text
Shipping
Fulfillment
Returns/RMA
Advanced Tax Providers
Multi-location UI/operations
Search
Themes/CMS
PWA
SEO
i18n
RTL
Markets
Currencies
Locales
Domains
Multi-storefront
Bulk Operations
Public REST API
```

## PWA

```text
installable
responsive
offline-safe cart behavior where technically appropriate
service worker
push notifications
```

Do not promise full offline checkout/payment.

## SEO

```text
sitemap
robots.txt
canonical URLs
Open Graph
hreflang
localized metadata
product structured data
```

## i18n

```text
Arabic RTL
English
Turkish
Spanish
French
locale-aware URLs
translation tables
manual locale switch
browser locale detection
```

## Email Deliverability

Use a transactional email provider abstraction.

Requirements:

```text
SPF
DKIM
DMARC
bounce handling
suppression list
password reset deliverability
transactional templates
```

Shared provider IPs are acceptable initially; dedicated IP is not a P0 requirement.

## Arabic Search

Meilisearch configuration MUST be tested with:

```text
Arabic normalization
diacritics
tokenization
prefix search
synonyms
mixed Arabic/Latin queries
Turkish casing
```

Search remains eventual and rebuildable.

---

# 36. Shipping Provider Contract

```typescript
interface ShippingProvider {
  getRates(input: RateRequest): Promise<ShippingRate[]>;
  createShipment(input: ShipmentRequest): Promise<ShipmentResult>;
  purchaseLabel(shipmentId: string): Promise<LabelResult>;
  cancelShipment(shipmentId: string): Promise<void>;
  trackShipment(trackingNumber: string): Promise<TrackingResult>;
  validateAddress(
    address: Address
  ): Promise<AddressValidationResult>;
}
```

---

# 37. P2 Ecosystem

```text
Developer Portal
OAuth Apps
App Marketplace
SDKs
AI Gateway
Semantic Search
Recommendations
Merchant Copilot
B2B
Subscriptions
Loyalty
Referral
Gift Cards
White Label
Multi-region
Advanced Analytics
```

These must not block the initial commercial P0 launch.

---

# 38. P0 Implementation Checklist

## Phase 0 — Repository / Engineering Foundation

```text
[ ] Monorepo or modular repository structure approved
[ ] TypeScript strict mode
[ ] Environment configuration validated
[ ] Secrets never committed
[ ] Docker development environment
[ ] PostgreSQL
[ ] Prisma
[ ] Migration pipeline
[ ] CI pipeline
[ ] SAST/dependency scanning
[ ] Structured logging
[ ] Correlation/request IDs
[ ] Health endpoint
[ ] Readiness endpoint
[ ] Basic metrics/health telemetry
[ ] Starter outbox poller / worker process

Scale-stack-only (activated by §55.1 trigger):
[ ] Redis
[ ] BullMQ
[ ] PgBouncer / managed pool
[ ] Sentry
[ ] Prometheus/Grafana
```

### Gate 0

```text
[ ] Fresh environment can boot
[ ] Database can migrate from empty state
[ ] CI is green
[ ] Secrets scan is clean
[ ] Health/readiness checks work
[ ] Starter outbox/worker can execute a durable event end-to-end
```

---

# 39. Phase 1 — Identity / Tenant / RBAC

```text
[ ] User model
[ ] Tenant model
[ ] Membership model
[ ] Role model
[ ] Permission model
[ ] Session model
[ ] MFA model
[ ] Tenant resolution
[ ] Domain resolution
[ ] Authorization middleware
[ ] Repository tenant scope
[ ] PostgreSQL RLS
[ ] Audit events
[ ] Rate limiting
```

Tests:

```text
[ ] Tenant A cannot read Tenant B
[ ] Tenant A cannot mutate Tenant B
[ ] Tenant A cannot access Tenant B cache
[ ] Tenant A cannot access Tenant B storage
[ ] Tenant A cannot access Tenant B search records
[ ] Role escalation blocked
[ ] Privileged MFA enforced
```

### Gate A — Security

```text
[ ] Cross-tenant suite green
[ ] RLS verified
[ ] Cache isolation verified
[ ] Storage isolation verified
[ ] Search isolation verified
[ ] MFA verified
[ ] Audit verified
[ ] Secrets scan clean
[ ] Critical/high security findings resolved
```

---

# 40. Phase 2 — Catalog / Money / Pricing

```text
[ ] Products
[ ] Translations
[ ] Categories
[ ] Options
[ ] Variants
[ ] SKU uniqueness
[ ] Media
[ ] SEO metadata
[ ] Currency metadata
[ ] Money utility
[ ] Price lists
[ ] Promotions
[ ] Coupons
[ ] Discount applications
```

Tests:

```text
[ ] Money never uses float
[ ] JPY works with exponent 0
[ ] Negative price rejected
[ ] Duplicate tenant SKU rejected
[ ] Translation uniqueness works
[ ] Product soft delete works
[ ] Pricing deterministic
```

---

# 41. Phase 3 — Cart / Checkout / Orders

```text
[ ] Guest cart
[ ] Persistent cart
[ ] Cart versioning
[ ] Server-side price calculation
[ ] Inventory validation
[ ] Tax calculation contract (P0 single-jurisdiction/basic rate engine)
[ ] Shipping calculation contract (P0 free/flat-rate merchant-defined shipping)
[ ] Promotion calculation
[ ] Order creation
[ ] Order state machine
[ ] Status history
[ ] Order snapshots
```

Critical tests:

```text
[ ] Client cannot manipulate total
[ ] Duplicate checkout cannot create two orders
[ ] Invalid order transition rejected
[ ] Total invariant always holds
[ ] Order snapshot survives product edits
```

---

# 42. Phase 4 — Inventory

```text
[ ] Inventory locations
[ ] Inventory items
[ ] Reservation
[ ] Reservation expiry
[ ] Reservation release
[ ] Commit reservation
[ ] Inventory adjustment
[ ] Atomic locking
[ ] Concurrency tests
```

Mandatory test:

```text
Given inventory = 1
When buyer A and buyer B reserve simultaneously
Then exactly one succeeds
And available never < 0
```

High-concurrency optimization:

```text
FOR UPDATE
+
atomic condition
+
SKIP LOCKED only where semantics permit
```

---

# 43. Phase 5 — Payments / Ledger

## Payments

```text
[ ] PaymentProvider interface
[ ] PaymentIntent
[ ] PaymentAttempt
[ ] Capture
[ ] Void
[ ] Refund
[ ] Provider event persistence
[ ] Signature verification
[ ] Idempotency
[ ] Reconciliation
```

## Ledger

```text
[ ] Ledger accounts
[ ] Journal entries
[ ] Journal lines
[ ] Double-entry validation
[ ] Immutable records
[ ] Reversal entries
[ ] Currency handling
[ ] FX metadata
[ ] Reconciliation
```

### Gate B — Financial

```text
[ ] Debits = credits
[ ] No duplicate capture effect
[ ] Refund <= capture
[ ] Currency invariants pass
[ ] Webhook replay safe
[ ] Reconciliation passes
[ ] Ledger mutation attempts blocked
```

---

# 44. Phase 6 — Outbox / Queue / DLQ

```text
[ ] Outbox table
[ ] Transactional insertion
[ ] Dispatcher
[ ] BullMQ workers
[ ] Retry policy
[ ] Exponential backoff
[ ] DLQ
[ ] Replay command
[ ] Consumer idempotency
[ ] Queue metrics
[ ] Queue lag alerts
```

Test:

```text
[ ] Worker crashes after DB commit
[ ] Event is retried
[ ] Consumer does not duplicate business effect
[ ] Failed event reaches DLQ
[ ] Replay succeeds
```

---

# 45. Phase 7 — Media / Notifications / Email

```text
[ ] Upload validation
[ ] Image processing
[ ] WebP
[ ] AVIF
[ ] Responsive variants
[ ] Object storage
[ ] CDN
[ ] Email provider abstraction
[ ] Password-reset transactional email
[ ] Password-reset token expiry and single-use enforcement
[ ] SPF
[ ] DKIM
[ ] DMARC
[ ] Bounce handling
[ ] Push abstraction
[ ] Consent record persistence
```

---

# 46. Phase 8 — Backup / Recovery / Operations

```text
[ ] Automated encrypted backup
[ ] Point-in-time recovery
[ ] Restore drill
[ ] Recovery runbook
[ ] RPO measured
[ ] RTO measured
[ ] Queue replay runbook
[ ] Outbox replay runbook
[ ] Provider reconciliation runbook
[ ] Incident response runbook
[ ] Status page
```

Suggested initial targets:

```text
RPO <= 1 hour
RTO <= 4 hours
```

These are targets, not guarantees, until measured.

### Gate C — Reliability

```text
[ ] Restore drill passed
[ ] Migration rehearsal passed
[ ] Queue replay passed
[ ] Outbox replay passed
[ ] Health/readiness passed
[ ] Recovery timings recorded
```

---

# 47. Phase 9 — Performance / Load

Measure:

```text
API latency
checkout latency
DB CPU
DB connections
DB lock contention
queue lag
worker throughput
search latency
cache hit ratio
error rate
```

Tests:

```text
[ ] concurrent checkout
[ ] concurrent inventory reservation
[ ] duplicate webhooks
[ ] duplicate refunds
[ ] concurrent coupon use
[ ] DB saturation
[ ] queue saturation
```

### Gate D — Performance

```text
[ ] Critical APIs meet approved SLO
[ ] Checkout concurrency passes
[ ] No unacceptable connection exhaustion
[ ] Queue lag remains within target
[ ] Error rate within target
```

---

# 48. Phase 10 — Final Tenant Isolation Certification

Run automatically in CI and staging:

```text
Tenant A → Tenant B orders
Tenant A → Tenant B products
Tenant A → Tenant B customers
Tenant A → Tenant B inventory
Tenant A → Tenant B payments
Tenant A → Tenant B ledger
Tenant A → Tenant B Redis
Tenant A → Tenant B search
Tenant A → Tenant B storage
Tenant A → Tenant B queues
Tenant A → Tenant B audit
```

Expected:

```text
404/403
+
zero data leakage
+
zero cache leakage
+
zero search leakage
+
zero storage leakage
```

### Gate E — Tenant Isolation

```text
[ ] All cross-tenant tests pass
[ ] RLS tests pass
[ ] Cache namespace tests pass
[ ] Search namespace/filter tests pass
[ ] Storage path tests pass
[ ] Queue tenant-context tests pass
[ ] Logs/events tenant tags verified
```

---

# 49. Failure Mode Matrix

| Failure | Required behavior |
|---|---|
| DB unavailable | Fail safely; no partial financial mutation |
| DB connection exhaustion | Backpressure + alert |
| Redis unavailable | Critical DB operations continue where designed; cache/ephemeral features degrade safely |
| Queue unavailable | Durable outbox retains events |
| Worker crash | Retry |
| Repeated worker failure | DLQ |
| Payment provider outage | No false capture; clear pending state |
| Duplicate webhook | No duplicate business effect |
| Duplicate checkout | Idempotent |
| Inventory race | Exactly-once successful reservation for available unit |
| Bad migration | Restore/recovery procedure |
| Search outage | Critical commerce flows remain source-of-truth driven |
| CDN outage | Origin/object storage recovery path |
| Tenant mismatch | 404/403 + audit |
| Ledger mismatch | Transaction rollback + critical alert |

---

# 50. Testing Architecture

## Unit

```text
Money
Pricing
Order transitions
Payment transitions
Refund limits
Inventory invariants
Ledger balance
Permissions
```

## Integration

```text
PostgreSQL
RLS
Prisma
Redis
BullMQ
Payment sandbox
Search adapter
Storage adapter
```

## E2E

```text
Signup
Onboarding
Product creation
Variant creation
Cart
Checkout
Payment
Order
Refund
Merchant dashboard
```

## Security

```text
Cross-tenant access
Role escalation
IDOR
CSRF
XSS
Webhook forgery
Idempotency replay
Secret exposure
Session replay
```

## Concurrency

```text
1 item / 2 buyers
2 simultaneous refunds
duplicate webhooks
duplicate provisioning
coupon race
```

## Recovery

```text
DB restore
Outbox replay
Queue replay
Provider reconciliation
```

---

# 51. Acceptance Criteria

## AC-TENANT-001

```text
Given Tenant A is authenticated
When Tenant A requests Tenant B resource
Then response is 404 or 403 according to policy
And no Tenant B data is returned
And no Tenant B cache is populated
And the event is auditable
```

## AC-ORDER-001

```text
Given a valid cart
When checkout succeeds
Then exactly one order exists for the idempotency key
And inventory is reserved atomically
And total invariant holds
And outbox event exists in the same transaction
```

## AC-PAYMENT-001

```text
Given idempotency key K
When the same request is submitted twice
Then exactly one business effect exists
And the second request returns the original result

When K is reused with a different request hash
Then HTTP 409 is returned
```

## AC-WEBHOOK-001

```text
Given provider event E
When E is delivered multiple times
Then E is stored once by provider identity
And business effect occurs once
```

## AC-INVENTORY-001

```text
Given one available unit
When two buyers reserve concurrently
Then exactly one reservation succeeds
And inventory never becomes negative
```

## AC-LEDGER-001

```text
Given payment P
When journal entry is created
Then debits equal credits
And journal lines commit atomically
And historical lines cannot be changed
And reversal creates a new entry
```

## AC-RESTORE-001

```text
Given a valid backup
When restore drill executes
Then critical data integrity checks pass
And measured RPO/RTO are recorded
```

---

# 52. Definition of Done

A domain is not complete until:

```text
[ ] Entities defined
[ ] DB schema defined
[ ] Foreign keys defined
[ ] Indexes defined
[ ] Constraints defined
[ ] Source of Truth defined
[ ] Consistency model defined
[ ] State transitions defined
[ ] Invariants implemented
[ ] Authorization implemented
[ ] Idempotency implemented where applicable
[ ] Failure modes documented
[ ] Retry/DLQ defined where async
[ ] Observability implemented
[ ] Audit behavior defined
[ ] Unit tests
[ ] Integration tests
[ ] Security tests
[ ] Concurrency tests
[ ] E2E critical path
[ ] Acceptance criteria pass
[ ] Migration tested
[ ] Backup/recovery tested
[ ] Rollback/recovery procedure documented
```

---

# 53. Release Gates

## Gate A — Security

```text
[ ] no unresolved critical/high tenant isolation issue
[ ] privileged MFA enabled
[ ] secrets absent from source control
[ ] audit verified
[ ] webhook signatures verified
```

## Gate B — Financial

```text
[ ] ledger balanced
[ ] no duplicate payment effects
[ ] refund caps enforced
[ ] currency rules verified
[ ] reconciliation passes
```

## Gate C — Reliability

```text
[ ] backup restore passes
[ ] queue replay passes
[ ] outbox replay passes
[ ] migration rehearsal passes
[ ] readiness checks pass
```

## Gate D — Performance

```text
[ ] approved SLOs pass
[ ] checkout concurrency passes
[ ] no unacceptable DB connection exhaustion
[ ] queue lag within target
```

## Gate E — Tenant Isolation

```text
[ ] DB/RLS isolation passes
[ ] cache isolation passes
[ ] search isolation passes
[ ] storage isolation passes
[ ] queue isolation passes
[ ] logs/events correctly tenant-tagged
```

---

# 54. P0 / P1 / P2 Final Classification (Amended v1.5 — Launch-Readiness)

> **ملاحظة معمارية (v1.5):** التصنيف الأصلي (v1.4) كان يفترض إطلاقاً تدريجياً حيث P0 = بنية خلفية آمنة فقط، وP1 = الميزات الظاهرة للعميل. هذا الترتيب **غير مناسب لهدف العمل الفعلي**: المنصة لازم تكون **قابلة للبيع فعلياً** لأول عميل عند اكتمال P0، وليس مجرد بنية تحتية بدون واجهة قابلة للاستخدام. لذلك تم نقل الحد الأدنى من الميزات الظاهرة (العربية RTL، الاشتراك الأساسي، الميزات الأساسية للمتجر) إلى P0، مع إبقاء التوسعات المتقدمة منها في P1.

## P0 — Commercial Safety Kernel + Minimum Sellable Product (MSP)

```text
# البنية الخلفية الآمنة (كما كانت)
Identity
Tenant Isolation
RBAC
Privileged MFA
Audit
Catalog
Variants
Money Model
Pricing Core
Cart
Checkout
Order State Machine
Payment Orchestration
Ledger
Inventory Reservation
Refunds
Tax Contract (Basic — single-jurisdiction default acceptable at launch)
Media Pipeline
Outbox
Idempotency
DLQ
Workers
Rate Limiting
Secrets
Observability (Basic — logs + uptime, full Prometheus/Grafana optional at this stage)
CI/CD
Backup / Restore verification
Transactional Email foundation for security-critical flows
Security Headers / CSP
Security tests
Tenant isolation tests

# منقول من P1 إلى P0 (v1.5) — الحد الأدنى لمتجر قابل للبيع فعلياً
i18n/RTL — العربية كلغة افتراضية أساسية، + إنجليزي وتركي كلغتين إضافيتين عند الإطلاق (3 لغات بجودة ترجمة احترافية كاملة)، مع بنية جاهزة لإضافة لغات لاحقاً دون تعديل هيكلي
Billing (Basic) — اشتراك شهري ثابت عبر Stripe Billing + خيار عمولة عبر Stripe Connect Application Fee (النسخة المبسطة فقط؛ الفوترة المتقدمة/Usage Metering تبقى P1)
Currencies (Basic) — عملة افتراضية لكل Tenant + عرض بعملة الزائر (تحويل تقريبي مقبول عند الإطلاق، الدقة المحاسبية الكاملة تبقى P1)
Domains (Basic) — Subdomain تلقائي لكل Tenant عبر Wildcard DNS (الدومين المخصص الكامل يبقى P1)
PWA (Basic) — قابلية التثبيت + سرعة تحميل مقبولة (الإشعارات المتقدمة Push تبقى P1)
SEO (Basic) — Sitemap, robots.txt, Meta tags قابلة للتعديل (hreflang المتقدم وStructured Data الكاملة تبقى P1)
Wishlist
Reviews (بدون نظام Moderation متقدم — موافقة بسيطة تكفي عند الإطلاق)
Q&A (نسخة أساسية)
Dark Mode
Cookie Consent
Order Tracking (صفحة تتبع بدون حساب إلزامي)
```

## P1 — Global Competitive Platform (المتبقي بعد نقل الحد الأدنى إلى P0)

```text
Shipping
Fulfillment
Returns/RMA
Advanced Tax (multi-jurisdiction, VAT/GST automation)
Multi-location inventory
Search (dedicated engine — Meilisearch or equivalent)
Themes/CMS
PWA advanced (Push Notifications)
SEO advanced (hreflang, full structured data)
i18n advanced (additional languages beyond Arabic/English/Turkish)
Markets (per-region storefront rules)
Currencies advanced (accounting-grade FX, multi-currency settlement)
Custom Domains (full CNAME/SSL automation per merchant)
Multi-storefront per tenant
Billing advanced (usage metering, grace periods, dunning)
Bulk Operations
Transactional Email (marketing-grade, beyond security-critical)
Public REST API
```

## P2 — Ecosystem / Differentiation

```text
App Marketplace
Developer Portal
SDKs
AI Gateway
Semantic Search
Recommendations
Merchant Copilot
B2B
Loyalty
Referral
Gift Cards
White Label
Multi-region
Advanced Analytics
```

> **ملاحظة:** "Subscriptions" هنا تعني اشتراكات العميل النهائي بمنتج معيّن (مثال: صندوق اشتراك شهري لمنتج)، وهي مختلفة عن "Billing" (اشتراك التاجر بالمنصة نفسها) المنقول أعلاه إلى P0.

---

# 55. Technology Decisions

| Area | Decision |
|---|---|
| Architecture | Modular Monolith |
| Database | PostgreSQL |
| ORM | Prisma |
| Pooling | Direct application pool at starter launch → PgBouncer/managed pool at scale |
| Cache | Redis at scale; PostgreSQL/HTTP-safe caching at starter launch |
| Queue | BullMQ at scale; transactional outbox + durable poller at starter launch |
| Search | PostgreSQL FTS at starter launch → Meilisearch/provider abstraction at scale |
| Payments | Stripe Connect + provider interface |
| Storage | R2/S3 abstraction |
| CDN/WAF | Cloudflare |
| Auth | Auth.js/NextAuth + secure password hashing |
| Secrets | Cloud/Vault at scale; protected environment secrets at starter launch with documented rotation |
| Observability | Structured logs + uptime/health monitoring at starter launch → Sentry/Prometheus/Grafana at scale |
| Deployment | Docker + VPS/managed containers initially |
| AI | Provider abstraction |

Technology must be justified by requirement, measured bottleneck, security need, or operational requirement.

## 55.1 Starter Stack — Budget-Constrained Launch Path (Added v1.5)

الجدول أعلاه يمثل البنية المستهدفة عند النمو (15+ tenant فعّال). لبدء الإطلاق الفعلي على ميزانية محدودة (VPS واحد بحدود $5-20/شهر) حتى الوصول لأول 10 عملاء، تُستبدل العناصر التالية مؤقتاً دون كسر العقود المعمارية بالأقسام السابقة (Provider abstraction تسمح بالاستبدال لاحقاً بدون إعادة كتابة):

| المكوّن | بدل البنية الثقيلة، ابدأ بـ | سبب الاستبدال |
|---|---|---|
| Redis + BullMQ | جدول `outbox_events` + Cron/worker بسيط داخل نفس العملية (polling كل بضع ثوانٍ) | Outbox أصلاً على PostgreSQL؛ لا حاجة لـ Redis حتى يثبت الحمل |
| Meilisearch | PostgreSQL Full-Text Search (`tsvector`) | يكفي لعدد منتجات محدود (آلاف قليلة)؛ Search abstraction تسمح بالتبديل لاحقاً |
| PgBouncer | اتصال مباشر بـ Prisma Connection Pool | غير ضروري بحمل منخفض على tenant واحد أو عدد قليل |
| Sentry + Prometheus/Grafana | تسجيل أخطاء بسيط (structured logs) + UptimeRobot مجاني للمراقبة | يكفي لمرحلة أقل من 15 tenant |
| Vault/Secrets Manager | متغيرات بيئة (`.env`) محمية بصلاحيات ملف صارمة (`chmod 600`) | يكفي لسيرفر واحد لا يزال قيد الإدارة اليدوية |

**شرط إجباري:** كل استبدال أعلاه يجب أن يبقى خلف نفس الواجهة/العقد المعماري المعرّف بالأقسام السابقة (Outbox contract, Search provider interface, إلخ)، بحيث الترقية لاحقاً للبنية الكاملة (Redis/BullMQ/Meilisearch) تكون **استبدال تنفيذ فقط دون تعديل منطق العمل**. المشغّل (Trigger) للترقية: تجاوز 15 tenant نشط، أو ظهور اختناق أداء فعلي مقاس (queue latency, DB CPU) — وليس افتراضاً مسبقاً.

---

# 56. Global Storefront Requirements (Amended v1.5 — Split P0/P1)

بعد تعديل التصنيف بالقسم 54، هذي القائمة مقسّمة صراحة:

**P0 — مطلوبة عند الإطلاق الأول (لا يجوز اعتبار P0 مكتملاً بدونها):**
```text
Responsive mobile-first UX
Dark mode
RTL (العربية كلغة افتراضية)
i18n (عربي + إنجليزي + تركي بجودة ترجمة كاملة عند الإطلاق)
SEO أساسي (Sitemap, robots.txt, Meta Title/Description قابلة للتعديل)
Open Graph أساسي
Wishlist (Schema: §64.4)
Reviews (نسخة أساسية، Schema: §64.4)
Q&A (نسخة أساسية، Schema: §64.4)
Cookie consent (تفاصيل: §56.1)
Order tracking (بدون حساب إلزامي، Schema: §64.7)
PWA أساسي (معايير قبول: §56.2)
```

## 56.1 Cookie Consent — نطاق دقيق (يغلق نقطة #19)

لا يكفي "شريط موافقة" بسيط؛ الحد الأدنى لـ P0:
```text
[ ] تصنيف صريح لفئات الكوكيز: essential | analytics | marketing | preferences
[ ] الافتراضي الآمن: essential = مفعّل دائماً (لا يحتاج موافقة) | non-essential = opt-in فقط (معطّل حتى موافقة صريحة)
[ ] جدول consent_records: (tenant_id, customer_id_or_anonymous_id, categories_accepted JSONB, consent_version, created_at)
[ ] حفظ نسخة (version) من نص سياسة الكوكيز وقت الموافقة، لإثبات الامتثال لاحقاً
```

## 56.2 PWA — معايير قبول صريحة (يغلق نقطة #18)

```text
[ ] Web App Manifest صحيح (name, icons, start_url, display: standalone)
[ ] أيقونات بكل الأحجام المطلوبة (192x192, 512x512 كحد أدنى)
[ ] HTTPS إجباري (شرط أساسي لعمل PWA أصلاً)
[ ] معايير Installability القياسية لمتصفح Chrome/Edge مستوفاة
[ ] Service Worker أساسي (تخزين مؤقت للأصول الثابتة فقط: CSS/JS/الشعار)
[ ] Offline fallback: صفحة "لا يوجد اتصال" بسيطة فقط
[ ] ممنوع صراحة بـ P0: أي محاولة دعم Offline Checkout أو Offline Payment — الدفع والسلة يتطلبان اتصال فعّال دائماً
[ ] التحقق عبر Lighthouse PWA audit (الهدف: علامة PWA خضراء، ليس بالضرورة 100%)
```

**P1 — توسعات لاحقة بعد استقرار القاعدة:**
```text
hreflang متقدم
Product structured data كاملة
Privacy controls متقدمة (لوائح خصوصية متعددة حسب الدولة)
Localized policies (سياسات مترجمة لكل لغة/دولة تلقائياً)
Push notifications
```

هذي الفئة الثانية (P1) فقط تبقى مؤجلة؛ الفئة الأولى (P0) إجبارية قبل اعتبار المنصة قابلة للبيع.

---

# 57. Monetization (Amended v1.5 — Basic Billing + Dynamic Plan Management Moved to P0)

**P0 — النسخة الأساسية (مطلوبة للإطلاق وأخذ أول اشتراك فعلي):**
```text
Subscription billing (باقة ثابتة شهرية واحدة أو أكثر عبر Stripe Billing)
Hybrid subscription + transaction fee model (التاجر يختار Subscription أو Commission)
Stripe Connect (ربط حساب كل تاجر لاستلام مدفوعاته مباشرة)
Merchant payout flows (أساسي)
Failed-payment handling (أساسي — إعادة محاولة + تعليق الحساب عند الفشل المتكرر)
Entitlements (أساسي — انظر §57.1: يجب أن تكون قابلة للتعديل من لوحة Super Admin، وليست Hardcoded)
```

**P1 — التوسعات المتقدمة لاحقاً مع النمو:**
```text
Usage metering when usage-based pricing is enabled
Plan limits متقدمة (حدود عدد منتجات/طلبات لكل باقة بمستوى تفصيلي أعمق)
Grace periods متقدمة
Dunning management (تسلسل تذكيرات الدفع الفاشل الآلي متعدد الخطوات)
```

Financial accounting for platform billing remains separate from merchant commerce ledger concerns.

## 57.1 Self-Service Plan & Entitlements Management (Added v1.5) — إلزامي بـ P0

**المتطلب الجوهري:** صاحب المنصة (Super Admin) يجب أن يتحكم بالباقات، الأسعار، والميزات المرتبطة بكل باقة **بالكامل من لوحة التحكم**، دون الحاجة للرجوع للمطور أو تعديل كود أو لوحة Stripe يدوياً لكل تغيير. هذا يشمل:

```text
[ ] واجهة CRUD كاملة بالـ Super Admin Dashboard لإدارة الباقات (Plans):
    - إنشاء/تعديل/تعطيل باقة جديدة (اسم، سعر شهري، سعر سنوي اختياري)
    - تفعيل/تعطيل خيار العمولة البديلة (Commission %) لكل باقة
[ ] واجهة إدارة الميزات (Feature Flags) لكل باقة، مثال:
    - max_products (رقم أو "unlimited")
    - languages_allowed (رقم أو "unlimited")
    - custom_domain (true/false)
    - payment_gateways_allowed (قائمة أو "all")
    - custom_css_html (true/false)
    - remove_platform_branding (true/false)
    - advanced_reports (true/false)
    - priority_support (true/false)
[ ] أي تعديل بالسعر أو الميزة من اللوحة يُطبّق تلقائياً:
    - يُزامن فورياً مع Stripe (تحديث Product/Price عبر API، وليس يدوياً بلوحة Stripe)
    - العملاء الحاليون على الباقة يتأثرون بالسياسة المحددة (فوري / عند التجديد القادم فقط) — يُحدَّد كل باقة تعديل بخيار "يطبّق على الاشتراكات الحالية أم الجديدة فقط؟"
[ ] كل ميزة بالنظام (سواء بالمتجر أو بلوحة التاجر) يجب أن تتحقق من entitlement التاجر الحالي عبر مصدر واحد مركزي (Entitlements Service)، وليس عبر شروط متفرقة بالكود (Hardcoded if-statements) — أي ميزة جديدة تُضاف لاحقاً تُربط بنفس النظام تلقائياً دون تعديل منطق تحقق منفصل لكل ميزة
[ ] عند تجاوز التاجر لحد الباقة (مثال: منتج رقم 101 بباقة محدودة بـ 100)، النظام يمنع الإجراء ويعرض رسالة توضح الحد + رابط مباشر للترقية (Upsell Prompt)
```

**Schema:** انظر §64.1 (جداول `plans`, `plan_versions`, `plan_prices`, `plan_features`, `subscriptions`, `tenant_entitlements`) — هذا القسم كان ناقص التفاصيل التنفيذية بـ v1.5 وتم إغلاقه بالكامل بـ v1.6.

**عقد إلزامي (Server-Authoritative، يغلق نقطة #7 من المراجعة المستقلة):**
```typescript
// يجب أن يكون هذا المصدر الوحيد للتحقق من الصلاحيات بكامل النظام —
// ممنوع أي "if (plan === 'pro')" متفرق بالكود خارج هذا العقد
interface EntitlementsService {
  has(tenantId: string, feature: string): Promise<boolean>;
  getLimit(tenantId: string, feature: string): Promise<number | 'unlimited'>;
  assertAllowed(tenantId: string, feature: string): Promise<void>; // يرمي خطأ 403 مع upsell hint إن رُفض
}
```
التنفيذ الداخلي يقرأ من `tenant_entitlements` (الجدول المشتق/Cache بـ §64.1)، وليس مباشرة من Stripe أو من متغيرات بيئة أو من شرط Hardcoded. أي endpoint أو مكوّن Frontend يحتاج التحقق من ميزة، يستدعي هذا العقد فقط.

**سبب اعتباره P0 وليس P1:** بما إن نموذج التسعير (اشتراك + عمولة) هو جزء أساسي من خطة العمل التجارية من اليوم الأول، فإن تثبيت الأسعار والميزات بالكود (Hardcoded) يعني أي تعديل تسعير مستقبلي = طلب من المطور + نشر كود جديد (Deployment). هذا غير مقبول تشغيلياً لصاحب منصة يحتاج مرونة تسعير مستمرة خصوصاً بمرحلة اختبار السوق الأولى (Early Pricing Experiments).

---

# 58. Operational Runbooks Required Before Production

```text
DB outage
Redis outage
Queue outage
Payment provider outage
Webhook storm
DLQ incident
Tenant isolation incident
Ledger discrepancy
Inventory oversell incident
Bad migration
Secret rotation
Backup restore
Provider reconciliation
Domain/DNS incident
CDN incident
```

Each runbook must include:

```text
Detection
Immediate containment
Diagnosis
Recovery
Verification
Communication
Postmortem
```

---

# 59. Final Architecture

```text
                         GLOBAL COMMERCE PLATFORM
                                   │
                  ┌────────────────┴────────────────┐
                  │                                 │
             CONTROL PLANE                      DATA PLANE
                  │                                 │
       Tenants / Billing / Plans            Catalog / Checkout
       Entitlements / Flags                 Orders / Payments
       RBAC / Compliance                    Inventory / Shipping
       Audit / Risk                         Customers / Storefront
                  │                                 │
                  └──────────────┬──────────────────┘
                                 │
                         PostgreSQL / RLS
                                 │
                        Transactional Outbox
                                 │
                         Redis / BullMQ
                                 │
                ┌────────────────┼─────────────────┐
                │                │                 │
             Workers          Webhooks         Analytics
                │
       ┌────────┼─────────┐
       │        │         │
     Media    Email      Push
       │
    R2/S3 + CDN

Derived systems:
Search / Cache / Analytics / Recommendations

External adapters:
Payments / Shipping / Tax
```

---

# 60. Final Engineering Position

هذه المنصة ليست Store Builder فقط.

هي **Commerce Infrastructure Platform** مبنية على:

```text
Strong financial correctness
Strong tenant isolation
Deterministic pricing
Transactional inventory
Idempotent payments
Immutable ledger
Transactional outbox
Asynchronous processing
Provider abstractions
Global localization foundation
Composable domains
Headless-ready API
Operational observability
```

ولا يلزم:

```text
Microservices
Kubernetes
Multi-region writes
GraphQL
Full B2B
App Marketplace
Advanced AI
```

قبل أن يثبت الحمل أو المتطلبات الحاجة إليها.

---

# 61. Final Start Condition

لا يبدأ فريق التطوير في تنفيذ P0 قبل اعتماد:

```text
[ ] PostgreSQL schema
[ ] RLS design
[ ] Transaction boundaries
[ ] Order state model
[ ] Payment state model
[ ] Inventory reservation contract
[ ] Ledger/account model
[ ] Outbox model
[ ] Idempotency contract
[ ] API error contract
[ ] Tenant isolation test suite
[ ] Backup/restore procedure
[ ] SLO targets
[ ] P0 Definition of Done
```

بعد الاعتماد:

```text
IMPLEMENT P0
    ↓
PASS GATE A
    ↓
PASS GATE B
    ↓
PASS GATE C
    ↓
PASS GATE D
    ↓
PASS GATE E
    ↓
COMMERCIAL LAUNCH
    ↓
P1
    ↓
P2
```

---

# 62. v1.3 Corrections / Final Schema Amendments

This section is normative and supersedes any conflicting v1.2 wording.

## 62.1 Applied schema corrections

```text
[✓] product_media relationship added
[✓] order_addresses snapshot table added
[✓] orders.customer_email_snapshot added
[✓] promotions schema added
[✓] coupons schema added
[✓] soft-delete-safe product slug uniqueness added
[✓] inventory available invariant formalized
[✓] journal entry currency made explicit
[✓] customer_addresses.type added
[✓] product_variants.status constrained
[✓] password-reset transactional email added to P0 operational checklist
```

## 62.2 Normative invariants

### Product slug
Only non-deleted products participate in tenant slug uniqueness.

### Inventory
```text
available = on_hand - reserved - committed
reserved + committed <= on_hand
```
The application MUST update these values transactionally while holding the inventory row lock. `SKIP LOCKED` is optional only for allocation workflows where skipping a busy row is semantically safe.

### Ledger currency
Each `journal_entry` has exactly one accounting currency. All journal lines in that entry MUST use the same currency. Foreign-exchange conversion MUST be represented by a separate journal entry/FX operation rather than mixing currencies inside one balanced entry.

### Order addresses
Billing and shipping addresses stored on an order are historical snapshots and MUST NOT be rewritten from the customer's current address book.

### Idempotency
For every endpoint classified as non-idempotent, the same idempotency key with a different canonical request hash MUST return HTTP 409 and MUST NOT create a second business effect.

## 62.3 P0 completion condition

P0 is not complete until the new schema objects, constraints, RLS policies, migrations, and tests are all included in CI and pass the applicable release gates.

---

# 61.1 Final Schema Completeness Gate

Before the P0 branch is considered implementation-ready:

```text
[ ] Every P0 domain entity listed in the Domain Model has either:
    - explicit DDL, or
    - an explicit documented adapter/external ownership boundary

[ ] Every tenant-scoped P0 table has:
    - tenant_id
    - RLS policy
    - tenant-aware indexes
    - cross-tenant test coverage

[ ] High-risk child relationships have composite tenant integrity enforcement

[ ] All immutable financial tables have DB privilege restrictions

[ ] Password reset token schema + email flow exist

[ ] Order address snapshot schema exists

[ ] P0 Tax schema and provider contract exist

[ ] P0 Security headers are defined

[ ] P0 Rate-limit contract is defined

[ ] P0 SLO targets are approved

[ ] CI validates migrations from an empty database
```



# 62.4 v1.4 Final Hardening Amendments

```text
[✓] order_addresses DDL added
[✓] P0 tax tables added
[✓] complete RLS coverage matrix added
[✓] composite tenant-integrity FK guidance added
[✓] ledger DB privilege immutability added
[✓] password reset token schema added
[✓] rate-limit contract added
[✓] HTTP security headers / CSP baseline added
[✓] P0 SLO baseline added
[✓] final schema completeness gate added
```

# 62.5 v1.5 Launch-Readiness Amendments

```text
[✓] P0 redefined as Minimum Sellable Product (MSP), not backend-only kernel
[✓] i18n/RTL (Arabic-first) moved from P1 → P0
[✓] Basic merchant Billing (subscription + commission via Stripe Connect) moved from P1 → P0
[✓] Basic Currencies (default + display conversion) moved from P1 → P0
[✓] Basic Domains (auto-subdomain via wildcard DNS) moved from P1 → P0
[✓] Basic PWA (installability) moved from P1 → P0
[✓] Basic SEO (sitemap, robots.txt, meta tags) moved from P1 → P0
[✓] Wishlist, Reviews (basic), Q&A (basic) moved from P1 → P0
[✓] Dark Mode, Cookie Consent, Order Tracking moved from P1 → P0
[✓] Self-Service Plan & Entitlements Management added to P0 (§57.1) — Super Admin
     controls plan pricing/features entirely from dashboard, synced to Stripe via API,
     no hardcoded prices or manual Stripe dashboard edits required for changes
[✓] Launch languages defined: Arabic (default) + English + Turkish, full-quality
     translation, i18n structure open for unlimited additional languages later
[✓] §55.1 Starter Stack added — budget-constrained launch path (single VPS $5–20/mo)
     replacing Redis/BullMQ/Meilisearch/PgBouncer/Sentry+Prometheus with lightweight
     equivalents behind the same architectural contracts, upgradeable without rewrite
[✓] Explicit upgrade trigger defined: 15+ active tenants OR measured bottleneck —
     not a default assumption
[✓] Advanced/enterprise-grade variants of the above (multi-currency accounting,
     custom domains, push notifications, advanced tax, usage metering, dunning)
     remain correctly in P1 — not removed, only re-sequenced
```

**سبب التعديل:** النسخة v1.4 كانت تصنّف كل ميزة ظاهرة للعميل (اللغة، الفوترة، العملة، الدومين) ضمن P1، بمعنى أن اكتمال P0 وحده كان سينتج بنية خلفية قوية جداً لكن **بدون منتج قابل للبيع فعلياً**. v1.5 لا تُسقط أي متطلب هندسي من v1.4 (كل الـRLS وLedger وIdempotency وGates باقية كما هي)، فقط تُعيد ترتيب الأولوية بحيث "P0 مكتمل" = "منتج جاهز لأول عميل حقيقي"، بدل أن يكون P0 مرحلة تحضيرية غير قابلة للاستخدام التجاري.

---

# 62.6 v1.7 Critical P0 Schema Amendments — Summary

```text
[✓] 64.1  Billing Schema كامل (plans, plan_versions, plan_prices, plan_features,
          billing_customers, subscriptions, subscription_items, billing_events,
          entitlements, tenant_entitlements)
[✓] 64.2  Platform Billing / Merchant Commerce Payment — فصل صريح، لا FK مباشر بينهما
[✓] 64.3  Currency — Display/Checkout/Settlement/Ledger موضّحة، P0 = عملة واحدة موحدة
[✓] 64.4  Wishlist / Reviews / Q&A — Schema كامل + cross-tenant guard
[✓] 64.5  Coupon Redemption — جدول مستقل + FOR UPDATE lock يمنع تجاوز usage_limit
[✓] 64.6  Promotion/Coupon Snapshot على order_items لإعادة بناء السجل المالي
[✓] 64.7  Order Tracking — نطاق P0 محدود صراحة (مرجع خارجي فقط، لا Fulfillment كامل)
[✓] 64.8  Domain Provisioning Contract — تطبيع hostname + منع collision بين tenants
[✓] 64.9  Merchant Onboarding — Commercial Critical Path من التسجيل حتى النشر
[✓] 64.10 Storefront Publishing State (DRAFT/PREVIEW/PUBLISHED/SUSPENDED)
[✓] 64.11 Platform Admin Domain — منفصل عن tenant_memberships، MFA إلزامي
[✓] 64.12 P0 API Endpoint Inventory — نموذج أولي بمعايير كل مسار جديد
[✓] 64.13 Canonical Event Catalog — 20 حدث أساسي بعقد موحّد
[✓] 64.14 Transaction Boundary Matrix — يمنع استدعاء شبكي داخل معاملة DB مفتوحة
[✓] 64.15 ملاحظات تكميلية: Tax inclusive/exclusive, RLS Control Plane,
          Audit hardening, .env security
[✓] Bug fix: trailing comma بجدول products (§4)
[✓] Contradiction fix: Rate Limiting Redis vs Starter Stack (§34.1)
[✓] Entitlements Service — عقد TypeScript صارم Server-Authoritative (§57.1)
[✓] 64.16 Missing P0 DDL closed: PriceList, ProductSEO, RecoveryCode, Connect account, basic Shipping, TaxRate,
          InventoryAdjustment, ReconciliationRecord, Settlement/Payout, FinancialTransaction, Cookie Consent, secure tracking token
```

**المصدر:** هذي التعديلات مبنية بالكامل على مراجعة هندسية مستقلة قيّمت v1.5 بـ 9.1/10 وحددت 25 ملاحظة، منها 10 نقاط حرجة اعتُبرت شرط P0 (وليست تحسينات اختيارية). v1.6 أغلقت العشر نقاط الحرجة الأساسية؛ v1.7 أغلقت أيضاً التناقضات المتبقية (Bug fixes وTax/RLS/Audit)، دون توسعة النطاق خارج P0 أو إضافة أي عنصر من P1/P2.

---

> **السياق:** مراجعة هندسية مستقلة على v1.5 كشفت أن نقل الميزات من P1 إلى P0 (بالقسم 54) غيّر **التصنيف** فقط دون إضافة الـ Schema/العقود التفصيلية المقابلة — بعكس بقية الوثيقة (Orders, Inventory, Ledger) المكتوبة بعمق SQL + Invariants كامل. هذا القسم يغلق الفجوة بإضافة نفس مستوى العمق لكل نقطة من العشر الحرجة المحددة، دون توسعة النطاق خارج P0 أو إضافة أي شيء من P1/P2.

---

# 64. v1.7 Critical P0 Schema — Full Detail

> السياق الكامل والمقدمة موضّحة بالقسم 62.6 أعلاه (الملخص). هذا القسم يحتوي التفاصيل التنفيذية الكاملة (SQL DDL + Invariants) لكل نقطة من العشر الحرجة.

## 64.1 Billing Domain Model — Schema كامل

```sql
CREATE TABLE plans (
  id UUID PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,              -- e.g. 'basic', 'pro', 'whitelabel'
  name TEXT NOT NULL,
  stripe_product_id TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE plan_versions (
  id UUID PRIMARY KEY,
  plan_id UUID NOT NULL REFERENCES plans(id),
  version INT NOT NULL,
  is_current BOOLEAN NOT NULL DEFAULT true,
  effective_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  effective_to TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (plan_id, version)
);

CREATE TABLE plan_prices (
  id UUID PRIMARY KEY,
  plan_version_id UUID NOT NULL REFERENCES plan_versions(id),
  billing_interval TEXT NOT NULL,          -- 'monthly' | 'yearly'
  amount_minor_units BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  stripe_price_id TEXT,                    -- synced, not source of truth
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE plan_features (
  id UUID PRIMARY KEY,
  plan_version_id UUID NOT NULL REFERENCES plan_versions(id),
  feature_key TEXT NOT NULL,               -- e.g. 'max_products', 'custom_domain'
  value_type TEXT NOT NULL,                -- 'boolean' | 'integer' | 'unlimited'
  value_boolean BOOLEAN,
  value_integer INT,
  UNIQUE (plan_version_id, feature_key)
);

-- P0 billing integrity additions
CREATE UNIQUE INDEX uq_plan_version_current
  ON plan_versions(plan_id)
  WHERE is_current = true;

CREATE UNIQUE INDEX uq_plan_price_variant
  ON plan_prices(plan_version_id, billing_interval, currency);

CREATE INDEX idx_plan_prices_version
  ON plan_prices(plan_version_id);

CREATE TABLE billing_customers (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id) UNIQUE,
  stripe_customer_id TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE subscriptions (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  plan_version_id UUID NOT NULL REFERENCES plan_versions(id),  -- pinned, not plan_id
  billing_customer_id UUID NOT NULL REFERENCES billing_customers(id),
  status TEXT NOT NULL,                    -- trialing|active|past_due|canceled|suspended
  pricing_model TEXT NOT NULL,             -- 'subscription' | 'commission'
  commission_percent NUMERIC(5,2),         -- required if pricing_model = 'commission'
  stripe_subscription_id TEXT,
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE subscription_items (
  id UUID PRIMARY KEY,
  subscription_id UUID NOT NULL REFERENCES subscriptions(id),
  plan_price_id UUID NOT NULL REFERENCES plan_prices(id),
  quantity INT NOT NULL DEFAULT 1,
  CHECK (quantity > 0)
);

CREATE TABLE billing_events (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  subscription_id UUID REFERENCES subscriptions(id),
  event_type TEXT NOT NULL,                -- invoice.paid, invoice.failed, ...
  provider_event_id TEXT NOT NULL UNIQUE,  -- Stripe event id, dedup key
  payload JSONB NOT NULL,
  status TEXT NOT NULL DEFAULT 'RECEIVED',
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status IN ('RECEIVED','PROCESSING','PROCESSED','FAILED'))
);

CREATE TABLE entitlements (
  id UUID PRIMARY KEY,
  feature_key TEXT NOT NULL UNIQUE,
  description TEXT
);

CREATE TABLE tenant_entitlements (
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  feature_key TEXT NOT NULL REFERENCES entitlements(feature_key),
  value_type TEXT NOT NULL,
  value_boolean BOOLEAN,
  value_integer INT,
  source_subscription_id UUID REFERENCES subscriptions(id),  -- resolved cache, not authoritative
  resolved_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, feature_key)
);
```

**Invariant:** `subscriptions.plan_version_id` هو المرجع الرسمي، وليس `plan_id` مباشرة — هذا يحل نقطة #8 (Plan Versioning). تعديل سعر/ميزة بالباقة (§57.1) ينشئ `plan_version` جديد بدل تعديل النسخة القديمة. `tenant_entitlements` جدول **مشتق (cache)** يُعاد بناؤه من `subscriptions.plan_version_id → plan_features`، وليس مصدر حقيقة مستقل — يُعاد حسابه عند أي تغيير اشتراك (Outbox event: `entitlement.changed`).

**قرار §57.1 "فوري أم عند التجديد":** يُنفَّذ عبر إما (أ) تحديث `subscriptions.plan_version_id` فوراً لكل الاشتراكات النشطة على الخطة القديمة، أو (ب) وضع `effective_from` مستقبلي على `plan_version` الجديد بحيث الاشتراكات الحالية تبقى مربوطة بالنسخة القديمة حتى `current_period_end`. القرار (أ) أو (ب) يُحدَّد لكل تعديل من واجهة Super Admin كما هو موصوف بـ §57.1.

## 64.2 فصل صريح: Platform Billing مقابل Merchant Commerce Payment

```text
PLATFORM BILLING (التاجر يدفع للمنصة)
  Tenant → billing_customers → Stripe Billing (Customer + Subscription)
  → invoice paid → billing_events → subscriptions.status = active

MERCHANT COMMERCE PAYMENT (عميل التاجر يدفع للتاجر عبر المنصة)
  Customer → PaymentIntent → Stripe Connect (Merchant's connected account)
  → payment_captures → merchant receives funds directly
  → application_fee_amount (إن استُخدم نموذج Commission) → منفصل تماماً في journal_entry خاص بالمنصة
```

**Invariant إجباري:** `PaymentIntent`/`PaymentCapture` (قسم 19، دفعات عملاء التاجر) و`billing_events`/`subscriptions` (اشتراك التاجر بالمنصة) **جدولان منفصلان بالكامل بدون أي مرجع FK مباشر بينهما**. العمولة (Commission) المستحقة على المنصة من مبيعات التاجر تُسجَّل بـ `journal_entry` منفصل بنوع `platform_commission`، لا تُخلط مطلقاً مع `journal_entry` الخاص بتسوية التاجر (Merchant Settlement). هذا يمنع بالضبط الخطأ المحاسبي المذكور بنقطة #2 من المراجعة.

## 64.3 Currency — توضيح صريح (يغلق نقطة #3)

```text
Display Currency  → عرض السعر للزائر فقط (تحويل تقريبي مقبول، Cosmetic only)
Checkout Currency → العملة الفعلية التي يُخصم بها الدفع (ثابتة = عملة التاجر الافتراضية في P0)
Settlement Currency → العملة التي يستلمها التاجر (= Checkout Currency في P0، لا تحويل)
Ledger Currency → نفس Checkout Currency لكل journal_entry (كما هو مثبت أصلاً بقسم 62.2)
```

**قاعدة P0 صارمة:** `Checkout Currency = Settlement Currency = Ledger Currency` دائماً (بدون استثناء) = عملة التاجر الافتراضية (`tenants.default_currency`). التحويل التقريبي **مسموح فقط** بواجهة العرض قبل الدخول لصفحة الدفع؛ بمجرد دخول Checkout، يُعرض السعر النهائي بعملة التاجر فقط، بدون التباس. تحويل عملة الدفع الفعلي (Multi-currency settlement) يبقى P1 كما هو مصنّف أصلاً.

## 64.4 Wishlist / Reviews / Q&A — Schema

```sql
CREATE TABLE wishlists (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  customer_id UUID NOT NULL REFERENCES customers(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, customer_id)
);

CREATE TABLE wishlist_items (
  wishlist_id UUID NOT NULL REFERENCES wishlists(id),
  product_id UUID NOT NULL REFERENCES products(id),
  tenant_id UUID NOT NULL REFERENCES tenants(id),   -- denormalized for RLS + cross-tenant guard
  added_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (wishlist_id, product_id)
);

CREATE TABLE reviews (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  product_id UUID NOT NULL REFERENCES products(id),
  customer_id UUID NOT NULL REFERENCES customers(id),
  order_id UUID NOT NULL REFERENCES orders(id),      -- P0 requires a verified order
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  body TEXT,
  status TEXT NOT NULL DEFAULT 'pending',   -- pending|approved|rejected
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, order_id, product_id, customer_id)
);

CREATE TABLE review_questions (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  product_id UUID NOT NULL REFERENCES products(id),
  customer_id UUID NOT NULL REFERENCES customers(id),
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'unanswered', -- unanswered|answered|hidden
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE review_answers (
  id UUID PRIMARY KEY,
  question_id UUID NOT NULL REFERENCES review_questions(id),
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  answered_by_user_id UUID NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

**Cross-tenant guard (إجباري):** كل جدول أعلاه يحمل `tenant_id` صراحة، وRLS policy يتحقق أن `product_id` و`customer_id` و`order_id` كلها تنتمي لنفس `tenant_id` عبر composite FK أو trigger. P0 reviews require a verified `order_id`; the server MUST confirm that the order belongs to the customer, contains the product, and is in `DELIVERED` before accepting the review. Q&A answers require tenant membership plus the applicable merchant/staff permission.

## 64.5 Coupon Redemption — Concurrency-Safe (يغلق نقطة #9)

```sql
CREATE TABLE coupon_redemptions (
  id UUID PRIMARY KEY,
  coupon_id UUID NOT NULL REFERENCES coupons(id),
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  customer_id UUID REFERENCES customers(id),
  order_id UUID NOT NULL REFERENCES orders(id),
  idempotency_key TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, coupon_id, order_id),
  UNIQUE (tenant_id, idempotency_key)
);
```

**Invariant:** حجز استخدام الكوبون يتم عبر معاملة واحدة (single DB transaction) تجمع:
```text
SELECT usage_count, usage_limit FROM coupons WHERE id = :id FOR UPDATE;
-- تحقق usage_count < usage_limit داخل نفس القفل
INSERT INTO coupon_redemptions (...);  -- يفشل تلقائياً لو تكرر (coupon_id, order_id)
UPDATE coupons SET usage_count = usage_count + 1 WHERE id = :id;
-- If the linked promotion has a usage_limit, lock the promotion in a
-- deterministic order and increment promotions.usage_count in the same transaction.
UPDATE promotions
SET usage_count = usage_count + 1
WHERE id = (SELECT promotion_id FROM coupons WHERE id = :id)
  AND (usage_limit IS NULL OR usage_count < usage_limit);
```
القفل (`FOR UPDATE`) على صف الكوبون نفسه يمنع طلبين متزامنين من تجاوز `usage_limit` — هذا يغلق ثغرة Race Condition المذكورة بالمراجعة.

## 64.6 Promotion/Coupon Snapshot على مستوى الطلب (يغلق نقطة #10)

```sql
CREATE TABLE discount_applications (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  order_id UUID NOT NULL REFERENCES orders(id),
  order_item_id UUID REFERENCES order_items(id),
  promotion_id UUID REFERENCES promotions(id),
  coupon_id UUID REFERENCES coupons(id),
  discount_type TEXT NOT NULL,
  amount_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  code_snapshot TEXT,
  promotion_name_snapshot TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (discount_type IN ('PERCENTAGE', 'FIXED')),
  CHECK (amount_minor >= 0)
);

CREATE INDEX idx_discount_applications_order
  ON discount_applications(tenant_id, order_id);

ALTER TABLE order_items
  ADD COLUMN discount_total_minor BIGINT NOT NULL DEFAULT 0;
```

`discount_applications` is the canonical historical discount record. Order-level and item-level discounts are both supported; historical snapshots remain reproducible after later coupon/promotion changes.

## 64.7 Order Tracking — الحد الأدنى لـ P0 (يغلق نقطة #5)

```sql
CREATE TABLE order_tracking_references (
  id UUID PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES orders(id),
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  carrier_name TEXT,
  tracking_number TEXT,
  tracking_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```
**نطاق P0 صريح:** هذا الجدول فقط — مرجع تتبع خارجي (رقم/رابط) يُدخله التاجر يدوياً بلوحة التحكم عند تحديث حالة الطلب لـ "تم الشحن". **لا يجوز** للمطور بناء `Shipment`/`Fulfillment`/`TrackingEvent` الكاملة أو التكامل التلقائي مع شركات الشحن ضمن P0 — هذا يبقى P1 كما هو مصنّف أصلاً بقسم 56/57.

## 64.8 Domain Provisioning Contract (يغلق نقطة #6)

```text
tenant.slug (unique, lowercase, [a-z0-9-]+, reserved words blocked)
      ↓
storefront.slug (defaults to tenant.slug, can diverge)
      ↓
generated_hostname = tenant.slug || '.' || PLATFORM_ROOT_DOMAIN
      ↓
Domain Resolution Middleware:
  1. Extract Host header
  2. Normalize (lowercase, strip port, reject non-ASCII unless punycode-decoded)
  3. Lookup storefront by hostname (exact match only — no partial/wildcard app-level matching)
  4. If not found → 404 (never fall back to a default tenant)
  5. If found but storefront.status != PUBLISHED → 503 "store unavailable"
  6. Bind resolved tenant_id to request context BEFORE any RLS-scoped query executes
```

**Security invariants:**
```text
[ ] Reserved subdomains blocked at slug-creation time: www, api, admin, app, cdn, mail, ftp, ns1, ns2
[ ] hostname → tenant_id resolution is a single authoritative lookup (unique index on hostname), never inferred from partial string matching
[ ] Tenant A's storefront can never resolve to Tenant B's hostname — enforced by UNIQUE constraint on storefronts.hostname, not application logic alone
[ ] Suspended tenant (tenants.status = SUSPENDED) → hostname resolves but storefront returns 503, does not 404 (avoids leaking "does this store exist" ambiguity while still blocking access)
```

## 64.9 Merchant Onboarding — Commercial Critical Path (يغلق نقطة #23)

```text
1. Merchant signup (email + password, or Google OAuth) → users row created
2. Create tenant (status=PROVISIONING) → tenant_memberships row (owner role)
3. Setup Wizard: store name, logo (optional), default_locale, default_currency
4. Create/resolve `billing_customers` and choose plan/version
5. Create subscription state:
   - subscription model → Stripe Billing subscription
   - commission model → local commercial configuration; Stripe Billing subscription not required
6. Complete Stripe Connect onboarding when merchant payments are enabled
7. Create first product (at least 1 product required before publish is allowed)
8. Provision generated storefront hostname/domain record
9. Validate billing/payment prerequisites and set `tenant.status = ACTIVE`
10. Storefront status: DRAFT → PREVIEW → PUBLISHED
```

**Acceptance criteria:** لا يجوز أن يصير `storefront.status = PUBLISHED` قبل اكتمال الخطوات 1-9، بما فيها `tenant.status = ACTIVE`, وجود domain resolution record، ووجود المنتج الأول. This removes the ACTIVE/PUBLISHED dependency cycle.

## 64.10 Storefront Publishing State (يغلق نقطة #24)

```text
Canonical status is defined in §7; allowed values are:
DRAFT | PREVIEW | PUBLISHED | SUSPENDED
```
```text
قاعدة عرض صارمة:
الزائر العام يرى المتجر فقط إذا:
  tenants.status = 'ACTIVE'
  AND storefronts.status = 'PUBLISHED'
أي حالة أخرى → 404 (DRAFT/PREVIEW) أو 503 (SUSPENDED) حسب §64.8
```

## 64.11 Platform Admin Domain (يغلق نقطة #25)

```sql
CREATE TABLE platform_admins (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) UNIQUE,
  platform_role TEXT NOT NULL,   -- 'super_admin' | 'billing_admin' | 'support_admin'
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```
**Invariant:** وصول Control Plane يتطلب `platform_admins` + MFA مفعّل، وهو منفصل تماماً عن `tenant_memberships`.

لا يُسمح باستخدام `SET LOCAL app.platform_admin = true` كحد أمني وحيد؛ custom GUC يمكن للـruntime تعيينه ولا يُعتبر دليلاً موثوقاً على هوية أو صلاحية المستخدم. لذلك يعتمد P0 على **DB trust boundary منفصل**:

```text
Normal tenant requests  → application runtime DB role
Platform-admin requests  → dedicated platform-admin DB role/pool
                         → credentials are server-side only
                         → MFA + platform_admins checked before role/pool selection
                         → every cross-tenant action audited
```

The normal runtime role MUST NOT have `BYPASSRLS`, table ownership, or permission to assume the platform-admin role.

## 64.12 P0 API Endpoint Inventory — Normative Launch Surface

The following is the complete P0 HTTP surface. Any endpoint added beyond this list is a specification change and must be added to this registry before implementation merge.

| Method | Path | Auth | Permission | Tenant scope | Idempotent |
|---|---|---|---|---|---|
| POST | `/v1/auth/register` | none | — | no | yes by canonical email/registration key |
| POST | `/v1/auth/login` | none | — | no | n/a |
| POST | `/v1/auth/logout` | session | — | user/session | yes |
| POST | `/v1/auth/password-reset/request` | none | — | no | yes |
| POST | `/v1/auth/password-reset/confirm` | reset token | — | user | yes |
| GET | `/v1/me` | session | — | user | n/a |
| POST | `/v1/tenants` | session | — | creates tenant | yes |
| GET | `/v1/tenants/:id` | session | — | tenant | n/a |
| PATCH | `/v1/tenants/:id` | session | settings.manage | tenant | version-checked |
| GET | `/v1/members` | session | staff.manage | tenant | n/a |
| POST | `/v1/members` | session | staff.manage | tenant | yes |
| PATCH | `/v1/members/:id` | session | staff.manage | tenant | version-checked |
| DELETE | `/v1/members/:id` | session | staff.manage | tenant | yes |
| POST | `/v1/mfa/factors` | session | — | user | yes |
| POST | `/v1/mfa/factors/:id/verify` | session | — | user | yes |
| DELETE | `/v1/mfa/factors/:id` | session | — | user | yes |
| GET | `/v1/storefront` | session/public* | — | tenant | n/a |
| PATCH | `/v1/storefront` | session | settings.manage | tenant | version-checked |
| POST | `/v1/storefront/preview-token` | session | settings.manage | tenant | yes |
| POST | `/v1/storefront/publish` | session | settings.manage | tenant | yes |
| POST | `/v1/domains/provision` | session | settings.manage | tenant | yes |
| GET | `/v1/domains` | session | settings.manage | tenant | n/a |
| POST | `/v1/products` | session | products.write | tenant | yes |
| GET | `/v1/products` | session/public* | products.read* | tenant | n/a |
| GET | `/v1/products/:id` | session/public* | products.read* | tenant | n/a |
| PATCH | `/v1/products/:id` | session | products.write | tenant | version-checked |
| DELETE | `/v1/products/:id` | session | products.write | tenant | yes |
| POST | `/v1/products/:id/variants` | session | products.write | tenant | yes |
| PATCH | `/v1/products/:id/variants/:variantId` | session | products.write | tenant | version-checked |
| DELETE | `/v1/products/:id/variants/:variantId` | session | products.write | tenant | yes |
| POST | `/v1/categories` | session | products.write | tenant | yes |
| PATCH | `/v1/categories/:id` | session | products.write | tenant | version-checked |
| DELETE | `/v1/categories/:id` | session | products.write | tenant | yes |
| POST | `/v1/media` | session | products.write | tenant | yes |
| DELETE | `/v1/media/:id` | session | products.write | tenant | yes |
| GET | `/v1/cart` | guest/session | — | tenant | n/a |
| POST | `/v1/cart` | guest/session | — | tenant | yes |
| PATCH | `/v1/cart/items/:itemId` | guest/session | — | tenant | version-checked |
| DELETE | `/v1/cart/items/:itemId` | guest/session | — | tenant | yes |
| POST | `/v1/cart/merge` | session | — | tenant | yes |
| POST | `/v1/checkout` | guest/session | — | tenant | yes |
| POST | `/v1/orders` | guest/session | — | tenant | yes |
| GET | `/v1/orders/:id` | session/public-token* | orders.read* | tenant | n/a |
| POST | `/v1/orders/:id/cancel` | session | orders.cancel | tenant | yes |
| POST | `/v1/orders/:id/refund` | session | orders.refund | tenant | yes |
| POST | `/v1/orders/:id/tracking` | session | orders.manage | tenant | yes |
| POST | `/v1/inventory/reservations` | session/internal | inventory.write | tenant | yes |
| POST | `/v1/inventory/reservations/:id/release` | session/internal | inventory.write | tenant | yes |
| POST | `/v1/inventory/adjustments` | session | inventory.write | tenant | yes |
| POST | `/v1/payments/intents` | guest/session | — | tenant | yes |
| POST | `/v1/payments/:id/capture` | internal/session | finance.manage | tenant | yes |
| POST | `/v1/payments/:id/void` | internal/session | finance.manage | tenant | yes |
| POST | `/v1/refunds` | session/internal | orders.refund | tenant | yes |
| GET | `/v1/finance/reconciliation` | session | finance.read | tenant | n/a |
| GET | `/v1/plans` | platform_admin | — | platform | n/a |
| POST | `/v1/admin/plans` | platform_admin | — | platform | yes |
| PATCH | `/v1/admin/plans/:id` | platform_admin | — | platform | yes |
| POST | `/v1/admin/plans/:id/publish-version` | platform_admin | — | platform | yes |
| POST | `/v1/merchant/payment-account/onboard` | session | settings.manage | tenant | yes |
| GET | `/v1/merchant/payment-account` | session | settings.manage | tenant | n/a |
| POST | `/v1/shipping-methods` | session | settings.manage | tenant | yes |
| PATCH | `/v1/shipping-methods/:id` | session | settings.manage | tenant | version-checked |
| DELETE | `/v1/shipping-methods/:id` | session | settings.manage | tenant | yes |
| GET | `/v1/tax-rates` | session | settings.manage | tenant | n/a |
| POST | `/v1/tax-rates` | session | settings.manage | tenant | yes |
| POST | `/v1/subscriptions` | session | billing.manage | tenant | yes |
| GET | `/v1/subscription` | session | billing.manage | tenant | n/a |
| POST | `/v1/subscription/change-plan` | session | billing.manage | tenant | yes |
| POST | `/v1/subscription/cancel` | session | billing.manage | tenant | yes |
| GET | `/v1/entitlements` | session | — | tenant | n/a |
| POST | `/v1/wishlist` | session | — | tenant | yes |
| POST | `/v1/wishlist/items` | session | — | tenant | yes |
| DELETE | `/v1/wishlist/items/:productId` | session | — | tenant | yes |
| POST | `/v1/reviews` | session | — | tenant | yes |
| PATCH | `/v1/reviews/:id/moderate` | session | products.write | tenant | yes |
| POST | `/v1/questions` | session | — | tenant | yes |
| POST | `/v1/questions/:id/answers` | session | products.write/staff | tenant | yes |
| GET | `/v1/orders/:id/tracking` | public-token/session | — | tenant | n/a |
| POST | `/v1/webhooks/stripe` | provider signature | — | resolved | yes by provider event ID |
| GET | `/v1/health` | none | — | platform | n/a |
| GET | `/v1/ready` | none | — | platform | n/a |
| POST | `/v1/admin/tenants/:id/suspend` | platform_admin | — | platform | yes |
| POST | `/v1/admin/tenants/:id/reactivate` | platform_admin | — | platform | yes |
| GET | `/v1/admin/audit` | platform_admin | — | platform | n/a |

`public*` routes are only public when the host resolves to a `PUBLISHED` storefront; tenant dashboard access still requires authenticated permission checks. Public order tracking uses an opaque, high-entropy tracking token and MUST NOT expose sequential order identifiers.

**قاعدة إلزامية لأي مسار جديد:** كل endpoint جديد يُضاف أثناء التنفيذ يجب أن يُوثَّق بنفس الأعمدة الستة أعلاه قبل الدمج (merge)، ضمن Definition of Done (قسم 52).

## 64.13 Canonical Event Catalog — Normative P0

Each event follows the §66.10 envelope:

```text
event_name
schema_version
event_id
aggregate_type
aggregate_id
tenant_id
producer
occurred_at
correlation_id
causation_id
payload
```

Canonical P0 events:

```text
tenant.created
tenant.activated
tenant.suspended
tenant.reactivated
storefront.created
storefront.published
storefront.suspended
domain.provisioned
product.created
product.updated
product.deleted
variant.created
variant.updated
inventory.reserved
inventory.released
inventory.adjusted
order.created
order.confirmed
order.cancelled
order.shipped
order.delivered
order.tracking.updated
payment.intent.created
payment.authorized
payment.captured
payment.failed
payment.voided
refund.created
refund.completed
coupon.redeemed
promotion.usage.incremented
subscription.created
subscription.updated
subscription.cancelled
billing.payment_succeeded
billing.payment_failed
entitlement.changed
wishlist.item_added
wishlist.item_removed
review.submitted
review.moderated
question.submitted
question.answered
media.created
media.deleted
audit.security_event
```

Payload rules:

```text
tenant_id is mandatory for tenant events.
Platform-only admin events may use null tenant_id only when the action is explicitly platform-scoped.
No event may contain plaintext secrets, payment credentials, password hashes, or reset tokens.
PII included in payload must be strictly necessary for downstream processing.
schema_version increments on breaking payload changes.
```

## 64.14 Transaction Boundary Matrix (يغلق نقطة #22)

| Operation | Transaction Boundary |
|---|---|
| Create order | DB transaction (order + order_items + order_addresses معاً) |
| Reserve inventory | DB transaction (نفس معاملة إنشاء الطلب، قفل صف المخزون) |
| Coupon redemption | DB transaction (§64.5 — قفل صف الكوبون + إدراج redemption) |
| Capture payment | Internal state transaction أولاً (PaymentAttempt) **ثم** استدعاء خارجي لـ Stripe؛ لا يجوز عكس الترتيب |
| Refund | DB transaction لتسجيل نية الاسترجاع، ثم استدعاء Provider، ثم DB transaction ثانية لتأكيد الحالة النهائية (Saga-style، ليس معاملة واحدة تمتد عبر شبكة) |
| Ledger posting | DB transaction (journal_entry + journal_lines معاً، متوازنة، لا يجوز كتابة جزئية) |
| Plan/Subscription update | DB transaction محلية أولاً (تسجيل النية) → استدعاء Stripe API → DB transaction ثانية لتأكيد النتيجة عبر Webhook (billing_events) |
| Merchant onboarding state transition | DB transaction per local state transition; external provider steps occur outside the DB transaction and are reconciled by webhook |
| Domain provisioning | DB transaction for tenant/storefront/domain rows; hostname uniqueness enforced by DB |
| Storefront publish | DB transaction validates tenant ACTIVE, first product, domain readiness, required settings, then writes state + outbox |
| Wishlist mutation | DB transaction with uniqueness enforcement |
| Review submission | DB transaction validates customer/order/product tenant integrity + outbox |
| Q&A submission/answer | DB transaction; answer requires merchant/staff authorization |
| Order tracking update | DB transaction updates tracking reference + status history + outbox |
| Entitlement resolution | Strongly consistent subscription/plan_version read for authorization-critical decisions; projection refresh may be async but stale projections MUST fail closed |
| Stripe webhook | DB transaction persists dedupe record + state mutation + outbox; ACK only after durable persistence |
| Outbox creation | **دائماً** بنفس معاملة DB التي أنتجت الحدث — ممنوع إدراج Outbox event بمعاملة منفصلة |

**القاعدة الذهبية:** أي عملية تتضمن استدعاء مزود خارجي (Stripe، بوابة شحن) تُقسَّم دائماً لمرحلتين: (1) تسجيل النية محلياً بمعاملة DB، (2) الاستدعاء الخارجي، (3) تأكيد النتيجة بمعاملة DB ثانية عبر Webhook/Response — لا يجوز أبداً وضع استدعاء شبكة خارجي **داخل** معاملة DB مفتوحة (يمنع قفل صفوف طويل الأمد بانتظار شبكة خارجية).

## 64.15 ملاحظات تكميلية سريعة (تغلق النقاط الثانوية المتبقية من المراجعة المستقلة)

**Tax inclusive/exclusive (نقطة #11):** كل `TaxCalculationContext` (قسم 27) يجب أن يحمل حقل صريح `price_display_mode: 'tax_inclusive' | 'tax_exclusive'` على مستوى كل Storefront، محدَّد من إعدادات التاجر. السعر `100` بدون هذا الحقل غامض وممنوع؛ يُحسب دائماً صراحة أي جزء منه ضريبة.

**RLS للـ Control Plane (نقطة #14):** `tenants` وجداول Control Plane الأخرى لا تخضع لنفس RLS policy البسيطة المعتمدة على `app.current_tenant` (قسم 30). الوصول يتم عبر دورين منفصلين صراحة: `tenant-scoped role` (يرى فقط `tenant_memberships` الخاصة به) و`platform-admin role` (وصول متحكم عبر السياق الصريح المعرّف بـ §64.11) — وليس تجاوز RLS دائم لأي دور.

**Audit hardening (نقطة #15):** جدول `audit_events` (قسم 26) يُمنع منه صلاحية `UPDATE`/`DELETE` على مستوى قاعدة البيانات لدور التطبيق (نفس مبدأ Ledger immutability بقسم 23.1)، ويحمل إلزامياً: `who, what, when, tenant_id, resource, before, after, request_id, correlation_id, ip, user_agent` — خصوصاً لعمليات billing/permissions/refund/inventory adjustment/plan change/entitlement change/domain change.

**أمان `.env` بمرحلة Starter Stack (نقطة #16):** بالإضافة لـ `chmod 600` (§55.1)، إلزامي: الملف خارج Git تماماً (`.gitignore`)، توثيق إجراء دوري لتدوير الأسرار (Secret Rotation) ولو يدوياً بهذي المرحلة، نسخ احتياطي مشفّر (Encrypted Backup) لا يحتوي القيم بنص صريح بدون تشفير، وممنوع ظهور أي secret بسجلات التطبيق (Logs) تحت أي ظرف.

---

# 64.16 P0 Schema Completeness Additions — Normative

The independent re-audit found several entities named as P0 domains but not previously given executable DDL. The following closes that gap without moving P1 capabilities into P0.

## 64.16.1 Basic Price Lists

```sql
CREATE TABLE price_lists (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  is_default BOOLEAN NOT NULL DEFAULT false,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  currency CHAR(3) NOT NULL,
  UNIQUE (tenant_id, code),
  CHECK (status IN ('ACTIVE','INACTIVE'))
);

CREATE UNIQUE INDEX uq_default_price_list
  ON price_lists(tenant_id)
  WHERE is_default = true;

ALTER TABLE prices
  ADD COLUMN price_list_id UUID REFERENCES price_lists(id);

CREATE UNIQUE INDEX uq_price_list_variant_currency
  ON prices(tenant_id, price_list_id, variant_id, currency);
```

P0 uses one default price list per tenant. Multiple market-specific price lists are a later extension.

## 64.16.2 Product SEO

```sql
CREATE TABLE product_seo (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  product_id UUID NOT NULL REFERENCES products(id),
  canonical_url TEXT,
  meta_title TEXT,
  meta_description TEXT,
  og_title TEXT,
  og_description TEXT,
  robots TEXT,
  UNIQUE (tenant_id, product_id)
);
```

## 64.16.3 MFA Recovery Codes

```sql
CREATE TABLE recovery_codes (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  code_hash TEXT NOT NULL UNIQUE,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_recovery_codes_user
  ON recovery_codes(user_id);
```

Recovery codes are stored only as cryptographic hashes and are single-use.

## 64.16.4 Basic Merchant Payment Account / Stripe Connect

```sql
CREATE TABLE merchant_payment_accounts (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id) UNIQUE,
  provider TEXT NOT NULL,
  provider_account_id TEXT NOT NULL UNIQUE,
  onboarding_status TEXT NOT NULL,
  charges_enabled BOOLEAN NOT NULL DEFAULT false,
  payouts_enabled BOOLEAN NOT NULL DEFAULT false,
  details_submitted BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

For P0, Stripe Connect is the provider. The account record is the source of local onboarding state; provider state is reconciled asynchronously.

## 64.16.5 Basic Shipping — Free / Flat Rate Only

```sql
CREATE TABLE shipping_methods (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  method_type TEXT NOT NULL,
  amount_minor BIGINT NOT NULL DEFAULT 0,
  currency CHAR(3) NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true,
  position INT NOT NULL DEFAULT 0,
  UNIQUE (tenant_id, name),
  CHECK (method_type IN ('FREE','FLAT_RATE')),
  CHECK (amount_minor >= 0),
  CHECK (position >= 0)
);

CREATE INDEX idx_shipping_methods_tenant
  ON shipping_methods(tenant_id, active, position);
```

P0 checkout calculates only these deterministic merchant-defined methods. `ShippingProvider` integrations remain P1.

## 64.16.6 Tax Rates — Basic P0 Engine

```sql
CREATE TABLE tax_rates (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  jurisdiction_id UUID NOT NULL REFERENCES tax_jurisdictions(id),
  tax_class_id UUID NOT NULL REFERENCES tax_classes(id),
  rate_bps INT NOT NULL,
  price_display_mode TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true,
  valid_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  valid_to TIMESTAMPTZ,
  CHECK (rate_bps >= 0 AND rate_bps <= 10000),
  CHECK (price_display_mode IN ('tax_inclusive','tax_exclusive'))
);

CREATE INDEX idx_tax_rates_lookup
  ON tax_rates(tenant_id, jurisdiction_id, tax_class_id, active, valid_from);
```

P0 requires a deterministic basic rate table. Full multi-jurisdiction automation remains P1.

## 64.16.7 Inventory Adjustments

```sql
CREATE TABLE inventory_adjustments (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  inventory_item_id UUID NOT NULL REFERENCES inventory_items(id),
  delta_on_hand BIGINT NOT NULL,
  reason TEXT NOT NULL,
  actor_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_inventory_adjustments_item
  ON inventory_adjustments(tenant_id, inventory_item_id, created_at);
```

Adjustment rules:

```text
[ ] row is locked before mutation
[ ] on_hand cannot become negative
[ ] available is recomputed atomically
[ ] every adjustment is audited
[ ] an adjustment never edits historical orders or ledger rows
```

## 64.16.8 Reconciliation Records

```sql
CREATE TABLE reconciliation_records (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  provider TEXT NOT NULL,
  reference_type TEXT NOT NULL,
  reference_id TEXT NOT NULL,
  status TEXT NOT NULL,
  expected_amount_minor BIGINT,
  actual_amount_minor BIGINT,
  currency CHAR(3),
  discrepancy_minor BIGINT,
  details JSONB,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, provider, reference_type, reference_id)
);
```

Reconciliation is mandatory for payments, refunds, merchant payouts, and provider webhooks.

## 64.16.9 Settlements / Payouts

```sql
CREATE TABLE settlements (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  provider TEXT NOT NULL,
  provider_settlement_id TEXT,
  currency CHAR(3) NOT NULL,
  gross_minor BIGINT NOT NULL,
  fee_minor BIGINT NOT NULL DEFAULT 0,
  net_minor BIGINT NOT NULL,
  status TEXT NOT NULL,
  settled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, provider, provider_settlement_id),
  CHECK (gross_minor >= 0),
  CHECK (fee_minor >= 0),
  CHECK (net_minor = gross_minor - fee_minor)
);

CREATE TABLE payouts (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  merchant_payment_account_id UUID NOT NULL REFERENCES merchant_payment_accounts(id),
  provider_payout_id TEXT,
  amount_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  status TEXT NOT NULL,
  arrival_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, provider_payout_id),
  CHECK (amount_minor > 0)
);
```

Provider payout state is reconciled to local state. No payout record may directly mutate ledger history.

## 64.16.10 Financial Transaction Index

```sql
CREATE TABLE financial_transactions (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  transaction_type TEXT NOT NULL,
  reference_type TEXT NOT NULL,
  reference_id UUID NOT NULL,
  journal_entry_id UUID REFERENCES journal_entries(id),
  amount_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, transaction_type, reference_type, reference_id),
  CHECK (amount_minor >= 0)
);
```

`financial_transactions` is a reconciliation/index layer. The immutable ledger remains the financial source of truth.

## 64.16.11 Cookie Consent Records

```sql
CREATE TABLE consent_records (
  id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  customer_id UUID REFERENCES customers(id),
  anonymous_id TEXT,
  categories_accepted JSONB NOT NULL,
  consent_version TEXT NOT NULL,
  policy_snapshot TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (customer_id IS NOT NULL OR anonymous_id IS NOT NULL)
);

CREATE INDEX idx_consent_tenant_subject
  ON consent_records(tenant_id, customer_id, anonymous_id, created_at);
```

Non-essential categories are opt-in only. Consent records are append-only.

## 64.16.12 Order Tracking Security

Add an opaque public token to the tracking reference:

```sql
ALTER TABLE order_tracking_references
  ADD COLUMN public_token_hash TEXT UNIQUE;
```

The plaintext token is generated once and returned only through the merchant/customer-facing flow. Public tracking endpoints accept the opaque token, never the sequential order ID.

## 64.16.13 Additional RLS Coverage

The following tables are also tenant-scoped and MUST be covered by RLS, tenant-aware indexes, and cross-tenant tests:

```text
price_lists
product_seo
recovery_codes (user-scoped; access by authenticated owner/admin policy)
merchant_payment_accounts
shipping_methods
tax_rates
inventory_adjustments
reconciliation_records
settlements
payouts
financial_transactions
consent_records
coupon_redemptions
discount_applications
wishlist_items
review_questions
review_answers
order_tracking_references
platform-admin audited target access
```


# 66. v1.7 Deep Audit Corrections — Normative Overrides

This section is normative. Where any earlier section conflicts with §66, §66 wins.

## 66.1 Starter Stack Consistency

P0 launch does **not** require Redis, BullMQ, PgBouncer, Meilisearch, Vault, Sentry, or Prometheus/Grafana.

The launch implementation MUST provide:

```text
PostgreSQL
Prisma
Transactional Outbox
One durable worker/poller process
PostgreSQL-backed rate limits
PostgreSQL FTS
Structured logs + uptime monitoring
Encrypted backups
```

Scale components remain behind the existing abstractions and are activated only by measured contention or the §55.1 trigger.

## 66.2 Billing / Plan Versioning

```text
plans
  → immutable plan_versions
      → plan_prices / plan_features
          → subscription pinned to plan_version
```

Rules:

```text
[ ] Historical plan_versions used by active subscriptions are immutable
[ ] Price/feature changes create new versions
[ ] Stripe IDs are integration references, not source of truth
[ ] Stripe Price changes use new/archived price objects as needed
[ ] At most one billable active subscription exists per tenant
[ ] Commission model does not require Stripe Billing
[ ] Commission percentage is bounded 0..100
[ ] Plan feature values are type-consistent
```

Required guards:

```sql
CREATE UNIQUE INDEX uq_active_tenant_subscription
  ON subscriptions(tenant_id)
  WHERE status IN ('trialing','active','past_due','suspended');

CREATE UNIQUE INDEX uq_stripe_subscription
  ON subscriptions(stripe_subscription_id)
  WHERE stripe_subscription_id IS NOT NULL;

ALTER TABLE subscriptions
  ADD CONSTRAINT chk_commission_percent
  CHECK (commission_percent IS NULL OR (commission_percent >= 0 AND commission_percent <= 100));

ALTER TABLE plan_features
  ADD CONSTRAINT chk_plan_feature_value
  CHECK (
    (value_type = 'boolean' AND value_boolean IS NOT NULL AND value_integer IS NULL)
    OR
    (value_type = 'integer' AND value_boolean IS NULL AND value_integer IS NOT NULL AND value_integer >= 0)
    OR
    (value_type = 'unlimited' AND value_boolean IS NULL AND value_integer IS NULL)
  );
```

### 66.2.1 Subscription Price / Plan-Version Integrity

A subscription item MUST reference a price belonging to the subscription's pinned plan version.

The implementation MUST enforce this with a database trigger or equivalent composite foreign-key design. A trigger form is:

```sql
CREATE OR REPLACE FUNCTION enforce_subscription_item_plan_version()
RETURNS trigger AS $$
DECLARE
  subscription_version UUID;
  price_version UUID;
BEGIN
  SELECT plan_version_id INTO subscription_version
    FROM subscriptions WHERE id = NEW.subscription_id FOR SHARE;

  SELECT plan_version_id INTO price_version
    FROM plan_prices WHERE id = NEW.plan_price_id FOR SHARE;

  IF subscription_version IS NULL OR price_version IS NULL
     OR subscription_version <> price_version THEN
    RAISE EXCEPTION 'subscription item plan version mismatch';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_subscription_item_plan_version
BEFORE INSERT OR UPDATE ON subscription_items
FOR EACH ROW EXECUTE FUNCTION enforce_subscription_item_plan_version();
```

## 66.3 Entitlement Freshness and Fail-Closed Authorization

`tenant_entitlements` is a projection/cache, not an independent source of truth.

Authorization-critical decisions MUST use a strongly consistent subscription/plan-version read or a projection with a validated version fingerprint. Missing, stale, or inconsistent entitlement state MUST fail closed for protected mutations.

## 66.4 Coupon / Promotion Usage

A redemption may consume both `coupon.usage_limit` and `promotion.usage_limit`. The transaction MUST lock the coupon and linked promotion in deterministic order, validate both limits, insert the redemption, and increment both counters.

Automatic promotions without coupons require their own usage accounting. `discount_applications` is the canonical historical discount record.

## 66.5 Payment Capture / Refund Idempotency

A payment cannot be captured beyond its intent/authorized amount, and total refunds cannot exceed total captures.

Mutation order:

```text
lock internal aggregate
→ validate amount/state
→ record internal intention
→ call provider outside DB transaction
→ reconcile response/webhook
→ finalize internal state
→ write outbox
```

## 66.6 Public Storefront State Machine

Public storefront access requires:

```text
tenant.status = ACTIVE
AND storefront.status = PUBLISHED
AND resolved domain exists
```

Publication requires:

```text
active tenant
first sellable product
valid locale/currency configuration
domain provisioned
required storefront settings
billing/commercial prerequisites
```

`SUSPENDED` is always non-public.

## 66.7 Tenant Integrity

For every high-risk cross-tenant relationship, enforce either:

```text
composite FK + parent UNIQUE(tenant_id, id)
```

or:

```text
database trigger enforcing tenant equality
```

Application-only checks are insufficient.

## 66.8 Platform Admin Trust Boundary

Normal tenant traffic and platform-admin traffic use separate DB roles/pools.

```text
normal runtime role:
  no BYPASSRLS
  no tenant-table ownership
  no platform-admin role inheritance

platform-admin role/pool:
  dedicated server-side credential
  MFA verified before selection
  limited to platform-admin handlers
  all actions audited
```

A request parameter, cookie, header, or mutable GUC MUST NEVER grant platform-admin authority.

## 66.9 API Completeness Gate

Every P0 endpoint must define:

```text
method
path
authentication
permission
tenant scope
idempotency
request schema
response schema
error codes
rate-limit policy
audit behavior
transaction boundary
```

Adding an undocumented P0 endpoint is a release-blocking defect.

## 66.10 Event Completeness Gate

Every canonical event must define:

```text
event_name
schema_version
event_id
aggregate_type
aggregate_id
tenant_id (null only for explicitly platform-scoped events)
producer
occurred_at
correlation_id
causation_id
payload
```

Consumers MUST deduplicate by `event_id` or an explicit domain idempotency key. Outbox remains the durable publication source.

## 66.11 Migration Safety

§64 DDL is the logical schema; production changes MUST be introduced through versioned Prisma migrations. `ALTER TABLE` snippets in this specification are migration intent, not instructions to mutate an already-live database out of band.

Each migration requires:

```text
up migration
backward-compatible deploy
backfill where needed
constraint validation
performance review
rollback/recovery procedure
```

## 66.12 P0 Commercial Readiness

P0 is launch-ready only when one external merchant can complete:

```text
signup
→ tenant creation
→ plan selection
→ required Stripe onboarding
→ product creation
→ publish
→ public storefront
→ cart
→ checkout
→ successful payment
→ order creation
→ inventory reservation
→ tracking reference
→ refund
```

with zero cross-tenant leakage, zero duplicate financial effects, balanced ledger, recoverable outbox, successful restore drill, approved SLOs, and documented operational runbooks.

---

# 67. Final Verdict

**v1.7 هي النسخة التنفيذية المرجعية.**

الوثيقة الأصلية v1.0 كانت Product/Architecture vision قوية.
v1.1 حولتها إلى Engineering Baseline.
v1.2 أضافت طبقة التنفيذ الفعلية.
v1.3 أغلقت فجوات الـschema الأولى.
v1.4 أغلقت فجوات التنفيذ والـsecurity والـRLS المتبقية.
v1.5 ضمنت أن P0 نفسه **منتج قابل للبيع فعلياً**، وأضافت مسار بنية تحتية واقعي لميزانية الإطلاق.
v1.6 أغلقت الفجوة بين **تصنيف** P0 و**تنفيذ** P0 — بإضافة الـSchema والعقود الصريحة لكل ميزة نُقلت إلى P0 بـ v1.5 (Billing كامل، Wishlist/Reviews/Q&A، Coupon concurrency، Order Tracking، Domain Provisioning، Onboarding، API Inventory، Event Catalog، Transaction Boundaries)، استناداً لمراجعة هندسية مستقلة أثبتت أن النقل بدون Schema كان يترك قرارات حرجة للمطور يخترعها بنفسه:

```text
PRD
 ↓
Architecture
 ↓
Domain Contracts
 ↓
Database Schema
 ↓
RLS
 ↓
Invariants
 ↓
API Contracts
 ↓
Tests
 ↓
Implementation Checklist
 ↓
Release Gates
```

**المعيار النهائي ليس طول الوثيقة ولا عدد الميزات.**

المعيار هو:

> هل يستطيع فريق هندسي مستقل أخذ هذه الوثيقة والبدء ببناء P0 دون اختراع قرارات حرجة من عنده؟

**الجواب في v1.7: نعم من ناحية القرارات المعمارية؛ لا يعني ذلك أن الكود مكتوب. التنفيذ يجب أن يمر عبر الـDDL/migrations، RLS policies، tests، provider sandboxes، وإغلاق Gates كما هو موثق. لا توجد فجوة P0 معروفة تتطلب من المطور اختراع قرار معماري جوهري.**

---

## Document Metadata

```text
Document: Unified Global Commerce Platform Specification
Version: 1.8
Status: Final P0 Engineering Specification + Deep Consistency/Security/Launch Closure
Target: Global SaaS Commerce — Arabic-first (+ English/Turkish) at launch, expanding globally
Architecture: Modular Monolith + Event-Driven Async Processing
             (Starter Stack permitted at launch, see §55.1; full stack at scale)
Primary DB: PostgreSQL
ORM: Prisma
Pooling: Direct pool at launch → PgBouncer / Managed Pool at scale
Cache / Queue: Postgres-based outbox + rate-limit counters at launch → Redis + BullMQ at scale
Search: Postgres Full-Text Search at launch → Meilisearch / Provider Abstraction at scale
Storage: R2/S3 + CDN
Payments: Stripe Connect (merchant commerce) + Stripe Billing (platform subscription) —
          explicitly separated domains, see §64.2
Security: Application Authorization + PostgreSQL RLS + explicit Platform Admin domain (§64.11)
Consistency: Strong for critical state, eventual for derived systems
P0 Definition: Minimum Sellable Product — commercial safety kernel
             + Arabic/RTL storefront + basic merchant billing
             + full schema closure for all P0-classified features (§64 + §66)
```

**End of Specification v1.7**

# 68. v1.8 Security Hardening Closure — Normative Overrides

> **Purpose:** This section closes the remaining P0 security and concurrency gaps identified by the deep review of v1.7. Where any earlier section conflicts with §68, §68 wins.
>
> **Scope:** Authentication/session lifecycle, CSRF, webhook authenticity/replay protection, SSRF, file uploads, OAuth account linking, authentication abuse controls, idempotency persistence, inventory-expiry races, domain verification, PII lifecycle, queue safety, audit integrity, secret handling, and security release gates.

## 68.1 Session Security Contract

Sessions are server-side security state. A bearer token MUST never be stored in plaintext.

Canonical schema:

```sql
ALTER TABLE sessions
  ADD COLUMN idle_expires_at TIMESTAMPTZ,
  ADD COLUMN absolute_expires_at TIMESTAMPTZ,
  ADD COLUMN last_seen_at TIMESTAMPTZ,
  ADD COLUMN replaced_by UUID REFERENCES sessions(id),
  ADD COLUMN ip_hash TEXT,
  ADD COLUMN user_agent_hash TEXT;

CREATE INDEX idx_sessions_active_user
  ON sessions(user_id, expires_at)
  WHERE revoked_at IS NULL;
```

Rules:

```text
[ ] token_hash is the only persisted bearer-token representation
[ ] session fixation is impossible: authentication creates a new session
[ ] privilege elevation rotates the session identifier/token
[ ] password reset revokes all active sessions for the user
[ ] MFA enrollment/reset for privileged users rotates sessions
[ ] logout revokes the current session
[ ] idle timeout is enforced server-side
[ ] absolute session lifetime is enforced server-side
[ ] revoked, expired, replaced sessions are rejected
[ ] concurrent refresh cannot mint unlimited valid sessions
```

Recommended P0 defaults:

```text
idle timeout: 12 hours
absolute lifetime: 30 days
privileged platform-admin idle timeout: 30 minutes
privileged platform-admin absolute lifetime: 8 hours
```

Exact values may be configured, but MUST be finite and documented.

## 68.2 Browser CSRF Contract

For authenticated browser mutations using cookies, CSRF protection is mandatory.

```text
Cookie:
  Secure
  HttpOnly
  SameSite=Lax (Strict where compatible)

Mutation requests:
  Origin validation
  + CSRF token for browser state-changing requests
```

Rules:

```text
[ ] POST/PATCH/PUT/DELETE browser mutations require CSRF validation
[ ] Origin/Referer is validated against an explicit trusted-origin allowlist
[ ] CORS is deny-by-default
[ ] credentialed CORS never uses '*'
[ ] GET/HEAD/OPTIONS have no state-changing side effects
[ ] webhook endpoints do not use browser CSRF; they use provider signatures
```

## 68.3 Webhook Authenticity and Replay Contract

Webhook handlers MUST verify the provider signature against the raw HTTP request body before parsing or normalization.

Required controls:

```text
raw_body_signature_verification
provider_account_or_destination_verification
timestamp_tolerance
event_id_deduplication
constant-time signature comparison
bounded payload size
```

Default timestamp tolerance:

```text
5 minutes
```

A valid signature outside the accepted timestamp window MUST be rejected unless the provider's protocol explicitly does not provide a timestamp; in that case, event-id deduplication plus provider-specific replay controls are mandatory.

Canonical processing:

```text
receive raw request
→ verify size/content limits
→ verify signature
→ verify timestamp/account
→ parse event
→ deduplicate event_id
→ persist WebhookEvent
→ acknowledge safely
→ process durable internal event
```

The provider event is never treated as authoritative for tenant identity merely because a payload contains `tenant_id`.

## 68.4 SSRF / Server-Side Fetch Contract

Any server-side HTTP request influenced directly or indirectly by merchant/customer input MUST pass through a controlled outbound-fetch policy.

Forbidden by default:

```text
file://
gopher://
ftp://
localhost
127.0.0.0/8
10.0.0.0/8
172.16.0.0/12
192.168.0.0/16
169.254.0.0/16
IPv6 loopback/link-local/private ranges
cloud metadata endpoints
Unix socket targets
```

Controls:

```text
[ ] URL scheme allowlist is https/http only where required
[ ] DNS resolution is performed by the controlled fetcher
[ ] resolved IP is checked before connection
[ ] redirect targets are revalidated on every hop
[ ] redirect count is bounded
[ ] connection/read/total timeouts are bounded
[ ] response size is bounded
[ ] provider-specific hostname allowlists are used where possible
[ ] DNS rebinding is mitigated by validating the resolved destination used for connection
```

Domain verification and provider adapters MUST NOT implement arbitrary URL fetching in application handlers.

## 68.5 Media / File Upload Security Contract

Uploaded content is untrusted even when the extension and declared MIME type appear valid.

Required P0 pipeline:

```text
upload staging
→ size limit
→ magic-byte/type detection
→ parser safety checks
→ optional malware-scan adapter
→ safe re-encode where applicable
→ object-store promotion
→ immutable random storage key
→ CDN/public publication only after validation
```

Rules:

```text
[ ] extension is never the security decision
[ ] Content-Type is never the security decision
[ ] SVG/HTML/script-capable content is rejected or served from a non-executable isolated origin
[ ] archive/decompression bombs are rejected
[ ] image dimensions/pixel counts are bounded
[ ] object keys are generated server-side
[ ] upload paths are tenant-scoped
[ ] users cannot choose executable storage keys
[ ] object storage is private by default
[ ] public media is served through a controlled origin/CDN
```

## 68.6 OAuth / External Identity Linking

External identities require a dedicated identity-link record.

```sql
CREATE TABLE user_identities (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  provider TEXT NOT NULL,
  provider_subject TEXT NOT NULL,
  provider_email CITEXT,
  email_verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(provider, provider_subject)
);

CREATE INDEX idx_user_identities_user
  ON user_identities(user_id);
```

Rules:

```text
[ ] provider + subject is the stable external identity key
[ ] OAuth login does not automatically merge an existing local account merely because emails match
[ ] linking an existing account requires an authenticated account-link flow
[ ] verified provider identity is required for an email-based linking policy
[ ] unlinking the last usable authentication factor is forbidden
[ ] provider tokens/secrets are encrypted and never logged
```

## 68.7 Authentication Abuse / Recovery Protection

Security-sensitive authentication surfaces MUST have dedicated rate limits and abuse controls.

Minimum surfaces:

```text
login
password reset request
password reset completion
MFA verification
MFA recovery-code attempts
OAuth callback initiation/completion
session refresh
account linking
```

Rules:

```text
[ ] IP + account/identity scoped rate limits
[ ] exponential backoff after repeated failures
[ ] generic responses for password-reset existence checks
[ ] reset-token brute force is infeasible because only hashes are stored
[ ] recovery codes are one-time and stored as hashes
[ ] suspicious authentication events are audited
[ ] lockout policy cannot become an easy tenant-wide denial-of-service vector
```

## 68.8 Idempotency Persistence Contract

`IdempotencyKey` is a durable transactional record, not an in-memory cache.

Canonical fields:

```sql
CREATE TABLE idempotency_keys (
  id UUID PRIMARY KEY,
  scope_type TEXT NOT NULL,
  scope_id UUID NOT NULL,
  endpoint TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  response_status INT,
  response_body JSONB,
  resource_type TEXT,
  resource_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  UNIQUE(scope_type, scope_id, endpoint, idempotency_key)
);
```

Rules:

```text
[ ] reservation of the idempotency key and business mutation are atomic where one transaction is possible
[ ] in-progress duplicate requests do not execute a second mutation
[ ] completed duplicates return the original outcome
[ ] same key + different canonical request hash returns 409
[ ] scope includes the authenticated tenant/actor boundary appropriate to the endpoint
[ ] TTL is explicit and longer than the maximum expected provider/client retry window
[ ] expired records are garbage-collected without permitting an unsafe replay window
```

For external-payment operations, the provider idempotency key and internal idempotency record MUST be correlated.

## 68.9 Inventory Reservation Expiry Race Protection

Reservation release MUST be conditional on the exact reservation version/state observed by the worker.

Canonical pattern:

```sql
UPDATE inventory_reservations
SET status = 'RELEASED',
    released_at = now(),
    version = version + 1
WHERE id = $1
  AND status = 'ACTIVE'
  AND version = $2
  AND expires_at <= now();
```

Rules:

```text
[ ] expiry worker never releases a reservation already consumed/committed
[ ] checkout conversion and expiry release serialize on the reservation row
[ ] inventory counters and reservation state change in one DB transaction
[ ] releasing zero rows is a safe no-op followed by reconciliation/logging
[ ] reservation version is monotonic
```

## 68.10 Domain Verification / Takeover Protection

A custom domain is not publishable merely because a hostname row exists.

Required verification state:

```sql
ALTER TABLE domains
  ADD COLUMN verification_method TEXT,
  ADD COLUMN verification_token_hash TEXT,
  ADD COLUMN verification_expires_at TIMESTAMPTZ,
  ADD COLUMN verified_hostname TEXT,
  ADD COLUMN verification_version BIGINT NOT NULL DEFAULT 1;
```

Verification rules:

```text
[ ] challenge token is cryptographically random
[ ] only the hash is persisted
[ ] challenge expires
[ ] challenge is single-use/versioned
[ ] DNS TXT or equivalent proof is required before activation
[ ] hostname uniqueness is enforced globally
[ ] domain cannot be attached to two tenants
[ ] ownership is revalidated after security-sensitive reassignment
[ ] removed domains cannot remain routable from stale caches
[ ] subdomain takeover conditions are checked before publication
```

## 68.11 PII Retention / Deletion / Anonymization

The platform MUST distinguish mutable customer PII from legally/operationally retained financial records.

Required policy classes:

```text
ERASABLE_PII
RETENTION_REQUIRED_FINANCIAL
SECURITY_AUDIT_RETENTION
```

Rules:

```text
[ ] account deletion triggers a documented data-lifecycle workflow
[ ] customer profile PII may be anonymized after required retention conditions are met
[ ] immutable order/ledger records are not deleted merely because an account is deleted
[ ] order snapshots are treated as historical records with controlled retention
[ ] exports include only authorized tenant data
[ ] logs do not contain passwords, bearer tokens, full payment credentials, MFA secrets, or reset tokens
[ ] sensitive fields are encrypted where required by the approved data-classification policy
```

## 68.12 Queue / Worker Safety

Every durable worker MUST implement:

```text
bounded payload size
schema validation
maximum attempts
exponential backoff + jitter
DLQ after terminal failure
poison-message detection
correlation_id propagation
tenant-context validation
```

Worker rules:

```text
[ ] payload tenant_id is treated as context, not authorization
[ ] privileged mutations re-resolve authorization from trusted state
[ ] duplicate messages are safe
[ ] retry does not create duplicate financial effects
[ ] a poisoned message cannot create an infinite retry loop
[ ] queue lag and DLQ depth are monitored
```

## 68.13 Audit Integrity Hardening

Audit records are security evidence and MUST be append-only for the application runtime role.

```sql
REVOKE UPDATE, DELETE ON audit_events FROM app_runtime;
```

Required fields:

```text
who
what
when
tenant_id
resource_type
resource_id
before
after
request_id
correlation_id
ip_hash
user_agent_hash
```

For high-risk platform actions, the implementation SHOULD maintain tamper-evidence by storing a hash of the previous audit record in a separate integrity field/chain. If implemented, verification MUST be part of the audit runbook.

## 68.14 Secrets / Cryptographic Key Handling

Rules:

```text
[ ] secrets are never committed to source control
[ ] production secrets are injected through the approved secret-management mechanism
[ ] encryption keys are separated from encrypted data where practical
[ ] key rotation procedure exists before launch
[ ] provider webhook secrets can be rotated without downtime
[ ] password hashing uses a current memory-hard password hashing algorithm such as Argon2id
[ ] encryption-at-rest keys and application secrets are not written to logs
[ ] .env.example contains placeholders only
```

## 68.15 Security Headers / Browser Boundary

P0 responses MUST define at minimum:

```text
Content-Security-Policy
Strict-Transport-Security
X-Content-Type-Options: nosniff
Referrer-Policy
Permissions-Policy
```

The CSP MUST be environment-specific and MUST NOT use unsafe broad defaults merely to make the application function.

Storefront-generated HTML/content is untrusted input and MUST be escaped/sanitized according to context.

## 68.16 P0 Threat Model / Abuse Cases

The security test suite MUST explicitly cover:

```text
T1  cross-tenant IDOR
T2  role escalation
T3  platform-admin impersonation
T4  session fixation/replay
T5  CSRF
T6  OAuth account takeover/linking
T7  password-reset abuse
T8  MFA recovery abuse
T9  webhook forgery/replay
T10 SSRF / DNS rebinding
T11 malicious file upload
T12 duplicate payment/capture/refund
T13 inventory expiry race
T14 coupon concurrency abuse
T15 domain takeover
T16 queue poison/retry storm
T17 audit tampering
T18 secret leakage through logs/errors
T19 stale entitlement privilege retention
T20 cache/search/storage tenant leakage
```

Each threat MUST have at least one automated regression test before the corresponding release gate passes.

## 68.17 Security Release Gate — Gate A+

Commercial launch is blocked unless all of the following pass:

```text
[ ] session lifecycle tests pass
[ ] CSRF tests pass
[ ] OAuth linking/anti-merge tests pass
[ ] authentication abuse/rate-limit tests pass
[ ] webhook signature + replay tests pass
[ ] SSRF test suite passes
[ ] upload-malware/type/polyglot/size tests pass
[ ] idempotency concurrency tests pass
[ ] inventory expiry race tests pass
[ ] domain verification/takeover tests pass
[ ] PII retention/deletion tests pass
[ ] queue poison/retry tests pass
[ ] audit immutability test passes
[ ] secret scanning passes CI
[ ] security headers/CSP tests pass
[ ] all T1-T20 threat regressions pass
```

## 68.18 P0 Security Definition of Done

P0 security is considered implemented only when:

```text
SPECIFIED
   ↓
IMPLEMENTED
   ↓
UNIT TESTED
   ↓
INTEGRATION TESTED
   ↓
ABUSE-CASE TESTED
   ↓
STAGING VERIFIED
   ↓
RELEASE GATE PASSED
```

A documented control that has no executable test or runtime enforcement is **not** considered closed.

---

# 69. Final Engineering Verdict — v1.8

**v1.8 is the security-hardened engineering baseline for P0.**

The document now distinguishes clearly between:

```text
architecture decision
schema/invariant
runtime enforcement
security control
automated regression test
release gate
```

No P0 security control may be considered complete merely because it is described in prose. It must have a concrete enforcement point and a corresponding test or measurable operational verification.

The final launch condition remains:

```text
P0 Commercial Path
+
Tenant Isolation
+
Financial Correctness
+
Authentication / Session Security
+
Webhook Authenticity
+
SSRF / Upload Security
+
Idempotency / Concurrency Safety
+
Domain Ownership Security
+
PII Lifecycle
+
Queue / Outbox Reliability
+
Audit Integrity
+
Backup / Restore
+
SLO / Observability
+
Threat Regression Suite
+
Gates A → E + Gate A+
=
COMMERCIAL LAUNCH
```

**Important:** v1.8 is a specification baseline, not evidence that the implementation has already passed these gates. The implementation repository must produce the migration, runtime controls, tests, staging evidence, and gate artifacts before launch.

## Document Metadata

```text
Document: Unified Global Commerce Platform Specification
Version: 1.8
Status: Final P0 Engineering Specification + Security Hardening Closure
Target: Global multi-tenant SaaS commerce platform, Arabic-first at launch (+ English/Turkish), expanding globally
Architecture: Modular Monolith + Event-Driven Async Processing
Primary DB: PostgreSQL
ORM: Prisma
Payments: Stripe Connect (merchant commerce) + Stripe Billing (platform subscription)
Security: Application Authorization + PostgreSQL RLS + explicit Platform Admin trust boundary + Security Hardening Contract (§68)
P0 Definition: Minimum Sellable Product + Commercial Safety Kernel + Security Hardening Closure
```
