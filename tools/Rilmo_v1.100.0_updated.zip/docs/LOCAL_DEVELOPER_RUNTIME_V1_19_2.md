# Local Developer Runtime — v1.19.2

## Objective

Provide a repeatable local path from a fresh checkout to a real browser-visible demo store without requiring external Stripe, SMTP, S3/R2 or payment credentials.

## Closed gaps

1. Compose no longer fails at interpolation time because of missing external secrets in development.
2. Development defaults to PostgreSQL in Docker rather than a hidden SQLite runtime path.
3. Development has an explicit mock-payment feature flag.
4. Development email is observable through a local sink file.
5. A deterministic demo seed creates the minimum useful commerce graph.
6. Storefront host context is injected by the server for `/store/{hostname}` routes.
7. A smoke test covers the local business flow through payment capture.
8. README contains the complete operator path from checkout to browser.

## Security boundaries

The mock provider is intentionally unavailable in staging and production. Local development must set `ALLOW_LOCAL_MOCK_PAYMENTS=true` explicitly. Production configuration validation remains unchanged for real secrets and infrastructure.

The demo credentials are test credentials only and must never be promoted to a non-local environment.

## Acceptance criteria

- `docker compose config` succeeds from a clean tree.
- `docker compose up -d --build` reaches healthy API and migration completion without provider secrets.
- `scripts/seed_demo.py` is repeatable.
- `/v1/health` and `/v1/ready` return success.
- `/store/demo.localhost` renders and points its API calls to `demo.localhost`.
- Guest cart and checkout work.
- Mock payment intent and capture work.
- Full automated test suite remains green.
