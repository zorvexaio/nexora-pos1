# Mandatory Real Staging Gate

This release must not be described as globally launch-ready until one real, non-local staging environment has produced evidence.

## Required staging environment

- Public HTTPS deployment URL
- PostgreSQL 18.6 (or the exact production-approved version)
- Redis
- Object storage
- Worker process
- TLS enabled
- Secrets injected by the deployment platform, never committed
- Database migrations executed from an empty database

## Minimum evidence run

1. Register merchant.
2. Authenticate.
3. Create product.
4. Create checkout/payment intent.
5. Execute provider sandbox payment.
6. Receive and verify webhook.
7. Confirm order state transition.
8. Verify ledger balance.
9. Create return.
10. Execute refund in provider sandbox.
11. Verify refund webhook/reconciliation.
12. Upload an allowed file and a blocked test file where the malware scanner is configured.
13. Verify tenant A cannot read tenant B.
14. Run PostgreSQL RLS smoke test.
15. Execute backup and restore rehearsal.
16. Run a bounded concurrency test and record p95/p99 latency and error rate.
17. Execute T1–T20 regression against the deployed URL.

## Evidence record

The following fields must be filled by the deployment owner:

- staging URL:
- deployment commit SHA:
- deployment timestamp:
- database version:
- provider sandbox account/reference:
- RLS result:
- payment lifecycle result:
- refund lifecycle result:
- backup/restore result:
- load/SLO result:
- T1–T20 result:
- logs/evidence location:

Until these fields contain real evidence, the gate remains **BLOCKED**.
