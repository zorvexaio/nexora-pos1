# Release Notes — Unified Global Commerce v1.47.0

## Security / API3 Hardening
- Promoted schema-aware ORM serialization to a release-blocking invariant backed by SQLAlchemy registry inspection.
- Added a canonical-serializer uniqueness gate so route/service-local `json_model()` implementations cannot bypass sensitive-field policy.
- Added regression coverage for credentials_encrypted, api_token_encrypted, key_hash, encrypted/hash/token/secret-like fields across the full mapper registry.

## Operational Evidence
- Existing Paddle parse-error redaction remains structured and observable without logging raw values.
- Release evidence is generated from the current VERSION and Alembic state rather than hand-maintained version literals.
