# Release 1.90.5

## Financial reference integrity hardening

- Payment capture now fails closed when a provider does not return a capture reference.
- Payment refund now fails closed when a provider does not return a refund reference.
- Prevents successful financial records from being persisted without an external reconciliation identifier.
- Added regression coverage for missing provider references.
