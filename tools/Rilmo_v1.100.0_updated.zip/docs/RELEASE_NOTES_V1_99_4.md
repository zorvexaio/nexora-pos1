# v1.99.4 — Pricing Intelligence

Adds merchant-facing pricing health analysis without mutating catalog prices.

## Merchant value
- Detects active variants priced below immutable catalog cost.
- Detects variants below a configurable target gross margin.
- Computes a deterministic minimum price for the requested target margin.
- Flags missing cost data instead of inventing profit.
- Keeps every result currency-bucketed; no cross-currency price or margin aggregation.

## Safety properties
- Read-only analytics endpoint; no automatic price mutation.
- Tenant-scoped product/variant query.
- Target margin is bounded to 0..10000 basis points.
- Division-by-zero at a 100% target margin is handled explicitly.
