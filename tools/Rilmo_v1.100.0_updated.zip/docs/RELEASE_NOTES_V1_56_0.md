# Release Notes — v1.56.0

## Server-side AI Assistant
- Added a public tenant-scoped storefront assistant at `/v1/public/storefront/{hostname}/assistant`.
- Added internal Ollama inference as the default provider.
- Added Qwen3.5 9B as the default server model; operator-configurable via `AI_MODEL`.
- No public exposure of the Ollama port in production.
- Added rate limits, question length limits, prompt-injection-resistant context handling, and deterministic fallback.
- Authenticated customers may receive minimal summaries of their own recent orders; guest shoppers receive catalog-only context.
- No assistant tool execution for payment, refund, cancellation, inventory or account mutation.
- Added storefront floating chat UI for desktop/mobile.

## Evidence
The release gate must run from a clean extraction and must verify Python compilation, route integrity, security checks, full pytest, manifest consistency, and release hygiene.
