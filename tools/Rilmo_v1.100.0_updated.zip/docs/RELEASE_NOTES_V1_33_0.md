# Unified Global Commerce v1.33.0

## Storefront Experience Upgrade

- Premium responsive storefront redesign with mobile-first navigation, sticky search, discovery hero, trust strip, product cards, product detail modal, wishlist, account center, cart drawer and checkout modal.
- First-class customer accounts separated from merchant identities.
- Passwordless customer email sign-in with one-time six-digit codes, expiry, attempt limits, rate limiting and secure HttpOnly sessions.
- Customer Google Sign-In using Google Identity Services/OIDC validation, state + nonce verification, verified-email requirement and tenant-bound identity records.
- Guest cart to customer cart merge on sign-in.
- Customer session endpoint, order history endpoint and secure logout.
- Search suggestions and intent-aware storefront search.
- Public payment-method discovery so the storefront selects an actually enabled merchant provider instead of hardcoding a gateway.
- Cart responses now include product title/SKU for a polished shopping experience.
- Public product/storefront media delivery with tenant/product ownership checks, immutable caching and safe object-store access.
- Storefront product cards and detail pages consume real published media when available.
- Added customer-account schema migration `20260818_0034_storefront_customer_accounts`.
- Added regression coverage for customer authentication, sessions, cart access and logout.

## Security

- Customer authentication is tenant-bound and does not create merchant RBAC memberships.
- Google OAuth state/nonce are hashed at rest and single-use.
- Email codes are stored only as hashes and are single-use with a five-attempt ceiling.
- Customer sessions are HttpOnly, SameSite=Lax and Secure in production.
- Public media is only served when the asset is linked to an active product on the requested published storefront.

## Verification

- 170 tests passed.
- Python compile check passed.
- Frontend JavaScript syntax check passed.
- Alembic upgrade/downgrade/re-upgrade round trip passed through `20260818_0034`.
