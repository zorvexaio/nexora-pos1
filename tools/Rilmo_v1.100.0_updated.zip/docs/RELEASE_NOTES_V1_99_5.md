# v1.99.5 — Merchant Decision Engine

## Purpose
Compose pricing, revenue, operations, and customer intelligence into a deterministic, ranked merchant action queue.

## Guarantees
- Read-only: no automatic price, payment, inventory, order, or customer mutation.
- Currency-safe: impact is never aggregated across currencies.
- Deterministic: same source state and inputs produce the same ranked decisions.
- Explainable: every decision carries evidence and a recommended action.
- Existing intelligence layers remain the source of truth.

## New endpoint
`GET /v1/analytics/merchant-decision-engine`
