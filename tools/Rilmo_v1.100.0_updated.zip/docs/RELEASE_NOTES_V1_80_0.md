# Release Notes — v1.80.0

## Deep global-readiness hardening

- Fixed the UCP payment-binding migration for SQLite/runtime-smoke compatibility using Alembic batch mode.
- Verified `upgrade → downgrade → upgrade` through `20260820_0058`.
- Verified live runtime smoke end-to-end.
- Verified 37 critical regression tests.
- Hardened release evidence so runtime gates cannot be reported PASS without execution.
- Recorded the full 330-test collection separately from terminal full-suite execution.
- External production evidence remains an explicit prerequisite for a genuine GLOBAL 100% certification.
