# Production Operations — v1.40.0

## Required control-plane services

PostgreSQL is the system of record. Redis is the distributed rate-limit backend and is required in production. Object storage is used for non-KYC media only, with encryption and checksum verification. Raw identity documents are not an application storage target.

## Failure policy

- Redis failure: rate-limited endpoints fail closed in production (`503 RATE_LIMIT_BACKEND_UNAVAILABLE`).
- KYC-provider failure: verification does not become VERIFIED; payout remains protected.
- Object-storage failure: uploads fail rather than silently persisting to an unsafe destination.
- Audit persistence failure: the containing transaction fails; an access-control decision must never be considered complete without an auditable record for protected compliance paths.

## Backup security

Backups are gzip-compressed SQL streams wrapped in the Rilmo authenticated backup envelope. The envelope uses scrypt-derived AES-256-GCM. Restore must be tested on an isolated target before production recovery.

## Security references

The application controls are mapped to OWASP Top 10:2025, OWASP ASVS 5.0.0, and the OWASP API Security Top 10:2023. The API-specific controls emphasize object-level/function-level authorization, resource consumption, SSRF, security misconfiguration, inventory management and unsafe consumption of third-party APIs.
