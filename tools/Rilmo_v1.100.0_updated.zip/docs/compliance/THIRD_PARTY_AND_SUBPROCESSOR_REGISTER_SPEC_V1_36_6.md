# Rilmo — Third-Party & Subprocessor Governance v1.36.6

## Mandatory register

For every external provider record:
- legal name;
- service;
- data categories received;
- purpose;
- role (processor/controller or equivalent);
- country of processing;
- subprocessor chain;
- security certification/evidence where available;
- DPA status;
- transfer mechanism;
- retention/deletion behavior;
- breach-notification contract terms;
- last review;
- next review.

## High-risk providers

KYC, payments, messaging, analytics, AI/model providers, cloud storage, email/SMS and customer support systems require additional privacy/security review.

## AI providers

The register must explicitly state whether prompts/outputs are used for provider training, retained by the provider, transferred across borders, or used for human review. Rilmo must not represent that a provider “never sees data” unless the contractual and technical configuration actually proves it.

## Change management

Adding a provider or enabling a new data category requires a privacy review before production use. The provider cannot receive production personal data while its DPA/transfer assessment remains unresolved.
