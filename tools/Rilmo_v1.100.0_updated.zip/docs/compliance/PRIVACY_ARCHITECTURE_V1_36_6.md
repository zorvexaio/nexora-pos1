# Rilmo — Privacy Architecture & Human Access Control v1.36.6

## Core user promise

Rilmo must never promise that no person can ever access personal data. The truthful promise is:

> Raw identity documents and biometric material are not stored in Rilmo by default. Merchant-facing staff, support agents, other merchants and other users do not receive access to them. Any exceptional human access to restricted compliance data must be explicitly authorised, purpose-bound, time-limited where possible, least-privileged, and auditable.

## Restricted data

KYC documents, selfie/video material, biometric templates, government identifiers and other legally protected sensitive data are treated as `RESTRICTED`.

## Human access model

### Support

Support may see operational identifiers and verification state, but not raw KYC documents or biometric material.

### Merchant administrators

Merchant administrators may see their own verification status and compliance actions. They do not receive another person’s KYC documents.

### Platform administrators

Platform administrators cannot simply override KYC or open raw KYC documents. Exception handling requires a dedicated compliance role, documented reason, case reference and audit trail.

### Compliance access

Where legally necessary, compliance personnel may receive narrowly scoped access to the minimum required information. The system must record who accessed what, why, under which case, and when.

## Technical controls

- Raw identity documents are not persisted in the Rilmo application database by default.
- Provider identifiers are stored instead of document files where possible.
- Restricted endpoints deny access to support and merchant roles.
- Logs contain no raw identity documents, full government identifiers, passwords, card credentials or provider secrets.
- Network identifiers used for consent evidence are hashed where the system only needs evidence of the originating context.
- Encryption at rest is required for sensitive data that Rilmo itself must retain.
- Production PostgreSQL must enforce tenant isolation with RLS.
- Privileged access requires MFA and step-up authentication for sensitive operations.
- Impersonation is read-only and audited.
- KYC webhook processing is signed, idempotent and protected against replay/out-of-order regressions.

## Privacy Center

Every authenticated user must have access to:

- current privacy preferences;
- consent history;
- applicable privacy notice version;
- data-subject request creation and status;
- account/data export request;
- erasure request where legally available;
- restriction/objection request where applicable;
- automated-decision review request where legally available;
- connected-app visibility and revocation.

## Data-subject requests

Requests enter a controlled queue. The platform must verify requester identity to a level proportionate to the sensitivity of the request and must apply legal exceptions such as tax, financial, fraud-prevention, legal-hold and dispute obligations.

Deletion is not a promise to delete immutable financial or legally required records immediately. Such records must instead be access-restricted, minimised, anonymised where technically and legally appropriate, and retained only for the required period.

## International transfers

The system maintains a jurisdiction and transfer register rather than assuming one global rule. For Turkey, transfer mechanisms must follow the current KVKK Article 9 framework and applicable standard contracts or other lawful mechanisms. For other markets, the legal team must map the applicable transfer mechanism before launch.

## AI privacy

AI features must not intentionally send unnecessary personal data to a general-purpose model. Product, support and merchant-assistant prompts must use the minimum context required. Restricted/KYC data is excluded by default from general AI prompts.

## Security incident

A security or privacy incident triggers:

1. detection;
2. containment;
3. data-impact assessment;
4. legal/privacy assessment;
5. regulator/customer notification when legally required;
6. remediation;
7. evidence preservation;
8. post-incident review.

No universal notification deadline is hard-coded because applicable deadlines differ by jurisdiction and incident type.
