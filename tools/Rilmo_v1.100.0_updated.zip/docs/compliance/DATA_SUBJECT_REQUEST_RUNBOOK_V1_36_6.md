# Rilmo — Data Subject Request Runbook

## Intake

1. Authenticate the requester.
2. Determine account/tenant/customer scope.
3. Route the request to the applicable jurisdiction profile.
4. Check for duplicate open requests.
5. Create an immutable request record.
6. Assign compliance/ privacy owner.

## Access / portability

Build an export from authoritative sources; exclude secrets and data belonging to other people; preserve immutable financial records where legally required while minimising disclosure.

## Rectification

Correct mutable source data and propagate changes only where law and data integrity permit.

## Erasure

Erase or anonymise eligible data; place legally required records under restricted retention instead of falsely claiming total deletion.

## Restriction / objection

Stop affected optional processing where required while preserving service/security processing permitted by law.

## Automated-decision review

Provide a meaningful review path for decisions subject to applicable legal safeguards. Never disclose trade secrets or security-sensitive fraud rules beyond what law requires.

## Closure

Record outcome, affected systems, exceptions, legal basis for retention, completion date and evidence. Notify the requester using the jurisdiction-appropriate response process.
