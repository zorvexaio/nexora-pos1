# Global Legal Notice — 2026

Rilmo uses a jurisdiction-aware legal control plane. No single Terms of Service or Privacy Policy is represented as universally compliant in every country. Each launch market must have a jurisdiction package covering consumer law, payments, tax/e-invoicing, privacy, data transfers, marketplace duties and platform distribution requirements.

The master policies in this directory are engineering/legal baselines and require review by qualified counsel before publication in each launch jurisdiction.
