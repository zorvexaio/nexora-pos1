# Rilmo — 2026 Global Legal/Regulatory Engineering Baseline

**Effective engineering baseline:** 2026-08-20

This document converts current public regulatory requirements into configurable software controls. It is not legal advice and does not certify Rilmo, a merchant, or a launch market as legally compliant. Market activation remains evidence-gated.

## Current 2026 reference points

### European Union — GDPR / DSA / AI Act / Data Act

- GDPR rights and processor/controller governance remain jurisdiction-specific; GDPR breach notification may require supervisory-authority notice within 72 hours when the applicable risk threshold is met.
- The EU Digital Services Act requires applicable online marketplaces to support trader traceability and mechanisms for illegal-content notices and user redress.
- AI Act Article 50 transparency obligations apply from **2 August 2026** for covered interactive AI systems and certain AI-generated/manipulated content. Rilmo therefore marks customer-facing AI responses with a human-readable notice and machine-readable provenance marker.
- The EU Data Act has applied since **12 September 2025** and remains part of the 2026 data-governance assessment where its scope is applicable.

### Türkiye — KVKK

- International transfers are governed by the amended Article 9 framework and applicable Board rules. Rilmo therefore uses an explicit transfer register and requires evidence for configured standard-contract transfer routes.
- The Authority publishes current standard contracts for controller-controller, controller-processor, processor-processor and processor-controller transfers. The platform never assumes that any arbitrary external AI provider route is lawful merely because it is technically reachable.

### California — CCPA/CPRA

- California's 2026 amendments and regulations are effective from **1 January 2026**.
- The engineering control plane includes opt-out signals, including GPC, and an ADMT/risk-assessment flag so applicable California workflows can be enabled without redesigning the data model.
- Jurisdiction qualification remains dependent on the business's legal scope and applicable thresholds.

### Brazil — LGPD

- International-transfer and rights controls are configurable through the jurisdiction engine rather than hard-coded into the global flow.

### India — DPDP

- The platform keeps India-specific privacy controls isolated from GDPR assumptions and routes applicable notice/rights/transfer requirements through the jurisdiction policy layer.

### Saudi Arabia / UAE

- Saudi PDPL and the rules governing transfers outside the Kingdom require explicit transfer governance and appropriate safeguards. UAE PDPL requires jurisdiction-aware processing, rights and security controls.

## Software enforcement

1. Jurisdiction is resolved from the applicable market/user context and can be overridden by reviewed legal policy.
2. DSR rights and internal due dates are policy-driven.
3. Optional analytics/marketing processing is blocked when an applicable GPC signal is present.
4. AI is disabled by default and all customer-facing AI interaction surfaces disclose AI usage.
5. External AI transfer is disabled unless explicitly enabled and covered by an approved transfer route.
6. DSA notice-and-action cases are auditable and support post-decision appeal states.
7. Merchant marketplace traceability is exposed through a dedicated public trader-information surface.
8. ROPA-style processing activities record purpose, legal basis, data categories, recipients, transfers, retention, DPIA and AI attributes.
9. Immutable financial/audit records are not destroyed merely because an account-deletion request exists; eligible data is erased or anonymised while legally required records are retained under restricted access.
10. No AI agent can execute financial or security-sensitive mutations.

## External launch blockers

The following cannot truthfully be marked complete by source code alone: legal-entity/controller-processor role confirmation, counsel approval of notices and contracts, payment/acquirer onboarding, tax and e-invoicing registrations, transfer agreements and notifications where required, independent penetration testing, production resilience evidence, DPIA where required, and jurisdiction-specific product/legal certification.

## Official sources checked for the 2026 baseline

- European Commission — GDPR application and breach obligations: https://commission.europa.eu/law/law-topic/data-protection/information-business-and-organisations/application-gdpr_en
- European Commission — Digital Services Act: https://digital-strategy.ec.europa.eu/en/policies/digital-services-act
- European Commission — AI Act transparency rules: https://digital-strategy.ec.europa.eu/en/policies/guidelines-ai-transparency-obligations
- European Commission — Data Act FAQs (updated 2026): https://digital-strategy.ec.europa.eu/en/library/commission-publishes-frequently-asked-questions-about-data-act
- Türkiye KVKK — standard contracts for international transfers: https://www.kvkk.gov.tr/Icerik/7991/Standard-Contracts
- Türkiye KVKK — Personal Data Protection Law, Article 9: https://www.kvkk.gov.tr/Icerik/6649/Personal-Data-Protection-Law
- California Privacy Protection Agency — 2026 CCPA updates/ADMT/risk assessment rules: https://cppa.ca.gov/regulations/ccpa_updates.html
- India MeitY — Digital Personal Data Protection Rules 2025: https://www.meity.gov.in/documents/act-and-policies/digital-personal-data-protection-rules-2025-gDOxUjMtQWa
- Saudi SDAIA — Personal Data Transfer Regulation: https://dgp.sdaia.gov.sa/wps/portal/pdp/knowledgecenter/details/RegulationonPersonalDataTransferOutsidetheKingdom
- UAE Government — Personal Data Protection Law: https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws.
