# Rilmo — Privacy Center Specification v1.36.6

## User-facing sections

### 1. Privacy overview

Shows the applicable privacy notice version, jurisdiction routing result, contact information, and a plain-language explanation of what Rilmo does and does not store.

### 2. Verification privacy

Shows:
- provider name;
- verification status;
- date of verification;
- provider reference (masked);
- statement that raw identity documents and biometric material are not stored by Rilmo by default;
- link to provider privacy information.

### 3. Consent center

Granular categories:
- strictly necessary;
- preferences;
- analytics;
- personalised experiences;
- email marketing;
- SMS marketing;
- WhatsApp marketing.

Each change creates an immutable consent event containing policy version, timestamp, jurisdiction, action and categories. Network identifiers are hashed rather than retained in raw form for consent evidence.

### 4. Data rights

Supported request types:
- ACCESS;
- RECTIFICATION;
- ERASURE;
- RESTRICTION;
- OBJECTION;
- PORTABILITY;
- REVIEW_AUTOMATED_DECISION.

The UI must explain that some requests may be limited by legal obligations, fraud controls, financial-record requirements, disputes or legal holds.

### 5. Connected services

List third-party applications/integrations, scopes, permissions and revoke controls.

## No dark patterns

The privacy center must not:
- hide rejection behind secondary navigation;
- preselect optional marketing;
- make withdrawal materially harder than granting consent;
- misrepresent a legal obligation as optional consent;
- use deceptive button labels.

## Identity verification for high-risk requests

Account authentication is the normal starting point. The platform may require stronger verification when the requested data is especially sensitive or fraud indicators exist. Verification must not require unnecessary new personal data.
