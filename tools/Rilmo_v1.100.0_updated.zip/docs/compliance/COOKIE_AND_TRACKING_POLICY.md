# Rilmo — Cookie & Tracking Policy

## Categories

### Strictly necessary
Authentication, session management, security, CSRF protection, checkout and core functionality.

### Preferences
Language, region, theme and user interface preferences.

### Analytics
Traffic and product analytics that are not strictly necessary.

### Advertising/measurement
Advertising identifiers, cross-site measurement or retargeting.

## Consent rule

Optional technologies must not activate before the applicable consent mechanism permits them.

The preference centre must allow:

- accept all;
- reject non-essential;
- granular choices;
- withdraw/change consent;
- view provider/category information.

Consent records should include:

- consent version;
- timestamp;
- categories accepted;
- region/jurisdiction;
- policy version;
- consent-management platform identifier.

Do not use dark patterns.

## Do-not-sell/share / targeted advertising

Where a jurisdiction provides such controls, the platform must expose the required opt-out mechanisms and respect applicable signals.

## Merchant responsibility

Each merchant may deploy its own third-party tracking on its storefront. Rilmo must provide a configuration and disclosure mechanism so merchants can document their technologies and obtain consent where required.
