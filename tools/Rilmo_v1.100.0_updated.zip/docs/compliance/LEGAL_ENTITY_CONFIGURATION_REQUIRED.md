# REQUIRED BEFORE PUBLIC LAUNCH — Legal Entity Configuration

The application intentionally does not invent the operator's legal identity.

Set and counsel-approve:

- `LEGAL_ENTITY_NAME`
- `LEGAL_ENTITY_ADDRESS`
- `LEGAL_ENTITY_COUNTRY`
- `LEGAL_ENTITY_REGISTRATION`
- `PRIVACY_CONTACT_EMAIL`
- `LEGAL_CONTACT_EMAIL`
- `DPO_NAME` / representative if required
- `TERMS_GOVERNING_LAW`
- `TERMS_JURISDICTION`
- `SUBPROCESSOR_REGISTER_URL`
- `SECURITY_CONTACT_URL`
- `DSR_REQUEST_URL`
- applicable regional representative details

**This is a hard release blocker.** A generic privacy policy with no identifiable controller/provider is not an acceptable final public policy.

Counsel must also approve jurisdiction-specific versions for each launch market.
