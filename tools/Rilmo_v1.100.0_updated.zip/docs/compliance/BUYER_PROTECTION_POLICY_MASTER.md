# Rilmo — Buyer Protection Policy (Master Template)

**Status:** Product/legal baseline. Counsel must adapt this for each launch jurisdiction.

Rilmo provides software workflows for cancellation, refund, return, delivery issues and customer–merchant disputes. Rilmo is not a bank and does not itself hold customer funds unless separately licensed and contracted to do so. Where supported, a regulated payment provider controls authorization, capture, settlement and refund.

### Automatic cancellation and refund
If a customer requests cancellation while an order remains within an eligible pre-fulfilment state, Rilmo may automatically void an uncaptured payment or submit an idempotent refund for the captured balance. Rilmo records a refund as completed only after the provider call succeeds or a trusted provider webhook confirms the outcome.

### Merchant communication
Customers and merchants can communicate through an order-linked issue thread. Messages are audited and customer responses expose only public-safe author roles and timestamps, not internal tenant or staff identifiers.

### Disputes and escalation
Issues may be acknowledged, refunded, resolved by replacement, rejected with a reason, or escalated for platform/compliance review. The availability and timing of remedies vary by jurisdiction, payment method, product type and merchant policy; mandatory consumer rights always prevail.
