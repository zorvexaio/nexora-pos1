# Rilmo — Data Processing Addendum (DPA) Baseline

This DPA is intended for business customers where Rilmo processes personal data on the merchant's behalf. Counsel must adapt it to the applicable law and contract.

## 1. Roles

For merchant customer data, the merchant and Rilmo determine controller/processor or equivalent roles based on actual processing.

## 2. Subject matter

Hosting and operation of ecommerce storefronts, customer accounts, catalog, orders, support, analytics, messaging, fraud prevention and integrations.

## 3. Processing instructions

Rilmo processes personal data only:

- to provide contracted services;
- on documented merchant instructions;
- to meet legal obligations;
- for security/fraud prevention where permitted;
- for limited service administration where the legal role permits.

## 4. Security

Rilmo maintains appropriate technical and organisational measures, including access controls, encryption, logging, tenant isolation, secure development, vulnerability management and incident response.

## 5. Subprocessors

Rilmo maintains a subprocessor register and requires contractual privacy/security obligations from subprocessors.

## 6. International transfers

Transfers use the applicable legal mechanism, such as adequacy, SCCs, UK transfer mechanisms, KVKK-approved mechanisms or LGPD/ANPD mechanisms as applicable.

## 7. Data subject requests

Rilmo provides reasonable assistance to merchants with access, deletion, correction, restriction, portability and other requests as applicable.

## 8. Security incidents

Rilmo must notify the merchant without undue delay after confirming a personal-data breach affecting the merchant's data, subject to legal restrictions and available information.

## 9. Deletion/return

At termination, Rilmo returns/deletes merchant data according to contract and applicable retention/legal-hold requirements.

## 10. Audit

The parties should define an evidence-based audit mechanism proportionate to risk, avoiding unrestricted access to other customers' data or security-sensitive infrastructure.
