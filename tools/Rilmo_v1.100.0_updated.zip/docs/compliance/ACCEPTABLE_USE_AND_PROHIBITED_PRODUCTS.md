# Rilmo — Acceptable Use & Prohibited Products Policy

## Core rule

A merchant may sell only products/services that are legal in the relevant destination, authorised by the merchant, accurately described, and permitted by Rilmo and its payment/shipping providers.

## Prohibited by default

- Illegal drugs and controlled substances.
- Weapons, explosives and prohibited weapon accessories.
- Counterfeit, stolen or pirated goods.
- Fraudulent financial products or investment schemes.
- Money laundering or payment-account rentals.
- Terrorist financing or sanctions evasion.
- Child sexual abuse material or exploitation.
- Non-consensual sexual material.
- Human trafficking or exploitation.
- Malware, credential theft and malicious services.
- Illegal gambling.
- Products requiring licences that the merchant cannot demonstrate.
- Products whose sale is prohibited in the destination market.
- Goods falsely claiming medical, therapeutic, safety or performance outcomes.
- Unlawful surveillance/spyware.
- Personal-data lists or services sold without lawful basis.
- Any product specifically blocked by a payment provider or applicable law.

## Restricted categories

The following require jurisdiction and provider review before activation:

- alcohol;
- tobacco/nicotine;
- CBD/cannabis;
- pharmaceuticals;
- supplements;
- medical devices;
- financial services;
- crypto assets;
- gambling;
- weapons/accessories;
- adult products/content;
- cosmetics with regulated claims;
- food;
- children's products;
- hazardous chemicals;
- drones/radio equipment;
- wildlife-derived goods;
- tickets and regulated services.

## Merchant controls

Rilmo should support:

- product-category risk flags;
- geo restrictions;
- age gates;
- licence evidence;
- payment-provider restrictions;
- automatic/manual review;
- product takedown;
- merchant suspension;
- appeal;
- audit trail.

## Enforcement

Rilmo may:

1. block publication;
2. restrict checkout;
3. pause payouts;
4. disable integrations;
5. remove content;
6. suspend a merchant;
7. preserve evidence;
8. report where legally required.

Enforcement must be proportionate and logged.

## EU marketplace layer

Where Rilmo falls within the scope of the EU Digital Services Act, marketplace obligations can include trader traceability and mechanisms concerning illegal products and user redress. The DSA expressly covers online marketplaces and related platform obligations. citeturn0search2turn0search12
