# Rilmo — Merchant Refund & Returns Policy (Master Template)

**Status:** Product/legal baseline. Jurisdiction-specific legal review is required before publication.

Merchants must provide clear cancellation, return and refund terms applicable to their goods/services. Those terms must not waive mandatory consumer rights. Rilmo provides software workflows; the merchant remains responsible for its lawful product, fulfilment and consumer obligations unless a separate agreement says otherwise.

Refunds are idempotent and capped by the captured balance. Merchant dispute resolution cannot manufacture a refund; it invokes the canonical payment-provider refund path and waits for provider success.
