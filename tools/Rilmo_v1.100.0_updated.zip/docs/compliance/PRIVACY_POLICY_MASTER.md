# Rilmo — Privacy Policy (Master Template)

**Document status:** Production legal template — MUST be reviewed and completed by qualified counsel for each launch jurisdiction before publication.  
**Version:** 1.0  
**Effective date:** `[INSERT DATE]`  
**Controller / Provider:** `[LEGAL ENTITY NAME]`  
**Registered address:** `[INSERT REGISTERED ADDRESS]`  
**Privacy contact:** `[PRIVACY EMAIL]`  
**DPO / representative, where legally required:** `[INSERT DETAILS]`

## 1. Scope

This notice explains how Rilmo (“Rilmo”, “we”, “us”) processes personal data when a person:

- creates or manages a merchant account;
- operates a storefront;
- purchases from a Rilmo-powered storefront;
- contacts support;
- uses AI, analytics, messaging, apps, APIs or integrations;
- visits Rilmo websites or documentation; or
- interacts with security, fraud, identity-verification or compliance controls.

A merchant may independently act as controller for its customers. In those cases, the merchant’s own privacy notice applies to its customer-facing processing, while Rilmo may act as processor/service provider. Contracts and the actual data flow determine the role; labels in this notice do not override applicable law.

## 2. Data categories

We use data minimisation. Depending on the service, data may include:

### Account and identity
Name, email, phone number, login credentials or authentication factors, language, country, account status and security events.

### Merchant/business data
Business name, business registration information, tax identifiers where required, beneficial-owner information where legally required, payout information, store configuration, domains and support records.

### Customer/order data
Name, contact information, shipping/billing address, order history, cart information, delivery information, refunds and communications.

### Payment data
Payment tokens, provider customer/payment identifiers, transaction status and limited payment metadata. **Rilmo does not intentionally store raw full payment-card numbers or CVV values.** Payment processing is delegated to approved payment providers where applicable.

### Security and technical data
IP address, device/browser characteristics, session identifiers, timestamps, approximate location derived from network data, authentication events, rate-limit events, fraud signals and audit logs.

### Identity verification / KYC
Where required: verification status, provider reference, country, decision/status, timestamps, risk indicators and limited compliance metadata. Raw identity documents, biometric templates and selfie/video material should remain with the specialised verification provider unless a specific lawful and documented requirement requires otherwise.

### AI interaction data
Prompts, generated outputs, product/catalog context and usage metadata necessary to provide AI features. Sensitive personal data must not be intentionally submitted to general-purpose AI features unless the feature explicitly supports it and the applicable lawful basis and safeguards are documented.

### Communications
Support tickets, messages, consent records, notification preferences and delivery metadata.

### Cookies and similar technologies
Strictly necessary cookies are used for authentication, security, session management and core functionality. Optional analytics/advertising technologies require the applicable consent or other lawful mechanism.

## 3. Purposes and lawful basis

The exact lawful basis depends on jurisdiction and context. Rilmo must maintain a processing register mapping each purpose to the applicable legal basis.

Typical purposes include:

| Purpose | Typical basis (jurisdiction-dependent) |
|---|---|
| Account creation and service delivery | Contract / steps before contract |
| Order and payment processing | Contract / legal obligation |
| Fraud prevention and security | Legitimate interests, legal obligation, or another permitted basis |
| KYC/KYB | Legal obligation / regulatory requirement / contract where permitted |
| Tax and accounting records | Legal obligation |
| Support | Contract / legitimate interests |
| Product analytics | Consent where required; otherwise a permitted non-identifying basis |
| Marketing email/WhatsApp/SMS | Consent or another jurisdiction-specific permitted basis |
| Personalised recommendations | Consent or legitimate interests where permitted, with required opt-out |
| AI generation | Contract / legitimate interests / consent as applicable |
| Legal claims and enforcement | Legal obligation / legitimate interests |
| Service improvement | Legitimate interests or consent where required |

**Do not rely on “consent” as a universal lawful basis.** The processing register must be jurisdiction-specific.

## 4. Special-category and sensitive data

Rilmo must not intentionally collect sensitive/special-category data unless a documented legal basis and necessity assessment exists.

Biometric identity verification is treated as high-risk data. In Türkiye, biometric data is within the special categories protected under KVKK and receives enhanced protection. citeturn0search21

Rilmo therefore follows a provider-minimisation architecture: the KYC provider should perform document/face/liveness processing; Rilmo receives only the minimum result and compliance metadata necessary for the service.

## 5. Children

Rilmo is not intended for unsupervised use by children. Merchant storefronts are responsible for determining whether their products/services are directed to children and for implementing applicable age/parental-consent requirements.

Where a jurisdiction imposes child-specific privacy rules, Rilmo applies the stricter applicable requirement and may restrict features until age/consent requirements are satisfied.

## 6. Sharing and subprocessors

Data may be shared with:

- payment providers;
- identity/KYC/KYB providers;
- cloud hosting, storage and CDN providers;
- email/SMS/WhatsApp providers;
- fraud/security providers;
- analytics providers where enabled;
- customer-support providers;
- shipping providers;
- app/integration providers selected by a merchant;
- professional advisers and authorities where legally required.

Rilmo must maintain a public or customer-accessible **Subprocessor Register** identifying each subprocessor, purpose, categories of data, processing location and applicable transfer safeguard.

## 7. International transfers

Rilmo is designed for international operation and may process data across borders. Transfers must use the mechanism required by the applicable jurisdiction.

For Türkiye, Law No. 6698 Article 9 and the current KVKK transfer framework must be followed; KVKK has published standard contractual clauses and guidance for international transfers. citeturn0search0turn0search9turn0search10

For the EEA/UK, the applicable adequacy decision, SCC/UK transfer mechanism, supplementary measures and transfer-risk assessment must be used where required. The UK ICO specifically requires transparency about third-country transfers. citeturn0search7turn0search41

Brazilian international transfers must follow LGPD and ANPD rules; Resolution CD/ANPD No. 19/2024 regulates international transfers. citeturn0search5turn0search17

The system must maintain a **Transfer Register** recording exporter, importer, countries, data categories, mechanism, contract/version, risk assessment and review date.

## 8. Retention

Rilmo does not keep personal data indefinitely.

Retention must be defined in a **Retention Schedule** by data class and jurisdiction. Legal/accounting obligations may require records to be retained after account closure. Security logs should have a separate documented period.

Deletion may be delayed or limited where required for:

- legal obligations;
- fraud/security investigations;
- dispute resolution;
- financial/accounting records;
- evidence preservation.

## 9. Security

Rilmo applies appropriate technical and organisational safeguards including:

- encryption in transit and at rest where appropriate;
- secrets management;
- least privilege;
- MFA;
- RBAC;
- PostgreSQL tenant isolation/RLS where deployed;
- audit logging;
- rate limiting;
- CSRF/CSP/security headers;
- webhook signature verification;
- idempotency;
- backup and recovery controls;
- malware scanning for uploads;
- vulnerability management;
- incident response;
- access reviews.

No security measure can guarantee absolute security.

## 10. Automated decision-making and profiling

Fraud, trust and KYC systems may use automated signals. Automated risk signals must not be treated as infallible.

Where applicable law provides rights concerning solely automated decisions, Rilmo must provide the legally required transparency, safeguards, human review or challenge mechanism. GDPR Article 22 contains specific protections around certain solely automated decisions. citeturn0search11

A high-risk fraud score should normally trigger **review/hold**, not an irreversible decision based solely on an opaque model.

## 11. Individual rights

Depending on jurisdiction, rights may include:

- access;
- correction;
- deletion/erasure;
- restriction;
- objection;
- portability;
- withdrawal of consent;
- information about processing;
- appeal/review of certain automated decisions;
- non-discrimination for exercising privacy rights where required.

California residents may have rights under the CCPA as amended by the CPRA, including rights concerning access and deletion and required notices. citeturn0search3turn0search13

Brazilian data subjects have rights under LGPD, including rights described in Article 18. citeturn0search18

## 12. Data subject request workflow

Rilmo must provide a request channel and internally:

1. authenticate the requester proportionately;
2. classify the request and jurisdiction;
3. identify all relevant tenants/systems;
4. preserve legally required records;
5. execute access/export/correction/deletion/restriction;
6. notify processors/subprocessors where required;
7. record exceptions and legal reasons;
8. respond within the applicable statutory deadline.

## 13. Cookies

The cookie banner/consent manager must distinguish:

- strictly necessary;
- preferences;
- analytics;
- advertising/measurement;
- other non-essential technologies.

No optional category may be activated before the applicable consent is obtained.

## 14. Data breach

Rilmo maintains an incident-response procedure covering detection, containment, evidence preservation, impact assessment, processor coordination, regulator notification and affected-person notification when legally required.

## 15. Changes

Material changes require versioning, effective-date management and notice where required.

## 16. Contact

`[INSERT PRIVACY CONTACT AND LOCAL REPRESENTATIVE DETAILS]`

**Legal note:** This master notice is an engineering/legal baseline, not jurisdiction-specific legal advice. Counsel must approve the final entity names, lawful bases, retention periods, transfer mechanisms, consumer rights wording and local representatives before launch.
