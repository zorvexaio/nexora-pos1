# Rilmo — Data Retention & Deletion Schedule

**Status:** Engineering baseline; legal counsel must set final periods by jurisdiction.

## Principles

- Collect only what is necessary.
- Define a purpose for every retained field.
- Never retain raw KYC documents in Rilmo unless legally necessary.
- Separate operational data from immutable financial/audit records.
- Use automated deletion/anonymisation jobs.
- Apply legal holds where required.
- Retention periods must be configurable by jurisdiction and record class.

## Baseline schedule

| Data class | Baseline treatment |
|---|---|
| Unverified registration | Delete/anonymise after configurable inactivity period |
| Active account | Retain while account is active |
| Customer profile | Retain while required for service; delete/anonymise after closure subject to legal obligations |
| Orders | Retain for accounting, tax, disputes and legal requirements |
| Payment records | Retain according to financial/legal requirements; no raw card data |
| KYC provider reference | Retain only as necessary for compliance/account lifecycle |
| Raw identity documents | Prefer provider retention; Rilmo should not store them |
| Fraud/risk events | Retain only for defined security/compliance period |
| Audit logs | Retain according to security/legal requirements |
| Support tickets | Retain for service, dispute and compliance period |
| Marketing consent | Retain as evidence of consent/withdrawal |
| Analytics | Prefer aggregation/anonymisation after useful period |
| Backups | Subject to backup rotation and legal-hold controls |

## Deletion architecture

Deletion must support:

- user/merchant request;
- automated retention job;
- tenant closure;
- subprocessor deletion request;
- backup expiry;
- legal hold;
- cryptographic destruction where appropriate;
- anonymisation where deletion would break immutable financial/audit integrity.

## Important

“Delete account” does not mean “delete every financial/legal record immediately.” Mandatory records may need to be retained and access restricted.
