# Rilmo — Security & Privacy Architecture Baseline

## Data classes

`PUBLIC` → `INTERNAL` → `CONFIDENTIAL` → `RESTRICTED`

KYC/identity/biometric material is `RESTRICTED`.

## Rules

1. Do not store raw card data.
2. Do not store raw KYC documents unless a documented legal requirement exists.
3. Never log passwords, access tokens, API secrets, full payment credentials or raw identity documents.
4. Encrypt sensitive data at rest where stored.
5. Encrypt all external traffic.
6. Use least privilege.
7. Separate tenant data.
8. Apply RLS in production PostgreSQL.
9. Require MFA for privileged accounts.
10. Require step-up authentication for sensitive admin actions.
11. Audit impersonation.
12. Audit KYC decisions and manual overrides.
13. Sign and verify webhooks.
14. Make compliance operations idempotent.
15. Prevent replay and out-of-order state transitions.
16. Maintain immutable financial/audit records where legally/operationally necessary.
17. Use configurable retention.
18. Keep production and development data separated.
19. Never use real customer/KYC data in tests.
20. Review subprocessors continuously.

## Privacy by design

Every new feature must answer:

- What personal data is collected?
- Why?
- Is it necessary?
- What is the lawful basis?
- Who receives it?
- Where is it processed?
- How long is it retained?
- Can it be avoided or anonymised?
- What rights apply?
- Does it require a DPIA/security review?

A feature cannot ship until these questions are recorded for high-risk processing.
