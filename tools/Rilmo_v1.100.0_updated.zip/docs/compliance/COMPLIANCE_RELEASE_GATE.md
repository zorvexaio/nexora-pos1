# Rilmo — Privacy, Legal & Trust Release Gate

**No public launch until every applicable blocker is closed.**

## Legal entity

- [ ] Legal entity verified.
- [ ] Registered address verified.
- [ ] Privacy contact verified.
- [ ] Terms jurisdiction approved.
- [ ] DPO/representative assessment completed.
- [ ] Merchant agreement approved.
- [ ] DPA approved.
- [ ] Subprocessor agreements reviewed.

## Privacy

- [ ] Final privacy notice approved.
- [ ] Cookie notice/consent approved.
- [ ] Data inventory approved.
- [ ] Record of Processing Activities completed where required.
- [ ] Retention schedule approved.
- [ ] DSR workflow tested.
- [ ] Deletion/anonymisation jobs tested.
- [ ] Legal hold tested.
- [ ] International transfer register completed.
- [ ] Transfer mechanisms executed where required.
- [ ] DPIA completed for high-risk processing where required.

## KYC / fraud

- [ ] KYC provider DPA approved.
- [ ] Biometric processing assessment completed.
- [ ] Provider location/transfer assessment completed.
- [ ] Automated decision review mechanism implemented.
- [ ] Manual review process staffed.
- [ ] False-positive monitoring enabled.
- [ ] Re-verification policy approved.
- [ ] Data minimisation verified.

## Commerce

- [ ] Payment contracts approved.
- [ ] Tax/invoice requirements approved.
- [ ] Refund/consumer rules mapped.
- [ ] Shipping/returns rules mapped.
- [ ] Prohibited-product matrix approved.
- [ ] Sanctions/export-control process approved.

## Security

- [ ] External penetration test completed.
- [ ] RLS production test completed.
- [ ] Secrets rotation tested.
- [ ] Backup restore tested.
- [ ] Disaster recovery test completed.
- [ ] Incident-response exercise completed.
- [ ] Security contact / vulnerability disclosure published.

## EU platform obligations

- [ ] DSA applicability assessed.
- [ ] Trader traceability assessed.
- [ ] Illegal-content reporting/complaints workflow assessed.
- [ ] Advertising/recommendation transparency assessed.
- [ ] Marketplace consumer information assessed.

## Approval

No “green” release status may be granted while any legally mandatory item remains unresolved.
