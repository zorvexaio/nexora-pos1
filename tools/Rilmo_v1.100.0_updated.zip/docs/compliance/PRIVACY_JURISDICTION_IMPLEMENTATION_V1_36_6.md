# Rilmo — Global Privacy Jurisdiction Implementation Matrix v1.36.6

This is an engineering routing baseline, not a legal opinion. Counsel must approve the final matrix before launch in each market.

| Market | Engineering focus |
|---|---|
| Türkiye | KVKK roles, special-category data, transfer mechanism, VERBIS/registration assessment, breach/DSAR workflow, merchant/customer notices |
| EU/EEA | GDPR transparency, data-subject rights, processor contracts, international transfers, DPIA where high risk, automated-decision safeguards, DSA assessment for marketplace functions |
| UK | UK GDPR, Data Protection Act requirements, international-transfer mechanism, data-subject rights |
| Brazil | LGPD rights, international-transfer mechanism, ANPD rules, processor/controller contracts |
| California / US states | State-by-state notice, sale/share/targeted-advertising opt-outs, sensitive-data controls, minors rules where applicable, contract/process mapping |
| Canada | Federal/provincial privacy assessment, consent/notice, safeguards and cross-border controls as applicable |
| Australia | Privacy Act obligations, notice, security, cross-border disclosure assessment |
| Japan | APPI requirements, overseas transfer and consent/notice assessment |
| Singapore | PDPA obligations, consent, notification, transfer protections |
| India | Applicable Digital Personal Data Protection requirements and implementing rules as they enter force; jurisdictional feature flags are mandatory |
| South Africa | POPIA roles, lawful processing, data-subject rights, cross-border controls |
| UAE / GCC | Local privacy law mapping by emirate/free zone/country and cross-border assessment |
| Other jurisdictions | GLOBAL-BASELINE applies only until counsel completes the jurisdiction profile; high-risk functions are blocked until approval |

## Transfer registry requirements

Every transfer record must document:
- exporter;
- importer;
- processor/controller role;
- destination country;
- data categories;
- purpose;
- sensitive-data flag;
- transfer mechanism;
- contract/DPA reference;
- supplementary security measures;
- effective date;
- review date;
- subprocessors.

## Important implementation rule

Country detection is a routing hint, not a legal determination. Merchant operating location, customer location, establishment, targeting, data role and service type can all affect applicability.
