# Unified Global Commerce v1.36.6 — Privacy & Compliance Hardening

## Scope

This release adds the privacy/legal engineering baseline required before public launch.

### Added
- Master Privacy Policy.
- Terms of Service baseline.
- Acceptable Use & Prohibited Products Policy.
- Data Retention & Deletion Schedule.
- Data Processing Addendum baseline.
- Cookie & Tracking Policy.
- Merchant Privacy Compliance Guide.
- Global Jurisdiction Compliance Matrix.
- Security & Privacy Architecture baseline.
- Compliance Release Gate.
- Legal Entity Configuration hard blocker.
- Compliance manifest.
- Public Arabic Privacy and Terms pages.
- Automated tests ensuring the compliance pack is present.

## Important legal status

These documents are **not a substitute for legal advice**. They intentionally contain legal-entity placeholders because the software cannot safely invent the contracting entity, registered address, governing law, DPO/representative, retention periods or jurisdiction-specific legal wording.

The public launch is blocked until:
1. the legal entity is configured;
2. counsel approves each applicable jurisdiction;
3. international-transfer mechanisms are documented;
4. KYC/biometric processing is reviewed;
5. DSR and retention workflows are tested;
6. payment, tax, consumer and prohibited-product requirements are approved;
7. the security and production staging gates are passed.


## v1.36.6 Privacy Control Plane

- Added Privacy Center API surface.
- Added immutable consent-event history with hashed network identifiers.
- Added data-subject request queue for access, rectification, erasure, restriction, objection, portability and automated-decision review.
- Added conservative jurisdiction routing for Turkey, EU/EEA, UK, Brazil, Japan, Singapore, Australia, India, South Africa, UAE, Saudi Arabia and US/Canada state privacy baseline.
- Added explicit human-access controls and privacy architecture specification.
- Added third-party/subprocessor governance specification.
- Added migration `20260818_0039`.
