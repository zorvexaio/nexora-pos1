# Rilmo — Human Access & Confidentiality Policy

## Default

Human access to personal data is deny-by-default and least-privilege. Operational staff receive only the fields required for their job.

## Never expose by default

- raw identity documents;
- selfie/video/biometric material;
- full government identifiers;
- passwords/recovery secrets;
- raw payment-card credentials;
- provider API secrets;
- other restricted KYC evidence.

## Support access

Support may view account status, order references, verification status and support history necessary to resolve the issue. Support cannot retrieve raw KYC evidence.

## Compliance access

A restricted compliance workflow may grant case-scoped access only when there is a documented lawful/operational reason. The access event must record actor, reason, case, target, timestamp and result.

## Audit

Privacy/security audit logs must themselves be protected from ordinary staff and must not contain restricted payloads. Logs should contain references, hashes or event metadata instead of raw sensitive content.

## Customer-facing statement

Rilmo must say exactly what it can support: documents are not stored in Rilmo by default; external verification providers may process the required information; exceptional lawful access can exist; routine staff access is prohibited.
