# Rilmo — Terms of Service (Master)

**Version:** 1.0  
**Effective date:** `[INSERT DATE]`  
**Provider:** `[LEGAL ENTITY NAME]`  
**Jurisdiction / governing law:** `[INSERT AFTER COUNSEL REVIEW]`

## 1. Service

Rilmo is a multi-tenant commerce platform providing storefront, catalog, order, customer, marketing, analytics, AI, integrations, payment and operational capabilities.

Features vary by plan, geography, provider availability and applicable law.

## 2. Eligibility

The person creating an account must have legal capacity to enter the agreement and must provide accurate information.

Business users must be authorised to represent the relevant business.

Rilmo may require identity, business and payment verification before enabling sensitive features.

## 3. Merchant responsibility

A merchant is solely responsible, to the extent required by applicable law, for:

- products and services offered;
- product safety and legality;
- prices and taxes;
- product descriptions and claims;
- intellectual-property rights;
- consumer rights and refunds;
- shipping and fulfilment;
- customer support;
- required licences;
- required invoices and records;
- marketing permissions;
- age restrictions;
- regulated products;
- compliance with applicable sanctions/export controls.

Rilmo is infrastructure and software provider unless a separate agreement states otherwise.

## 4. Prohibited activity

The platform may not be used for:

- unlawful goods/services;
- stolen or counterfeit goods;
- fraud, phishing or impersonation;
- money laundering or terrorist financing;
- sanctions evasion;
- deceptive schemes;
- illegal gambling;
- malware or malicious software;
- trafficking or exploitation;
- non-consensual intimate content;
- child sexual abuse material or exploitation;
- unlawful weapons/explosives;
- illegal drugs;
- regulated products without required licences;
- infringement of intellectual-property rights;
- unlawful collection or sale of personal data;
- manipulation of platform reviews, traffic or transactions;
- abuse of payment systems;
- attempts to bypass KYC, fraud or security controls.

Rilmo may publish a jurisdiction-specific Prohibited Products Matrix.

## 5. Merchant verification

Rilmo may require KYC/KYB, beneficial-owner verification, sanctions screening, payment-provider verification and ongoing re-verification.

Verification does not constitute an endorsement of the merchant or its products.

## 6. AI features

AI-generated content may be inaccurate, incomplete or unsuitable.

Merchants remain responsible for reviewing AI-generated:

- product descriptions;
- claims;
- prices;
- SEO text;
- advertising;
- customer responses;
- images;
- legal/compliance content.

AI must not be used as a substitute for professional legal, tax, medical or financial advice.

## 7. Intellectual property

Users retain rights they own in their content, subject to the licences necessary to operate the service.

Users must not upload content they do not have rights to use.

Rilmo retains rights in its software, trademarks, infrastructure, documentation and proprietary technology.

## 8. Customer content

Merchants grant Rilmo the limited rights necessary to host, process, transmit, display and transform merchant content to provide the service.

Rilmo must not use private merchant/customer data for unrelated commercial purposes unless the applicable contract and law permit it.

## 9. Payments

Payment processing may be provided by third-party payment processors. Merchants must comply with processor terms and verification requirements.

Rilmo may place holds or restrict payouts when reasonably necessary for fraud prevention, disputes, legal obligations or payment-provider requirements, subject to applicable law and contractual requirements.

## 10. Suspension and termination

Rilmo may restrict, suspend or terminate accounts for:

- material breach;
- security risk;
- suspected fraud;
- illegal activity;
- sanctions;
- payment-provider restrictions;
- abuse;
- failure to complete required verification.

Emergency restrictions may occur immediately where necessary to protect users, the platform or comply with law. Where legally and operationally appropriate, the merchant should receive notice and an appeal/review route.

## 11. Appeals

A merchant whose store is restricted should have access to a documented review process unless prohibited by law or security considerations.

Review decisions should be logged with reason, evidence category and reviewer.

## 12. Availability

Rilmo aims for reliable service but does not guarantee uninterrupted availability unless an applicable SLA says otherwise.

## 13. Third-party services

Integrations may have their own terms, privacy notices, service limitations and geographic restrictions.

## 14. Liability

Liability limitations, exclusions and indemnities must be drafted for each target jurisdiction by counsel. Do not publish a universal liability clause without jurisdictional review.

## 15. Consumer rights

Nothing in these terms removes mandatory consumer rights that cannot lawfully be waived.

## 16. Governing law

`[COUNTRY / STATE / COURTS — COUNSEL TO COMPLETE]`

## 17. Contact

`[LEGAL ENTITY / ADDRESS / LEGAL CONTACT]`

**Legal note:** This is a platform baseline and must be adapted by counsel for Türkiye, EEA/EU, UK, US states and other launch markets.
