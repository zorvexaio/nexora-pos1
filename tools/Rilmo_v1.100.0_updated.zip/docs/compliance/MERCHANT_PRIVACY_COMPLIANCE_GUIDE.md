# Rilmo — Merchant Privacy Compliance Guide

Rilmo is a platform, not a universal legal shield. Each merchant remains responsible for its own storefront processing.

## Merchant launch checklist

- [ ] Legal business identity configured.
- [ ] Privacy notice published.
- [ ] Terms/refund policy published.
- [ ] Shipping policy published.
- [ ] Contact information published.
- [ ] Cookie/consent mechanism configured where required.
- [ ] Marketing consent configured.
- [ ] Customer data access/deletion workflow configured.
- [ ] Payment provider disclosure configured.
- [ ] Shipping provider disclosure configured.
- [ ] Third-party app disclosures configured.
- [ ] Product legality reviewed.
- [ ] Tax/invoicing configured.
- [ ] Age restrictions configured where applicable.
- [ ] Data retention configured.
- [ ] Cross-border transfer disclosure configured.

## Platform responsibility

Rilmo should provide templates, controls and technical enforcement, but must not claim that enabling a checkbox makes a merchant legally compliant in every country.
