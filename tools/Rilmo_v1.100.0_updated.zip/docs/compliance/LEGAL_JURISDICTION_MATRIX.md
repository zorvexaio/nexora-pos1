# Rilmo — Jurisdiction Compliance Matrix

This matrix is an engineering planning layer, not legal advice.

| Market | Primary privacy framework to assess | Key Rilmo controls |
|---|---|---|
| Türkiye | KVKK | special-category controls, transfer mechanism, VERBIS/DPO assessment where applicable, notices, DSR |
| EEA/EU | GDPR + ePrivacy + DSA where applicable | lawful bases, DPIA, DSR, SCC/adequacy, cookie consent, automated decision safeguards, marketplace obligations |
| UK | UK GDPR + DPA 2018 + PECR | privacy notice, DSR, transfer mechanism, cookies/marketing |
| California | CCPA/CPRA | notice at collection, consumer rights, opt-out mechanisms, sensitive-data controls |
| Brazil | LGPD | legal bases, DSR, transfer controls, incident procedures |
| Other US states | State-specific privacy laws | jurisdiction detection, configurable rights/opt-out workflows |
| Canada | PIPEDA/provincial laws | notice, consent, safeguards, access/correction |
| Australia | Privacy Act + applicable reforms | notice, consent, access/correction, cross-border disclosures |
| Japan | APPI | purpose notice, transfer requirements, rights |
| Singapore | PDPA | consent, notification, access/correction, transfer safeguards |
| UAE/GCC | Local privacy and sector rules | local counsel, transfer controls, notices |
| India | DPDP and applicable rules when effective/applicable | notice, consent/legitimate statutory basis as applicable, rights, transfers |
| South Africa | POPIA | notice, lawful processing, rights, operator controls |

## Engineering rule

Do not hard-code one country's privacy model into the global platform. Use a **Jurisdiction Policy Engine** controlling:

- notice version;
- lawful-basis labels;
- consent requirements;
- cookie categories;
- DSR rights;
- retention;
- transfer mechanism;
- age thresholds;
- marketing channels;
- automated-decision disclosures;
- representative/contact details.

## Türkiye

KVKK's current international-transfer framework must be checked at launch; standard contractual clauses and official guidance are available from the authority. citeturn0search0turn0search10

## EU

The DSA should be assessed if Rilmo operates an in-scope online platform/marketplace for EU users. citeturn0search2

## California

CCPA/CPRA applicability must be assessed based on the business and data thresholds, and required consumer notices/rights implemented where applicable. citeturn0search3turn0search13
