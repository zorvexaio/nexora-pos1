# Runtime Environment Evidence — v1.42.0

## Local builder environment
The source and test tree passes the functional and static gates, but this builder image intentionally does not match every pinned production dependency in `requirements.txt`. The strict `scripts/environment_audit.py` therefore remains **FAIL** in this local image and must not be overridden.

## Reproducible environment
The repository contains exact dependency pins, `httpcore==1.0.9` as a direct dependency for the DNS-pinned webhook transport, a clean-install guard, and CI environment verification. GitHub Actions is the authoritative clean-install evidence path.

## Production-equivalent evidence
- PostgreSQL runtime role / BYPASSRLS / FORCE-RLS: automated CI gate `scripts/postgres_runtime_security_gate.py`.
- Backup and restore: automated CI rehearsal `scripts/backup_restore_rehearsal.sh`.
- Payment/KYC provider integrations: staging credentials and real provider webhooks remain environment-specific and are intentionally not fabricated in source control.
