# Unified Global Commerce v1.92.2

## Security hardening — storefront analytics tenant integrity

Public storefront analytics events now validate `product_id` against the active verified storefront tenant before persistence. Foreign-tenant product identifiers are rejected with `LIVE_EVENT_PRODUCT_INVALID`, preventing cross-tenant analytics attribution and catalog identity leakage.

Regression coverage added in `tests/test_v1921_live_event_tenant_integrity.py`.
