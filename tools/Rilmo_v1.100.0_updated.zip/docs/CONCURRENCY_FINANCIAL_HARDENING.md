# Concurrency & Financial Hardening v1.8.8

## Payment mutations
Capture and refund operations are serialized per payment intent with a durable `payment_operations` record. The provider is called only after the DB records the operation intent and commits. Finalization re-locks the payment intent and re-checks cumulative captured/refunded amounts. Different concurrent operations on the same intent fail closed with `PAYMENT_OPERATION_IN_PROGRESS`.

## Inventory mutations
Reservation and adjustment endpoints require idempotency keys and lock the target inventory row with `FOR UPDATE` before mutating counters. PostgreSQL documents `FOR UPDATE` as a row-level write lock; the implementation relies on this for race prevention.

## Provider calls
External Stripe calls do not execute inside an open DB transaction. Provider idempotency keys are the durable operation keys.


### Migration
`20260816_0014_payment_operation_serialization` introduces the durable payment-operation state machine used to serialize provider effects.
