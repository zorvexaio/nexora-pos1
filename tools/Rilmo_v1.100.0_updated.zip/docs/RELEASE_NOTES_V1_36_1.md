# Unified Global Commerce v1.36.1

## Runtime verification and deployment parity closure

- Corrected `scripts/local_runtime_smoke.py` to validate the current storefront host contract using `<meta name="store-host">` instead of the removed inline `window.__STORE_HOST__`.
- Added explicit server-readiness waiting and a clear timeout failure to the local runtime smoke test.
- Smoke test now records the full path: health → ready → storefront → guest cart → checkout → payment intent → capture.
- Wired `ENCRYPTION_KEY` into Docker migration/api runtime configuration so local Compose reflects the production secret model.
- Removed duplicate migration environment variables from Docker Compose.
- Aligned Docker's default AI model with application configuration (`gpt-5.6`).
- Aligned release manifest, `VERSION`, and README to 1.36.1.

## Validation

- 178/178 tests passed with warnings treated as errors.
- Full Alembic upgrade/downgrade/re-upgrade passed.
- Live local smoke passed against a real Uvicorn process and SQLite runtime.
- Release/frontend/spec/hygiene audits passed.
