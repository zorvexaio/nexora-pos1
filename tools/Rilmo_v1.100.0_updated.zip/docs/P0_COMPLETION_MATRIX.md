# P0 Completion Matrix — v1.8 Deep Pass

| Domain | Implementation | Local verification | Staging verification |
|---|---|---|---|
| Identity/session | DONE | PASS | Required |
| Tenant/RBAC | DONE | PASS | Required |
| PostgreSQL RLS | MIGRATION | Static verified | Required |
| Catalog/pricing | DONE | PASS via checkout | Required |
| Cart/checkout/orders | DONE | PASS | Required |
| Payments/refunds | DONE | PASS | Stripe required |
| Ledger | DONE | Structural tests | DB privilege proof required |
| Inventory | DONE | Basic tests | Race suite required |
| Outbox/DLQ | DONE | Worker compile | Poison/retry integration required |
| Domain provisioning | DONE | Token tests | DNS takeover test required |
| Storefront publication | DONE | Route checks | Real DNS required |
| Billing/entitlements | DONE | Schema/API | Stripe Billing required |
| Wishlist/reviews/Q&A | DONE | API smoke | Required |
| SSRF/upload policy | DONE | 2 abuse tests | Provider integration required |
| CSRF/auth abuse | DONE | CSRF + rate-limit code | Browser/staging required |
| PII lifecycle | DONE | Anonymization API | Retention policy verification required |
| Threat model T1–T20 | PARTIAL | 7 local tests | Full suite required |
| Commercial Gates A–E/A+ | NOT CLAIMED | N/A | Must pass before launch |
