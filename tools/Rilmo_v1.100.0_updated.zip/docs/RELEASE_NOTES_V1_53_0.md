# Rilmo / Unified Global Commerce v1.53.0

## Global compliance infrastructure
- Digital Product Passport (DPP) model and revision history.
- Public, redacted DPP endpoint with opaque token and versioned snapshots.
- Tenant-scoped DPP tables with PostgreSQL ENABLE + FORCE RLS.
- Product compliance, provenance, materials, certification and circularity fields are versioned and auditable.
- DPP is jurisdiction-aware infrastructure, not a legal claim; merchants remain responsible for applicable product-sector obligations.

## Engineering gates
- Runtime/integration tests required for DPP create, publish and revision flows.
- Release hygiene rejects local DB journals, caches, bytecode and build helper scripts.
- Current UCP alignment remains v2026-04-08; catalog/cart capabilities are tracked separately.
