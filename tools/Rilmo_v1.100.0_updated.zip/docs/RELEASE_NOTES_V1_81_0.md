# Rilmo / Unified Global Commerce v1.81.0

- Hardened UCP agent identity with UCP-Agent profile binding and bearer credential verification.
- Added hashed agent credential storage, one-time credential issuance, and secure rotation.
- Added migration 20260820_0059_agent_ucp_credentials.
- Added machine-readable agent profile endpoint.
