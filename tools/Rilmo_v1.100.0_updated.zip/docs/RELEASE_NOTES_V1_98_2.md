# v1.98.2 — Historical Profitability Integrity

## Why this release exists
Catalog cost is mutable. Reconstructing historical COGS from the current product variant would make merchant profitability reports change after a catalog edit.

## Changes
- Added `order_items.cost_amount_minor` as an immutable cost snapshot captured at order creation.
- Checkout and POS now persist the variant cost snapshot into every new order line.
- Added tenant-scoped `GET /v1/analytics/profitability` with bounded windows and explicit cost-coverage reporting.
- Gross margin is calculated from merchandise line revenue versus known historical COGS; shipping/tax are not incorrectly treated as product revenue.
- Existing historical orders remain valid with `NULL` cost snapshots and are surfaced as incomplete cost coverage instead of fabricated margins.
- Added Alembic migration `20260909_0070_order_item_cost_snapshot`.
