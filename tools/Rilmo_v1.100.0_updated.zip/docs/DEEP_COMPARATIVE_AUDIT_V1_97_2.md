# Deep Comparative Audit — v1.97.2

## Compared artifacts

- `v1.96.20_DEEP_HARDENED_RELEASE.zip`
  - SHA-256: `309129f007339c9b2ef2cb595829b479cb2f7c2a5c90dc4b3bb17c6579ebb586`
  - Verified from the stored library artifact.
- `v1.97.1_RELEASE.zip`
  - SHA-256: `c73d1398fdf17361a26c206bdadc579eca5c96eda5b9345d44afe89cdcdc00f`
  - Verified from the stored release artifact.

## Material finding

`v1.97.1` was newer by version number but its packaged Alembic surface omitted `20260823_0066_pos_session_open_uniqueness.py` and `20260825_0067_inventory_available_invariant.py` that were present in the v1.96.20 deep-hardened artifact. Its application code also regressed several verified controls from v1.96.20, including inventory-location disambiguation, available-stock protection, OAuth token rate limiting, WhatsApp webhook bounds/duplicate handling, shipping carrier path validation, dynamic payment User-Agent construction, merchant settings authorization, and terminal-payment callback protection.

It also contained a checkout wrapper mismatch: `/orders` stopped forwarding the `request` and `response` parameters required by the underlying checkout function. The release tooling in the compared artifact no longer excluded `media_store` from clean releases.

## Consolidation performed

v1.97.2 was constructed by preserving the verified v1.96.20 hardening and re-applying the newer v1.97.x closures:

- OAuth refresh-token client binding.
- OAuth scope re-authorization revocation of existing credentials.
- Tenant-scoped domain-purchase idempotency.
- API-key entitlement/scope enforcement.
- Advanced analytics entitlement.
- Storefront variant selection/accessibility state updates.

The lost migrations were restored and the domain-purchase idempotency migration was renumbered as `20260908_0068` so the final chain is a single linear head: `0065 -> 0066 -> 0067 -> 0068`.

## Verification evidence

- Fresh SQLite Alembic upgrade: PASS through `20260908_0068`.
- Python compilation: PASS.
- JavaScript syntax check for storefront: PASS.
- Deep regression/consolidation test selection: **103/103 PASS**.
- Full pytest collection: **847 tests collected**.
- Full single-process pytest run with `-W error`: not completed in this sandbox; the run exceeded the execution timeout after reaching about 8%. This is recorded as unverified rather than converted to PASS.
- Release artifact audit: PASS.
- Release consistency: PASS.
- Final release structural audit: PASS.
- Security gate: PASS.
- Regulatory readiness audit: PASS (16 checks).
- Spec audit: PASS (196 ORM tables, 88 structurally tenant-scoped RLS tables, 332 unique method/path route declarations).
- Spec/schema audit: PASS.
- Frontend audit: PASS.
- Dependency audit: PASS.
- Release hygiene: PASS before final packaging.
- ZIP integrity (`unzip -t`): PASS.

## Environment boundary

The runtime dependency-lock gate is not claimed as PASS in this sandbox because the preinstalled environment does not match the production lock (for example FastAPI, Starlette, SQLAlchemy, cryptography, pytest and other pinned versions are different, and some locked packages are absent). PostgreSQL/RLS runtime, real provider E2E, load/soak/failover, backup/restore and independent security evidence remain external production gates.
