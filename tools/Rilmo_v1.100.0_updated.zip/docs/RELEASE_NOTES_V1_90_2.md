# Release 1.90.2

## Critical financial consistency hardening
- Provider-success webhooks for iyzico and PayTR now materialize a local `PaymentCapture` record before finalizing the payment.
- Provider-success webhooks now post the corresponding balanced merchant-sale ledger entry.
- Provider capture IDs are idempotently bound to a single payment intent and amount/currency.
- Full-capture webhooks confirm the associated order without creating duplicate confirmation transitions.
- Added regression coverage for successful iyzico and PayTR webhook capture materialization and ledger balance.
