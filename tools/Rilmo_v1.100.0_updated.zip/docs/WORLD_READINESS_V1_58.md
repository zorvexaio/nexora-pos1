# Rilmo World Readiness — v1.58.0

## Purpose
This document prevents the project from confusing a strong codebase with proof of global production readiness. A 100% global certification cannot be established by local source tests alone.

## Current engineering position
- Multi-tenant commerce core with PostgreSQL RLS controls.
- Payments, billing, tax, shipping, B2B, POS-oriented operations, app ecosystem, workflows, webhooks and reconciliation.
- Agentic commerce with UCP-aligned discovery/checkout surfaces and transaction policy controls.
- Server-side AI with internal Ollama default, bounded concurrency, deterministic fallback and production egress isolation.
- Digital Product Passport model with identifiers, data carriers, conformance metadata and public-data boundary.
- Privacy/KVKK control plane, KYC isolation, least privilege and auditable exceptional access.
- SBOM, deterministic manifests, release hygiene and artifact-level verification.

## Global benchmark gaps that are NOT honestly closable in a ZIP
1. Production multi-region topology, measured RTO/RPO, failover and capacity evidence.
2. Real PostgreSQL production-role/RLS verification.
3. Real iyzico/PayTR/Paddle certification, settlement, refund and webhook replay evidence.
4. Independent penetration test and AI/agent red-team assessment.
5. Real DNS takeover/ownership testing on the production DNS provider.
6. Real object-storage/ClamAV malicious corpus and lifecycle testing.
7. Staging T1–T20 regression on production-like infrastructure.
8. Legal review for each launch jurisdiction, including controller/processor/subprocessor roles, transfer mechanisms and tax/e-invoicing obligations.
9. Commercial proof: merchants, GMV, uptime history, support operations, app ecosystem size and partner network.

## Current external reference points checked 2026-08-19
- UCP latest published release observed: v2026-04-08.
- OWASP ASVS latest stable: 5.0.0.
- PCI DSS current published version: v4.0.1.
- EU DPP Registry is operational as of 20 July 2026; certain battery passports become mandatory 18 February 2027.
- NIST AI RMF 1.0 is being revised; the Generative AI Profile remains an active companion resource.

## Certification rule
Rilmo must not be described as "100% globally production-certified" until all external gates above have attached evidence and an independent assessor has signed the release.
