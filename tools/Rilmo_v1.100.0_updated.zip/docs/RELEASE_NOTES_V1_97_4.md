# Unified Global Commerce v1.97.4

## Return integrity hardening

- Return creation now locks the target order and order-item rows with PostgreSQL row locks.
- Duplicate `order_item_id` entries inside a single return request are aggregated before quantity validation.
- This closes two concrete over-return races: concurrent return requests for the same order line and duplicate line entries within one request.
- Added regression tests covering the locking contract and duplicate-item aggregation.

## Evidence

- Return regression + v1.97.4 hardening tests: 5/5 PASS.
- Full production readiness remains dependent on real PostgreSQL/RLS runtime evidence, real provider sandbox/live evidence, load/failover/backup-restore rehearsal, and independent security/legal review.
