# Release Notes — v1.42.0

## Security closure
- DNS-pinned outbound app-webhook transport prevents resolver TOCTOU between SSRF validation and connection.
- Reverse-proxy forwarding headers are explicitly constrained by `FORWARDED_ALLOW_IPS`; production rejects wildcard trust.
- Production server startup is centralized in `scripts/run_server.py` so proxy trust is configuration-driven.
- Added `scripts/postgres_runtime_security_gate.py` to fail closed when the application DB role has SUPERUSER/BYPASSRLS or tenant tables lack ENABLE+FORCE RLS or retain client-settable worker bypass policies.
- Added encrypted backup/restore rehearsal automation for CI.
- Removed unused Stripe dependency and stale editor artifact.
- Pinned `httpcore` directly because the application uses its network-backend interface for DNS pinning.

## Evidence
The local artifact includes code, tests, CI gates, documentation, and release hygiene. Production-specific PostgreSQL/RLS and backup/restore evidence is executed by the GitHub Actions PostgreSQL jobs and must also be repeated against the actual production-equivalent environment before deployment.
