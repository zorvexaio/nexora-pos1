# Unified Global Commerce v1.84.0

## Release focus
Payment-bound domain commerce, event-contract hardening, and closure of previously untested integration services.

## Material changes
- PaymentIntent now supports an explicit `domain_purchase_id` binding.
- Domain purchase checkout enforces exact amount and currency and rejects ambiguous payment targets.
- Domain registrar execution is deferred until a confirmed payment capture event.
- Domain registration is idempotent at the purchase state level and cannot attach a domain to another tenant.
- Worker event governance now separates internal side-effect handlers from auxiliary app-webhook/audit events.
- Legacy SMS verification delivery delegates to the canonical notifications provider to avoid duplicate provider implementations.
- Added tests for SMS provider behavior, ClamAV scanning, domain registrar contracts, and worker auxiliary-event routing.
- Test evidence source is now based on live pytest collection: 346 tests, rather than the stale 330-test documentation count.

## Important certification boundary
This release is engineering-hardened, not globally certified. Production PostgreSQL/RLS evidence, real payment/KYC/DNS/object-storage evidence, operational SLO/load evidence, independent penetration testing, independent AI red-team, and jurisdiction-specific legal/tax review remain external gates.
