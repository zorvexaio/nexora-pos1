# v1.99.0 — Merchant Command Center

## Product milestone

v1.99.0 turns the analytics layer into an operational merchant cockpit rather than a collection of counters.

### Added
- `GET /v1/analytics/command-center`
- Currency-safe revenue, refunds, net revenue, AOV and gross-profit signals.
- Historical-cost integrity: profit is explicitly unknown when cost snapshots are incomplete.
- Top-product economics with units, revenue, known COGS and completeness state.
- Operational signals for out-of-stock, low-stock, fulfillment backlog and risk-review orders.
- New-customer signal and total customer base.
- Deterministic prioritized action cards for the merchant dashboard.

### Design principle
The platform must never create a misleading financial KPI by mixing currencies or inventing missing cost data. The command center therefore exposes both business opportunity and data-quality state.
