# Rilmo World Commerce Platform — v1.49

## Product thesis
Rilmo is designed as a multi-tenant commerce operating layer rather than a single storefront. The platform combines commerce, B2B, POS, experimentation, AI discoverability, machine-readable feeds and agentic checkout protocols behind the same tenant, catalog, pricing, inventory and authorization model.

## Capability map

### B2B
B2BCompany → B2BCompanyContact → B2BCatalog → B2BCatalogItem → B2BCatalogAssignment

The price returned by the B2B price service is calculated from the server-side catalog item and variant, never from client-submitted totals.

### POS / Omnichannel foundation
POSLocation → POSRegister → POSSession → POSOrderLink → Order / InventoryItem

POS sale prices come from `ProductVariant.price_amount_minor`; mutations require idempotency and the inventory row is locked during the sale.

### Growth & experimentation
CommerceExperiment → stable deterministic variant assignment → storefront rollouts.

Assignments are keyed by tenant + experiment + subject so the same shopper stays on the same variant.

### AI discoverability and feeds
The platform computes product discoverability signals from product copy, SEO metadata, multilingual coverage and active variants, then exposes machine-readable catalog feeds.

Feed inventory is derived from actual `InventoryItem.available` quantities.

### Agentic commerce / UCP
Rilmo publishes a machine-readable storefront profile and a UCP-compatible checkout foundation. UCP checkout sessions require a merchant-generated external session identifier, resolve variant prices from the authoritative catalog and are idempotent on retries.

The current implementation references the UCP `2026-04-08` protocol version; external conformance testing and provider certification remain staging/production gates.

## Security boundaries
- Public agentic endpoints do not use the browser's cookie-authenticated session.
- Normal browser flows keep the existing CSRF enforcement.
- Tenant-scoped World Commerce tables are covered by database-level RLS.
- Generic serialization remains fail-closed for secrets and secret-like fields.
- Audit-chain hash fields are exposed only through the dedicated authorized audit representation.

## Non-claims
This layer increases product surface area and differentiating capability. It does not, by itself, prove market leadership, live SLA performance, local regulatory approvals, real payment-provider certification, or third-party ecosystem adoption. Those require operational and commercial execution outside the source tree.
