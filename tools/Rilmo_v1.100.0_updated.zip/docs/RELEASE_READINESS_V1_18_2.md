# Release Readiness — v1.18.2

## Local engineering gate

- 152/152 automated tests pass with `pytest -q -W error`.
- Alembic head: `20260816_0029`; upgrade → downgrade → re-upgrade verified locally.
- Static route/spec/schema/security/frontend/dependency audits pass.
- Release hygiene passes after removing local database/cache/bytecode artifacts.
- Python source was AST-normalized for readability; official Black 26.5.1 and Ruff 0.16.0 are pinned in `requirements-dev.txt` and enforced by CI.

## External staging gate

**BLOCKED.** No public staging deployment evidence is included in this artifact.

The project must not be described as globally production-ready until `docs/STAGING_EVIDENCE_RECORD.md` is populated from a real HTTPS deployment with the evidence listed in `docs/STAGING_GATE.md`.

Required evidence includes real provider sandbox payment/refund/webhook cycles, PostgreSQL RLS isolation, backup/restore, malware scanning, bounded load/SLO results, and deployed T1–T20 regression.
