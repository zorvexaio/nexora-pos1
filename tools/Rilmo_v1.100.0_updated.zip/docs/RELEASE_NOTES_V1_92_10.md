# Release Notes — v1.92.10

## Payment reference integrity
- iyzico refunds now require the provider-specific `refundHostReference` instead of reusing the payment identifier.
- iyzico cancels now require the provider-specific `cancelHostReference`.
- PayTR refunds now require the returned `reference_no`; the payment/order reference is no longer fabricated as a refund reference.

## Domain registration integrity
- Cloudflare domain registration no longer fabricates a reference from the hostname when the registrar returns an empty result.
- Empty registrar results now remain explicitly pending without a fake external reference and are handled by the worker's reconciliation policy.

## Verification
- Added provider-reference regression tests.
- Existing financial, worker, security, schema and release gates must pass before release.
