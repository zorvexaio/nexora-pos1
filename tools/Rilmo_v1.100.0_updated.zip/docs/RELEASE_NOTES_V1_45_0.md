# Release Notes — Unified Global Commerce v1.45.0

## Operational and webhook integrity hardening

- Added atomic provider webhook claiming with database uniqueness protection.
- Concurrent/replayed webhook deliveries now return idempotently instead of racing a pre-check into a 500.
- Reuse of a provider event ID with a different payload hash is rejected as `WEBHOOK_PAYLOAD_MISMATCH` and is treated as a provider-integrity/security signal.
- Hardened `/v1/ready` to report database and Redis readiness and return HTTP 503 when production dependencies are unavailable.
- Readiness reports the deployed application version for deployment diagnostics.
- Existing payment idempotency, capture/refund caps, inventory locking, RLS, KYC privacy controls, impersonation isolation, and regulatory gates remain unchanged.

## Verification

- 220 tests passed with warnings treated as errors.
- Source, schema, frontend, security, regulatory, dependency, and release hygiene gates are required for release.
- Live runtime, PostgreSQL/RLS, backup/restore, and staging evidence remain environment-specific gates and are not fabricated as local evidence when the required infrastructure is unavailable.
