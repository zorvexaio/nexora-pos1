# P0 T1–T20 Threat Regression Matrix

The v1.8 specification requires at least one automated regression test for every T1–T20 threat before Gate A+ can pass.

| ID | Threat | Automated coverage in this repository | Status |
|---|---|---|---|
| T1 | cross-tenant IDOR | `test_cross_tenant_idor_blocked`, cart/wishlist boundary tests | PASS |
| T2 | role escalation | `test_role_escalation_is_blocked` | PASS |
| T3 | platform-admin impersonation | `test_platform_admin_cannot_be_impersonated` | PASS |
| T4 | session fixation/replay | `test_session_replay_after_logout_is_rejected` | PASS |
| T5 | CSRF | `test_cookie_csrf_boundary` | PASS |
| T6 | OAuth account takeover/linking | `test_oauth_linking_cannot_take_over_existing_identity` | PASS |
| T7 | password-reset abuse | `test_password_reset_existence_does_not_leak` | PASS |
| T8 | MFA recovery abuse | `test_recovery_code_is_single_use_and_hashed` | PASS |
| T9 | webhook forgery/replay | signature + replay tests | PASS |
| T10 | SSRF / DNS rebinding | outbound URL policy tests | PASS |
| T11 | malicious file upload | upload type/size/active-content tests | PASS |
| T12 | duplicate payment/capture/refund | duplicate capture + refund-cap/idempotency tests | PASS |
| T13 | inventory expiry race | `test_inventory_expiry_releases_stock` | PASS |
| T14 | coupon concurrency abuse | coupon usage-limit transaction test | PASS |
| T15 | domain takeover | domain verification token reuse test | PASS |
| T16 | queue poison/retry storm | `test_queue_poison_reaches_dlq` | PASS |
| T17 | audit tampering | `test_audit_tampering_is_detectable` | PASS |
| T18 | secret leakage through logs/errors | secret serialization and reset tests | PASS |
| T19 | stale entitlement privilege retention | `test_cancel_subscription_revokes_entitlements` | PASS |
| T20 | cache/search/storage tenant leakage | tenant-prefixed media key + cross-tenant mutation test | PASS |

**Important:** PASS here means an automated regression exists and passes in the local test environment. It does not substitute for staging evidence required by the commercial release gate.
