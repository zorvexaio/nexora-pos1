# Release Notes — v1.31.0

## Focus
Deep security, reliability, permission and AI-output hardening over v1.30.0.

## Security fixes
- Bounded request payloads by endpoint class.
- Added anti-abuse throttling for AI, Live View ingestion and affiliate clicks.
- Added function-level permission checks to the new growth APIs.
- Required WhatsApp webhook HMAC signing secret and deduplicated inbound provider message IDs.
- Removed inline storefront bootstrap JavaScript that conflicted with the deployed CSP; storefront host now comes from a CSP-safe meta tag.
- Converted upload policy `ValueError` paths into explicit 422 API errors.

## AI reliability
- Responses API now uses distinct strict JSON schemas for product copy, merchant assistant and search ranking rather than applying one incompatible schema to every AI operation.

## Dependencies
- Pydantic 2.13.3
- email-validator 2.3.0
- cryptography 49.0.0
- FastAPI 0.140.0, SQLAlchemy 2.0.51 and Pillow 12.3.0 remain on the verified current stable pins used by this release.

## Verification
- 168 tests passed.
- Migration round-trip passed.
- Release, frontend, schema, source-format and dependency audits passed.
