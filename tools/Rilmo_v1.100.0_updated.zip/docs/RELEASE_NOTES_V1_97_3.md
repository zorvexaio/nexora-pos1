# Unified Global Commerce v1.97.3 — Concurrency & Trace Hardening

## Security/consistency hardening
- Password-reset token consumption now locks the token row before validation/update, preventing concurrent redemption races.
- Merchant phone verification now locks the pending verification row before incrementing attempts/consuming the code, preventing concurrent double-use.
- Request correlation IDs are bounded and character-validated before being reflected into response headers, with a server-generated fallback for malformed/oversized values.

## Verification
- Targeted regression suite must cover password-reset replay, merchant phone replay, and request-ID validation.
- Release artifact is rebuilt only after all release gates pass.
