# Unified Global Commerce v1.92.18

## CI and release-control hardening

- Removed the stale Alembic CI assertion pinned to revision `20260822_0063`.
- CI now requires exactly one Alembic head without hard-coding a historical revision.
- Added regression coverage to prevent reintroduction of the stale migration-head check.
- No schema migration is introduced by v1.92.18; the database head remains `20260822_0064`.

## Evidence target

- Full test inventory remains the v1.92.17 baseline plus the release-control regression.
- Security and release gates must be re-run after packaging.
