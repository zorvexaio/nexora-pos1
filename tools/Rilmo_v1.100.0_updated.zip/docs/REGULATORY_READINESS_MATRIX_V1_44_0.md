# Rilmo Regulatory Readiness Matrix — v1.44.0

This is an engineering readiness matrix, not a legal opinion.

| Area | Engineering controls | Production evidence required | Applicability |
|---|---|---|---|
| KVKK | Privacy center, DSRs, transfer register, KYC minimization, access grants, audit logging | Legal entity/controller-processor mapping, notices, contracts, transfer mechanism evidence | Turkey / where applicable |
| International transfers | Transfer route records, contract type, signature/authority evidence, approval state | Signed standard contract/BCR or other valid mechanism, filing/record evidence where required | Where data leaves Türkiye |
| PCI DSS 4.0.1 | Provider-hosted/tokenized payment pattern, webhook verification, no raw PAN/CVV storage | SAQ/ROC determination, provider AOC/attestation, segmentation evidence | Payment flows |
| EAA / accessibility | WCAG-oriented controls, accessibility statement, regression gate | Published accessibility review with assistive-technology tests | EU e-commerce/services where applicable |
| DSA | Platform model switch; merchant/trader disclosure can be enabled for marketplace mode | Legal qualification as hosting service/marketplace, trader verification/contact processes | Only if Rilmo operates as a marketplace/intermediary |
| GPSR | Product/catalog fields can be extended without exposing KYC data | Applicable economic-operator/product-safety workflows and jurisdiction review | Where Rilmo acts within scope |

Production must not describe these controls as certification. Legal qualification depends on the actual entity, business model, jurisdictions, contracts, and deployment.
