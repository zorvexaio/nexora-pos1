# Release Notes — v1.97.0

## OAuth security closure

- Re-authorization now treats scope changes as a credential-boundary event. Existing access and refresh tokens for the installation are revoked before the new scope set becomes active.
- The installation row is locked during authorization to prevent concurrent scope-update races.
- This prevents an old token issued with broader permissions from remaining usable after the merchant explicitly narrows the app grant.

## Verification

- OAuth scope-revocation regression suite: **5/5 PASS**.
- Existing OAuth client-binding and PKCE tests remain included in the targeted run.

## Release boundary

This release contains local deterministic evidence only. Production/global certification still requires the external PostgreSQL/RLS, real provider, load/soak/failover, backup/restore and independent security evidence defined by the project gates.
