# Unified Global Commerce v1.36.0

Security and production-hardening release.

- Upgraded FastAPI to 0.141.1 and Boto3 to 1.43.55.
- Added CSRF enforcement for customer-cookie mutations.
- Added customer email verification rate limiting by identity and IP.
- Removed hardcoded PayTR localhost IP and production test mode.
- PayTR now rejects unsupported non-TRY settlement for this integration.
- Paddle webhook timestamp validation now uses configurable tolerance.
- Removed duplicate Twilio settings.
- Synchronized release version to 1.36.0 across runtime and Compose defaults.
- Added regression/security test coverage.
- Fixed upload stream/file lifecycle leaks on rejected multipart uploads.
- Release gate now runs the complete migration cycle and warnings-as-errors suite.
- Final route inventory: 199 unique method/path declarations.
