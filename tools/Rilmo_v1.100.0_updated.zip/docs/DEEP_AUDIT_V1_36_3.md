# Deep Audit — v1.36.3

This release closes two reliability/security gaps discovered during release-candidate review:

1. App webhooks now use `app_webhook_deliveries` so one failing destination cannot force successful destinations to be retried with the whole outbox event.
2. Idempotency records in `IN_PROGRESS` state are rejected for a concurrent duplicate operation, while the first transaction is explicitly marked as the fresh owner.
3. Production outbound app-webhook destinations require an exact host allowlist via `APP_WEBHOOK_ALLOWED_HOSTS` to reduce SSRF/DNS-rebinding exposure.

Validation target: OWASP ASVS 5.0 and current WSTG guidance.
