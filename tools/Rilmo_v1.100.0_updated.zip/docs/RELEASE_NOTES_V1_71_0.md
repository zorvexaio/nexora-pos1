# v1.71.0 — Global 2026 Legal & Compliance Enforcement Layer

## Engineering changes

- Added jurisdiction compliance policy control plane for GDPR, KVKK, UK GDPR, LGPD, US state privacy, India DPDP, Saudi PDPL and UAE PDPL baselines.
- Added a ROPA-style processing-activity register with legal bases, data categories, recipients, transfer mechanisms, retention, DPIA and AI flags.
- DSR due dates and supported rights are now derived from jurisdiction policy rather than a single global hard-coded window.
- Added EU AI Act Article 50 transparency metadata for AI interactions, including a human-readable disclosure and machine-readable marker.
- Added California GPC enforcement before analytics visitor identifiers are created.
- Added DSA Notice-and-Action submission, decision and appeal surfaces for jurisdictions where marketplace controls apply.
- Added public trader information surface for marketplace traceability.
- Added PostgreSQL platform-role context for platform-only compliance RLS policies.
- Added 2026 engineering baselines based on current official regulator publications.

## Legal boundary

This release encodes technical controls and configurable jurisdiction policy. It does not represent legal advice, a universal legal warranty, or an external certification. Launch remains gated by entity configuration, counsel approval, contracts, transfer instruments, tax/e-invoicing registrations, payment-provider onboarding and market-specific evidence.
