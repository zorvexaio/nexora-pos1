# Release Notes — v1.58.0

## Security closure
- Production server-only AI now rejects arbitrary external AI_BASE_URL values.
- Only the internal Ollama service hostnames are accepted while AI_SERVER_ONLY is enabled in production.
- Added adversarial tests for AI endpoint exfiltration prevention.

## Release integrity
- Updated current version/evidence metadata to v1.58.0.
- Added an explicit world-readiness matrix separating engineering evidence from external certification.
- Historical release notes remain unchanged as historical records.
