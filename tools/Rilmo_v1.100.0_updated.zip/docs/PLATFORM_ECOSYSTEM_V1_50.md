# Rilmo Platform Ecosystem v1.50

## Objective

Turn Rilmo from a product-only commerce SaaS into a platform other developers can safely extend.

## App Marketplace

- Platform Admin publishes an approved application listing.
- Listing contains category, pricing model, supported countries/locales and feature metadata.
- Public catalog is read-only and excludes OAuth client secrets/access tokens.
- Reviews require an active installation and are tenant-scoped with one review per app/tenant.

## Workflow Engine

- Existing workflow definitions now have durable per-step execution records.
- Supported actions are deliberately constrained: email, coupon creation, loyalty points and HTTPS webhook enqueueing.
- Webhooks are queued into the existing outbox instead of being sent inline.
- Every step has input/output state, status, timestamps and an error boundary.

## Event Contracts

The `commerce_event_schemas` registry is the compatibility boundary for third-party applications. New event versions must be additive or explicitly versioned; consumers must not rely on undocumented response shapes.

## Security Rules

- Tenant-owned platform tables use `ENABLE + FORCE ROW LEVEL SECURITY` on PostgreSQL.
- Public marketplace endpoints never disclose app OAuth secrets or access tokens.
- Workflow webhooks require HTTPS.
- Workflow step inputs intentionally exclude secrets and headers from persisted step input payloads.

## Strategic Direction

This layer is the foundation for an ecosystem comparable in architecture to mature commerce platforms: developers build apps, merchants install them, workflows automate operations, and event contracts make the platform composable.
