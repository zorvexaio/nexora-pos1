# v1.99.3 — Revenue Intelligence

Adds currency-safe revenue intelligence with equal-period growth and refund-pressure signals.

## Safety properties
- No cross-currency revenue aggregation.
- Growth is calculated only within the same currency.
- Refunds count only `SUCCEEDED`/`COMPLETED` records.
- Zero prior-period revenue returns an explicit null growth value instead of an invented percentage.
