# Rilmo / Unified Global Commerce v1.44.0

## Security and session integrity
- Split employee and read-only impersonation sessions; ending impersonation preserves the employee session.
- Impersonation requires a reason and, in production, a support/compliance ticket reference.
- Separate CSRF token for impersonation sessions, integrated into the web client.
- Removed wildcard service imports from the session-model path that could shadow the domain Session model.

## Production readiness
- Production configuration now requires legal entity name, privacy contact email, privacy policy version, and terms effective date.
- Added platform model switch (`merchant_saas` / `marketplace`) for jurisdictional readiness.
- Added accessibility engineering statement and release audit.
- Added PCI DSS v4.0.1 scope statement and regulatory readiness matrix.

## Current security reference set
- OWASP ASVS 5.0.0
- OWASP Top 10:2025
- OWASP API Security Top 10:2023
- PCI DSS v4.0.1
- KVKK international-transfer standard-contract framework

This release contains engineering controls and evidence gates. It does not represent legal certification or a substitute for production penetration testing, QSA/legal review, or jurisdiction-specific assessment.
