# Rilmo Accessibility Engineering Statement — v1.44.0

Rilmo targets WCAG 2.2 AA engineering practices for the merchant dashboard and storefront surfaces. The European Accessibility Act covers e-commerce services; Member States implemented the directive nationally, and the EU Commission notes e-commerce among covered services. This document is an engineering statement and is not a legal certification.

Engineering controls included in this release:

- semantic landmarks and a skip-to-content path on the primary dashboard shell;
- visible keyboard focus styles;
- labels or accessible names for primary form controls;
- keyboard-operable interactive controls;
- reduced-motion preference support where animation is non-essential;
- text alternatives for storefront product media when supplied by the merchant;
- no reliance on color alone for status messaging;
- accessibility regression checks as part of the release audit.

Known boundary: dynamic merchant-authored content and third-party payment/KYC UIs may require separate accessibility validation. Production accessibility evidence must include representative keyboard, screen-reader, zoom/reflow and mobile tests on the actual published storefront and checkout experience.
