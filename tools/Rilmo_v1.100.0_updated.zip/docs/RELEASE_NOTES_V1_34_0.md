# Unified Global Commerce v1.34.0

## Trust & merchant identity
- Real merchant profile requirements: legal name, phone, country, city and address.
- Phone verification with hashed one-time codes and provider adapter; no OTP plaintext stored in Outbox.
- Google identity linkage required for production activation.
- Platform-admin verification state controls whether a merchant can publish.

## Store reputation
- Public verified-store trust score and rating.
- Customer store reviews require a completed-order proof by default.
- Review moderation queue for platform admins.
- Abuse-report intake, rate limiting and automatic escalation to `UNDER_REVIEW`; platform admins can suspend or restore stores at any time with MFA.

## Domains
- Authoritative registrar availability checks.
- $10/year configured platform price subject to registrar wholesale cost.
- Domain purchase is pending-payment and never registers before payment capture.
- Custom-domain root serving with product URLs, robots and sitemap.
- Optional platform subdomain provisioning when `PLATFORM_ROOT_DOMAIN` is configured.

## Commerce UX
- Public pricing/plan presentation.
- Platform Trust Center in the admin dashboard.
- Custom domains are treated as first-class storefront hosts instead of internal `/store/*` pages only.
- Structured SEO metadata and schema.org Store/Product markup.

## Security
- Dynamic Host Trust replaces static TrustedHost-only validation so verified custom domains work without opening a wildcard Host allowlist.
- Production SMS verification fails closed when no SMS provider is configured.
- Pydantic updated to 2.13.4.

## Verification
- 175 automated tests passing.
- Python compile pass.
- JavaScript syntax pass.
- Alembic migration round-trip verified.
