# PostgreSQL Runtime Role Hardening

The application database role must be `NOSUPERUSER` and `NOBYPASSRLS`. Every table containing `tenant_id` must have both `ENABLE ROW LEVEL SECURITY` and `FORCE ROW LEVEL SECURITY`.

The release gate `scripts/postgres_runtime_security_gate.py` checks these conditions against the live database. PostgreSQL documents that superusers and roles with `BYPASSRLS` bypass row security, and table owners normally bypass RLS unless `FORCE ROW LEVEL SECURITY` is enabled.
