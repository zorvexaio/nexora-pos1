## v1.100.0 — Rilmo Visual Commerce & Search Surface

Current release: **1.100.0**.
release_consistency_gate: **PASS** — VERSION 1.100.0

- Replaced the generic shopping-bag app mark with a custom Rilmo monogram identity across PWA icons, dashboard shell and storefront.
- Upgraded storefront visual hierarchy with branded hero art, identity rail, premium brand-promise section, stronger product presentation and responsive mobile behavior.
- Added richer dynamic storefront SEO metadata: robots directives, Open Graph image, Twitter cards, canonical URLs and Product/Offer/Brand JSON-LD where price data is available.
- Existing dynamic `robots.txt` and `sitemap.xml` routes remain tenant-aware and index only active, published, verified storefronts/products.
- Added regression coverage for the visual identity and SEO surface.

## v1.99.9 — Workflow Outbox Exactly-Once Queue Boundary



Historical release: **1.99.9**.
release_consistency_gate: **PASS** — VERSION 1.99.9

- Added a durable `OutboxEvent.dedupe_key` unique index and bound workflow queue events to `(tenant, workflow, source event)` so repeated worker delivery cannot enqueue the same `workflow.run.queued` event more than once.
- Hardened workflow triggering to repair the rare committed-run/missing-queue-event state exactly once instead of silently skipping it.
- Made migration `0071` SQLite batch-safe while preserving the PostgreSQL constraint contract.
- Fresh empty-database Alembic verification: `alembic upgrade head` completed successfully through `20260909_0074`; final `alembic_version` = `20260909_0074`.
- Targeted regression evidence: **9 passed, 0 failed**.
- Full-suite verification is still pending in this environment; the first full run exceeded the execution timeout at approximately 15% after reporting one version-surface failure, which was then fixed. No full-suite PASS is claimed until a complete run finishes.

- Added `/v1/analytics/customer-intelligence`: deterministic RFM-style customer segmentation, repeat-customer rate, per-currency customer economics and top-customer ranking.
- Refunds are only applied when refund currency matches the order currency; mismatches are explicitly excluded and surfaced in integrity metadata.
- Cross-currency LTV is never synthesized into a single number.
- Added regression coverage for segmentation, refunds, repeat rate and currency-integrity boundaries.

## v1.99.1 — POS transaction integrity closure

release_consistency_gate: **PENDING** — VERSION 1.99.1 until final artifact gates run.

- v1.99.1 POS integrity closure: serialized register-session opening on the register row, rejected invalid/non-positive quantities, enforced POS currency consistency, prevented cross-tenant customer attachment, and required an inventory record for physical products at the configured POS location.
- v1.97.9 release-integrity closure: refreshed stale current-version documentation, aligned legacy release-contract tests with dynamic payment User-Agent and durable provider-tenant binding, and restored exact release-builder exclusion regression coverage.
- Verification: 863/863 tests pass across four deterministic batches; release artifact audit, release consistency, security, spec, spec-schema, frontend, dependency, hygiene and final structural gates PASS.

- Restored verified POS, inventory, OAuth token rate-limit, WhatsApp, shipping-path, payment-callback, and merchant settings authorization hardening from v1.96.20 where v1.97.1 had regressed.
- Preserved v1.97.x OAuth client binding, scope reauthorization revocation, tenant-scoped domain idempotency, API-key/analytics entitlements, and storefront variant selection.
- Alembic chain is a single head through migration `20260908_0068`.

# IMPLEMENTATION STATUS — v1.97.9

Generated from the current release workspace on 2026-09-09.

## v1.97.0 OAuth privilege revocation closure
- Closed a privilege-retention flaw in OAuth re-authorization: when an installation's requested scopes change, all active access and refresh credentials belonging to that installation are revoked before the new authorization code is exchanged.
- Added row locking to the installation lookup so concurrent re-authorization requests cannot race the granted-scope transition.
- New regression: old bearer token rejected, old refresh token rejected, new authorization token receives only the reduced scope set.
- Targeted OAuth regression evidence: **5/5 PASS**.

## Release evidence boundary
- Local deterministic evidence only; PostgreSQL/RLS, real-provider, load/failover, backup/restore and independent penetration-test evidence remain external gates.

# IMPLEMENTATION STATUS — v1.96.9

Generated from the current release workspace on 2026-09-09.

## v1.96.9 deep security closure
- Closed domain-purchase idempotency cross-tenant replay: lookup is now tenant-scoped, and the database uniqueness invariant is `(tenant_id, idempotency_key)`.
- Closed OAuth refresh-token client confusion: a refresh token can only be redeemed by the application that owns its installation.
- Preserved authorization-code PKCE, exact redirect URI validation and single-use authorization codes.
- Migration `20260908_0066_domain_purchase_idempotency_scope.py` advances the Alembic head to `20260908_0066`; PostgreSQL applies the constraint change, while SQLite remains metadata/test-only.
- Targeted regression evidence: OAuth/permission/payment suite **12/12 PASS**; domain idempotency suite **7/7 PASS**.

## Release evidence boundary
- These results are local deterministic evidence only. They do not constitute a global 100% certification. External PostgreSQL/RLS, real-provider, load/failover, backup/restore and independent penetration-test evidence remains required.

# IMPLEMENTATION STATUS — v1.96.8

## v1.96.8 authorization hardening
- Verified test execution for this release workspace: **738 passed** across all executed test-file groups; **754 tests collected** by the full test suite.
- Release gates and structural audits were rerun after the final source/test changes and passed.
- Closed internal route-to-route permission bypass in `merchant_update_order_issue`: `RESOLVE_REFUND` now explicitly requires `orders.refund`, even though the outer endpoint requires `orders.manage`.
- Added `assert_permission()` as the canonical internal permission enforcement helper, reusing the same role/grant mapping as FastAPI dependency injection.
- Regression coverage: staff denied, owner allowed.

# IMPLEMENTATION STATUS — v1.96.3

Generated from the release workspace on 2026-08-23.

## Verified release-workspace evidence
- Test inventory: **728 tests collected**.
- Prior release v1.95.4 evidence recorded **720/720 PASS** across deterministic shards.
- New v1.96.3 readiness regression tests: **2/2 PASS** in the current workspace.
- Release consistency: **PASS**.
- Security gate: **PASS**.
- Final structural release audit: **PASS**.
- Spec audit: **PASS**.
- Spec/schema audit: **PASS**.
- Frontend/PWA audit: **PASS**.
- Regulatory readiness audit: **PASS (16 checks)**.
- Release hygiene: **PASS**.
- Runtime dependency lock audit: **BLOCKED in the current execution sandbox** because its installed Python environment does not match the release lock (multiple packages are older/missing). The sandbox has no outbound package index access, so the locked environment could not be installed here.

## v1.96.3 readiness hardening
- `/v1/ready` now fails closed in production when required object storage is unavailable.
- `/v1/ready` now fails closed in production when the required ClamAV malware scanner is unavailable.
- Database, migration-head, Redis, object-storage and malware-scanner readiness are now represented explicitly.
- New regression tests cover both healthy dependency readiness and object-storage outage behavior.

## Production topology retained
- PostgreSQL, Redis, ClamAV, migration, API, worker and optional AI services are explicitly defined in production Compose.
- API and worker wait for successful migrations before starting.
- PostgreSQL and Redis are internal-only and health-checked.
- Migration mode is fail-closed to PostgreSQL.
- Production images remain pinned to PostgreSQL 18.6 and Redis 8.10.0.

## Security / architecture closures retained
- Tenant RLS closure migration `20260822_0065_tenant_rls_closure.py` remains the Alembic head.
- Customer session resolution binds tenant context before sensitive reads.
- Workflow webhook durable creation is separated from external DNS/network delivery.
- Payment provider endpoints remain protected against merchant-controlled SSRF in production.
- Mock payment paths remain forbidden outside tests/local development.
- Production merchant identity validation requires the real Veriff provider.
- Production SaaS billing requires Paddle.

## External evidence still required before GLOBAL 100% certification
- [ ] Real PostgreSQL runtime-role + RLS cross-tenant smoke test against deployment infrastructure.
- [ ] Real payment-provider sandbox/webhook replay evidence for each enabled provider.
- [ ] Real shipping/SMS provider verification.
- [ ] Object-storage + malware-scanning lifecycle evidence against deployment infrastructure.
- [ ] Load/soak/multi-instance failover and SLO evidence.
- [ ] Backup/restore rehearsal against production topology.
- [ ] Independent penetration test and AI/agent red-team.
- [ ] Jurisdiction-specific legal/tax/e-invoicing review.

Global 100% certification is intentionally not claimed until those external gates and the locked dependency environment are executed successfully.
release_consistency_gate: **PASS** — VERSION 1.96.8

## v1.96.3 staging-gate hardening
- Staging smoke now validates `/v1/ready` instead of process-only `/v1/health`.
- Staging target resolution now rejects every non-global IP, including IPv6/link-local/reserved/private ranges.
- Redirects are disabled so a public staging URL cannot silently redirect the CI probe to an internal address.
- Credentials, query strings, fragments and non-root paths are rejected from `STAGING_URL`.

## v1.96.3 staging-gate security closure
- The real-staging smoke gate now probes `/v1/ready`, not process-only `/v1/health`.
- Target DNS is accepted only when every resolved address is globally routable; IPv4/IPv6 private, loopback, link-local, reserved and other non-global ranges are rejected.
- HTTP redirects are disabled in the smoke probe to prevent a public staging hostname from redirecting the CI client into an internal destination.
- `STAGING_URL` is restricted to a credential-free HTTPS origin without path/query/fragment components.
- Regression contract: **4/4 PASS**.

## v1.96.3 customer payment-order authorization closure

- Closed a storefront authorization gap in `POST /v1/payments/intents`: a customer actor must own the targeted order.
- Regression tests: **8/8 PASS** in the current workspace.
- Full-suite status remains recorded by `release_evidence.py`; timeouts are never converted into PASS.

## v1.96.8 authorization hardening
- Closed tenant staff role escalation: `staff.manage` cannot grant `admin`/`owner`.
- Only tenant owner may grant `admin`/`owner` or modify owner membership.
- Added regression coverage for staff/admin privilege escalation.

## v1.97.1 — storefront variant-selection closure
- Closed a real storefront UX/commerce defect: product detail variant buttons were rendered but had no selection handler, so Add to Cart always used the first variant.
- Variant selection now updates the active/ARIA state, selected variant ID and authoritative displayed price before Add to Cart.
- Regression contract verified with Node syntax validation and a static frontend contract test.
