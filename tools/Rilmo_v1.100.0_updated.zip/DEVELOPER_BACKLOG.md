# Developer Backlog — v1.57.0

## P0 / Current

- [x] SaaS billing architecture conversion.
- [x] Merchant-owned iyzico/PayTR checkout.
- [x] Paddle MoR billing adapter and webhook verification.
- [x] Plan/entitlement matrix and enforcement hooks.
- [x] Platform billing discount model.
- [x] Merchant product discount model with price snapshots.
- [x] Remove Tabby/Tamara/Stripe Connect active routes and providers.
- [x] Local runtime seed and smoke test.
- [x] Full automated test suite: 162 passed.

## External Staging

- [ ] Hetzner application deployment.
- [ ] Managed/separate PostgreSQL with live RLS verification.
- [ ] Redis and S3-compatible object storage.
- [ ] Paddle seller onboarding and real subscription evidence.
- [ ] iyzico/PayTR merchant account sandbox evidence.
- [ ] Backup/restore rehearsal.
- [ ] Load/SLO evidence.
- [ ] T1–T20 deployed staging regression.

## Legal / Business

- [ ] Turkish counsel/accounting review.
- [ ] VAT/tax and e-invoice determination.
- [ ] KVKK and international SaaS terms/privacy.


## v1.36.4 — Merchant Trust & Identity Security

- [x] External KYC provider abstraction.
- [x] Veriff session creation and signed webhook handling.
- [x] KYC state machine and provider-only approval.
- [x] Merchant risk event ledger and risk scoring.
- [x] Manual compliance review queue and decisions.
- [x] Payout hold / freeze / re-verification controls.
- [x] Production guard preventing mock KYC.
- [ ] Configure and certify Veriff in real staging.
- [ ] Legal/KVKK review of identity and biometric-data processing.
- [ ] Calibrate fraud thresholds and monitor false positives.


## v1.53.0 — Global compliance infrastructure
- Digital Product Passport with versioned, auditable, tenant-isolated records.
- Public DPP endpoint exposes only explicitly public product compliance data.
- Release hygiene strengthened against local DB journals and build artifacts.

## v1.53.0 — Global Product Compliance
- Digital Product Passport / Product Compliance Graph.
- Public DPP endpoint with rate limiting and payload cap.
- Release hygiene blocks SQLite journal/WAL/SHM artifacts.


## v1.54.0 — Agent Transaction Safety
- Agent spend limits per checkout.
- Agent currency allowlist.
- Agent buyer-country allowlist enforcement.
- Runtime enforcement on UCP checkout completion.


## v1.54.0 — Agent Transaction Safety
- [x] Agent spend limits per checkout.
- [x] Agent currency allowlist.
- [x] Agent buyer-country allowlist enforcement.
- [x] Runtime enforcement on UCP checkout completion.
- [x] Release hygiene blocks DB journals/WAL/SHM and known build patch scripts.


## v1.55.0 — DPP Interoperability
- [x] Conformance profile metadata for DPP lifecycle interoperability.
- [x] Stable product identifier scheme and identifier enforcement for published passports.
- [x] Data carrier metadata.
- [x] External registry lifecycle state/reference without claiming official registration.
- [x] Runtime tests for published-identifier enforcement and invalid registry state rejection.
- [ ] Official EU DPP Registry onboarding/conformance evidence (external).


## v1.58.0 — AI egress isolation and global readiness
- [x] Production server-only AI endpoint egress guard.
- [x] Adversarial runtime tests for external AI endpoint rejection.
- [x] Release evidence corrected to current route/test counts.
- [x] World-readiness matrix distinguishes code-complete controls from external operational certification.
- [ ] Production multi-region deployment with measured RTO/RPO.
- [ ] Independent penetration test and AI red-team assessment.
- [ ] Live payment-provider certification and webhook replay evidence.
- [ ] Legal entity/controller-processor/subprocessor review per launch jurisdiction.


## v1.97.4 — Return integrity hardening
- [x] Serialize return creation per order using database row locks.
- [x] Aggregate duplicate order-item entries before return quantity validation.
- [x] Add regression tests for duplicate-line and concurrency safety contracts.
- [ ] PostgreSQL concurrent transaction evidence in real staging.
