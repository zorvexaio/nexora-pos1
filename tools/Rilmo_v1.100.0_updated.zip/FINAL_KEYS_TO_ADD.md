# FINAL KEYS TO ADD — v1.63.0

# FINAL KEYS / CREDENTIALS TO ADD BEFORE PRODUCTION

This file intentionally contains no real secrets. Add credentials only through the deployment secret manager or an untracked production `.env` file.

## Required for production
- SECRET_KEY
- ENCRYPTION_KEY (dedicated; never reuse SECRET_KEY)
- WEBHOOK_SECRET
- DATABASE_URL
- REDIS_URL
- PUBLIC_BASE_URL
- ALLOWED_HOSTS
- CORS_ORIGINS
- TRUSTED_ORIGINS
- FORWARDED_ALLOW_IPS
- LEGAL_ENTITY_NAME
- PRIVACY_CONTACT_EMAIL
- PRIVACY_POLICY_VERSION
- TERMS_EFFECTIVE_DATE
- SMTP_HOST / SMTP_USERNAME / SMTP_PASSWORD / MAIL_FROM
- S3/R2: S3_ENDPOINT_URL / S3_BUCKET / S3_REGION / S3_ACCESS_KEY_ID / S3_SECRET_ACCESS_KEY
- Google OAuth: GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET / GOOGLE_REDIRECT_URI
- KYC/Veriff: VERIFF_API_BASE_URL / VERIFF_API_KEY / VERIFF_SHARED_SECRET
- SMS credentials when merchant phone verification is enabled
- WHATSAPP_APP_SECRET when WhatsApp is enabled
- APP_WEBHOOK_ALLOWED_HOSTS

## Payment / billing credentials
Configure only the licensed/contracted provider actually used in each market:
- Paddle: PADDLE_API_KEY / PADDLE_WEBHOOK_SECRET
- iyzico: IYZICO_API_KEY / IYZICO_SECRET_KEY
- PayTR: PAYTR_MERCHANT_ID / PAYTR_MERCHANT_KEY / PAYTR_MERCHANT_SALT
- Turkey e-invoicing provider: TURKEY_EINVOICE_PROVIDER / TURKEY_EINVOICE_ENDPOINT / TURKEY_EINVOICE_API_TOKEN

## AI
Default production mode is local Ollama only:
- AI_PROVIDER=ollama
- AI_BASE_URL=http://ollama:11434
- AI_EXTERNAL_PROVIDER_ALLOWED=false

No paid AI API key is required in this mode. Local inference still consumes server resources.

## Card installments
- CARD_INSTALLMENT_SAME_PRICE_ONLY=true
- CARD_INSTALLMENT_MAX_COUNT within the enforced production range
- Rilmo must not add interest, markup, or a hidden installment surcharge to the merchant's product price.

## Never commit
Never commit real secrets, private keys, OAuth secrets, payment credentials, KYC secrets, webhook secrets, database passwords, or cloud access keys.
