"""Compare canonical CREATE TABLE names in the supplied v1.8 specification with ORM metadata."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / 'docs' / 'REFERENCE_SPEC_v1_8.md'
external = Path('/mnt/data/Unified_Global_Commerce_Platform_Specification_v1_8.md')
if external.exists():
    SPEC = external
spec = SPEC.read_text(encoding='utf-8')
expected = []
for m in re.finditer('CREATE TABLE\\s+(?:IF NOT EXISTS\\s+)?([A-Za-z_][\\w]*)', spec, re.I):
    n = m.group(1).lower()
    if n not in expected:
        expected.append(n)
source = (ROOT / 'app/models/domain.py').read_text(encoding='utf-8')
actual = [x.lower() for x in re.findall('__tablename__\\s*=\\s*[\\\'\\"]([^\\\'\\"]+)', source)]
missing = sorted(set(expected) - set(actual))
print(f'Spec tables: {len(expected)}; ORM tables: {len(actual)}')
if missing:
    print('MISSING: ' + ', '.join(missing))
    raise SystemExit(1)
print('PASS: every canonical CREATE TABLE name from v1.8 has an ORM table mapping.')
