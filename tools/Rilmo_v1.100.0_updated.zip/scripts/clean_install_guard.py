from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
texts=[]
for name in ('requirements-runtime.txt','requirements.txt','requirements-dev.txt'):
    p=ROOT/name
    if p.exists(): texts.append(p.read_text(encoding='utf-8'))
REQ='\n'.join(texts)
required = {'fastapi': '0.141.1', 'starlette': '0.52.1', 'pytest': '9.1.1', 'pytest-asyncio': '1.4.0'}
found = {}
for line in REQ.splitlines():
    m = re.match(r'^([A-Za-z0-9_.-]+)==([^#\s]+)$', line.strip())
    if m: found[m.group(1).lower()] = m.group(2)
missing = [f'{k}=={v}' for k,v in required.items() if found.get(k)!=v]
if missing:
    print('FAIL: missing exact test/runtime pins:')
    for x in missing: print('-',x)
    raise SystemExit(1)
ini=(ROOT/'pytest.ini').read_text(encoding='utf-8')
if 'asyncio_default_fixture_loop_scope' not in ini:
    print('FAIL: pytest asyncio loop policy disappeared; review test configuration')
    raise SystemExit(1)
print('PASS: clean-install dependency guard')
