#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL required}"
: "${BACKUP_ENCRYPTION_KEY:?BACKUP_ENCRYPTION_KEY required}"
: "${1:?encrypted backup path required}"
python scripts/secure_backup.py decrypt --passphrase "$BACKUP_ENCRYPTION_KEY" --input "$1" | gunzip | psql "$DATABASE_URL"
