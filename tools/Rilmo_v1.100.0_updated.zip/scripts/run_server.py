#!/usr/bin/env python3
from app.core.config import get_settings
import uvicorn

if __name__ == '__main__':
    s = get_settings()
    uvicorn.run('app.main:app', host='0.0.0.0', port=8000, proxy_headers=bool(s.FORWARDED_ALLOW_IPS), forwarded_allow_ips=s.FORWARDED_ALLOW_IPS or '127.0.0.1')
