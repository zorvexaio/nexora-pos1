from __future__ import annotations
import json, hashlib, importlib.metadata as md
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
version=(ROOT/'VERSION').read_text(encoding='utf-8').strip()
def read_requirements(path: Path, seen=None):
    seen = set() if seen is None else seen
    if path in seen:
        return []
    seen.add(path)
    out=[]
    for raw in path.read_text(encoding='utf-8').splitlines():
        line=raw.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('-r '):
            child=(path.parent/line[3:].strip()).resolve()
            if child.exists(): out.extend(read_requirements(child, seen))
            continue
        if '==' in line: out.append(line)
    return out

requirements = read_requirements(ROOT/'requirements-runtime.txt') + read_requirements(ROOT/'requirements.txt') + read_requirements(ROOT/'requirements-dev.txt')
# De-duplicate package pins while preserving the first occurrence.
seen_names=set(); pinned=[]
for line in requirements:
    name=line.split('==',1)[0].split('[',1)[0].lower()
    if name not in seen_names:
        pinned.append(line); seen_names.add(name)

packages=[]
for line in pinned:
    line=line.strip()
    if not line or line.startswith('#') or '==' not in line: continue
    name,ver=line.split('==',1)
    packages.append({'name':name.split('[',1)[0],'version':ver,'purl':f'pkg:pypi/{name.split("[",1)[0].lower()}@{ver}'})

files=[]
for p in sorted(x for x in ROOT.rglob('*') if x.is_file() and '.git' not in x.parts and '__pycache__' not in x.parts):
    rel=p.relative_to(ROOT).as_posix()
    if rel in {'docs/RELEASE_PROVENANCE.json','docs/SBOM.cdx.json'}: continue
    h=hashlib.sha256(p.read_bytes()).hexdigest()
    files.append({'path':rel,'sha256':h})

sbom={'bomFormat':'CycloneDX','specVersion':'1.6','version':1,'metadata':{'component':{'type':'application','name':'Rilmo Unified Global Commerce','version':version}},'components':packages,'externalReferences':[{'type':'distribution','url':'https://pypi.org/'}], 'properties':[{'name':'release.file_count','value':str(len(files))},{'name':'release.tree_hash','value':hashlib.sha256(''.join(x['sha256'] for x in files).encode()).hexdigest()}]}
(ROOT/'docs/SBOM.cdx.json').write_text(json.dumps(sbom,ensure_ascii=False,indent=2,sort_keys=True),encoding='utf-8')
print(f'SBOM_GENERATED packages={len(packages)} files={len(files)}')
