#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, struct, sys
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC=b'RILMOBK'
VERSION=1
SALT_LEN=16
NONCE_LEN=12
TAG_LEN=16

def derive(passphrase: str, salt: bytes) -> bytes:
    return Scrypt(salt=salt, length=32, n=2**15, r=8, p=1).derive(passphrase.encode())

def encrypt(passphrase: str, output: Path) -> None:
    plaintext=sys.stdin.buffer.read()
    salt=os.urandom(SALT_LEN); nonce=os.urandom(NONCE_LEN)
    key=derive(passphrase,salt)
    aad=MAGIC+bytes([VERSION])
    ciphertext=AESGCM(key).encrypt(nonce, plaintext, aad)
    output.write_bytes(aad+salt+nonce+ciphertext)

def decrypt(passphrase: str, input_path: Path) -> None:
    blob=input_path.read_bytes()
    if len(blob) < len(MAGIC)+1+SALT_LEN+NONCE_LEN+TAG_LEN or blob[:len(MAGIC)] != MAGIC:
        raise SystemExit('Invalid Rilmo backup envelope')
    idx=len(MAGIC); version=blob[idx]; idx+=1
    if version != VERSION: raise SystemExit('Unsupported backup version')
    salt=blob[idx:idx+SALT_LEN]; idx+=SALT_LEN
    nonce=blob[idx:idx+NONCE_LEN]; idx+=NONCE_LEN
    ciphertext=blob[idx:]
    plaintext=AESGCM(derive(passphrase,salt)).decrypt(nonce,ciphertext,MAGIC+bytes([version]))
    sys.stdout.buffer.write(plaintext)

parser=argparse.ArgumentParser(); sub=parser.add_subparsers(dest='op',required=True)
p=sub.add_parser('encrypt'); p.add_argument('--passphrase',required=True); p.add_argument('--output',required=True,type=Path)
p=sub.add_parser('decrypt'); p.add_argument('--passphrase',required=True); p.add_argument('--input',required=True,type=Path)
a=parser.parse_args()
if a.op=='encrypt': encrypt(a.passphrase,a.output)
else: decrypt(a.passphrase,a.input)
