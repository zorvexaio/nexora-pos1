"""Fail-closed PostgreSQL production evidence gate.

Requires DATABASE_URL pointing at a disposable/staging PostgreSQL instance.
This gate is intentionally never satisfied by SQLite.
"""
from __future__ import annotations
import os, sys
from sqlalchemy import create_engine, text

url = os.environ.get('DATABASE_URL','')
if not url.startswith(('postgresql://','postgresql+psycopg://','postgresql+psycopg2://')):
    raise SystemExit('FAIL: DATABASE_URL must be a real PostgreSQL URL')
engine=create_engine(url, future=True)
with engine.connect() as db:
    role=db.execute(text("SELECT current_user, r.rolsuper, r.rolbypassrls FROM pg_roles r WHERE r.rolname=current_user")).mappings().one()
    if role['rolsuper'] or role['rolbypassrls']:
        raise SystemExit('FAIL: application role must not be SUPERUSER/BYPASSRLS')
    tz=db.execute(text("SHOW TimeZone")).scalar_one()
    if str(tz).upper() != 'UTC':
        raise SystemExit(f'FAIL: PostgreSQL TimeZone must be UTC, got {tz!r}')
    # Every public table carrying tenant_id must have both RLS flags.
    missing=db.execute(text("""
      SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
      WHERE n.nspname='public' AND c.relkind='r'
        AND EXISTS (SELECT 1 FROM information_schema.columns x WHERE x.table_schema='public' AND x.table_name=c.relname AND x.column_name='tenant_id')
        AND (c.relrowsecurity IS NOT TRUE OR c.relforcerowsecurity IS NOT TRUE)
      ORDER BY c.relname
    """)).scalars().all()
    if missing:
        raise SystemExit('FAIL: tenant tables without ENABLE+FORCE RLS: '+', '.join(missing))
    unsafe=db.execute(text("""
      SELECT schemaname,tablename,policyname FROM pg_policies
      WHERE schemaname='public' AND (qual LIKE '%app.worker%' OR with_check LIKE '%app.worker%')
    """)).all()
    if unsafe:
        raise SystemExit('FAIL: RLS policy still uses client-settable app.worker GUC')
    # Verify transaction-local tenant context is actually isolated.
    tenants=db.execute(text("SELECT id FROM tenants LIMIT 2")).scalars().all()
    if len(tenants) < 2:
        raise SystemExit('FAIL: need at least two tenants for live isolation evidence')
    db.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {'t': str(tenants[0])})
    count_a=db.execute(text("SELECT count(*) FROM products WHERE tenant_id=:t"), {'t': str(tenants[0])}).scalar_one()
    db.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {'t': str(tenants[1])})
    count_b=db.execute(text("SELECT count(*) FROM products WHERE tenant_id=:t"), {'t': str(tenants[0])}).scalar_one()
    if count_b != 0:
        raise SystemExit('FAIL: cross-tenant product visibility detected under live RLS')
print(f'PASS: PostgreSQL role/RLS/timezone/live-isolation evidence; role={role["current_user"]}; timezone={tz}; tenant_tables_checked')
