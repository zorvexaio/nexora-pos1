#!/usr/bin/env python3
"""Developer Runtime smoke test: health -> seed -> storefront -> guest cart -> checkout -> mock capture."""
import os
import time
import uuid
import httpx

BASE_URL = os.getenv('LOCAL_RUNTIME_URL', 'http://127.0.0.1:8000').rstrip('/')
TENANT_HOST = os.getenv('DEMO_STORE_HOST', 'demo.localhost')


def main() -> None:
    with httpx.Client(base_url=BASE_URL, timeout=15.0, follow_redirects=True) as c:
        deadline = time.monotonic() + 15.0
        last_error = None
        while time.monotonic() < deadline:
            try:
                health = c.get('/v1/health')
                if health.status_code == 200:
                    break
            except httpx.HTTPError as exc:
                last_error = exc
            time.sleep(0.25)
        else:
            raise RuntimeError(f'Local runtime did not become ready at {BASE_URL}: {last_error}')
        health.raise_for_status()
        assert health.json()['status'] == 'healthy'
        ready = c.get('/v1/ready')
        ready.raise_for_status()

        cfg = c.get('/v1/public/config')
        cfg.raise_for_status()
        assert cfg.json()['payment_provider'] == 'mock', cfg.text

        discovery = c.get('/.well-known/ucp')
        discovery.raise_for_status()
        assert discovery.json()['ucp']['version'] == '2026-04-08'
        ucp_profile = c.get(f'/v1/public/storefront/{TENANT_HOST}/ucp/profile')
        ucp_profile.raise_for_status()
        assert ucp_profile.json()['ucp']['version'] == '2026-04-08'

        store = c.get(f'/v1/public/storefront/{TENANT_HOST}')
        store.raise_for_status()
        payload = store.json()
        assert payload['products'], 'Demo storefront has no products'
        tenant_id = payload['tenant']['id']
        variant_id = payload['products'][0]['variants'][0]['id']
        ucp = c.post(f'/v1/public/storefront/{TENANT_HOST}/ucp/checkouts', json={
            'external_session_id': f'live-smoke-{uuid.uuid4().hex}',
            'currency': payload['products'][0]['variants'][0]['currency'],
            'line_items': [{'variant_id': variant_id, 'quantity': 1, 'unit_price_minor': 1}],
        })
        ucp.raise_for_status()
        assert ucp.json()['line_items'][0]['unit_price_minor'] > 1

        html = c.get(f'/store/{TENANT_HOST}')
        html.raise_for_status()
        assert f'<meta name="store-host" content="{TENANT_HOST}">' in html.text

        cart = c.post(f'/v1/cart?tenant_id={tenant_id}')
        cart.raise_for_status()
        cart_id = cart.json()['id']
        item = c.post(f'/v1/cart/items?tenant_id={tenant_id}&cart_id={cart_id}',
                      json={'variant_id': variant_id, 'quantity': 1})
        item.raise_for_status()

        checkout = c.post(f'/v1/checkout?tenant_id={tenant_id}',
                          headers={'Idempotency-Key': str(uuid.uuid4())},
                          json={'cart_id': cart_id, 'customer_email': 'buyer@example.com',
                                'customer_name': 'Demo Buyer'})
        checkout.raise_for_status()
        order = checkout.json()
        assert order['status'] == 'PENDING_PAYMENT'

        payment = c.post(f'/v1/payments/intents?tenant_id={tenant_id}',
                         headers={'Idempotency-Key': str(uuid.uuid4())},
                         json={'order_id': order['id'], 'amount_minor': order['total_minor'],
                               'currency': order['currency'], 'provider': 'mock'})
        payment.raise_for_status()
        intent = payment.json()
        assert intent['provider'] == 'mock'

        capture = c.post(f"/v1/payments/{intent['id']}/capture?tenant_id={tenant_id}",
                         headers={'Idempotency-Key': str(uuid.uuid4())})
        capture.raise_for_status()
        result = capture.json()
        assert result['status'] in {'CAPTURED', 'SUCCEEDED'}, result
        print('LOCAL_RUNTIME_SMOKE_PASS')
        print(f"STORE={BASE_URL}/store/{TENANT_HOST}")
        print(f"ORDER_ID={order['id']}")
        print(f"PAYMENT_ID={intent['id']}")


if __name__ == '__main__':
    main()
