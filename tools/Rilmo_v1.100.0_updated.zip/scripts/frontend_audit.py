from pathlib import Path
import re
root = Path(__file__).resolve().parents[1] / 'app/frontend'
required = ['index.html', 'app.js', 'styles.css', 'manifest.json', 'sw.js', 'offline.html', 'icon-192.png', 'icon-512.png']
missing = [x for x in required if not (root / x).exists()]
if missing:
    raise SystemExit('Missing frontend assets: ' + ', '.join(missing))
html = (root / 'index.html').read_text(encoding='utf-8')
if 'script src="/app.js"' not in html or 'stylesheet" href="/styles.css"' not in html:
    raise SystemExit('Frontend is not using external CSP-compatible assets')
if re.search('\\s(onclick|onload|onerror)\\s*=', html, re.I):
    raise SystemExit('Inline event handlers remain in index.html')
manifest = (root / 'manifest.json').read_text(encoding='utf-8')
for token in ['192x192', '512x512', 'standalone', 'start_url', 'ar']:
    if token not in manifest:
        raise SystemExit('Manifest missing ' + token)
js = (root / 'app.js').read_text(encoding='utf-8')
if "localStorage.setItem('token'" in js or "localStorage.getItem('token'" in js:
    raise SystemExit('Bearer session token must not be stored in localStorage')
print('PASS: PWA/CSP/frontend session-storage audit')
