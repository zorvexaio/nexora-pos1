from __future__ import annotations
import os, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def run(cmd, env=None):
    e = os.environ.copy()
    e.update(env or {})
    print('+', ' '.join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, env=e, check=True)

def main():
    run([sys.executable, '-m', 'compileall', '-q', 'app', 'tests', 'scripts'])
    run([sys.executable, 'scripts/clean_install_guard.py'])
    run([sys.executable, 'scripts/runtime_dependency_lock_gate.py'])
    run([sys.executable, 'scripts/final_release_audit.py'])
    run([sys.executable, 'scripts/spec_audit.py'])
    run([sys.executable, 'scripts/spec_schema_audit.py'])
    run([sys.executable, 'scripts/frontend_audit.py'])
    run(['node', '--check', 'app/frontend/app.js'])
    run(['node', '--check', 'app/frontend/storefront.js'])
    db = ROOT / 'release_gate.sqlite'
    if db.exists():
        db.unlink()
    env = {'ENVIRONMENT': 'test', 'DATABASE_URL': f'sqlite:///{db.name}', 'SECRET_KEY': 'test-secret-32-bytes-long', 'WEBHOOK_SECRET': 'test-webhook-secret-32-bytes-long', 'DOMAIN_VERIFICATION_MODE': 'token'}
    try:
        run(['alembic', 'upgrade', 'head'], env)
        run(['alembic', 'downgrade', 'base'], env)
        run(['alembic', 'upgrade', 'head'], env)
    finally:
        if db.exists():
            db.unlink()
        journal = ROOT / 'release_gate.sqlite-journal'
        if journal.exists():
            journal.unlink()
    run([sys.executable, '-c', "import pytest_asyncio; print('pytest-asyncio', pytest_asyncio.__version__)"])
    run([sys.executable, '-m', 'pytest', '-q', '-W', 'error'])
    print('RELEASE_GATE_LOCAL_PASS')
if __name__ == '__main__':
    main()
