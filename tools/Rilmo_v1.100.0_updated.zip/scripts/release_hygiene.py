from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
BAD_SUFFIXES = {'.db', '.sqlite', '.sqlite3', '.pyc', '.pyo', '.log', '.journal', '.wal', '.shm'}
BAD_NAMES = set()
BAD_DIRS = {'.pytest_cache', '__pycache__', '.mypy_cache', '.ruff_cache', '.local'}
BAD_BACKUP_RE = __import__('re').compile(r'.*\.(?:bak|pre_[0-9]+|orig|old)$')
bad = []
for p in ROOT.rglob('*'):
    rel = p.relative_to(ROOT)
    if any((part in BAD_DIRS for part in rel.parts)):
        bad.append(str(rel))
        continue
    if p.is_file() and (p.suffix.lower() in BAD_SUFFIXES or p.name in BAD_NAMES or p.name.startswith('_apply_v') or p.name.startswith('.coverage') or p.name.endswith(('-journal', '-wal', '-shm'))):
        bad.append(str(rel))
if bad:
    print('RELEASE_HYGIENE_FAIL')
    print('\n'.join(sorted(bad)))
    sys.exit(1)
for p in ROOT.rglob('*'):
    if p.is_file() and (BAD_BACKUP_RE.fullmatch(p.name) or p.name in {'collected.txt','filelist.txt','suspicious.txt','isolated_full.out','isolated_full.pid','shard1.out','shard1.txt','shard2.out','shard2.txt','shard3.out','shard3.txt','shard4.out','shard4.txt'}):
        print('RELEASE_HYGIENE_FAIL')
        print(p.relative_to(ROOT))
        raise SystemExit(1)
print('RELEASE_HYGIENE_PASS')
