#!/usr/bin/env python3
"""Run each pytest file in an isolated subprocess and aggregate deterministic results."""
from __future__ import annotations
import argparse, concurrent.futures, os, signal, subprocess, sys, time
from pathlib import Path

def run_one(path: str, timeout: int):
    started = time.monotonic()
    try:
        p = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-W', 'error', path], capture_output=True, text=True, timeout=timeout, start_new_session=True)
        return path, p.returncode, time.monotonic() - started, (p.stdout + p.stderr)[-3000:]
    except subprocess.TimeoutExpired as exc:
        out = ((exc.stdout or '') if isinstance(exc.stdout, str) else (exc.stdout or b'').decode(errors='replace'))
        err = ((exc.stderr or '') if isinstance(exc.stderr, str) else (exc.stderr or b'').decode(errors='replace'))
        return path, 124, time.monotonic() - started, ('TIMEOUT\n' + out + err)[-3000:]
    except Exception as exc:
        return path, 125, time.monotonic() - started, f'RUNNER_ERROR: {type(exc).__name__}: {exc}'

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--workers',type=int,default=6); ap.add_argument('--timeout',type=int,default=60)
    a=ap.parse_args(); files=sorted(str(p) for p in Path('tests').glob('test_*.py'))
    failed=[]; total=0
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as ex:
        futs=[ex.submit(run_one,f,a.timeout) for f in files]
        for fut in concurrent.futures.as_completed(futs):
            path,rc,dur,out=fut.result()
            status='PASS' if rc==0 else 'FAIL'
            print(f'{status} {path} ({dur:.1f}s)')
            if rc!=0:
                failed.append(path); print(out)
            else:
                import re
                m=re.search(r'(\d+) passed', out)
                if m: total += int(m.group(1))
    print(f'FILES={len(files)} TESTS_PASSED={total} FILES_FAILED={len(failed)}')
    if failed:
        print('FAILED_FILES=' + ','.join(sorted(failed)))
        return 1
    return 0

if __name__ == '__main__': raise SystemExit(main())
