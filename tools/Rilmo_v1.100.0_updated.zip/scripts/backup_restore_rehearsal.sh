#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL required}"
: "${BACKUP_ENCRYPTION_KEY:?BACKUP_ENCRYPTION_KEY required}"
: "${RESTORE_DATABASE_URL:?RESTORE_DATABASE_URL required}"
out="$(mktemp --suffix=.tijory.enc)"
trap 'rm -f "$out"' EXIT
python scripts/secure_backup.py encrypt --passphrase "$BACKUP_ENCRYPTION_KEY" --output "$out" < <(pg_dump "$DATABASE_URL" --format=plain --no-owner --no-privileges | gzip -9)
chmod 600 "$out"
python scripts/secure_backup.py decrypt --passphrase "$BACKUP_ENCRYPTION_KEY" --input "$out" | gunzip | psql "$RESTORE_DATABASE_URL" >/dev/null
count_source="$(psql "$DATABASE_URL" -Atqc "SELECT count(*) FROM public.tenants")"
count_restore="$(psql "$RESTORE_DATABASE_URL" -Atqc "SELECT count(*) FROM public.tenants")"
[[ "$count_source" == "$count_restore" ]]
printf 'BACKUP_RESTORE_REHEARSAL_PASS tenants=%s\n' "$count_source"
