#!/usr/bin/env python3
"""Generate high-entropy production secrets without embedding reusable defaults in source."""
import secrets
for name in ("SECRET_KEY", "ENCRYPTION_KEY", "WEBHOOK_SECRET"):
    print(f"{name}={secrets.token_urlsafe(48)}")
