"""Run a real HTTPS staging smoke against a deployed instance.

The staging gate is intentionally fail-closed: it refuses private/local targets,
refuses redirects (which could otherwise land on an internal target), and checks
/readiness rather than merely process liveness.
"""
from __future__ import annotations

import ipaddress
import os
import socket
from urllib.parse import urlparse

import httpx


def _resolve_public(host: str) -> set[str]:
    addresses = {item[4][0] for item in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)}
    for raw in addresses:
        addr = ipaddress.ip_address(raw)
        if not addr.is_global:
            raise ValueError(f"target resolves to non-global address {raw}")
    return addresses


def main() -> int:
    base = os.getenv("STAGING_URL", "").strip().rstrip("/")
    if not base:
        print("STAGING_BLOCKED: STAGING_URL is required")
        return 2
    parsed = urlparse(base)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        print("STAGING_BLOCKED: STAGING_URL must be a credential-free HTTPS URL")
        return 2
    if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        print("STAGING_BLOCKED: STAGING_URL must contain only scheme and host")
        return 2
    host = parsed.hostname.lower()
    if host in {"localhost", "localhost.localdomain"}:
        print("STAGING_BLOCKED: local hostname is forbidden")
        return 2
    try:
        _resolve_public(host)
    except (OSError, ValueError) as exc:
        print(f"STAGING_BLOCKED: target is not publicly routable: {exc}")
        return 2

    try:
        with httpx.Client(base_url=base, timeout=10, follow_redirects=False) as client:
            response = client.get("/v1/ready")
    except Exception as exc:
        print(f"STAGING_FAIL: {exc}")
        return 1
    if 300 <= response.status_code < 400:
        print("STAGING_FAIL: readiness endpoint must not redirect")
        return 1
    if response.status_code != 200:
        print(f"STAGING_FAIL: /v1/ready returned {response.status_code}")
        return 1
    print(f"STAGING_READY_PASS url={base} status={response.status_code}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
