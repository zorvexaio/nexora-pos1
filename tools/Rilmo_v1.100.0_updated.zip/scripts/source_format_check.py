"""Verify the checked-in source is AST-safe and normalized by the release formatter."""
from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGETS = (ROOT / "app", ROOT / "tests", ROOT / "scripts")


def main() -> int:
    files = []
    for root in TARGETS:
        files.extend(sorted(root.rglob("*.py")))
    failures = []
    max_line = 0
    for path in files:
        text = path.read_text(encoding="utf-8")
        try:
            ast.parse(text, filename=str(path))
        except SyntaxError as exc:
            failures.append(f"SYNTAX:{path}:{exc.lineno}:{exc.msg}")
            continue
        for number, line in enumerate(text.splitlines(), 1):
            max_line = max(max_line, len(line))
            if len(line) > 100 and not line.lstrip().startswith(("from ", "import ")):
                # Long URLs, CSP strings, SQL/XML literals and generated constants are
                # allowed; the report makes these explicit instead of hiding them.
                if len(line) > 500:
                    failures.append(f"LONG_LINE:{path}:{number}:{len(line)}")
    if failures:
        print("SOURCE_FORMAT_CHECK_FAIL")
        print("\n".join(failures))
        return 1
    print(f"SOURCE_FORMAT_CHECK_PASS files={len(files)} max_line={max_line}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
