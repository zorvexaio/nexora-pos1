from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
fail = []
route = (root / 'app/routes/v1.py').read_text()
if "provider:str='mock'" in (root / 'app/schemas/api.py').read_text():
    fail.append('PaymentIn default still mock')
provider_source = (root / 'app/services/payment_providers.py').read_text()
if "ENVIRONMENT != 'test'" not in provider_source or 'ALLOW_LOCAL_MOCK_PAYMENTS' not in provider_source:
    fail.append('Mock provider does not have an explicit test/local-development security boundary')
prisma = (root / 'prisma/schema.prisma').read_text()
if 'model OAuthStates' not in prisma:
    fail.append('Prisma OAuthStates missing')
if 'verification_method String?' not in prisma:
    fail.append('Prisma domain verification fields missing')
if 'payment_operations PaymentOperation[]' not in prisma:
    fail.append('Prisma PaymentOperation relation missing')
if 'model PrivacyTransferRegister' not in prisma:
    fail.append('Prisma PrivacyTransferRegister mirror missing')
if 'contract_type' not in prisma or 'signatory_authority_reference' not in prisma:
    fail.append('Prisma KVKK transfer governance fields missing')
if not (root / 'requirements-runtime.txt').exists():
    fail.append('Runtime requirements file missing')
runtime_req = (root / 'requirements-runtime.txt').read_text() if (root / 'requirements-runtime.txt').exists() else ''
if 'fastapi==0.141.1' not in runtime_req:
    fail.append('Runtime requirements missing FastAPI pin')
if 'pytest==' in runtime_req or 'pytest-asyncio==' in runtime_req:
    fail.append('Production runtime requirements include test tooling')
req = (root / 'requirements-runtime.txt').read_text() + '\n' + (root / 'requirements.txt').read_text()
if 'fastapi==0.141.1' not in req:
    fail.append('FastAPI pin mismatch')
if 'starlette==0.52.1' not in req:
    fail.append('Starlette is not explicitly pinned to 0.52.1')
if 'pytest-asyncio==1.4.0' not in req:
    fail.append('pytest-asyncio is not explicitly pinned to 1.4.0')
if (root / 'alembic/versions/0001_p0_rls.sql').exists():
    fail.append('Dead legacy 0001_p0_rls.sql still present')
for required in ['docs/REGULATORY_READINESS_MATRIX_V1_44_0.md','docs/PCI_DSS_SCOPE_V4_0_1.md','docs/ACCESSIBILITY_STATEMENT_V1_44_0.md','docs/PRODUCTION_SECURITY_BASELINE_V1_44_0.md','docs/RELEASE_NOTES_V1_44_0.md','docs/RELEASE_NOTES_V1_49_0.md','docs/PLATFORM_WORLD_COMMERCE_V1_49.md']:
    if not (root / required).exists():
        print('Missing required release document:', required)
        sys.exit(1)

if not (root / 'alembic/versions/20260819_0042_impersonation_session_ticket.py').exists():
    fail.append('Impersonation ticket migration missing')
if not (root / 'alembic/versions/20260819_0043_worldclass_commerce.py').exists() or not (root / 'alembic/versions/20260819_0044_worldclass_rls.py').exists():
    fail.append('World Commerce migrations 0043/0044 missing')
if not (root / 'app/routes/worldclass.py').exists() or not (root / 'app/services/worldclass.py').exists():
    fail.append('World Commerce service/route layer missing')
if 'worldclass_router' not in (root / 'app/main.py').read_text():
    fail.append('World Commerce router is not registered')
if not (root / 'docker-compose.production.yml').exists():
    fail.append('Production compose hardening overlay missing')
readme = (root / 'README.md').read_text()
if 'documentation/schema mirror only' not in readme or 'SQLAlchemy' not in readme:
    fail.append('README does not document Prisma mirror / SQLAlchemy runtime truth')
canon = []
spec = (root / 'docs/REFERENCE_SPEC_v1_8.md').read_text() if (root / 'docs/REFERENCE_SPEC_v1_8.md').exists() else ''
for model in ['Markets', 'NotificationTemplates', 'NotificationDeliveries', 'RiskAssessments', 'ApiKeys']:
    if f'model {model}' not in prisma:
        fail.append(f'Prisma map missing {model}')
for name in ['oauth_states', 'domains', 'payment_operations']:
    if name not in prisma:
        fail.append(f'Prisma map missing {name}')
if fail:
    print('FAIL')
    [print('-', x) for x in fail]
    sys.exit(1)
print('PASS: final release structural audit')
