"""Static P0/v1.8 implementation audit. Fails on structural contradictions that can be proven locally."""
from pathlib import Path
import ast, re, sys
ROOT = Path(__file__).resolve().parents[1]
models = (ROOT / 'app/models/domain.py').read_text()
classes = ast.parse(models)
tables = {}
for c in classes.body:
    if isinstance(c, ast.ClassDef):
        cols = set((n.target.id for n in c.body if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)))
        name = None
        for n in c.body:
            if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == '__tablename__' for t in n.targets)):
                if isinstance(n.value, ast.Constant):
                    name = n.value.value
        if name:
            tables[name] = cols
rls = [
    'storefronts',
    'domains',
    'products',
    'product_translations',
    'product_variants',
    'categories',
    'product_seo',
    'media_assets',
    'prices',
    'promotions',
    'coupons',
    'coupon_redemptions',
    'customers',
    'carts',
    'cart_items',
    'orders',
    'order_items',
    'order_status_history',
    'inventory_locations',
    'inventory_items',
    'inventory_reservations',
    'inventory_adjustments',
    'payment_intents',
    'payment_captures',
    'refunds',
    'ledger_accounts',
    'journal_entries',
    'journal_lines',
    'outbox_events',
    'dead_letter_events',
    'idempotency_keys',
    'webhook_events',
    'provider_events',
    'reconciliation_records',
    'settlements',
    'payouts',
    'financial_transactions',
    'price_lists',
    'market_prices',
    'discount_applications',
    'product_options',
    'product_option_values',
    'product_variant_option_values',
    'shipping_methods',
    'tax_rates',
    'merchant_payment_accounts',
    'billing_customers',
    'subscriptions',
    'entitlements',
    'wishlists',
    'wishlist_items',
    'reviews',
    'questions',
    'answers',
    'order_tracking_references',
    'consent_records',
    'themes',
    'theme_assignments',
    'loyalty_accounts',
    'loyalty_transactions',
    'abandoned_cart_campaigns',
    'marketing_preferences',
    'app_installations',
    'app_webhook_subscriptions',
    'app_oauth_authorization_codes',
    'app_refresh_tokens',
    'app_access_tokens',
    'return_requests',
    'return_items',
    'markets',
    'notification_templates',
    'notification_deliveries',
    'risk_assessments',
    'api_keys',
    'b2b_companies','b2b_company_contacts','b2b_catalogs','b2b_catalog_assignments','b2b_catalog_items',
    'pos_locations','pos_registers','pos_sessions','pos_order_links',
    'commerce_experiments','commerce_experiment_assignments','commerce_experiment_observations','product_feeds','ucp_checkout_sessions','ucp_events',
 ]
errors = []
for t in rls:
    if t not in tables:
        errors.append(f'RLS table missing from ORM: {t}')
    elif 'tenant_id' not in tables[t]:
        errors.append(f'RLS table has no tenant_id: {t}')
route_defs = []
route_files = sorted((ROOT / 'app/routes').glob('*.py'))
for route_file in route_files:
    if route_file.name == '__init__.py':
        continue
    module = ast.parse(route_file.read_text(encoding='utf-8'))
    for node in ast.walk(module):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for dec in node.decorator_list:
            if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and isinstance(dec.func.value, ast.Name) and (dec.func.value.id == 'router')):
                continue
            method = dec.func.attr.upper()
            if method not in {'GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS', 'HEAD'} or not dec.args:
                continue
            path_node = dec.args[0]
            if isinstance(path_node, ast.Constant) and isinstance(path_node.value, str):
                route_defs.append((method, path_node.value, node.name))
route_keys = [(m, p) for m, p, _ in route_defs]
duplicates = sorted({k for k in route_keys if route_keys.count(k) > 1})
routes = len(route_defs)
if duplicates:
    errors.append('Duplicate router routes: ' + ', '.join((f'{m} {p}' for m, p in duplicates)))
required = ['/auth/register', '/auth/login', '/auth/logout', '/auth/password-reset/request', '/auth/password-reset/confirm', '/me', '/tenants', '/tenants/{tenant_id}', '/products', '/checkout', '/payments/intents', '/refunds', '/webhooks/paddle', '/webhooks/iyzico', '/webhooks/paytr', '/health', '/ready']
for r in required:
    if r not in {p for _, p, _ in route_defs}:
        errors.append(f'Core route missing: {r}')
if not errors:
    print(f'PASS: {len(tables)} ORM tables; {len(rls)} RLS tables structurally tenant-scoped; {routes} route declarations (method+path), unique')
else:
    print('FAIL')
    print('\n'.join(('- ' + e for e in errors)))
    sys.exit(1)
