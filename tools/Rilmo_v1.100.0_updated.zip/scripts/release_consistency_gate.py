from __future__ import annotations
from pathlib import Path
import re, sys, zipfile
ROOT=Path(__file__).resolve().parents[1]
VERSION=(ROOT/"VERSION").read_text(encoding="utf-8").strip()
fail=[]
text_files=[p for p in ROOT.rglob("*") if p.is_file() and p.suffix.lower() in {".py",".yml",".yaml",".env",".md",".txt",".toml"} and ".git" not in p.parts]
for p in text_files:
    try: t=p.read_text(encoding="utf-8")
    except UnicodeDecodeError: continue
    # Old application identifiers/releases are never allowed in a current runtime/build surface.
    if "UnifiedGlobalCommerce/1.36" in t and "test_v164_global_release.py" not in p.name and p.name not in {"release_consistency_gate.py", "IMPLEMENTATION_STATUS.md"}:
        fail.append(f"stale user-agent: {p}")
    if re.search(r"(?:APP_VERSION|version|release)[=: ]+1\.(?:[0-5][0-9])\.\d+", t, re.I):
        if "RELEASE_MANIFEST_" not in p.name and "RELEASE_NOTES" not in p.name and "DEEP_AUDIT" not in p.name and "LOCAL_RELEASE_EVIDENCE" not in p.name:
            fail.append(f"stale version reference: {p}")
# Current release-control documents must agree with VERSION. Historical release-note
# documents are intentionally excluded because they are immutable audit history.
for fn in ("README.md","IMPLEMENTATION_STATUS.md",".env.example","docker-compose.yml","docs/compliance/compliance_manifest.json","RELEASE_MANIFEST.json") :
    p=ROOT/fn
    if p.exists():
        t=p.read_text(encoding="utf-8")
        if VERSION not in t:
            fail.append(f"{fn} does not reference current VERSION {VERSION}")
if fail:
    print("RELEASE_CONSISTENCY_FAIL")
    for x in fail: print("-",x)
    raise SystemExit(1)
print(f"RELEASE_CONSISTENCY_PASS VERSION={VERSION}")
