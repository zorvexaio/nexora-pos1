from __future__ import annotations
import ast
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

def text(path: str) -> str:
    return (ROOT / path).read_text(encoding='utf-8')


# Route registry completeness: every router module participates in security review.
route_files = sorted((ROOT / 'app' / 'routes').glob('*.py'))
route_keys = []
for route_file in route_files:
    if route_file.name == '__init__.py':
        continue
    try:
        tree = ast.parse(route_file.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'route module parse failed: {route_file}: {exc}')
        continue
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for dec in node.decorator_list:
            if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute)):
                continue
            if not (isinstance(dec.func.value, ast.Name) and dec.func.value.id == 'router'):
                continue
            if dec.func.attr.lower() not in {'get','post','patch','put','delete','options','head'} or not dec.args:
                continue
            if isinstance(dec.args[0], ast.Constant):
                route_keys.append((dec.func.attr.upper(), str(dec.args[0].value), str(route_file)))
if len(route_keys) < 240:
    errors.append(f'route registry unexpectedly small: {len(route_keys)}')
if len(route_keys) != len({(m,p) for m,p,_ in route_keys}):
    errors.append('duplicate route declaration detected across router modules')
if not any('worldclass.py' in f for _,_,f in route_keys):
    errors.append('worldclass router module is not included in the audited route registry')

# Release/version consistency
version = text('VERSION').strip()
for path in ['docker-compose.yml', '.env.example', 'scripts/live_runtime_gate.py', 'README.md']:
    body = text(path)
    if any(stale in body for stale in ['1.36.3','1.40.0']):
        errors.append(f'{path}: stale release reference')
if not re.fullmatch(r'\d+\.\d+\.\d+', version):
    errors.append('VERSION is not semver')
requirements = text('requirements-runtime.txt')
if 'redis==8.0.1' not in requirements:
    errors.append('redis 8.0.1 dependency missing')
if 'httpcore==1.0.9' not in requirements:
    errors.append('httpcore 1.0.9 dependency missing')
backup = text('scripts/backup_postgres.sh') + text('scripts/restore_postgres.sh') + text('scripts/secure_backup.py')
if 'aes-256-cbc' in backup.lower() or 'openssl enc -aes-256-cbc' in backup.lower():
    errors.append('legacy unauthenticated CBC backup encryption remains')
if 'AESGCM' not in backup or 'Scrypt' not in backup:
    errors.append('authenticated backup encryption controls missing')

# Server-only AI must not be able to exfiltrate customer/store context to an arbitrary endpoint.
config = text('app/core/config.py')
advanced = text('app/services/advanced.py')
if 'AI_SERVER_ONLY' not in config or 'urlparse(self.AI_BASE_URL).hostname' not in config:
    errors.append('server-only AI endpoint egress guard missing')
if "AI_SERVER_ONLY and provider != 'ollama'" not in advanced:
    errors.append('server-only AI provider guard missing')

main = text('app/main.py')
# OWASP ASVS 5 / API Top 10 control anchors
required_main_tokens = [
    "Content-Security-Policy",
    "Strict-Transport-Security",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Cross-Origin-Opener-Policy",
    "Cross-Origin-Resource-Policy",
    "X-Frame-Options",
    "X-CSRF-Token",
]
for token in required_main_tokens:
    if token not in main:
        errors.append(f'missing application security control: {token}')

v1 = text('app/routes/v1.py')
# Sensitive privacy/KYC function-level authorization.
required_compliance = [
    "@router.post('/platform/compliance/kyc-access')",
    "@router.post('/platform/privacy/incidents')",
    "@router.post('/platform/privacy/requests/{request_id}/ready')",
    "@router.post('/platform/privacy/incidents/{incident_id}')",
]
for marker in required_compliance:
    idx = v1.find(marker)
    if idx < 0:
        errors.append(f'missing compliance route: {marker}')
    else:
        block = v1[idx:idx+1200]
        if 'current_platform_compliance_officer' not in block:
            errors.append(f'compliance route lacks compliance-officer guard: {marker}')

# Upload pipeline: validation + malware scan must precede persistence.
media_idx = v1.find("@router.post('/media')")
if media_idx < 0:
    errors.append('media upload route missing')
else:
    media_block = v1[media_idx:media_idx+2600]
    if 'validate_upload(' not in media_block or 'scan_bytes(' not in media_block:
        errors.append('media upload route lacks validation + malware scan')

privacy = text('app/services/privacy.py')
for forbidden in ['passport_number', 'document_url', 'selfie', 'biometric_template']:
    if forbidden in privacy:
        errors.append(f'privacy service contains raw identity field: {forbidden}')

# Ensure the release has a reproducible dependency/runtime gate and a machine-readable SBOM.
# v1.53 DPP / compliance graph controls
for marker in ["@router.put('/products/{product_id}/digital-passport')", "@router.get('/public/storefront/{hostname}/products/{slug}/digital-passport/{public_token}')"]:
    if marker not in (ROOT / 'app' / 'routes' / 'worldclass.py').read_text(encoding='utf-8'):
        errors.append(f'missing DPP route control: {marker}')
if not (ROOT / 'alembic/versions/20260819_0048_product_passport.py').exists():
    errors.append('missing DPP migration 0048')
if not (ROOT / 'docs/DIGITAL_PRODUCT_PASSPORT_V1_53.md').exists():
    errors.append('missing DPP compliance architecture document')

if not (ROOT / 'scripts/environment_audit.py').exists():
    errors.append('missing environment drift gate')
if not (ROOT / 'scripts/generate_sbom.py').exists():
    errors.append('missing SBOM generator')
# Ensure the release has a reproducible test gate and real postgres gate.
ci = text('.github/workflows/ci.yml')
for marker in ['python -m pytest -q -W error', 'python scripts/postgres_rls_smoke.py']:
    if marker not in ci:
        errors.append(f'CI missing gate: {marker}')

# Ensure current ASVS/API mapping docs exist.
for rel in ['docs/SECURITY_ASVS_5_API_TOP10_MATRIX.md', 'docs/PRODUCTION_EVIDENCE_GATES.md', 'docs/PRODUCTION_SECURITY_BASELINE_V1_44_0.md']:
    if not (ROOT / rel).exists():
        errors.append(f'missing security/go-live control document: {rel}')

if errors:
    print('SECURITY_GATE_FAIL')
    for item in errors:
        print('-', item)
    raise SystemExit(1)
print(f'SECURITY_GATE_PASS version={version}')
