#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL required}"
: "${BACKUP_ENCRYPTION_KEY:?BACKUP_ENCRYPTION_KEY required}"
out="${1:-backup-$(date -u +%Y%m%dT%H%M%SZ).tijory.enc}"
pg_dump "$DATABASE_URL" --format=plain --no-owner --no-privileges | gzip -9 | python scripts/secure_backup.py encrypt --passphrase "$BACKUP_ENCRYPTION_KEY" --output "$out"
chmod 600 "$out"
printf 'Authenticated encrypted backup written to %s\n' "$out"
