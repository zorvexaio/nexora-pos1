from __future__ import annotations

import datetime as dt
import hashlib
import os
import re
import shutil
import stat
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
OUT = ROOT.parent / f"Unified_Global_Commerce_v{VERSION}_RELEASE.zip"
BAD_DIRS = {".pytest_cache", "__pycache__", ".mypy_cache", ".ruff_cache", ".local", "media_store"}
EXCLUDE_FROM_CLEAN_RELEASE = {".git"}
BAD_SUFFIX = {".db", ".sqlite", ".sqlite3", ".pyc", ".pyo", ".log", ".journal", ".wal", ".shm"}
BAD_SUBSTRINGS = {"-journal", "-wal", "-shm"}
BAD_PREFIXES = {".coverage"}
BAD_EXACT_FILES = {
    "collected.txt", "filelist.txt", "suspicious.txt", "isolated_full.out", "isolated_full.pid",
    "shard1.out", "shard1.txt", "shard2.out", "shard2.txt", "shard3.out", "shard3.txt",
    "shard4.out", "shard4.txt",
}
BAD_SUFFIXES_EXTRA = {".bak"}
BAD_BACKUP_PATTERNS = (re.compile(r".*\.pre_[0-9]+$"), re.compile(r".*\.(orig|old)$"))
BAD_FILE_PATTERNS = (re.compile(r'^_apply_v\d+\.py$'),)


def should_skip(p: Path) -> bool:
    rel = p.relative_to(ROOT)
    return (
        not p.is_file()
        or any(part in BAD_DIRS or part in EXCLUDE_FROM_CLEAN_RELEASE for part in rel.parts)
        or p.suffix.lower() in BAD_SUFFIX
        or p.suffix.lower() in BAD_SUFFIXES_EXTRA
        or p.name in BAD_EXACT_FILES
        or any(pattern.fullmatch(p.name) for pattern in BAD_FILE_PATTERNS)
        or any(pattern.fullmatch(p.name) for pattern in BAD_BACKUP_PATTERNS)
        or any(x in p.name for x in BAD_SUBSTRINGS)
        or any(p.name.startswith(x) for x in BAD_PREFIXES)
    )


def source_date() -> dt.date:
    raw = os.environ.get("SOURCE_DATE_EPOCH")
    if raw is None:
        return dt.datetime.now(dt.timezone.utc).date()
    return dt.datetime.fromtimestamp(int(raw), tz=dt.timezone.utc).date()


def zip_datetime() -> tuple[int, int, int, int, int, int]:
    # ZIP timestamps must be >= 1980-01-01; fixed metadata makes the artifact byte-reproducible.
    return (1980, 1, 1, 0, 0, 0)


def add_reproducible(zf: zipfile.ZipFile, p: Path) -> None:
    rel = p.relative_to(ROOT).as_posix()
    data = p.read_bytes()
    info = zipfile.ZipInfo(rel, date_time=zip_datetime())
    info.create_system = 3
    mode = p.stat().st_mode
    perms = 0o755 if mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH) else 0o644
    info.external_attr = (stat.S_IFREG | perms) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


# Clean transient development artifacts before calculating the release surface.
for p in sorted(ROOT.rglob("*"), reverse=True):
    if p.is_dir() and p.name in BAD_DIRS:
        shutil.rmtree(p)
    elif p.is_file() and (
        p.suffix.lower() in BAD_SUFFIX
        or p.suffix.lower() in BAD_SUFFIXES_EXTRA
        or any(x in p.name for x in BAD_SUBSTRINGS)
        or any(p.name.startswith(x) for x in BAD_PREFIXES)
    ):
        p.unlink()

release_manifest = ROOT / "RELEASE_MANIFEST.json"
manifest_files = []
for p in sorted(ROOT.rglob("*")):
    if should_skip(p) or p == release_manifest or p.name == "SHA256MANIFEST.txt":
        continue
    rel = p.relative_to(ROOT)
    manifest_files.append({
        "path": rel.as_posix(),
        "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        "bytes": p.stat().st_size,
    })

release_manifest.write_text(
    __import__("json").dumps(
        {
            "release": "Unified Global Commerce",
            "version": VERSION,
            "generated_at": source_date().isoformat(),
            "file_count": len(manifest_files),
            "files": manifest_files,
        },
        indent=2,
    ) + "\n",
    encoding="utf-8",
)

manifest = ROOT / "SHA256MANIFEST.txt"
rows = [f"{entry['sha256']}  {entry['path']}" for entry in manifest_files]
manifest.write_text("\n".join(rows) + "\n", encoding="utf-8")

if OUT.exists():
    OUT.unlink()
with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(ROOT.rglob("*")):
        if should_skip(p):
            continue
        add_reproducible(z, p)

print(f"RELEASE={OUT}")
print(f"FILES={len(rows)}")
subprocess.run(
    [sys.executable, str(ROOT / "scripts/release_artifact_audit.py"), "--zip", str(OUT)],
    cwd=ROOT,
    check=True,
)
