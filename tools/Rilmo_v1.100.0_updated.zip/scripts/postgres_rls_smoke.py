"""Real PostgreSQL FORCE-RLS smoke test. Run only against a disposable database after migrations."""
import os, uuid
from sqlalchemy import create_engine, text
url = os.environ.get('DATABASE_URL')
if not url or not url.startswith('postgresql'):
    raise SystemExit('DATABASE_URL must point to PostgreSQL')
engine = create_engine(url, future=True)
a, b = (str(uuid.uuid4()), str(uuid.uuid4()))
pa = str(uuid.uuid4())
with engine.begin() as db:
    db.execute(text("INSERT INTO tenants(id,slug,name,status,default_currency,default_locale,created_at) VALUES (:id,:slug,:name,'ACTIVE','USD','ar',now())"), {'id': a, 'slug': 'rls-a-' + a[:8], 'name': 'RLS A'})
    db.execute(text("INSERT INTO tenants(id,slug,name,status,default_currency,default_locale,created_at) VALUES (:id,:slug,:name,'ACTIVE','USD','ar',now())"), {'id': b, 'slug': 'rls-b-' + b[:8], 'name': 'RLS B'})
    db.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {'t': a})
    db.execute(text("INSERT INTO products(id,tenant_id,slug,status,product_type,title,version,created_at) VALUES (:id,:tenant,'rls-product','ACTIVE','PHYSICAL','RLS Product',1,now())"), {'id': pa, 'tenant': a})
    assert db.execute(text('SELECT count(*) FROM products WHERE id=:id'), {'id': pa}).scalar_one() == 1
    db.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {'t': b})
    assert db.execute(text('SELECT count(*) FROM products WHERE id=:id'), {'id': pa}).scalar_one() == 0
    db.execute(text("SELECT set_config('app.worker','on',true)"))
    assert db.execute(text('SELECT count(*) FROM products WHERE id=:id'), {'id': pa}).scalar_one() == 0
    db.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {'t': a})
    assert db.execute(text('SELECT count(*) FROM products WHERE id=:id'), {'id': pa}).scalar_one() == 1
print('PASS: PostgreSQL FORCE RLS tenant isolation; client-settable bypass GUC rejected')
