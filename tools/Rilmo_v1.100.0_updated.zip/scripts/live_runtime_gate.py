#!/usr/bin/env python3
"""Run the real local runtime smoke test against a fresh migrated demo database."""
from __future__ import annotations
import os, signal, socket, subprocess, sys, tempfile, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def free_port() -> int:
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return int(s.getsockname()[1])

def run(cmd, env):
    subprocess.run(cmd, cwd=ROOT, env=env, check=True)

def main():
    port = free_port()
    db_path = Path(tempfile.gettempdir()) / f'ugc_live_gate_{os.getpid()}.db'
    if db_path.exists(): db_path.unlink()
    env = os.environ.copy()
    env.update({
        'ENVIRONMENT':'development',
        'DATABASE_URL':f'sqlite:///{db_path}',
        'ALLOW_LOCAL_MOCK_PAYMENTS':'true',
        'APP_VERSION':(ROOT/'VERSION').read_text().strip(),
        'PUBLIC_BASE_URL':f'http://127.0.0.1:{port}',
        'SECRET_KEY':'local-development-secret-32-bytes-minimum-123456789',
        'ENCRYPTION_KEY':'local-encryption-secret-32-bytes-minimum-123456789',
        'WEBHOOK_SECRET':'local-webhook-secret-32-bytes-minimum-123456789',
        'DOMAIN_VERIFICATION_MODE':'token',
        'DEMO_STORE_HOST':'demo.localhost',
        'FORWARDED_ALLOW_IPS':'127.0.0.1',
    })
    proc = None
    try:
        run([sys.executable,'-m','alembic','upgrade','head'],env)
        run([sys.executable,'scripts/seed_demo.py'],env)
        proc = subprocess.Popen([sys.executable,'-m','uvicorn','app.main:app','--host','127.0.0.1','--port',str(port),'--proxy-headers','--forwarded-allow-ips','127.0.0.1'],cwd=ROOT,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        smoke_env = env | {'LOCAL_RUNTIME_URL':f'http://127.0.0.1:{port}'}
        run([sys.executable,'scripts/local_runtime_smoke.py'],smoke_env)
        print('LIVE_RUNTIME_GATE_PASS')
    finally:
        if proc is not None:
            proc.terminate()
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait(timeout=5)
        if db_path.exists(): db_path.unlink()

if __name__ == '__main__': main()
