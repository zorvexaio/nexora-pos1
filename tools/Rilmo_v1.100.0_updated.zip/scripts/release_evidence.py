"""Generate deterministic local/CI release evidence without manufacturing PASS states."""
from __future__ import annotations
from pathlib import Path
import concurrent.futures, json, os, re, subprocess, sys, tempfile, time
from datetime import datetime, timezone
try:
    import yaml
except Exception:
    yaml = None
ROOT = Path(__file__).resolve().parents[1]
VERSION = (ROOT / 'VERSION').read_text(encoding='utf-8').strip()

def run(cmd, timeout=90):
    env = dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    try:
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, env=env, timeout=timeout)
        return r.returncode, (r.stdout + r.stderr).strip(), False
    except subprocess.TimeoutExpired as exc:
        out = ((exc.stdout or '') if isinstance(exc.stdout, str) else '').strip()
        err = ((exc.stderr or '') if isinstance(exc.stderr, str) else '').strip()
        return 124, (out + '\n' + err).strip(), True

def add(results, name, ok, detail):
    results.append({'name': name, 'status': 'PASS' if ok else 'FAIL', 'detail': detail})

results=[]
rc,out,timed=run([sys.executable,'scripts/runtime_dependency_lock_gate.py'],60)
runtime_ok=(rc==0 and not timed)
add(results,'runtime_dependency_lock',runtime_ok,(out.splitlines()[-1] if out else 'no output') + (' [TIMEOUT]' if timed else ''))
for name, cmd in [
    ('final_release_audit', [sys.executable, 'scripts/final_release_audit.py']),
    ('spec_audit', [sys.executable, 'scripts/spec_audit.py']),
    ('spec_schema_audit', [sys.executable, 'scripts/spec_schema_audit.py']),
    ('frontend_audit', [sys.executable, 'scripts/frontend_audit.py']),
    ('release_consistency', [sys.executable, 'scripts/release_consistency_gate.py']),
    ('security_gate', [sys.executable, 'scripts/security_gate.py']),
    ('regulatory_readiness', [sys.executable, 'scripts/regulatory_readiness_audit.py']),
]:
    rc,out,timed = run(cmd,180)
    add(results,name,rc==0 and not timed, (out.splitlines()[-1] if out else 'no output') + (' [TIMEOUT]' if timed else ''))

for f in ['app/frontend/app.js','app/frontend/storefront.js']:
    rc,out,timed=run(['node','--check',f],30)
    add(results,f'node_check:{f}',rc==0 and not timed,out or 'Node syntax check')

if yaml:
    try:
        d=yaml.safe_load((ROOT/'docker-compose.production.yml').read_text(encoding='utf-8'))
        keys=[]
        env=d['services'].get('api', {}).get('environment', {})
        if isinstance(env, dict): keys.extend(env.keys())
        else:
            for item in env:
                if isinstance(item,str) and '=' in item: keys.append(item.split('=',1)[0])
        dup=sorted({k for k in keys if keys.count(k)>1})
        add(results,'production_compose_unique_env',not dup,f'duplicate env keys={dup}')
    except Exception as exc:
        add(results,'production_compose_unique_env',False,str(exc))
else:
    add(results,'production_compose_unique_env',False,'PyYAML unavailable')

# Actual local runtime gate; never mark PASS without executing it.
rc,out,timed=run([sys.executable,'scripts/live_runtime_gate.py'],180)
add(results,'live_runtime_gate',rc==0 and 'LIVE_RUNTIME_GATE_PASS' in out and not timed,out.splitlines()[-1] if out else 'no output')

# Collect test inventory separately. Do not run or label tests PASS when the installed environment
# does not match the repository lock; that would produce non-reproducible evidence.
rc,out,timed=run([sys.executable,'-m','pytest','--collect-only','-q'],30)
m=re.search(r'(\d+) tests collected',out)
collected=int(m.group(1)) if m else 0
add(results,'pytest_collection',rc==0 and collected>0, f'{collected} tests collected')
critical_files=[
    'tests/test_v179_ucp_payment_binding.py','tests/test_v176_ucp_contract.py',
    'tests/test_v174_release_contract.py','tests/test_v173_runtime_closure.py',
    'tests/test_v172_global_safety.py','tests/test_v171_global_legal_2026.py',
    'tests/test_v165_merchant_kyb_payment_gate.py','tests/test_v167_buyer_protection_refund.py',
    'tests/test_v152_workflow_webhook_runtime.py','tests/test_v157_ai_security.py'
]
if runtime_ok:
    rc,out,timed=run([sys.executable,'-m','pytest','-q','-W','error',*critical_files],180)
    mm=re.search(r'(\d+) passed',out); passed=int(mm.group(1)) if mm else 0
    add(results,'critical_regression_suite',rc==0 and not timed,f'{passed} passed' + (' [TIMEOUT]' if timed else ''))
    rc,out,timed=run([sys.executable,'scripts/run_test_shards.py','--shards','4','--timeout','120'],300)
    full_ok=rc==0 and 'SHARDS_FAILED=0' in out and not timed
    add(results,'full_sharded_test_suite',full_ok,(out.splitlines()[-1] if out else 'no output') + (' [TIMEOUT]' if timed else ''))
else:
    add(results,'critical_regression_suite',False,'NOT VERIFIED: runtime dependency lock mismatch')
    add(results,'full_sharded_test_suite',False,'NOT VERIFIED: runtime dependency lock mismatch')
    full_ok=False

status_lines=[f'# IMPLEMENTATION STATUS — v{VERSION}','',f'Generated from the repository on {datetime.now(timezone.utc).date().isoformat()}.','',f'- Test inventory: **{collected} tests collected**','- Critical regression suite: **' + ('PASS' if any(r["name"]=="critical_regression_suite" and r["status"]=="PASS" for r in results) else 'FAIL') + '**','- Full sharded suite: **' + ('PASS' if full_ok else 'NOT VERIFIED') + '**','', '## Verified gates']
status_lines += [f'- {r["name"]}: **{r["status"]}** — {r["detail"]}' for r in results]
status_lines += ['', '## External evidence required before GLOBAL 100% certification',
'- [ ] Production PostgreSQL/RLS runtime-role evidence',
'- [ ] Real payment-provider sandbox/production onboarding and webhook replay evidence',
'- [ ] Production DNS ownership/takeover test',
'- [ ] Object-storage + malware scanning corpus/lifecycle evidence',
'- [ ] Load/stress/soak/SLO and multi-instance failover evidence',
'- [ ] Backup/restore rehearsal against production topology',
'- [ ] Independent penetration test',
'- [ ] Independent AI/agent red-team',
'- [ ] Jurisdiction-specific legal/tax/e-invoicing review',
]
(ROOT/'IMPLEMENTATION_STATUS.md').write_text('\n'.join(status_lines)+'\n',encoding='utf-8')

evidence={'release':VERSION,'generated_at':datetime.now(timezone.utc).isoformat(),'test_inventory':collected,'results':results,'global_100_certified':False,'reason':'External production evidence is not present in the repository; local full-suite verification is recorded honestly and any timeout is never converted into PASS.'}
(ROOT/f'docs/LOCAL_RELEASE_EVIDENCE_V{VERSION.replace(".", "_")}.json').write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8')
print(json.dumps(evidence,indent=2))
failed=[r for r in results if r['status']=='FAIL']
raise SystemExit(1 if failed else 0)
