from __future__ import annotations
import importlib.metadata as md
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = [ROOT / "requirements-runtime.txt", ROOT / "requirements.txt", ROOT / "requirements-dev.txt"]

def parse(lines):
    out = {}
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("-") or "==" not in line:
            continue
        name, ver = line.split("==", 1)
        out[name.split("[", 1)[0].lower()] = ver.strip()
    return out

expected = {}
for path in FILES:
    expected.update(parse(path.read_text(encoding="utf-8").splitlines()))

fail = []
for name, wanted in sorted(expected.items()):
    try:
        installed = md.version(name)
    except md.PackageNotFoundError:
        fail.append(f"{name}: missing (expected {wanted})")
        continue
    if installed != wanted:
        fail.append(f"{name}: installed {installed}, expected {wanted}")

if fail:
    print("RUNTIME_DEPENDENCY_LOCK_FAIL")
    for item in fail:
        print("-", item)
    raise SystemExit(1)
print(f"RUNTIME_DEPENDENCY_LOCK_PASS packages={len(expected)}")
