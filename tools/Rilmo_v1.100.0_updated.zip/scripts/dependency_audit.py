from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
runtime = (root / 'requirements-runtime.txt').read_text()
checks = {
    'fastapi': 'fastapi==0.141.1' in runtime,
    'starlette': 'starlette==0.52.1' in runtime,
    'httpx': 'httpx==0.28.1' in runtime,
    'sqlalchemy': 'sqlalchemy==2.0.52' in runtime,
    'cryptography': 'cryptography==50.0.0' in runtime,
}
for name, ok in checks.items():
    print(f"{name}: {('PASS' if ok else 'FAIL')}")
if not all(checks.values()):
    raise SystemExit(1)
print('PASS: runtime dependency pins are explicit and reproducible')
