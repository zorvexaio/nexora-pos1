#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(ok,msg):
    checks.append((ok,msg))
req_files=[
 'docs/ACCESSIBILITY_STATEMENT_V1_44_0.md',
 'docs/PCI_DSS_SCOPE_V4_0_1.md',
 'docs/REGULATORY_READINESS_MATRIX_V1_44_0.md',
 ]
for f in req_files:
    check((ROOT/f).exists(), f'Missing {f}')
index=ROOT/'app/frontend/index.html'
access=ROOT/'app/frontend/accessibility.html'
check(access.exists(), 'Accessibility statement page exists')
if index.exists():
    t=index.read_text(encoding='utf-8')
    check('skip-to-content' in t, 'Dashboard skip link present')
    check('mainContent' in t, 'Dashboard main content landmark/id present')
    check('aria-label=' in t, 'Static dashboard accessible names present')
if access.exists():
    t=access.read_text(encoding='utf-8')
    check('WCAG 2.2 AA' in t, 'Accessibility page states target level')
# production configuration contracts
cfg=(ROOT/'app/core/config.py').read_text(encoding='utf-8')
for token in ['LEGAL_ENTITY_NAME','PRIVACY_CONTACT_EMAIL','PRIVACY_POLICY_VERSION','TERMS_EFFECTIVE_DATE','PLATFORM_MODEL']:
    check(token in cfg, f'Production config requires {token}')
for name in ['privacy.html','kvkk.html','terms.html']:
    check((ROOT/'app/frontend'/name).exists(), f'Public compliance page exists: {name}')
failed=[m for ok,m in checks if not ok]
if failed:
    print('REGULATORY_READINESS_AUDIT_FAIL')
    for m in failed: print('-',m)
    sys.exit(1)
print(f'REGULATORY_READINESS_AUDIT_PASS checks={len(checks)}')
