"""Fail-closed audit for the PostgreSQL role and FORCE-RLS posture used by the app."""
from __future__ import annotations
import os
import sys
from sqlalchemy import create_engine, text

url = os.environ.get('DATABASE_URL', '')
if not url.startswith('postgresql'):
    raise SystemExit('DATABASE_URL must point to PostgreSQL')

engine = create_engine(url, future=True)
with engine.begin() as db:
    role = db.execute(text("""
        SELECT current_user, r.rolsuper, r.rolbypassrls
        FROM pg_roles r WHERE r.rolname = current_user
    """)).mappings().one()
    if role['rolsuper'] or role['rolbypassrls']:
        print('RUNTIME_ROLE_RLS_FAIL: application role must be neither SUPERUSER nor BYPASSRLS')
        sys.exit(1)

    missing_force = db.execute(text("""
        SELECT c.relname
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relkind = 'r'
          AND n.nspname = 'public'
          AND EXISTS (
            SELECT 1 FROM information_schema.columns col
            WHERE col.table_schema='public' AND col.table_name=c.relname AND col.column_name='tenant_id'
          )
          AND (c.relrowsecurity IS NOT TRUE OR c.relforcerowsecurity IS NOT TRUE)
        ORDER BY c.relname
    """)).scalars().all()
    if missing_force:
        print('RUNTIME_ROLE_RLS_FAIL: tenant tables without ENABLE+FORCE RLS:')
        print('\n'.join(missing_force))
        sys.exit(1)

    unsafe_policies = db.execute(text("""
        SELECT schemaname, tablename, policyname, qual
        FROM pg_policies
        WHERE schemaname='public' AND tablename IN (
            SELECT DISTINCT c.relname
            FROM pg_class c
            JOIN pg_namespace n ON n.oid=c.relnamespace
            WHERE c.relkind='r' AND n.nspname='public'
              AND EXISTS (SELECT 1 FROM information_schema.columns col
                          WHERE col.table_schema='public' AND col.table_name=c.relname AND col.column_name='tenant_id')
        )
        AND (qual LIKE '%app.worker%' OR with_check LIKE '%app.worker%')
    """)).mappings().all()
    if unsafe_policies:
        print('RUNTIME_ROLE_RLS_FAIL: tenant policy still depends on client-settable app.worker GUC')
        for row in unsafe_policies:
            print(dict(row))
        sys.exit(1)

    print(f"RUNTIME_ROLE_RLS_PASS role={role['current_user']} tenant_tables_force_rls=checked")
