#!/usr/bin/env python3
"""Run the full pytest inventory in isolated subprocess shards and aggregate results."""
from __future__ import annotations
import argparse, os, signal, subprocess, sys, tempfile, concurrent.futures
from pathlib import Path

def collect() -> list[str]:
    out=subprocess.check_output([sys.executable,'-m','pytest','--collect-only','-q'],text=True)
    return [line.strip() for line in out.splitlines() if line.startswith('tests/') and '::' in line]

def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument('--shards',type=int,default=4); ap.add_argument('--timeout',type=int,default=120); a=ap.parse_args()
    items=collect(); total=len(items); size=(total+a.shards-1)//a.shards
    failures=[]
    jobs=[]
    for i in range(a.shards):
        chunk=items[i*size:(i+1)*size]
        if chunk: jobs.append((i+1, chunk))

    def run_one(job):
        i, chunk = job
        env = dict(os.environ)
        env["TEST_DB_PATH"] = str(Path(tempfile.gettempdir()) / f"rilmo_shard_{i}_{os.getpid()}.db")
        cmd = [sys.executable, "-m", "pytest", "-q", "-W", "error", *chunk]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                env=env, start_new_session=True)
        try:
            stdout, stderr = proc.communicate(timeout=a.timeout)
            rc = proc.returncode
        except subprocess.TimeoutExpired as exc:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
                stdout, stderr = proc.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                stdout, stderr = proc.communicate(timeout=5)
            rc = 124
            stdout = (stdout or "") + "\nSHARD_TIMEOUT\n"
        result = subprocess.CompletedProcess(cmd, rc, stdout, stderr)
        return i, chunk, result

    with concurrent.futures.ThreadPoolExecutor(max_workers=a.shards) as ex:
        futures=[ex.submit(run_one,j) for j in jobs]
        for fut in concurrent.futures.as_completed(futures):
            i, chunk, r = fut.result()
            ok=r.returncode==0
            print(f'SHARD_{i}_TESTS={len(chunk)} STATUS={"PASS" if ok else "FAIL"}')
            if not ok:
                print(r.stdout[-4000:]); print(r.stderr[-2000:]); failures.append(i)
    print(f'SHARDS_FAILED={len(failures)}')
    return 1 if failures else 0
if __name__=='__main__': raise SystemExit(main())
