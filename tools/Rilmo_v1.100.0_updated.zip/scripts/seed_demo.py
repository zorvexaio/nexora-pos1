#!/usr/bin/env python3
"""Create a deterministic local demo merchant for the Developer Runtime."""
from datetime import datetime, timezone
import os
import secrets
import sys
import subprocess
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from app.core.database import SessionLocal
from app.core.security import hash_password
from app.models.domain import (
    Domain, InventoryItem, InventoryLocation, Product, ProductTranslation,
    ProductVariant, Storefront, Tenant, TenantMembership, TaxRate, User, Plan, PlanVersion, PlanFeature, Subscription, SubscriptionItem, Entitlement, TenantEntitlement, PlanPrice,
)
from app.services.core import ensure_seed

DEMO_EMAIL = os.getenv('DEMO_ADMIN_EMAIL', 'merchant@example.test').lower()
DEMO_PASSWORD = os.getenv('DEMO_ADMIN_PASSWORD', '')
if not DEMO_PASSWORD:
    DEMO_PASSWORD = 'Demo-' + secrets.token_urlsafe(18) + '!9'
if os.getenv('ENVIRONMENT', 'development').strip().lower() == 'production':
    raise SystemExit('seed_demo.py is disabled in production')
DEMO_HOST = os.getenv('DEMO_STORE_HOST', 'demo.localhost').lower()


def get_or_create(db, model, **kwargs):
    row = db.query(model).filter_by(**kwargs).first()
    if row:
        return row, False
    row = model(**kwargs)
    db.add(row)
    db.flush()
    return row, True


def ensure_schema() -> None:
    env = os.environ.copy()
    subprocess.run([sys.executable, '-m', 'alembic', 'upgrade', 'head'], cwd=PROJECT_ROOT, env=env, check=True)


def main() -> None:
    ensure_schema()
    db = SessionLocal()
    try:
        ensure_seed(db)
        user = db.query(User).filter_by(email=DEMO_EMAIL).first()
        if not user:
            user = User(email=DEMO_EMAIL, password_hash=hash_password(DEMO_PASSWORD), display_name='Demo Merchant')
            db.add(user)
            db.flush()
        tenant, _ = get_or_create(db, Tenant, slug='demo-store', name='Demo Store', status='ACTIVE',
            default_currency='USD', default_locale='ar')
        tenant.status = 'ACTIVE'
        membership, _ = get_or_create(db, TenantMembership, tenant_id=tenant.id, user_id=user.id,
            role='owner', status='ACTIVE')
        starter = db.query(Plan).filter_by(code='starter', is_active=True).first()
        pv = db.query(PlanVersion).filter_by(plan_id=starter.id, is_current=True).first() if starter else None
        if pv and not db.query(Subscription).filter_by(tenant_id=tenant.id, status='active').first():
            sub = Subscription(tenant_id=tenant.id, plan_version_id=pv.id, status='active',
                pricing_model='saas_subscription', billing_provider='mock',
                provider_subscription_id='mock_demo_starter_'+tenant.id)
            db.add(sub); db.flush()
            pp = db.query(PlanPrice).filter_by(plan_version_id=pv.id,billing_interval='month').first()
            if pp: db.add(SubscriptionItem(subscription_id=sub.id, plan_price_id=pp.id, quantity=1))
            for f in db.query(PlanFeature).filter_by(plan_version_id=pv.id).all():
                db.add(Entitlement(tenant_id=tenant.id,feature_key=f.feature_key,value_type=f.value_type,
                    value_boolean=f.value_boolean,value_integer=f.value_integer,version=1))
                db.add(TenantEntitlement(tenant_id=tenant.id,feature_key=f.feature_key,value_type=f.value_type,
                    value_boolean=f.value_boolean,value_integer=f.value_integer,source_subscription_id=sub.id))
        sf, _ = get_or_create(db, Storefront, tenant_id=tenant.id, name='Demo Store', slug='default',
            default_locale='ar', default_currency='USD', price_display_mode='tax_exclusive', status='PUBLISHED')
        sf.status = 'PUBLISHED'
        domain, _ = get_or_create(db, Domain, tenant_id=tenant.id, storefront_id=sf.id, hostname=DEMO_HOST,
            is_primary=True, verification_method='local', verified_hostname=DEMO_HOST,
            verified_at=datetime.now(timezone.utc))
        domain.verified_at = datetime.now(timezone.utc)
        products = [
            ('arabic-mug', 'كوب عربي', 'كوب سيراميك تجريبي عالي الجودة.', 'MUG-AR', 1899, 25),
            ('daily-notebook', 'دفتر يومي', 'دفتر عملي للمهام والملاحظات.', 'NOTE-01', 1299, 50),
            ('canvas-bag', 'حقيبة قماش', 'حقيبة قماش قابلة لإعادة الاستخدام.', 'BAG-01', 2499, 30),
        ]
        loc, _ = get_or_create(db, InventoryLocation, tenant_id=tenant.id, name='Main Warehouse', status='ACTIVE')
        for slug, title, desc, sku, price, stock in products:
            product, _ = get_or_create(db, Product, tenant_id=tenant.id, storefront_id=sf.id, slug=slug,
                title=title, description=desc, status='ACTIVE', product_type='PHYSICAL')
            product.status = 'ACTIVE'
            variant, _ = get_or_create(db, ProductVariant, tenant_id=tenant.id, product_id=product.id, sku=sku,
                price_amount_minor=price, currency='USD', status='ACTIVE')
            variant.status = 'ACTIVE'
            translation = db.query(ProductTranslation).filter_by(tenant_id=tenant.id, product_id=product.id, locale='ar').first()
            if not translation:
                translation = ProductTranslation(tenant_id=tenant.id, product_id=product.id, locale='ar', name=title,
                    description=desc, seo_title=title, seo_description=desc)
                db.add(translation)
            inv = db.query(InventoryItem).filter_by(tenant_id=tenant.id, variant_id=variant.id, location_id=loc.id).first()
            if not inv:
                inv = InventoryItem(tenant_id=tenant.id, variant_id=variant.id, location_id=loc.id,
                    on_hand=stock, reserved=0, committed=0, available=stock, version=1)
                db.add(inv)
            else:
                inv.on_hand = max(inv.on_hand, stock)
                inv.available = max(0, inv.on_hand - inv.reserved - inv.committed)
        tax = db.query(TaxRate).filter_by(tenant_id=tenant.id, country_code='US', region=None).first()
        if not tax:
            db.add(TaxRate(tenant_id=tenant.id, country_code='US', region=None, rate_bps=0, inclusive=False))
        db.commit()
        print('DEMO_RUNTIME_READY')
        print(f'ADMIN_EMAIL={DEMO_EMAIL}')
        print(f'ADMIN_PASSWORD={DEMO_PASSWORD}')
        print(f'STOREFRONT_URL=http://localhost:8000/store/{DEMO_HOST}')
        print(f'API_STOREFRONT_HOST={DEMO_HOST}')
        print('LOCAL_PAYMENT_PROVIDER=mock')
    finally:
        db.close()


if __name__ == '__main__':
    main()
