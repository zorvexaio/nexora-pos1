from __future__ import annotations

import argparse
import hashlib
import json
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath

CONTROL_FILES = {"RELEASE_MANIFEST.json", "SHA256MANIFEST.txt"}


def fail(message: str) -> None:
    print(f"RELEASE_ARTIFACT_AUDIT_FAIL: {message}")
    raise SystemExit(1)


def normalized_name(name: str) -> str:
    if "\\" in name:
        fail(f"backslash path in ZIP member: {name}")
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts:
        fail(f"unsafe ZIP path: {name}")
    return p.as_posix()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_sha_manifest(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        parts = line.split("  ", 1)
        if len(parts) != 2 or len(parts[0]) != 64:
            fail(f"malformed SHA256MANIFEST entry: {raw!r}")
        digest, path = parts
        path = normalized_name(path)
        if path in CONTROL_FILES:
            fail(f"SHA256MANIFEST illegally contains control file: {path}")
        if path in out:
            fail(f"duplicate SHA256MANIFEST path: {path}")
        out[path] = digest.lower()
    return out


def verify(zip_path: Path) -> None:
    if not zip_path.is_file():
        fail(f"ZIP does not exist: {zip_path}")

    with zipfile.ZipFile(zip_path, "r") as zf:
        infos = zf.infolist()
        names = [normalized_name(info.filename.rstrip("/")) for info in infos if not info.is_dir()]
        if len(names) != len(set(names)):
            fail("ZIP contains duplicate file names")

        name_set = set(names)
        for info in infos:
            if info.is_dir():
                continue
            mode = stat.S_IFMT(info.external_attr >> 16)
            if mode and mode != stat.S_IFREG:
                fail(f"non-regular ZIP member rejected: {info.filename}")

        for control in CONTROL_FILES:
            if control not in name_set:
                fail(f"required control file missing from ZIP: {control}")

        try:
            manifest = json.loads(zf.read("RELEASE_MANIFEST.json"))
        except Exception as exc:  # pragma: no cover - defensive parsing boundary
            fail(f"invalid RELEASE_MANIFEST.json: {exc}")

        if not isinstance(manifest, dict):
            fail("RELEASE_MANIFEST.json must be an object")
        version = str(manifest.get("version", "")).strip()
        if not version:
            fail("manifest version missing")
        release = manifest.get("release")
        if release != "Unified Global Commerce":
            fail(f"unexpected release name: {release!r}")

        entries = manifest.get("files")
        if not isinstance(entries, list):
            fail("manifest files must be a list")
        if manifest.get("file_count") != len(entries):
            fail(f"manifest file_count mismatch: {manifest.get('file_count')} != {len(entries)}")

        manifest_map: dict[str, tuple[str, int]] = {}
        for entry in entries:
            if not isinstance(entry, dict):
                fail("manifest entry is not an object")
            path = normalized_name(str(entry.get("path", "")))
            digest = str(entry.get("sha256", "")).lower()
            size = entry.get("bytes")
            if path in CONTROL_FILES:
                fail(f"manifest must not include control file: {path}")
            if path in manifest_map:
                fail(f"duplicate manifest path: {path}")
            if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                fail(f"invalid SHA-256 for {path}")
            if not isinstance(size, int) or size < 0:
                fail(f"invalid byte count for {path}")
            manifest_map[path] = (digest, size)

        actual_payload = name_set - CONTROL_FILES
        expected_payload = set(manifest_map)
        missing = sorted(expected_payload - actual_payload)
        extra = sorted(actual_payload - expected_payload)
        if missing:
            fail("manifest claims files missing from ZIP: " + ", ".join(missing))
        if extra:
            fail("ZIP contains files absent from manifest: " + ", ".join(extra))

        for path, (expected_sha, expected_size) in sorted(manifest_map.items()):
            data = zf.read(path)
            actual_sha = sha256_bytes(data)
            actual_size = len(data)
            if actual_size != expected_size:
                fail(f"size mismatch for {path}: manifest={expected_size} zip={actual_size}")
            if actual_sha != expected_sha:
                fail(f"SHA-256 mismatch for {path}: manifest={expected_sha} zip={actual_sha}")

        sha_map = parse_sha_manifest(zf.read("SHA256MANIFEST.txt").decode("utf-8"))
        if sha_map != {path: digest for path, (digest, _) in manifest_map.items()}:
            missing_sha = sorted(set(manifest_map) - set(sha_map))
            extra_sha = sorted(set(sha_map) - set(manifest_map))
            mismatched_sha = sorted(
                path for path in set(manifest_map) & set(sha_map)
                if manifest_map[path][0] != sha_map[path]
            )
            fail(
                "SHA256MANIFEST mismatch: "
                f"missing={missing_sha}, extra={extra_sha}, mismatched={mismatched_sha}"
            )

        if zip_path.name.endswith("_RELEASE.zip"):
            suffix_version = zip_path.name.removeprefix("Unified_Global_Commerce_v").removesuffix("_RELEASE.zip")
            if suffix_version != version:
                fail(f"ZIP filename version {suffix_version} != manifest version {version}")

    print(
        f"RELEASE_ARTIFACT_AUDIT_PASS version={version} "
        f"payload_files={len(manifest_map)} total_zip_files={len(name_set)}"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify a release ZIP against its embedded manifest.")
    parser.add_argument("--zip", dest="zip_path", type=Path, required=True)
    args = parser.parse_args()
    verify(args.zip_path)


if __name__ == "__main__":
    main()
