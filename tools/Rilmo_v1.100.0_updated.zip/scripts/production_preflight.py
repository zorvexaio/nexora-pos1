from __future__ import annotations
import os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
fail: list[str] = []

def req(name: str, *, min_len: int = 1) -> str:
    value = os.getenv(name, "").strip()
    if len(value) < min_len:
        fail.append(f"{name}: missing or too short")
    return value

def forbid(name: str, values: set[str]) -> None:
    value = os.getenv(name, "").strip().lower()
    if value in values:
        fail.append(f"{name}: insecure production value {value!r}")

if os.getenv("ENVIRONMENT", "").strip().lower() != "production":
    fail.append("ENVIRONMENT must be production")

secret = req("SECRET_KEY", min_len=32)
encryption = req("ENCRYPTION_KEY", min_len=32)
webhook = req("WEBHOOK_SECRET", min_len=32)
req("DATABASE_URL")
req("REDIS_URL")
req("PUBLIC_BASE_URL")
req("LEGAL_ENTITY_NAME")
req("PRIVACY_CONTACT_EMAIL")
req("PRIVACY_POLICY_VERSION")
req("TERMS_EFFECTIVE_DATE")

if secret and encryption and secret == encryption:
    fail.append("SECRET_KEY and ENCRYPTION_KEY must be different")

for name in ("COOKIE_SECURE", "AI_SERVER_ONLY", "AI_EXTERNAL_PROVIDER_ALLOWED", "MEDIA_SCAN_REQUIRED", "CARD_INSTALLMENT_SAME_PRICE_ONLY"):
    if name in os.environ:
        pass

if os.getenv("COOKIE_SECURE", "").strip().lower() != "true":
    fail.append("COOKIE_SECURE must be true")
if os.getenv("AI_SERVER_ONLY", "true").strip().lower() != "true":
    fail.append("AI_SERVER_ONLY must be true")
if os.getenv("AI_EXTERNAL_PROVIDER_ALLOWED", "false").strip().lower() != "false":
    fail.append("AI_EXTERNAL_PROVIDER_ALLOWED must be false by default")
if os.getenv("CARD_INSTALLMENT_SAME_PRICE_ONLY", "true").strip().lower() != "true":
    fail.append("CARD_INSTALLMENT_SAME_PRICE_ONLY must be true")
if os.getenv("MEDIA_SCAN_REQUIRED", "true").strip().lower() != "true":
    fail.append("MEDIA_SCAN_REQUIRED must be true")

for name in ("ALLOW_LOCAL_MOCK_PAYMENTS", "DOMAIN_VERIFICATION_MODE", "BILLING_PROVIDER"):
    if name == "ALLOW_LOCAL_MOCK_PAYMENTS" and os.getenv(name, "false").strip().lower() == "true":
        fail.append("ALLOW_LOCAL_MOCK_PAYMENTS must not be true")

ai_provider = os.getenv("AI_PROVIDER", "ollama").strip().lower()
if ai_provider != "ollama":
    fail.append("AI_PROVIDER must be ollama for zero-paid-API production policy")

if os.getenv("DATABASE_URL", "").lower().startswith("sqlite"):
    fail.append("SQLite is forbidden in production")

# Production callback and public URL safety.
public_base = os.getenv('PUBLIC_BASE_URL', '').strip()
if public_base and public_base.startswith('http://'):
    fail.append('PUBLIC_BASE_URL must use HTTPS in production')
google_redirect = os.getenv('GOOGLE_REDIRECT_URI', '').strip()
if google_redirect and ('localhost' in google_redirect or '127.0.0.1' in google_redirect or google_redirect.startswith('http://')):
    fail.append('GOOGLE_REDIRECT_URI must be a real HTTPS production callback')

# Production object storage and malware scanner must be configured.
for name in ('S3_BUCKET', 'S3_ACCESS_KEY_ID', 'S3_SECRET_ACCESS_KEY', 'CLAMAV_HOST'):
    req(name)

# Version consistency is a hard production requirement.
version_file = (ROOT / 'VERSION').read_text(encoding='utf-8').strip()
app_version = os.getenv('APP_VERSION', '').strip()
if app_version and app_version != version_file:
    fail.append(f'APP_VERSION {app_version!r} does not match VERSION {version_file!r}')

allowed_hosts = [x.strip() for x in os.getenv("ALLOWED_HOSTS", "").split(",") if x.strip()]
if not allowed_hosts or "*" in allowed_hosts:
    fail.append("ALLOWED_HOSTS must be a non-empty explicit allowlist")

forwarded = os.getenv("FORWARDED_ALLOW_IPS", "").strip()
if not forwarded or forwarded == "*":
    fail.append("FORWARDED_ALLOW_IPS must explicitly identify trusted proxies")

# Validate selected payment configuration without requiring every provider key.
provider = os.getenv("PAYMENT_PROVIDER", os.getenv("MERCHANT_PAYMENT_PROVIDER", "")).strip().lower()
if provider == "iyzico":
    req("IYZICO_API_KEY")
    req("IYZICO_SECRET_KEY")
elif provider == "paytr":
    req("PAYTR_MERCHANT_ID")
    req("PAYTR_MERCHANT_KEY")
    req("PAYTR_MERCHANT_SALT")
elif provider == "paddle":
    req("PADDLE_API_KEY")
    req("PADDLE_WEBHOOK_SECRET")

billing_provider = os.getenv("BILLING_PROVIDER", "paddle").strip().lower()
if billing_provider != "paddle":
    fail.append("BILLING_PROVIDER must be paddle in production")
else:
    req("PADDLE_API_KEY")
    req("PADDLE_WEBHOOK_SECRET")

kyc_provider = os.getenv("MERCHANT_KYC_PROVIDER", "veriff").strip().lower()
if os.getenv("REQUIRE_MERCHANT_IDENTITY", "true").strip().lower() == "true":
    if kyc_provider != "veriff":
        fail.append("MERCHANT_KYC_PROVIDER must be veriff in production")
    else:
        req("VERIFF_API_BASE_URL")
        req("VERIFF_API_KEY")
        req("VERIFF_SHARED_SECRET")

# Local .env is not a deployment secret store contract.
if (ROOT / ".env").exists() and os.getenv("ALLOW_DOTENV_IN_PRODUCTION", "false").lower() != "true":
    fail.append("Do not deploy a checked-in/local .env; use a secret manager")

if fail:
    print("PRODUCTION_PREFLIGHT_FAIL")
    for item in fail:
        print("-", item)
    raise SystemExit(1)

print("PRODUCTION_PREFLIGHT_PASS")
