from __future__ import annotations
import importlib.metadata as md
from pathlib import Path
import re, sys

ROOT=Path(__file__).resolve().parents[1]
req=(ROOT/'requirements.txt').read_text(encoding='utf-8')
expected={}
for line in req.splitlines():
    line=line.strip()
    if not line or line.startswith('#') or '==' not in line:
        continue
    name,ver=line.split('==',1)
    name=name.split('[',1)[0].strip().lower()
    expected[name]=ver.strip()

fail=[]
for name,ver in expected.items():
    try:
        actual=md.version(name)
    except md.PackageNotFoundError:
        fail.append(f'{name}: MISSING (expected {ver})')
        continue
    if actual != ver:
        fail.append(f'{name}: INSTALLED {actual} != PINNED {ver}')

if fail:
    print('ENVIRONMENT_AUDIT_FAIL')
    print('This gate is intentionally strict: tests are not release evidence when runtime dependencies drift from requirements.txt.')
    for x in fail: print('-',x)
    raise SystemExit(1)
print(f'ENVIRONMENT_AUDIT_PASS packages={len(expected)}')
