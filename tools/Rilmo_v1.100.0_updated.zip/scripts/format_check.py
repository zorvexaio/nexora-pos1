"""Formatting policy gate.

The project standard is Black + Ruff. This script intentionally fails closed when
those tools are unavailable instead of pretending that source formatting was verified.
"""
from __future__ import annotations
import shutil
import subprocess
import sys

def main() -> int:
    missing = [tool for tool in ('black', 'ruff') if shutil.which(tool) is None]
    if missing:
        print('FORMAT_TOOL_MISSING:' + ','.join(missing))
        return 2
    commands = [['black', '--check', '.'], ['ruff', 'check', '.']]
    for command in commands:
        result = subprocess.run(command, check=False)
        if result.returncode:
            return result.returncode
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
