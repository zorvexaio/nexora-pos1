# Rilmo — Unified Global Commerce

## v1.100.0 — Pricing Intelligence

Merchant-grade commerce platform focused on trustworthy economics, automation, and tenant isolation.

Pricing Intelligence exposes under-cost and below-target-margin alerts from immutable product cost data while keeping currencies separate.


## v1.99.9 — Customer Intelligence & Currency-Safe RFM

This is the current release. It merges the verified deep-hardening controls from v1.96.20 with the OAuth and storefront security closures from v1.97.x while preserving a single Alembic head.

The current release source of truth is `VERSION`; historical release notes below remain immutable traceability records.

## v1.97.0 — OAuth privilege revocation closure

- Re-authorizing an installed app with a changed scope set now revokes all previously issued access and refresh tokens for that installation before the new authorization is completed.
- Installation locking prevents concurrent authorization requests from racing while replacing the granted-scope set.
- Regression coverage proves that an old bearer token and refresh token cannot survive a scope reduction, while the newly issued token receives only the newly granted scope set.

## v1.96.9 — deep security closure
- Domain-purchase idempotency is tenant-scoped at both query and database-constraint layers.
- OAuth refresh tokens are client-bound to their application installation.

Closed a financial authorization bypass where `RESOLVE_REFUND` could invoke the canonical refund handler internally without enforcing the dedicated `orders.refund` permission. Added `assert_permission()` for safe route-to-route authorization. Staff roles remain denied; owner/admin roles remain allowed.

## v1.96.3 customer payment-order authorization closure

- Customer actors can now create a payment intent only for orders owned by the authenticated storefront customer.
- Added regression coverage for cross-customer payment-intent access and preserved same-customer payment flow.

## v1.96.3 — billing state-machine closure

## v1.96.3 — RLS closure and release-evidence hardening

- Closes PostgreSQL tenant RLS coverage for sensitive customer, merchant-trust, domain-commerce and buyer-protection tables.
- Binds customer session tenant context before session lookup.
- Keeps production readiness claims dependent on real PostgreSQL/provider evidence.

# Unified Global Commerce v1.96.3

## v1.95.0 — Security, reliability and route hardening

- Production and staging payment traffic uses only platform-controlled provider endpoints; merchant-supplied `base_url` is limited to test/development.
- Workflow webhook endpoint validation is fail-closed for malformed URLs, control characters, invalid ports, and non-global DNS answers.
- World Commerce analytics/catalog/experiment inputs are bounded and deterministic, with inactive variants excluded from agent-facing catalogs.
- Global readiness and public DSA routes are covered by regression tests, including runtime execution paths.

Current release: 1.100.0

# Unified Global Commerce v1.92.16

## v1.92.16 — Worker transaction-boundary hardening

- Webhook delivery is committed outside the outbox event transaction to prevent rollback-driven duplicate delivery.
- Monthly platform report creation tolerates concurrent unique-period races.

# Unified Global Commerce v1.92.16

## v1.92.16 — Public domain verification hardening

Public storefront, shipping, and product routes now require a verified custom domain. See `docs/RELEASE_NOTES_V1_92_1.md`.

# Unified Global Commerce v1.92.16

## v1.92.16 — Payment idempotency integrity hardening

- Payment operations now persist a canonical request hash.
- Reusing one `Idempotency-Key` with different payment parameters is rejected with `IDEMPOTENCY_REQUEST_MISMATCH`.
- Capture, refund, and void operations bind their idempotency key to the immutable payment parameters they operate on.
- Migration `20260821_0062` adds the request-hash column and index.
- Existing v1.90.2 security/payment hardening remains in force.

## v1.90.2 — Security and payment-callback hardening, environment locking and global product-safety metadata

- Release version is 1.90.2 and all current release-control surfaces resolve from `VERSION`.- Runtime dependency-lock gate verifies the exact versions declared by `requirements.txt` and `requirements-dev.txt` before a release can be certified.- CI Alembic head verification is aligned to migration `20260820_0060`.- Product digital passports now have explicit manufacturer/responsible-economic-operator and safety/recall fields for distance-sale compliance workflows.- AI disclosure metadata now distinguishes interactive AI responses from machine-readable synthetic-content marking requirements; provider-specific provenance/watermark evidence remains external.- A full-suite timeout is never converted into PASS; the evidence pipeline records `NOT VERIFIED` until the pinned environment completes the suite.

Rilmo / Unified Global Commerce is the current production-oriented commerce platform release. Historical release notes remain below for traceability; the current release source of truth is `VERSION` and the current production contract.

Production-oriented multi-tenant commerce platform with a premium responsive storefront, first-class customer accounts, Google/email passwordless sign-in, guest-to-account cart merge, smart search, secure checkout orchestration, payments, loyalty, marketing, apps/OAuth, analytics, support and security hardening.

See `docs/RELEASE_NOTES_V1_34_0.md`, `docs/DEEP_AUDIT_V1_32_0.md`, and `docs/RELEASE_NOTES_V1_33_0.md` for release history and security evidence.





## v1.90.2 — Payment-bound domain commerce and event-contract hardening

- UCP checkout completion now locks the checkout row for transactional concurrency control on databases that support row-level locks, preventing concurrent completion races.
- Added regression coverage for the lock contract.
- Full-suite verification remains explicitly separated from critical regression verification; timeouts are never reported as PASS.

## v1.79.0 — Production runtime closure

- Exact Alembic-head enforcement at production/staging startup and readiness; schema drift fails closed.
- Release manifest is generated from the current `VERSION` and is checked by the release-consistency gate.
- The current test tree statically collects 325 tests; clean batched execution covers all 326 tests, while the monolithic all-files invocation is intentionally not represented as a single-run PASS in this environment.

## v1.79.0 — Global release integrity + payment-safe UCP completion

- Release-control documents are aligned to the single `VERSION` source of truth.
- Alembic HEAD is reported from the actual repository head (`20260820_0058`), not a stale historical migration.
- Test inventory is reported from real pytest collection (326 tests); route counts are kept distinct from test counts.
- UCP checkout completion is fail-closed in staging/production: a checkout cannot become `COMPLETED` without an already captured, tenant-owned payment intent covering the checkout total.
- Local development may use the existing mock-payment path explicitly; production never treats a protocol callback alone as proof of payment.
- Release CI adds explicit collection-count and Alembic-head consistency checks.

## v1.71.0 — Global Governance & Fully Governed AI Entry Points

- AI is optional and fail-open to deterministic rules; commerce remains fully functional without any AI provider or API key.
- Tenant-scoped AI policy controls enablement, daily quota, customer/merchant agent access, and privacy boundary.
- Customer, merchant, and platform agents are separated by role and context. AI has no payment, refund, price-change, shipping-charge, inventory-write, KYC, or raw payment-data tools.
- Sensitive operations can only be proposed; execution requires a normal authenticated application flow with explicit confirmation and audit logging.
- Provider access is abstracted behind a server-side gateway; internal Ollama is the zero-paid-API default. External providers remain disabled by default.
- Per-tenant AI usage counters and backpressure provide deterministic spend/resource control.
- Every merchant AI entry point is now policy/quota-gated; customer search reranking uses the same customer-agent governance path.
- External models never receive internal database identifiers unless explicitly required by an approved internal-only workflow.
- Customer AI receives order tracking state only; payment amounts/status and raw financial fields are excluded from the model context.
- Read-only agent tool registry is deny-by-default and exposes no executable commerce mutation capability.

## v1.68.0 — Buyer Protection, Order Conversations & Refund Resolution

- Customer cancellation before merchant acceptance can void/refund through the configured payment provider using idempotency.
- Order issues now support an audited conversation between customer and merchant.
- Merchant `RESOLVE_REFUND` executes the canonical refund flow instead of changing status only.
- Customer-facing issue messages redact internal tenant/user identifiers.

## v1.66.0 — Shipping Trust & Customer-Visible Delivery

Merchants must configure at least one active shipping method before publication. Each method supports a selected carrier/service, normal shipping price, free-shipping toggle, free-shipping threshold, promotional label, and estimated delivery window. Customers see these choices before checkout, while checkout pricing remains server-authoritative. Merchants can change carriers later without rewriting historical orders; each order stores a shipping-method/carrier snapshot.

## v1.65.0 — Production Launch Pack
- Adds `scripts/production_preflight.py` as a fail-closed production deployment gate.
- Separates software PASS from external production evidence.
- Adds production launch runbook and external-evidence register.
- Keeps local Ollama as the zero-paid-API default and same-price card-installment policy.

## v1.61.0 — Global Launch Control Plane

This release adds an executable global readiness layer. It keeps country/jurisdiction readiness separate from software correctness and blocks a market from being marked READY until its legal, tax/invoicing, payment, data-transfer and app-distribution evidence is verified.

It also enforces a production AI default of internal Ollama with rules-only fallback, exposes an Apple/Google physical-vs-digital payment policy matrix, and makes Rilmo card-installment policy explicitly zero-price-delta.

External certifications, production provider approvals, penetration testing and jurisdiction-specific legal review remain external evidence by design.

## v1.58.0 — Global AI Safety + World Readiness

The current release extends Rilmo into a compliance-aware, agent-safe Commerce OS. It adds profile-driven Digital Product Passport interoperability metadata aligned to the 2026 EU DPP standards landscape, stable product identifiers for published passports, data-carrier metadata, and explicit external-registry lifecycle state. It also retains the agent transaction safety layer: spend limits, currency/country allowlists, scopes, idempotency and rate limiting.

The DPP layer is intentionally an internal interoperability abstraction: it does **not** claim EU Registry registration or legal certification. Official registry onboarding, conformance testing, legal review, production PostgreSQL/RLS evidence, external penetration testing and deployed load/failover evidence remain external gates.

Current local verification: **273 tests pass with `pytest -q -W error`**, migration `20260819_0050` passes upgrade/downgrade/re-upgrade, security/spec/schema/frontend/dependency/regulatory gates pass, and the live runtime gate passes on the full migration chain.

## v1.57.0 — Server-side AI hardening

Pinned Ollama runtime, bounded AI concurrency, deterministic fallback, and server-only AI context isolation.

## v1.49.0 — World Commerce Layer

Rilmo v1.49 extends the hardened multi-tenant commerce core into a broader Commerce OS layer. It adds B2B catalog/pricing primitives, POS foundations, deterministic experiments, executive analytics, AI discoverability, machine-readable product feeds and UCP-compatible agentic commerce endpoints.

### World-class capability set
- B2B companies, contacts, catalogs, assignments and quantity-aware pricing.
- POS locations/registers/sessions and idempotent inventory-linked sales.
- Experiment rollouts with deterministic visitor assignment.
- AI discoverability scoring and product feeds for machine/AI channels.
- UCP-compatible merchant discovery and checkout foundation using the 2026-04-08 protocol reference.
- Database-level RLS for all new tenant-scoped World Commerce tables.

The World Commerce layer is additive: existing security, privacy, payments, webhooks, RLS, KYC and release-gate controls remain part of the same platform. Production provider certification, live PostgreSQL/RLS evidence, external pentesting, load/SLO validation and jurisdiction-specific legal reviews remain deployment gates rather than claims made by the source tree.

## v1.34 Trust, Domain & Premium Commerce
- Merchant identity onboarding with real profile, phone verification and mandatory Google linkage.
- Platform Trust Center with abuse reports, moderation, verified-store scoring and suspend/restore actions.
- Verified customer store reviews with purchase proof and moderation.
- $10/year domain purchase preparation with authoritative availability checks and post-payment registrar fulfillment.
- Dynamic trusted-host routing for verified custom domains, including `/`, `/product/*`, robots and sitemap.
- Public plan/pricing presentation and platform-admin controls guarded by MFA.
- No production secrets are stored in source; external provider credentials remain environment/secret-manager configuration.

# Unified Global Commerce Platform — v1.31.0

Global multi-tenant commerce platform foundation, Turkey-first regional payment/tax/shipping expansion, financial kernel, security controls, operations, themes, loyalty, automation and app-platform foundations.

## v1.31.0 — Deep Hardening & Production Safety

v1.31.0 is a security and reliability pass over the v1.30 growth layer. It adds bounded request bodies, cost-sensitive AI rate limiting, public analytics/affiliate throttling, mandatory WhatsApp webhook signing secrets, CSP-safe storefront host injection, permission enforcement for AI/WhatsApp/Landing/Affiliate features, structured AI outputs for each use case, upload-validation error normalization, webhook provider-message deduplication, and dependency refreshes for Pydantic, email-validator and cryptography.

The release was validated with 168 automated tests, clean SQLite migration round-trip, frontend/CSP audit, source-format audit, dependency-pin audit and Python compilation.

## What changed in v1.30.0 — Growth + AI + Commerce OS

v1.30.0 builds directly on the verified v1.20.0 SaaS architecture and closes the main post-staging product gaps identified against modern SaaS commerce platforms. The implementation is code-complete for the new product layer; external provider credentials, marketplace approvals and deployed staging evidence remain environment gates rather than missing source-code features.

- **AI product studio:** structured product-copy generation, SEO copy, multilingual output, merchant-context prompts, generation history and safe local fallback. OpenAI integration uses the current Responses API contract; the supplied development default is `gpt-5.6`, configurable via environment.
- **AI merchant assistant:** catalog-grounded answers with recommended product IDs and safe fallback behavior.
- **Intent-aware storefront search:** deterministic lexical scoring plus optional AI reranking for natural-language queries such as gift intent; no external AI key is required for the fallback path.
- **Live commerce analytics:** hashed visitor events, active visitors, event counters and an admin live view.
- **WhatsApp Commerce:** encrypted tenant channel configuration, webhook verification/signature validation, outbound/inbound message logging, order notifications and opt-in abandoned-cart messaging. Production mode requires approved WhatsApp templates for business-initiated messages.
- **Campaign landing pages:** tenant-scoped CMS records, SEO fields, publish lifecycle and a safe server-rendered campaign route.
- **Affiliate engine:** programs, partners, click attribution, conversion attribution, commissions and payout balances.
- **Support operations:** audited, read-only merchant impersonation sessions with server-side mutation blocking.
- **Platform intelligence:** monthly platform report generation and email delivery for platform admins.
- **Modern frontend:** responsive merchant console, mobile-first storefront, AI/Growth/Operations navigation, PWA/offline shell and CSP-safe UI.
- **Production hardening:** migration contract, session impersonation fields, webhook security, template-only WhatsApp production guard and new route inventory all included in the release.



## What changed in v1.20.0

This release establishes the **SaaS billing architecture** on top of the v1.19.2 local-runtime baseline. The repository now provides a complete path from a fresh checkout to a populated, browsable demo store and a local payment capture flow.

- Runtime ORM: SQLAlchemy + Alembic.
- `prisma/schema.prisma` is a documentation/schema mirror only; it is not the runtime ORM.
- Primary database target: PostgreSQL 18.6.
- Local runtime: Docker Compose with PostgreSQL + Redis; object storage uses the existing safe local filesystem adapter in development.
- Local email: development mail sink at `.local/mail.outbox.log` instead of requiring SMTP credentials.
- Local payments: explicit `ALLOW_LOCAL_MOCK_PAYMENTS=true` enables the mock provider **only in `development`**. Automated tests remain supported through `ENVIRONMENT=test`.
- Demo data: `scripts/seed_demo.py` creates a merchant, storefront, verified local domain, products, translations and inventory.
- Storefront HTML now injects its canonical host so `/store/demo.localhost` works even when the browser itself is on `localhost`.
- Local smoke test covers health, readiness, public storefront, guest cart, checkout, payment intent and mock capture.

## Quick Start — zero to browser

### Prerequisites

- Docker Desktop / Docker Engine with Compose v2.
- Git.
- No Stripe, Tabby, Tamara, SMTP, S3/R2 or real payment-provider credentials are required for the local developer path.

### 1. Copy local environment

```bash
cp .env.example .env
```

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

The supplied development values are intentionally non-production. Do **not** reuse them in staging or production.

### 2. Build and start

```bash
docker compose up -d --build
```

Check status:

```bash
docker compose ps
```

API health:

```text
http://localhost:8000/v1/health
```

API documentation:

```text
http://localhost:8000/docs
```

### 3. Seed the demo merchant

```bash
docker compose exec api python scripts/seed_demo.py
```

The deterministic demo credentials are:

```text
Email:    merchant@example.test
Password: ChangeMe123!
```

### 4. Open the merchant dashboard

```text
http://localhost:8000/
```

Login using the demo account above.

### 5. Open the public storefront

```text
http://localhost:8000/store/demo.localhost
```

The storefront includes published demo products and a working local cart/checkout flow. Merchant checkout is provider-owned by iyzico/PayTR; SaaS subscription billing is provider-neutral with Paddle MoR as the production target and mock billing locally.

### 6. Run the end-to-end local smoke test

From the host:

```bash
python scripts/local_runtime_smoke.py
```

Or from the API container:

```bash
docker compose exec api python scripts/local_runtime_smoke.py
```

Expected result:

```text
LOCAL_RUNTIME_SMOKE_PASS
```

The smoke test proves the local runtime contract, but it is **not** evidence of production provider certification, PostgreSQL RLS deployment, real payment settlement, or production infrastructure readiness.

## Local runtime architecture

```text
Browser
  |
  v
FastAPI :8000
  |---- PostgreSQL :5432
  |---- Redis :6379
  |---- local media_store/
  |---- .local/mail.outbox.log
  `---- mock payment provider (development flag only)
```

### Local storage and email

Development intentionally does not require S3/R2 or SMTP credentials.

- Uploaded media goes through the existing path-safe local object-store adapter.
- Non-production email is written to `.local/mail.outbox.log` so password-reset and notification flows remain observable without an external mail account.

### Mock payments security boundary

The mock provider is disabled by default everywhere except tests and explicitly enabled local development.

```text
ENVIRONMENT=test                             -> allowed
ENVIRONMENT=development + ALLOW_LOCAL_MOCK_PAYMENTS=true -> allowed
ENVIRONMENT=staging                          -> forbidden
ENVIRONMENT=production                       -> forbidden
```

Production validation still requires real secrets, real object storage, real transactional email, real payment credentials and the remaining external release gates.

## v1.20.0 SaaS architecture

The platform no longer operates as a marketplace and does not collect a percentage of merchant sales.

```text
Platform
  └── SaaS subscription → Paddle (Merchant of Record for production)

Merchant Store
  └── Customer payment → merchant-owned iyzico / PayTR account

Merchant discounts
  └── ProductDiscount → tenant-scoped product price reduction

Platform billing discounts
  └── PlatformBillingDiscount → SaaS plan subscription only
```

Tabby, Tamara and Stripe Connect are removed from the active payment architecture. Stripe Billing remains only as a future provider-adapter option, not as a Turkey default.

Plans: **Starter $12**, **Growth $30**, **Scale $100** per month. Plan entitlements are evaluated separately from RBAC permissions: a user must have the required permission and the tenant must have the required entitlement.

See `docs/V1_20_SAAS_MIGRATION_ARCHITECTURE.md` for the canonical architecture, migration invariants, rollback plan and Definition of Done.

## Common commands

```bash
make up
make seed
make smoke
make test
make logs
make down
make reset
```

Without `make`:

```bash
docker compose up -d --build
docker compose exec api python scripts/seed_demo.py
python scripts/local_runtime_smoke.py
pytest -q -W error
docker compose down
```

## Troubleshooting

### Port 5432 is already used

Edit `.env` and change the host-side port mapping only if necessary, or stop the local PostgreSQL service that owns port 5432. The container still listens on 5432 internally.

### Port 8000 is already used

Stop the conflicting process or change the Compose host mapping from `127.0.0.1:8000:8000` to another local port and update `PUBLIC_BASE_URL`, `CORS_ORIGINS`, and `TRUSTED_ORIGINS` consistently.

### The demo store is empty

Run the seed command again:

```bash
docker compose exec api python scripts/seed_demo.py
```

The seed is designed to be repeatable and will not intentionally duplicate the deterministic demo records.

### I changed database schema and migrations fail

Inspect:

```bash
docker compose logs migrate
docker compose exec api alembic current
docker compose exec api alembic history
```

Do not delete production databases to solve migration problems.

## Verification

Run:

```bash
pytest -q -W error
alembic upgrade head
python scripts/final_release_audit.py
python scripts/release_hygiene.py
```

The release evidence is in `IMPLEMENTATION_STATUS.md` and `docs/V1_30_GROWTH_ARCHITECTURE.md`, `docs/V1_20_SAAS_MIGRATION_ARCHITECTURE.md` and `docs/V1_20_SAAS_RBAC_ENTITLEMENT_MATRIX.md`. The v1.19.2 local-runtime baseline remains documented in `docs/LOCAL_DEVELOPER_RUNTIME_V1_19_2.md`.

## Production rule

No local mock provider is a substitute for real staging evidence. Production remains gated on real PostgreSQL/RLS verification, Redis/object-storage operation, real payment-provider sandbox/certification, backup/restore rehearsal, security testing, load testing, legal/compliance work and all external release evidence.

## v1.32 security requirements

Production deployments require a dedicated `ENCRYPTION_KEY` separate from `SECRET_KEY`. MFA-enabled accounts must complete TOTP verification before a browser/API session is issued. Production also requires explicit CORS/host allowlists and an HTTPS `PUBLIC_BASE_URL`.


## Local runtime smoke contract (v1.49.0)

`scripts/local_runtime_smoke.py` waits for `/v1/health` readiness, verifies the storefront host metadata contract (`meta[name=store-host]`), then exercises guest cart → checkout → mock payment intent → capture. A failure to start the server now fails explicitly instead of producing a misleading downstream assertion.

## v1.36.4 hardening
- App webhook delivery has an independent delivery ledger with per-subscription/event idempotency and retry state.
- Production app-webhook destinations use an exact host allowlist via `APP_WEBHOOK_ALLOWED_HOSTS` to reduce SSRF/DNS-rebinding exposure.
- Concurrent duplicate idempotency operations return `409 IDEMPOTENCY_IN_PROGRESS` instead of executing twice.


## Merchant Identity & Trust Security (v1.36.4)

Merchant activation uses an external identity-verification provider rather than a platform-admin identity override. The current production adapter is Veriff. Identity sessions are provider-hosted; Rilmo stores verification identifiers, status, timestamps and minimized metadata, not raw ID/selfie media. Provider decisions arrive through HMAC-authenticated webhooks and are processed idempotently.

Risk controls include merchant risk events, configurable thresholds, compliance review cases, payout holds, merchant freeze/unfreeze and forced re-verification. Publishing/financial activation remains blocked while KYC is unresolved, the merchant is under review, or a high-risk payout hold is active.

Set `MERCHANT_KYC_PROVIDER=veriff` and configure `VERIFF_API_BASE_URL`, `VERIFF_API_KEY` and `VERIFF_SHARED_SECRET` for real staging/production. Do not use the mock provider outside non-production test environments.

## v1.50 Platform Ecosystem

Rilmo now exposes a first-class platform layer in addition to commerce features:

- Public App Marketplace catalog and verified merchant reviews.
- Workflow execution with durable per-step state.
- Versioned Commerce Event schemas as a stable developer contract.
- Tenant isolation and least-privilege controls inherited by platform tables.

The public marketplace UI is served at `/app/frontend/marketplace.html` and reads only the public catalog contract; OAuth client secrets and access tokens are never returned by that endpoint.


## v1.58.0 — Server-side AI hardening

- Private server-side Ollama AI, pinned production image, and per-process concurrency backpressure.
- No public Ollama port in production.
- Deterministic zero-API-cost fallback remains available.

## v1.56.0 — Server-side free AI storefront assistant
The storefront now exposes a tenant-scoped customer assistant backed by an internal Ollama service by default. No customer request requires a paid external model API; the inference workload runs inside the deployment network. Qwen3.5 9B is the default model and can be changed with `AI_MODEL`. The assistant has no order/payment mutation tools and only receives public catalog data plus minimal authenticated-customer order summaries.


## AI deployment posture

AI is optional and production defaults are fail-closed. Set `AI_ENABLED=true` only when AI is explicitly desired. The Ollama/model-init services are behind the Compose `ai` profile; enable them with `docker compose --profile ai up` or the equivalent deployment mechanism. No external paid AI provider is required.

## Global readiness boundary — v1.90.2

The platform is engineered for international multi-tenant commerce and uses fail-closed market controls. “Global 100%” is not asserted merely because code-level gates pass: each launch market must have verified legal/tax/e-invoicing, payment, data-transfer, accessibility, consumer-product-safety and operational evidence. Unknown jurisdictions remain blocked until an approved market profile exists.

Security verification is mapped to OWASP ASVS 5.0.0 engineering controls; payment scope is minimized by provider-hosted/tokenized payment flows and must still be assessed against PCI DSS v4.0.1 with the applicable acquirer/QSA. EU AI Act Article 50 transparency workflows are represented as machine-readable engineering metadata, while actual provider provenance/watermark evidence and legal review remain deployment evidence.

## v1.92.16 — External I/O reconciliation hardening
- Commits webhook delivery PROCESSING state before network I/O.
- Adds stale-processing recovery to `RECONCILIATION_REQUIRED`.
- Prevents domain registrar hostname fallback from becoming a provider reference.
- Adds webhook processing timestamp migration `20260822_0064`.

### v1.96.3 release-control closure
- Test shard runner now terminates timed-out pytest process groups deterministically.
- Isolated test runner uses process-group-aware execution to prevent orphaned pytest workers.
- Release version synchronized to 1.96.2.

## v1.97.1 — storefront variant-selection closure
The storefront product-detail experience now supports real variant selection: selecting a variant updates the active state, accessible `aria-pressed` state, Add-to-Cart variant ID and displayed price. This closes a user-visible commerce defect where the first variant was always added regardless of the customer's selection.
