import sys
import types
import uuid
from urllib.parse import parse_qs, urlparse


def _google_settings(monkeypatch):
    from app.core.config import get_settings
    s = get_settings()
    monkeypatch.setattr(s, 'GOOGLE_CLIENT_ID', 'client-id')
    monkeypatch.setattr(s, 'GOOGLE_CLIENT_SECRET', 'client-secret')
    monkeypatch.setattr(s, 'GOOGLE_REDIRECT_URI', 'http://localhost:8000/v1/auth/google/callback')
    monkeypatch.setattr(s, 'GOOGLE_JWKS_URL', 'https://example.test/jwks')
    monkeypatch.setattr(s, 'GOOGLE_ISSUERS', 'https://accounts.google.com,accounts.google.com')
    return s


def _install_fake_jwt(monkeypatch, nonce, subject='google-sub', email='oauth-existing@example.com', verified=True):
    class Key:
        key = 'public-key'

    class Client:
        def __init__(self, url):
            self.url = url

        def get_signing_key_from_jwt(self, token):
            assert token == 'id-token'
            return Key()

    fake = types.SimpleNamespace(
        PyJWKClient=Client,
        decode=lambda token, key, algorithms, audience, issuer: {
            'sub': subject,
            'nonce': nonce,
            'email': email,
            'email_verified': verified,
            'iss': 'https://accounts.google.com',
            'aud': audience,
        },
    )
    monkeypatch.setitem(sys.modules, 'jwt', fake)


class FakeResponse:
    def __init__(self, status_code=200, payload=None):
        self.status_code = status_code
        self._payload = payload or {}

    def json(self):
        return self._payload


def _mock_google_http(monkeypatch, subject='google-sub', email='oauth-existing@example.com', verified=True):
    import app.routes.auth_google_routes as routes  # google oauth moved here in Phase 3 split
    calls = []

    def post(url, **kwargs):
        calls.append(('post', url, kwargs))
        return FakeResponse(200, {'access_token': 'access-token', 'id_token': 'id-token'})

    def get(url, **kwargs):
        calls.append(('get', url, kwargs))
        return FakeResponse(200, {'sub': subject, 'email': email, 'email_verified': verified, 'name': 'OAuth User'})

    monkeypatch.setattr(routes.httpx, 'post', post)
    monkeypatch.setattr(routes.httpx, 'get', get)
    return calls


def _start(client, monkeypatch):
    _google_settings(monkeypatch)
    r = client.get('/v1/auth/google/start')
    assert r.status_code == 200
    query = parse_qs(urlparse(r.json()['authorization_url']).query)
    return query['state'][0], query['nonce'][0]


def test_google_oauth_full_success_creates_identity_and_session(client, monkeypatch):
    state, nonce = _start(client, monkeypatch)
    email = f'oauth-{uuid.uuid4().hex[:10]}@example.com'
    subject = f'google-{uuid.uuid4().hex[:10]}'
    _mock_google_http(monkeypatch, subject=subject, email=email)
    _install_fake_jwt(monkeypatch, nonce, subject=subject, email=email)

    r = client.get('/v1/auth/google/callback', params={'code': 'auth-code', 'state': state})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['ok'] is True
    assert body['user']['email'] == email
    assert 'access_token' in body
    assert 'session=' in r.headers.get('set-cookie', '')


def test_google_oauth_invalid_nonce_is_client_error_and_state_remains_unused(client, monkeypatch):
    state, nonce = _start(client, monkeypatch)
    _mock_google_http(monkeypatch)
    _install_fake_jwt(monkeypatch, nonce)

    client.cookies.set('oauth_nonce', 'wrong-cookie-nonce')
    r = client.get('/v1/auth/google/callback', params={'code': 'auth-code', 'state': state})
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'OAUTH_NONCE_INVALID'

    # A second callback must still be rejected as invalid nonce, not become a successful replay.
    r2 = client.get('/v1/auth/google/callback', params={'code': 'auth-code', 'state': state})
    assert r2.status_code == 400
    assert r2.json()['detail']['error']['code'] == 'OAUTH_NONCE_INVALID'


def test_google_oauth_token_exchange_failure_is_gateway_error(client, monkeypatch):
    state, _ = _start(client, monkeypatch)
    import app.routes.auth_google_routes as routes  # google oauth moved here in Phase 3 split
    monkeypatch.setattr(routes.httpx, 'post', lambda *a, **k: FakeResponse(400, {'error': 'invalid_grant'}))
    r = client.get('/v1/auth/google/callback', params={'code': 'bad', 'state': state})
    assert r.status_code == 502
    assert r.json()['detail']['error']['code'] == 'GOOGLE_OAUTH_FAILED'


def test_google_oauth_existing_email_requires_explicit_link(client, monkeypatch):
    email = f'oauth-existing-{uuid.uuid4().hex[:10]}@example.com'
    reg = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'})
    assert reg.status_code == 200, reg.text
    state, nonce = _start(client, monkeypatch)
    subject = f'google-existing-{uuid.uuid4().hex[:10]}'
    _mock_google_http(monkeypatch, subject=subject, email=email)
    _install_fake_jwt(monkeypatch, nonce, subject=subject, email=email)
    r = client.get('/v1/auth/google/callback', params={'code': 'auth-code', 'state': state})
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'ACCOUNT_LINK_REQUIRED'


def test_google_oauth_replay_after_success_is_rejected(client, monkeypatch):
    state, nonce = _start(client, monkeypatch)
    _mock_google_http(monkeypatch)
    _install_fake_jwt(monkeypatch, nonce)
    r = client.get('/v1/auth/google/callback', params={'code': 'auth-code', 'state': state})
    assert r.status_code == 200
    # Use a fresh client without the deleted cookies but reuse the state: DB used_at must stop replay.
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as fresh:
        fresh.cookies.set('oauth_state', state)
        fresh.cookies.set('oauth_nonce', nonce)
        r2 = fresh.get('/v1/auth/google/callback', params={'code': 'auth-code', 'state': state})
    assert r2.status_code == 400
    assert r2.json()['detail']['error']['code'] == 'OAUTH_STATE_EXPIRED'

def test_onboarding_payment_step_requires_active_enabled_account(client, monkeypatch):
    reg = client.post('/v1/auth/register', json={'email': f'onboard-{uuid.uuid4().hex[:10]}@example.com', 'password': 'VerySecurePassword123!'})
    assert reg.status_code == 200, reg.text
    token = reg.json()['access_token']
    tid = reg.json()['tenant']['id']
    headers = {'Authorization': f'Bearer {token}'}
    # Merely having a payment-account row is insufficient: provider verification must enable charges+payouts.
    r = client.post('/v1/merchant/payment-account/configure?tenant_id=' + tid, headers=headers,
                    json={'provider': 'iyzico', 'credentials': {'api_key': 'k', 'secret_key': 's'}})
    assert r.status_code == 200, r.text
    status = client.get('/v1/onboarding/status', params={'tenant_id': tid}, headers=headers)
    assert status.status_code == 200
    assert 'payment_account' in status.json()['blockers']
