from types import SimpleNamespace
from unittest.mock import MagicMock
import pytest

import app.routes.v1 as v1
from app.models import OAuthState
from app.core.errors import AppError


def test_amount_minor_rounding_and_numeric_inputs():
    import app.routes.webhook_routes as wh  # _amount_minor moved here in Phase 3 split
    assert wh._amount_minor('10.005') == 1001
    assert wh._amount_minor(10) == 1000
    assert wh._amount_minor('0.01') == 1


def test_shipping_offer_validation_all_branches():
    base = dict(carrier_code='platform', free_shipping=False, free_shipping_threshold_minor=None,
                estimated_days_min=2, estimated_days_max=4)
    assert v1._validate_shipping_offer(SimpleNamespace(**base)) == 'platform'
    with pytest.raises(AppError) as exc:
        v1._validate_shipping_offer(SimpleNamespace(**{**base, 'carrier_code':'unknown'}))
    assert exc.value.code == 'SHIPPING_CARRIER_UNSUPPORTED'
    with pytest.raises(AppError) as exc:
        v1._validate_shipping_offer(SimpleNamespace(**{**base, 'free_shipping_threshold_minor':100}))
    assert exc.value.code == 'FREE_SHIPPING_THRESHOLD_REQUIRES_FREE_SHIPPING'
    with pytest.raises(AppError) as exc:
        v1._validate_shipping_offer(SimpleNamespace(**{**base, 'estimated_days_min':5, 'estimated_days_max':2}))
    assert exc.value.code == 'SHIPPING_ESTIMATE_INVALID'


def test_shipping_public_view_free_and_paid():
    method = SimpleNamespace(id='m1', name='Std', carrier_code='platform', service_code='std',
        currency='TRY', amount_minor=2500, free_shipping=True, free_shipping_threshold_minor=5000,
        offer_label='Standard', estimated_days_min=2, estimated_days_max=4, is_active=True)
    paid = v1._shipping_public_view(method, 4999)
    free = v1._shipping_public_view(method, 5000)
    assert paid['amount_minor'] == 2500 and paid['free_shipping'] is False
    assert free['amount_minor'] == 0 and free['free_shipping'] is True


def test_oauth_redirect_uri_and_unsupported_provider(monkeypatch):
    # _oauth_redirect_uri moved to auth_google_routes.py in Phase 3 split
    import app.routes.auth_google_routes as goauth
    monkeypatch.setattr(goauth, 'get_settings', lambda: SimpleNamespace(GOOGLE_REDIRECT_URI='https://example.test/oauth'))
    assert goauth._oauth_redirect_uri('google') == 'https://example.test/oauth'
    with pytest.raises(AppError) as exc:
        goauth._oauth_redirect_uri('evil')
    assert exc.value.code == 'OAUTH_PROVIDER_UNSUPPORTED'


def test_consume_oauth_state_success_and_replay():
    # _consume_oauth_state moved to auth_google_routes.py in Phase 3 split
    import app.routes.auth_google_routes as goauth
    db = MagicMock()
    db.execute.return_value.rowcount = 1
    goauth._consume_oauth_state(db, OAuthState, 'state-1', 'now')
    db.execute.assert_called_once()
    db.execute.return_value.rowcount = 0
    with pytest.raises(AppError) as exc:
        goauth._consume_oauth_state(db, OAuthState, 'state-1', 'now')
    assert exc.value.code == 'OAUTH_STATE_REPLAY'


def test_tenant_membership_delegates(monkeypatch):
    sentinel = object()
    monkeypatch.setattr(v1, 'bind_tenant_context', lambda tenant_id, user, db: sentinel)
    assert v1._tenant_membership_or_403('t1', object(), object()) is sentinel


def test_merchant_profile_complete_individual_and_business():
    assert not v1._merchant_profile_complete(None)
    base = dict(legal_name='A', phone='1', country_code='TR', city='Konya', address_line1='x',
                business_type='individual', tax_id=None, registration_number=None,
                business_registry_country=None, beneficial_owner_name=None, beneficial_owner_country=None)
    assert v1._merchant_profile_complete(SimpleNamespace(**base)) is True
    assert v1._merchant_profile_complete(SimpleNamespace(**{**base, 'beneficial_owner_name':'A'}))
    business = {**base, 'business_type':'company', 'tax_id':'T', 'registration_number':'R',
                'business_registry_country':'TR', 'beneficial_owner_name':'A', 'beneficial_owner_country':'TR'}
    assert v1._merchant_profile_complete(SimpleNamespace(**business))
    assert not v1._merchant_profile_complete(SimpleNamespace(**{**business, 'tax_id':None}))


def test_merchant_business_verification_complete():
    assert not v1._merchant_business_verification_complete(None)
    assert not v1._merchant_business_verification_complete(SimpleNamespace(kyb_status='PENDING', kyb_verified_at=None, kyb_evidence_hash=None))
    assert v1._merchant_business_verification_complete(SimpleNamespace(kyb_status='VERIFIED', kyb_verified_at='now', kyb_evidence_hash='h'))


def test_merchant_payment_ready_queries_active_account():
    db = MagicMock()
    db.query.return_value.filter_by.return_value.first.return_value = object()
    assert v1._merchant_payment_ready(db, 't1') is True
    db.query.return_value.filter_by.return_value.first.return_value = None
    assert v1._merchant_payment_ready(db, 't1') is False


def test_google_verified_queries_verified_identity():
    db = MagicMock()
    db.query.return_value.filter_by.return_value.filter.return_value.first.return_value = object()
    assert v1._google_verified(db, 'u1') is True
    db.query.return_value.filter_by.return_value.filter.return_value.first.return_value = None
    assert v1._google_verified(db, 'u1') is False
