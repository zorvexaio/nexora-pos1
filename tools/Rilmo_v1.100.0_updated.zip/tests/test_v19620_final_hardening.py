import hashlib
import hmac
import json

from tests.test_p0 import register


def _auth(x):
    return {'Authorization': f"Bearer {x['access_token']}"}


def test_oauth_token_endpoint_is_rate_limited(monkeypatch, client):
    from app.core.database import SessionLocal
    from app.core.security import token_hash
    from app.models.domain import AppDefinition
    from app.routes import oauth_routes as v1  # oauth/token moved here in Phase 3 split

    register(client, 'oauth-rate-limit-v19620@example.com')
    db = SessionLocal()
    try:
        db.add(AppDefinition(
            name='Rate Limited OAuth App', slug='oauth-rate-limit-v19620',
            client_id='oauth-rate-limit-client-v19620',
            client_secret_hash=token_hash('wrong-secret'),
            redirect_uris=['https://example.com/cb'], scopes=['store.read'],
            status='APPROVED'))
        db.commit()
    finally:
        db.close()

    calls = []
    monkeypatch.setattr(v1, 'enforce_rate_limit', lambda db, key, limit, window_seconds=60: calls.append((key, limit, window_seconds)))
    r = client.post('/v1/oauth/token', data={
        'grant_type': 'authorization_code',
        'client_id': 'oauth-rate-limit-client-v19620',
        'client_secret': 'wrong-secret-actually',
    })
    assert r.status_code == 401
    assert len(calls) == 2
    assert calls[0][0].startswith('oauth:token:ip:')
    assert calls[1][0].startswith('oauth:token:client:')
    assert all(call[1] == 30 for call in calls)


def test_whatsapp_webhook_is_bounded_and_idempotent(client):
    from app.core.database import SessionLocal
    from app.core.security import encrypt_secret, token_hash
    from app.models.domain import WhatsAppChannel, WhatsAppMessage

    x = register(client, 'whatsapp-webhook-v19620@example.com')
    tid = x['tenant']['id']
    secret = 'webhook-secret-v19620'
    db = SessionLocal()
    try:
        db.add(WhatsAppChannel(
            tenant_id=tid,
            phone_number_id='123456',
            access_token_encrypted=encrypt_secret('access-token-v19620'),
            app_secret_encrypted=encrypt_secret(secret),
            verify_token_hash=token_hash('verify-token-v19620'),
            status='ACTIVE'))
        db.commit()
    finally:
        db.close()

    payload = {'entry': [{'changes': [{'value': {'messages': [{
        'id': 'wamid.v19620.1', 'from': '905551112233',
        'type': 'text', 'text': {'body': 'hello'}}]}}]}]}
    raw = json.dumps(payload, separators=(',', ':')).encode()
    signature = 'sha256=' + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    headers = {'X-Hub-Signature-256': signature}

    first = client.post(f'/v1/whatsapp/webhook/{tid}', content=raw, headers=headers)
    second = client.post(f'/v1/whatsapp/webhook/{tid}', content=raw, headers=headers)
    assert first.status_code == 200
    assert second.status_code == 200

    db = SessionLocal()
    try:
        rows = db.query(WhatsAppMessage).filter_by(
            tenant_id=tid, provider_message_id='wamid.v19620.1').all()
        assert len(rows) == 1
    finally:
        db.close()


def test_whatsapp_webhook_rejects_oversized_payload_before_processing(client):
    from app.core.database import SessionLocal
    from app.core.security import encrypt_secret, token_hash
    from app.models.domain import WhatsAppChannel

    x = register(client, 'whatsapp-size-v19620@example.com')
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        db.add(WhatsAppChannel(
            tenant_id=tid,
            phone_number_id='123456',
            access_token_encrypted=encrypt_secret('access-token-v19620'),
            app_secret_encrypted=encrypt_secret('webhook-secret-v19620'),
            verify_token_hash=token_hash('verify-token-v19620'),
            status='ACTIVE'))
        db.commit()
    finally:
        db.close()

    oversized = b'x' * (2 * 1024 * 1024)
    r = client.post(f'/v1/whatsapp/webhook/{tid}', content=oversized,
                    headers={'Content-Length': str(len(oversized))})
    assert r.status_code == 413
