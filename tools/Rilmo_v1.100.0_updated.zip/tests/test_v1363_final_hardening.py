from datetime import datetime, timezone


def test_idempotency_fresh_then_concurrent_conflict(client):
    from app.core.database import SessionLocal
    from app.services.core import idem, body_hash
    from app.models.domain import Tenant
    x = client.post('/v1/auth/register', json={'email': 'idem-v1363@example.com', 'password': 'VerySecurePassword123!'}).json()
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        key = 'same-operation'
        first, _ = idem(db, tid, None, 'TEST', key, body_hash({'a': 1}))
        assert first.status == 'IN_PROGRESS'
        assert getattr(first, '_idempotency_fresh', False) is True
        second, _ = idem(db, tid, None, 'TEST', key, body_hash({'a': 1}))
        assert second.status == 'IN_PROGRESS'
        assert getattr(second, '_idempotency_fresh', False) is False
        assert second.id == first.id
    finally:
        db.rollback()
        db.close()


def test_webhook_delivery_isolated_from_event(client, monkeypatch):
    from app.core.database import SessionLocal
    from app.core.security import encrypt_secret
    from app.models.domain import Tenant, AppWebhookSubscription, AppWebhookDelivery, OutboxEvent
    from app.services import app_webhooks

    x = client.post('/v1/auth/register', json={'email': 'webhook-v1363@example.com', 'password': 'VerySecurePassword123!'}).json()
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        from app.models.domain import AppDefinition, AppInstallation
        definition = AppDefinition(name='Test App', slug='test-app-v1363', client_id='client-v1363', client_secret_hash='hash', redirect_uris=[], scopes=['webhooks'])
        db.add(definition); db.flush()
        inst = AppInstallation(tenant_id=tid, app_id=definition.id, granted_scopes=['webhooks'], access_token_hash='token-hash-v1363', status='ACTIVE')
        db.add(inst); db.flush()
        sub = AppWebhookSubscription(tenant_id=tid, installation_id=inst.id, event_type='order.created',
            endpoint_url='https://hooks.example.com/events', secret_hash='x',
            secret_encrypted=encrypt_secret('delivery-secret'), status='ACTIVE')
        db.add(sub)
        db.flush()
        event = OutboxEvent(tenant_id=tid, aggregate_type='order', aggregate_id='order-1',
            event_type='order.created', schema_version=1, payload={'tenant_id': tid},
            occurred_at=datetime.now(timezone.utc), status='PENDING')
        db.add(event)
        db.flush()
        monkeypatch.setattr(app_webhooks, '_public_https', lambda url: True)
        assert app_webhooks.deliver_event(db, event) is True
        db.commit()
        rows = db.query(AppWebhookDelivery).filter_by(subscription_id=sub.id, event_id=event.id).all()
        assert len(rows) == 1
        assert rows[0].status == 'PENDING'
        app_webhooks.deliver_event(db, event)
        db.commit()
        rows = db.query(AppWebhookDelivery).filter_by(subscription_id=sub.id, event_id=event.id).all()
        assert len(rows) == 1
    finally:
        db.close()
