from types import SimpleNamespace
from datetime import datetime, timezone, timedelta
import pytest

class Q:
    def __init__(self, value=None): self.value=value; self.updated=[]
    def filter(self,*a,**k): return self
    def filter_by(self,*a,**k): return self
    def order_by(self,*a,**k): return self
    def limit(self,*a,**k): return self
    def with_for_update(self,*a,**k): return self
    def join(self,*a,**k): return self
    def all(self): return self.value if isinstance(self.value,list) else ([] if self.value is None else [self.value])
    def first(self): return self.value
    def update(self, values, **k):
        if self.value:
            rows=self.value if isinstance(self.value,list) else [self.value]
            for r in rows:
                for key,val in values.items(): setattr(r,key,val)
        return len(self.all())
class DB:
    def __init__(self,m=None,dialect='sqlite'):
        self.mapping=m or {}; self.bind=SimpleNamespace(dialect=SimpleNamespace(name=dialect)); self.info={}; self.added=[]; self.deleted=[]; self.commits=0; self.rollbacks=0
    def query(self,c): return self.mapping.get(c,Q())
    def commit(self): self.commits+=1
    def rollback(self): self.rollbacks+=1
    def add(self,x): self.added.append(x)
    def delete(self,x): self.deleted.append(x)
    def flush(self): pass
    def close(self): pass

def test_claim_postgres_branch(monkeypatch):
    import app.worker as w
    ev=SimpleNamespace(id='x',status='PENDING',next_attempt_at=None)
    db=DB({w.OutboxEvent:Q([ev])},'postgresql')
    import app.worker as worker
    # set_tenant_context is the real PostgreSQL session call; stub it here to isolate row-lock behavior.
    monkeypatch.setattr(worker, 'set_tenant_context', lambda *a,**k: None)
    assert w._claim_events(db,1,10,'t')==['x']

def test_release_no_tenant_and_postgres_and_non_pending_order():
    import app.worker as w
    r=SimpleNamespace(status='ACTIVE',expires_at=datetime.now(timezone.utc)-timedelta(1),inventory_item_id='i',tenant_id='t',quantity=1,order_id='o')
    inv=SimpleNamespace(reserved=1,available=0,on_hand=5,committed=1,version=1)
    order=SimpleNamespace(status='SHIPPED',id='o')
    db=DB({w.InventoryReservation:Q([r]),w.InventoryItem:Q(inv),w.Order:Q(order)},'postgresql')
    assert w.release_expired_reservations(db,tenant_id=None)==1
    assert order.status=='SHIPPED'

def test_cleanup_no_tenant():
    import app.worker as w
    db=DB({w.GuestSession:Q([]),w.Cart:Q([])})
    assert w.cleanup_guest_state(db,tenant_id=None)==0

def test_notification_success_template_postgres(monkeypatch):
    import app.worker as w
    monkeypatch.setattr(w, 'set_tenant_context', lambda *a, **k: None)
    import app.services.mailer as mailer
    row=SimpleNamespace(status='QUEUED',scheduled_at=None,created_at=datetime.now(timezone.utc),channel='email',error_message=None,template_id='tpl',tenant_id='t',recipient='a@b.com',payload={'x':1},sent_at=None)
    tpl=SimpleNamespace(subject='S',body='B')
    db=DB({w.NotificationDelivery:Q([row]),w.NotificationTemplate:Q(tpl)},'postgresql')
    sent=[]; monkeypatch.setattr(mailer,'send_email',lambda *a,**k:sent.append(a))
    assert w.process_notification_deliveries(db,10,'t')==1
    assert row.status=='SENT' and sent

def test_whatsapp_success_and_exception(monkeypatch):
    import app.worker as w
    monkeypatch.setattr(w, 'set_tenant_context', lambda *a, **k: None)
    import app.services.advanced as adv
    ch=SimpleNamespace(id='c',tenant_id='t',status='ACTIVE')
    row=SimpleNamespace(direction='OUTBOUND',status='QUEUED',created_at=datetime.now(timezone.utc),tenant_id='t',channel_id='c',error_message=None,recipient='1',body='x',meta={'template_name':'t','template_params':['x']},provider_message_id=None,sent_at=None)
    db=DB({w.WhatsAppMessage:Q([row]),w.WhatsAppChannel:Q(ch)},'postgresql')
    monkeypatch.setattr(adv,'send_whatsapp',lambda *a,**k:('mid',{'ok':1}))
    assert w.process_whatsapp_deliveries(db,10,'t')==1 and row.status=='SENT'
    row2=SimpleNamespace(**row.__dict__); row2.status='QUEUED'; row2.provider_message_id=None
    db2=DB({w.WhatsAppMessage:Q([row2]),w.WhatsAppChannel:Q(ch)})
    monkeypatch.setattr(adv,'send_whatsapp',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('network')))
    assert w.process_whatsapp_deliveries(db2,10,'t')==0 and row2.status=='RECONCILIATION_REQUIRED'

def test_workflow_missing_disabled_and_invalid_loyalty():
    import app.worker as w
    from app.models.domain import WorkflowDefinition, LoyaltyAccount
    run=SimpleNamespace(workflow_id='w',tenant_id='t',input_payload={},status='QUEUED',started_at=None,completed_at=None,output_payload=None,id='r')
    with pytest.raises(RuntimeError,match='missing or disabled'):
        w._execute_workflow(DB({WorkflowDefinition:Q(None)}),run)
    wf=SimpleNamespace(enabled=True,steps=[{'type':'ADD_LOYALTY_POINTS','points':0}])
    with pytest.raises(RuntimeError,match='Invalid loyalty'):
        w._execute_workflow(DB({WorkflowDefinition:Q(wf)}),run)
    wf2=SimpleNamespace(enabled=True,steps=[{'type':'ADD_LOYALTY_POINTS','customer_id':'c','points':1}])
    with pytest.raises(RuntimeError,match='Loyalty account not found'):
        w._execute_workflow(DB({WorkflowDefinition:Q(wf2),LoyaltyAccount:Q(None)}),run)

def test_monthly_report_non_first_existing_and_delivery_failure(monkeypatch):
    import app.worker as w
    # non-first-day branch
    class D(datetime):
        @classmethod
        def now(cls,*a,**k): return cls(2026,8,22,tzinfo=timezone.utc)
    monkeypatch.setattr(w,'datetime',D)
    assert w.run_platform_monthly_report(DB()) is False
    # first day + existing
    class F(datetime):
        @classmethod
        def now(cls,*a,**k): return cls(2026,9,1,tzinfo=timezone.utc)
    monkeypatch.setattr(w,'datetime',F)
    from app.models.domain import PlatformMonthlyReport
    assert w.run_platform_monthly_report(DB({PlatformMonthlyReport:Q(SimpleNamespace(period_key='2026-08'))})) is False

def test_domain_registration_unavailable_storefront_missing_owned_and_provider_error(monkeypatch):
    import app.worker as w
    from app.models.domain import Domain,Storefront
    base=SimpleNamespace(status='PENDING_PAYMENT',tenant_id='t',customer_price_minor=100,currency='USD',hostname='x.com',years=1,registrant_snapshot={},domain_id=None,provider_reference=None,completed_at=None,failure_reason=None)
    import app.services.domain_registrar as reg
    monkeypatch.setattr(reg,'check_domain',lambda h:{'registrable':False})
    db=DB(); db.info={'captured_amount_minor':100,'captured_currency':'USD'}
    with pytest.raises(RuntimeError,match='unavailable'):
        w.process_domain_registration(db,base)
    monkeypatch.setattr(reg,'check_domain',lambda h:{'registrable':True})
    db2=DB({Domain:Q(None),Storefront:Q(None)}); db2.info={'captured_amount_minor':100,'captured_currency':'USD'}
    with pytest.raises(RuntimeError,match='Published storefront'):
        w.process_domain_registration(db2,base)
    owned=SimpleNamespace(tenant_id='other',id='d')
    db3=DB({Domain:Q(owned)}); db3.info={'captured_amount_minor':100,'captured_currency':'USD'}
    with pytest.raises(RuntimeError,match='another tenant'):
        w.process_domain_registration(db3,base)
    sf=SimpleNamespace(id='sf',version=1,status='PUBLISHED')
    db4=DB({Domain:Q(None),Storefront:Q(sf)}); db4.info={'captured_amount_minor':100,'captured_currency':'USD'}
    monkeypatch.setattr(reg,'register_domain',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('timeout')))
    assert w.process_domain_registration(db4,base)=='RECONCILIATION_REQUIRED'

def test_run_once_delivery_exception_isolated(monkeypatch):
    import app.worker as w
    import app.services.app_webhooks as aw
    monkeypatch.setattr(w,'get_settings',lambda:SimpleNamespace(OUTBOX_MAX_ATTEMPTS=2,OUTBOX_BATCH_SIZE=1,OUTBOX_VISIBILITY_TIMEOUT_SECONDS=1,APP_WEBHOOK_BATCH_SIZE=1,WHATSAPP_ORDER_CONFIRMED_TEMPLATE='',WHATSAPP_ORDER_SHIPPED_TEMPLATE='',WHATSAPP_ABANDONED_CART_TEMPLATE=''))
    monkeypatch.setattr(w,'_tenant_ids',lambda db:['t']); monkeypatch.setattr(w,'run_platform_monthly_report',lambda db:False); monkeypatch.setattr(w,'set_tenant_context',lambda *a:None); monkeypatch.setattr(w,'release_expired_reservations',lambda *a,**k:0); monkeypatch.setattr(w,'cleanup_guest_state',lambda *a,**k:0); monkeypatch.setattr(w,'_claim_events',lambda *a,**k:['e'])
    monkeypatch.setattr(w,'process_notification_deliveries',lambda *a,**k:0); monkeypatch.setattr(w,'process_whatsapp_deliveries',lambda *a,**k:0); monkeypatch.setattr(aw,'recover_stale_webhook_deliveries',lambda *a,**k:0); calls={'n':0}
    def webhook_delivery(*a,**k):
        calls['n']+=1
        if calls['n']>1: raise RuntimeError('delivery')
    monkeypatch.setattr(aw,'process_webhook_deliveries',webhook_delivery); monkeypatch.setattr(aw,'deliver_event',lambda *a:None)
    import app.services.workflow_webhooks as ww
    monkeypatch.setattr(ww,'recover_stale_workflow_webhook_deliveries',lambda *a,**k:0); monkeypatch.setattr(ww,'process_workflow_webhook_deliveries',lambda *a,**k:0)
    ev=SimpleNamespace(id='e',tenant_id='t',event_type='return.approved',payload={},status='PROCESSING',attempt_count=0,processed_at=None,next_attempt_at=None,last_error=None)
    db=DB({w.OutboxEvent:Q(ev)})
    sessions=[DB(),DB(),DB(),DB(),DB(),db,DB()]; it=iter(sessions); monkeypatch.setattr(w,'SessionLocal',lambda:next(it))
    assert w.run_once()==1 and ev.status=='PROCESSED'

def test_tenant_ids_and_order_no_order_branch(monkeypatch):
    import app.worker as w
    db=DB({w.Tenant.id:Q([('t1',),('t2',)])})
    assert w._tenant_ids(db)==['t1','t2']
    # Exercise the order/shipped branch when the referenced order is absent.
    from tests.test_v203_worker_run_once_exhaustive import setup, ev
    w, event_db = setup(monkeypatch, ev('order.confirmed', {'order_id':'missing'}), {w.Order:None, w.WhatsAppChannel:None, w.OrderAddress:None})
    assert w.run_once()==1 and event_db.mapping[w.OutboxEvent].status=='PROCESSED'


def test_run_once_abandoned_cart_condition_false_and_notification_already_processed(monkeypatch):
    import app.worker as w
    from app.models.domain import AbandonedCartCampaign, NotificationDelivery
    from tests.test_v203_worker_run_once_exhaustive import setup, ev
    campaign=SimpleNamespace(cart_id='cart',status='COMPLETED',attempt_count=1,id='camp')
    row=SimpleNamespace(status='SENT',channel='email',template_id=None,scheduled_at=None)
    mapping={AbandonedCartCampaign:campaign, NotificationDelivery:row}
    w, event_db = setup(monkeypatch, ev('marketing.abandoned_cart.scheduled', {'campaign_id':'camp'}), mapping)
    # Notification event is handled separately below; here we only need the false campaign predicate.
    assert w.run_once()==1 and campaign.status=='COMPLETED'
    w, event_db = setup(monkeypatch, ev('notification.send.queued', {'notification_delivery_id':'n'}), {NotificationDelivery:row})
    assert w.run_once()==1 and row.status=='SENT'


def test_domain_registration_without_info_attribute(monkeypatch):
    import app.worker as w
    p=SimpleNamespace(status='PENDING_PAYMENT',tenant_id='t',customer_price_minor=100,currency='USD')
    class NoInfoDB(DB):
        def __init__(self):
            super().__init__()
            # Remove info from instance and class so hasattr(db, 'info') is false.
            del self.info
    db=NoInfoDB()
    with pytest.raises(RuntimeError,match='capture amount/currency mismatch'):
        w.process_domain_registration(db,p)


def test_monthly_report_success_and_recipient_failure(monkeypatch):
    import app.worker as w
    from app.models.domain import PlatformMonthlyReport, User
    class F(datetime):
        @classmethod
        def now(cls,*a,**k): return cls(2026,9,1,tzinfo=timezone.utc)
    monkeypatch.setattr(w,'datetime',F)
    monkeypatch.setattr('app.services.advanced.platform_metrics',lambda *a,**k:{'orders':3})
    import app.services.mailer as mailer
    sent=[]
    def mail(recipient,*args):
        sent.append(recipient)
        if recipient=='bad@example.com': raise RuntimeError('smtp')
    monkeypatch.setattr(mailer,'send_email',mail)
    users=[SimpleNamespace(email='ok@example.com'),SimpleNamespace(email='bad@example.com')]
    # Main DB contains users and no existing report; SessionLocal returns the persisted report DB.
    persisted=SimpleNamespace(period_key='2026-08',delivery_status='SENDING')
    main=DB({PlatformMonthlyReport:Q(None),User:Q(users)})
    report_db=DB({PlatformMonthlyReport:Q(persisted)})
    monkeypatch.setattr(w,'SessionLocal',lambda:report_db)
    assert w.run_platform_monthly_report(main) is True
    assert persisted.delivery_status=='RECONCILIATION_REQUIRED' and sent==['ok@example.com','bad@example.com']


def test_monthly_report_persisted_row_missing_after_send(monkeypatch):
    import app.worker as w
    from app.models.domain import PlatformMonthlyReport, User
    class F(datetime):
        @classmethod
        def now(cls,*a,**k): return cls(2026,9,1,tzinfo=timezone.utc)
    monkeypatch.setattr(w,'datetime',F)
    monkeypatch.setattr('app.services.advanced.platform_metrics',lambda *a,**k:{'orders':1})
    monkeypatch.setattr('app.services.mailer.send_email',lambda *a,**k:None)
    main=DB({PlatformMonthlyReport:Q(None),User:Q([])})
    report_db=DB({PlatformMonthlyReport:Q(None)})
    monkeypatch.setattr(w,'SessionLocal',lambda:report_db)
    assert w.run_platform_monthly_report(main) is False

def test_run_once_domain_event_initializes_missing_db_info(monkeypatch):
    import app.worker as w
    from app.models.domain import DomainPurchase
    from tests.test_v203_worker_run_once_exhaustive import setup, ev
    purchase=SimpleNamespace(id='p')
    w,db=setup(monkeypatch, ev('domain.purchase.payment_captured', {'purchase_id':'p','amount_minor':100,'currency':'usd'}), {DomainPurchase:purchase})
    del db.info
    called=[]
    monkeypatch.setattr(w,'process_domain_registration',lambda db,p: called.append((db,p)) or 'COMPLETED')
    assert w.run_once()==1 and called


def test_run_once_notification_second_queued_check_false(monkeypatch):
    import app.worker as w
    from app.models.domain import NotificationDelivery
    from tests.test_v203_worker_run_once_exhaustive import setup, ev
    class FlippingRow:
        def __init__(self): self._n=0; self.channel='email'; self.template_id=None; self.scheduled_at=None
        @property
        def status(self):
            self._n += 1
            return 'QUEUED' if self._n == 1 else 'SENT'
    row=FlippingRow()
    w,db=setup(monkeypatch, ev('notification.send.queued', {'notification_delivery_id':'n'}), {NotificationDelivery:row})
    assert w.run_once()==1


def test_run_once_falsy_string_event_skips_webhook_delivery_call(monkeypatch):
    import app.worker as w
    from tests.test_v203_worker_run_once_exhaustive import setup
    class FalsyEventType(str):
        def __bool__(self): return False
    event=__import__('types').SimpleNamespace(id='e1',tenant_id='t1',event_type=FalsyEventType('return.approved'),payload={},status='PROCESSING',attempt_count=0,processed_at=None,next_attempt_at=None,last_error=None)
    w,db=setup(monkeypatch,event,{})
    assert w.run_once()==1 and db.mapping[w.OutboxEvent].status=='PROCESSED'
