from pathlib import Path
import yaml

def test_product_search_and_variant_payload(client):
    from tests.test_p0 import register
    x = register(client, 'search-final@example.com')
    h = {'Authorization': f"Bearer {x['access_token']}"}
    tid = x['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'red-shoe', 'title': 'Red Shoe', 'description': 'running shoe', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'RED-1', 'price_amount_minor': 1200, 'currency': 'USD'}).json()
    r = client.get(f'/v1/products?tenant_id={tid}&q=red')
    assert r.status_code == 200
    assert r.json()['total'] == 1
    assert r.json()['items'][0]['variants'][0]['sku'] == 'RED-1'

def test_product_create_idempotency(client):
    from tests.test_p0 import register
    x = register(client, 'product-idem-final@example.com')
    h = {'Authorization': f"Bearer {x['access_token']}"}
    tid = x['tenant']['id']
    headers = {**h, 'Idempotency-Key': 'product-create-1'}
    payload = {'slug': 'idem-product', 'title': 'Idem Product', 'description': 'x', 'status': 'ACTIVE', 'product_type': 'PHYSICAL'}
    a = client.post(f'/v1/products?tenant_id={tid}', headers=headers, json=payload)
    b = client.post(f'/v1/products?tenant_id={tid}', headers=headers, json=payload)
    assert a.status_code == 200 and b.status_code == 200
    assert a.json()['id'] == b.json()['id']

def test_metrics_are_not_public(client):
    r = client.get('/v1/metrics-lite')
    assert r.status_code == 403

def test_compose_contract():
    cfg = yaml.safe_load(Path('docker-compose.yml').read_text())
    assert cfg['services']['db']['image'] == 'postgres:18.6'
    assert cfg['services']['migrate']['environment']['ENVIRONMENT'] == 'migration'
    assert 'STRIPE_SECRET_KEY' not in cfg['services']['migrate']['environment']
    assert cfg['services']['api']['depends_on']['migrate']['condition'] == 'service_completed_successfully'


def test_release_version_is_consistent_across_runtime_defaults():
    import re
    version = Path('VERSION').read_text(encoding='utf-8').strip()
    env = Path('.env.example').read_text(encoding='utf-8')
    compose = Path('docker-compose.yml').read_text(encoding='utf-8')
    readme = Path('README.md').read_text(encoding='utf-8')
    assert f"APP_VERSION={version}" in env
    assert f"APP_VERSION: ${{APP_VERSION:-{version}}}" in compose
    assert f"v{version}" in readme
