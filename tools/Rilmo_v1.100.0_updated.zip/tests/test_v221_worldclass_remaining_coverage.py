import pytest
from app.core.errors import AppError
from app.services.worldclass import stable_variant, storefront_metrics, catalog_for_agent, compute_feed


# --- stable_variant ---------------------------------------------------

def test_stable_variant_rejects_non_integer_traffic():
    with pytest.raises(AppError) as exc:
        stable_variant('key', [{'key': 'control'}], 'not-a-number')
    assert exc.value.code == 'EXPERIMENT_TRAFFIC_INVALID'

def test_stable_variant_bucket_above_traffic_returns_first_variant():
    # A traffic_bps of 0 guarantees the visitor's bucket (0-9999) is always
    # >= traffic, forcing the "outside experiment" branch.
    result = stable_variant('any-visitor-key', [{'key': 'control'}, {'key': 'treatment'}], 0)
    assert result == 'control'


# --- storefront_metrics -------------------------------------------------

def test_storefront_metrics_rejects_non_integer_days(db_session):
    with pytest.raises(AppError) as exc:
        storefront_metrics(db_session, 'tenant-x', days='not-a-number')
    assert exc.value.code == 'ANALYTICS_WINDOW_INVALID'


# --- catalog_for_agent ---------------------------------------------------

def test_catalog_for_agent_rejects_non_integer_limit(db_session):
    with pytest.raises(AppError) as exc:
        catalog_for_agent(db_session, 'tenant-x', limit='not-a-number')
    assert exc.value.code == 'CATALOG_LIMIT_INVALID'


# --- compute_feed ---------------------------------------------------

def test_compute_feed_delegates_to_catalog_for_agent(db_session):
    from app.models.domain import Product, ProductVariant, ProductFeed

    tenant_id = 'tenant-feed-v220'
    p = Product(tenant_id=tenant_id, slug='feed-item', title='Feed Item', status='PUBLISHED')
    db_session.add(p)
    db_session.flush()
    db_session.add(ProductVariant(tenant_id=tenant_id, product_id=p.id, sku='FEED-1',
        price_amount_minor=1500, currency='USD', status='ACTIVE'))
    feed = ProductFeed(tenant_id=tenant_id, country_code='de', locale='DE', channel='google')
    db_session.add(feed)
    db_session.commit()

    items = compute_feed(db_session, feed)
    assert len(items) == 1
    assert items[0]['sku'] == 'FEED-1'
    assert items[0]['country_code'] == 'DE'
    assert items[0]['locale'] == 'de'
