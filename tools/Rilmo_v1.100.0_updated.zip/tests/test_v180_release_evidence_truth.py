from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_release_evidence_never_hardcodes_live_runtime_pass():
    t = (ROOT / 'scripts/release_evidence.py').read_text(encoding='utf-8')
    assert "add(results,'live_runtime_gate',True" not in t
    assert 'LIVE_RUNTIME_GATE_PASS' in t


def test_release_evidence_records_test_collection_separately():
    t = (ROOT / 'scripts/release_evidence.py').read_text(encoding='utf-8')
    assert 'pytest_collection' in t
    assert 'full_sharded_test_suite' in t
    assert 'global_100_certified' in t


def test_ucp_payment_binding_migration_is_sqlite_safe():
    t = (ROOT / 'alembic/versions/20260820_0058_ucp_payment_binding.py').read_text(encoding='utf-8')
    assert 'batch_alter_table("payment_intents", recreate="always")' in t
    assert 'create_foreign_key' in t
