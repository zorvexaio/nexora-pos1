from tests.test_p0 import register

def h(x):
    return {'Authorization': f"Bearer {x['access_token']}"}

def test_theme_assignment_and_public_config(client):
    x = register(client, 'theme112@example.com')
    headers = h(x)
    tid = x['tenant']['id']
    r = client.post(f'/v1/themes?tenant_id={tid}', headers=headers, json={'slug': 'modern', 'name': 'Modern', 'settings': {'primary': '#111', 'radius': '18px'}})
    assert r.status_code == 200
    theme = r.json()
    assert client.post(f'/v1/themes/assign?tenant_id={tid}', headers=headers, json={'theme_id': theme['id']}).status_code == 200
    assert client.post(f'/v1/themes/publish?tenant_id={tid}', headers=headers).status_code == 200

def test_loyalty_earn_redeem_is_idempotent(client):
    x = register(client, 'loyalty112@example.com')
    headers = h(x)
    tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Customer
    db = SessionLocal()
    c = Customer(tenant_id=tid, email='loyalty-customer@example.com')
    db.add(c)
    db.commit()
    cid = c.id
    db.close()
    r = client.post(f'/v1/loyalty/earn?tenant_id={tid}', headers=headers, json={'customer_id': cid, 'points': 100, 'reason': 'order', 'idempotency_key': 'loyalty-112-1'})
    assert r.status_code == 200 and r.json()['points_balance'] == 100
    dup = client.post(f'/v1/loyalty/earn?tenant_id={tid}', headers=headers, json={'customer_id': cid, 'points': 100, 'reason': 'order', 'idempotency_key': 'loyalty-112-1'})
    assert dup.status_code == 200 and dup.json()['duplicate'] is True
    red = client.post(f'/v1/loyalty/redeem?tenant_id={tid}', headers=headers, json={'customer_id': cid, 'points': 40, 'reason': 'reward', 'idempotency_key': 'loyalty-112-2'})
    assert red.status_code == 200 and red.json()['points_balance'] == 60

def test_loyalty_cannot_go_negative(client):
    x = register(client, 'loyalty-negative112@example.com')
    headers = h(x)
    tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Customer
    db = SessionLocal()
    c = Customer(tenant_id=tid, email='negative@example.com')
    db.add(c)
    db.commit()
    cid = c.id
    db.close()
    r = client.post(f'/v1/loyalty/redeem?tenant_id={tid}', headers=headers, json={'customer_id': cid, 'points': 1, 'reason': 'reward', 'idempotency_key': 'loyalty-neg-1'})
    assert r.status_code == 409

def _activate_plan(client, tid, headers, code='growth'):
    from app.core.database import SessionLocal
    from app.models.domain import Plan, PlanVersion
    db=SessionLocal(); plan=db.query(Plan).filter_by(code=code).first(); pv=db.query(PlanVersion).filter_by(plan_id=plan.id,is_current=True).first(); db.close()
    r=client.post(f'/v1/subscriptions?tenant_id={tid}',headers=headers,json={'plan_version_id':pv.id}); assert r.status_code==200, r.text

def test_abandoned_cart_scan_is_tenant_scoped(client):
    a = register(client, 'marketing-a112@example.com')
    b = register(client, 'marketing-b112@example.com')
    ha = h(a)
    hb = h(b)
    _activate_plan(client, a['tenant']['id'], ha, 'growth')
    _activate_plan(client, b['tenant']['id'], hb, 'growth')
    assert client.post(f"/v1/marketing/abandoned-carts/scan?tenant_id={a['tenant']['id']}", headers=ha).status_code == 200
    r = client.post(f"/v1/marketing/abandoned-carts/scan?tenant_id={b['tenant']['id']}", headers=ha)
    assert r.status_code in (403, 404)

def test_app_installation_scope_is_constrained(client):
    x = register(client, 'apps112@example.com')
    headers = h(x)
    tid = x['tenant']['id']
    r = client.post(f'/v1/apps/install?tenant_id={tid}', headers=headers, json={'app_id': 'missing', 'scopes': ['products.read']})
    assert r.status_code in (403, 404)

def test_webhook_endpoint_rejects_non_https(client):
    x = register(client, 'webhook112@example.com')
    headers = h(x)
    tid = x['tenant']['id']
    r = client.post(f'/v1/apps/installations/missing/webhooks?tenant_id={tid}', headers=headers, json={'event_type': 'order.created', 'endpoint_url': 'http://127.0.0.1:8080/hook'})
    assert r.status_code in (403, 404)

def test_loyalty_idempotency_rejects_changed_request(client):
    x = register(client, 'loyalty-idem-mismatch@example.com')
    headers = h(x); tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Customer
    db = SessionLocal()
    c = Customer(tenant_id=tid, email='idem-loyalty@example.com')
    db.add(c); db.commit(); cid = c.id; db.close()
    first = client.post(f'/v1/loyalty/earn?tenant_id={tid}', headers=headers,
        json={'customer_id': cid, 'points': 100, 'reason': 'order', 'idempotency_key': 'same-key-1'})
    assert first.status_code == 200
    changed = client.post(f'/v1/loyalty/earn?tenant_id={tid}', headers=headers,
        json={'customer_id': cid, 'points': 101, 'reason': 'order', 'idempotency_key': 'same-key-1'})
    assert changed.status_code == 409
    assert changed.json()['detail']['error']['code'] == 'IDEMPOTENCY_MISMATCH'

def test_loyalty_redeem_idempotency_rejects_changed_request(client):
    x = register(client, 'loyalty-redeem-mismatch@example.com')
    headers = h(x); tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Customer
    db = SessionLocal()
    c = Customer(tenant_id=tid, email='redeem-idem@example.com')
    db.add(c); db.commit(); cid = c.id; db.close()
    assert client.post(f'/v1/loyalty/earn?tenant_id={tid}', headers=headers,
        json={'customer_id': cid, 'points': 100, 'reason': 'seed', 'idempotency_key': 'seed-redeem'}).status_code == 200
    first = client.post(f'/v1/loyalty/redeem?tenant_id={tid}', headers=headers,
        json={'customer_id': cid, 'points': 40, 'reason': 'reward', 'idempotency_key': 'same-redeem'})
    assert first.status_code == 200
    changed = client.post(f'/v1/loyalty/redeem?tenant_id={tid}', headers=headers,
        json={'customer_id': cid, 'points': 41, 'reason': 'reward', 'idempotency_key': 'same-redeem'})
    assert changed.status_code == 409
    assert changed.json()['detail']['error']['code'] == 'IDEMPOTENCY_MISMATCH'
