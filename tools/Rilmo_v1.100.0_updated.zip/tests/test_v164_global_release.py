from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_release_version_consistency():
    version=(ROOT/"VERSION").read_text(encoding="utf-8").strip()
    for fn in ("README.md",".env.example","docker-compose.yml"):
        text=(ROOT/fn).read_text(encoding="utf-8")
        assert version in text

def test_no_legacy_payment_user_agent():
    text=(ROOT/"app/services/payment_providers.py").read_text(encoding="utf-8")
    assert "UnifiedGlobalCommerce/1.36" not in text
    assert "'UnifiedGlobalCommerce/' + get_settings().APP_VERSION" in text
    assert "'UnifiedGlobalCommerce/1.64" not in text

def test_production_preflight_has_critical_guards():
    text=(ROOT/"scripts/production_preflight.py").read_text(encoding="utf-8")
    for marker in ("GOOGLE_REDIRECT_URI", "PUBLIC_BASE_URL", "S3_BUCKET", "CLAMAV_HOST", "APP_VERSION"):
        assert marker in text
