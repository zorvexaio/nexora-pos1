from pathlib import Path
from unittest.mock import patch
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]

def test_workflow_webhook_has_real_delivery_consumer():
    service=(ROOT/'app/services/workflow_webhooks.py').read_text()
    worker=(ROOT/'app/worker.py').read_text()
    assert 'def materialize_workflow_webhook' in service
    assert 'def process_workflow_webhook_deliveries' in service
    assert 'materialize_workflow_webhook' in worker
    assert 'process_workflow_webhook_deliveries' in worker

def test_workflow_webhook_is_not_reported_completed_before_delivery():
    service=(ROOT/'app/services/platform_ecosystem.py').read_text()
    assert "row.status = 'QUEUED' if step_type == 'WEBHOOK' else 'COMPLETED'" in service

def test_workflow_webhook_delivery_is_persisted_and_updates_step():
    models=(ROOT/'app/models/domain.py').read_text()
    assert 'class WorkflowWebhookDelivery(Base):' in models
    assert "UniqueConstraint('workflow_run_id', 'step_position')" in models
    mig=(ROOT/'alembic/versions/20260819_0047_workflow_webhook_delivery.py').read_text()
    assert 'ENABLE ROW LEVEL SECURITY' in mig and 'FORCE ROW LEVEL SECURITY' in mig

def test_workflow_webhook_has_ssrf_controls():
    service=(ROOT/'app/services/workflow_webhooks.py').read_text()
    assert "p.scheme.lower() != 'https'" in service
    assert 'ip.is_global' in service
    assert '_post_pinned' in service

def test_release_builder_excludes_internal_patch_scripts():
    build=(ROOT/'scripts/build_release.py').read_text()
    assert "BAD_FILE_PATTERNS" in build and "re.compile(r'^_apply_v\\d+\\.py$')" in build

def test_workflow_webhook_runtime_transitions_queued_to_completed(client, monkeypatch):
    from app.core.database import SessionLocal
    from app.models.domain import WorkflowDefinition, WorkflowWebhookDelivery, WorkflowStepRun, OutboxEvent
    from app.services.workflow_webhooks import materialize_workflow_webhook, process_workflow_webhook_deliveries
    res=client.post('/v1/auth/register',json={'email':'workflow-webhook-v152@example.com','password':'VerySecurePassword123!','display_name':'Webhook Test'}); assert res.status_code==200, res.text; x=res.json()
    tid = x['tenant']['id']; headers={'Authorization':'Bearer '+x['access_token']}
    db=SessionLocal()
    try:
        w=WorkflowDefinition(tenant_id=tid,slug='webhook-v152',name='Webhook v152',trigger_event='order.created',enabled=True,steps=[{'type':'WEBHOOK','url':'https://example.com/hook'}])
        db.add(w); db.commit(); wid=w.id
    finally: db.close()
    res=client.post(f'/v1/workflows/{wid}/execute',params={'tenant_id':tid},headers=headers,json={'input_payload':{'order_id':'ord-v152'}})
    assert res.status_code==200, res.text
    run=res.json(); assert run['status']=='COMPLETED'
    db=SessionLocal()
    try:
        step=db.query(WorkflowStepRun).filter_by(workflow_run_id=run['id'],position=0).one()
        assert step.status=='QUEUED'
        ev=db.query(OutboxEvent).filter_by(event_type='workflow.webhook.requested',aggregate_id=run['id']).one()
        monkeypatch.setattr('socket.getaddrinfo', lambda *args, **kwargs: [(2, 1, 6, '', ('93.184.216.34', 443))])
        delivery=materialize_workflow_webhook(db,ev)
        assert delivery.status=='PENDING'
        calls=[]
        monkeypatch.setattr('app.services.workflow_webhooks._post_pinned', lambda *args, **kwargs: (200,b'',{}))
        assert process_workflow_webhook_deliveries(db)==1
        db.refresh(delivery); db.refresh(step)
        assert delivery.status=='SUCCEEDED'
        assert step.status=='COMPLETED'
        assert step.output_payload['delivered'] is True
    finally:
        db.close()
