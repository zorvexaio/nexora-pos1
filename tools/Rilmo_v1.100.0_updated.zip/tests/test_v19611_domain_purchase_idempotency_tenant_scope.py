from datetime import datetime, timezone


def _register(client, email):
    r = client.post('/v1/auth/register', json={
        'email': email,
        'password': 'VerySecurePassword123!',
        'display_name': 'Domain Idempotency Test',
    })
    assert r.status_code == 200, r.text
    return r.json()


def _insert_purchase(tid, key):
    from app.core.database import SessionLocal
    from app.models.domain import DomainPurchase
    db = SessionLocal()
    try:
        row = DomainPurchase(
            tenant_id=tid,
            hostname='example.test',
            years=1,
            provider='cloudflare',
            provider_cost_minor=100,
            customer_price_minor=200,
            currency='USD',
            status='PENDING_PAYMENT',
            idempotency_key=key,
            registrant_snapshot={'country_code': 'TR'},
            created_at=datetime.now(timezone.utc),
        )
        db.add(row)
        db.commit()
        return row.id
    finally:
        db.close()


def test_domain_purchase_idempotency_lookup_is_tenant_scoped(client):
    a = _register(client, 'v19611-domain-a@example.com')
    b = _register(client, 'v19611-domain-b@example.com')
    from app.core.database import SessionLocal
    from app.models.domain import DomainPurchase

    key = 'same-idempotency-key-cross-tenant'
    a_id = _insert_purchase(a['tenant']['id'], key)
    assert a_id

    db = SessionLocal()
    try:
        b_row = db.query(DomainPurchase).filter_by(
            tenant_id=b['tenant']['id'], idempotency_key=key
        ).first()
        assert b_row is None
    finally:
        db.close()


def test_domain_purchase_idempotency_key_is_unique_per_tenant_not_globally(client):
    a = _register(client, 'v19611-domain-c@example.com')
    b = _register(client, 'v19611-domain-d@example.com')
    key = 'reusable-per-tenant'
    _insert_purchase(a['tenant']['id'], key)
    second_id = _insert_purchase(b['tenant']['id'], key)
    assert second_id
