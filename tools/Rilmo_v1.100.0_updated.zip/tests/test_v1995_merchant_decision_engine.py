from app.routes.worldclass import analytics_merchant_decision_engine

class MerchantUser:
    id = 'merchant-user'


def _layers():
    return {
        'revenue': {
            'currencies': {
                'TRY': {'net_revenue_minor': 90000, 'growth_bps': -2500, 'refund_rate_bps': 1200},
            }
        },
        'pricing': {
            'alerts': [
                {'status': 'UNDER_COST', 'variant_id': 'v1', 'currency': 'TRY', 'price_minor': 6000, 'cost_minor': 7000, 'gap_to_target_minor': 2750},
                {'status': 'MISSING_COST', 'variant_id': 'v2', 'currency': 'TRY'},
            ]
        },
        'command': {'operations': {'out_of_stock': 2, 'fulfillment_backlog': 3, 'risk_review': 1}},
        'customer': {'segments': {'AT_RISK': 7}, 'repeat_customer_rate_bps': 2200},
    }


def test_decision_engine_ranks_critical_and_high_actions(db_session, monkeypatch):
    layers = _layers()
    monkeypatch.setattr('app.routes.worldclass._perm', lambda *a, **k: None)
    monkeypatch.setattr('app.routes.worldclass.analytics_revenue_intelligence', lambda *a, **k: layers['revenue'])
    monkeypatch.setattr('app.routes.worldclass.analytics_pricing_intelligence', lambda *a, **k: layers['pricing'])
    monkeypatch.setattr('app.routes.worldclass.analytics_command_center', lambda *a, **k: layers['command'])
    monkeypatch.setattr('app.routes.worldclass.analytics_customer_intelligence', lambda *a, **k: layers['customer'])
    r = analytics_merchant_decision_engine('tenant-1', 30, 2000, MerchantUser(), db_session)
    assert r['decisions'][0]['priority'] == 'CRITICAL'
    assert r['decisions'][0]['code'] in {'PROTECT_UNIT_MARGIN', 'RESTOCK_OUT_OF_STOCK'}
    assert any(x['code'] == 'RECOVER_REVENUE_DECLINE' for x in r['decisions'])
    assert any(x['code'] == 'RETAIN_AT_RISK_CUSTOMERS' for x in r['decisions'])
    assert r['integrity']['read_only'] is True


def test_decision_engine_is_currency_safe_and_does_not_auto_mutate(db_session, monkeypatch):
    layers = _layers()
    monkeypatch.setattr('app.routes.worldclass._perm', lambda *a, **k: None)
    monkeypatch.setattr('app.routes.worldclass.analytics_revenue_intelligence', lambda *a, **k: layers['revenue'])
    monkeypatch.setattr('app.routes.worldclass.analytics_pricing_intelligence', lambda *a, **k: layers['pricing'])
    monkeypatch.setattr('app.routes.worldclass.analytics_command_center', lambda *a, **k: layers['command'])
    monkeypatch.setattr('app.routes.worldclass.analytics_customer_intelligence', lambda *a, **k: layers['customer'])
    r = analytics_merchant_decision_engine('tenant-1', 30, 2000, MerchantUser(), db_session)
    assert r['integrity']['cross_currency_impact_not_aggregated'] is True
    assert r['integrity']['no_automatic_price_mutation'] is True
    assert r['integrity']['no_automatic_payment_mutation'] is True
    assert r['integrity']['no_automatic_inventory_mutation'] is True
    assert all(x['rank'] == i for i, x in enumerate(r['decisions'], 1))


def test_decision_engine_has_safe_input_bounds(db_session, monkeypatch):
    monkeypatch.setattr('app.routes.worldclass._perm', lambda *a, **k: None)
    try:
        analytics_merchant_decision_engine('tenant-1', 0, 2000, MerchantUser(), db_session)
    except Exception:
        raise AssertionError('days=0 should be normalized to the supported minimum')
