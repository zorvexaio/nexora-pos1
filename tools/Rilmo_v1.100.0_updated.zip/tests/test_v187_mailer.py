import smtplib
from types import SimpleNamespace
import pytest
from app.core.errors import AppError
from app.services import mailer


def _fake_settings(**overrides):
    base = dict(
        ENVIRONMENT='development',
        PUBLIC_BASE_URL='https://shop.example.com',
        PASSWORD_RESET_TTL_MINUTES=30,
        LOCAL_MAIL_OUTBOX='/tmp/rilmo_mail_test_outbox.log',
        SMTP_HOST='', SMTP_PORT=587, SMTP_TLS=True,
        SMTP_USERNAME='', SMTP_PASSWORD='', MAIL_FROM='',
    )
    base.update(overrides)
    return SimpleNamespace(**base)


# --- local/dev sink ----------------------------------------------------

def test_send_password_reset_writes_local_message_outside_production(monkeypatch, tmp_path):
    outbox = tmp_path / 'mail.log'
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(LOCAL_MAIL_OUTBOX=str(outbox)))
    mailer.send_password_reset('user@example.com', 'tok123')
    content = outbox.read_text(encoding='utf-8')
    assert 'user@example.com' in content
    assert 'tok123' in content
    assert 'Reset your password' in content

def test_send_email_writes_local_message_outside_production(monkeypatch, tmp_path):
    outbox = tmp_path / 'mail.log'
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(LOCAL_MAIL_OUTBOX=str(outbox)))
    mailer.send_email('someone@example.com', 'Hello', 'Body text')
    content = outbox.read_text(encoding='utf-8')
    assert 'someone@example.com' in content
    assert 'Hello' in content
    assert 'Body text' in content

def test_local_mail_outbox_appends_multiple_messages(monkeypatch, tmp_path):
    outbox = tmp_path / 'mail.log'
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(LOCAL_MAIL_OUTBOX=str(outbox)))
    mailer.send_email('a@example.com', 'One', 'first')
    mailer.send_email('b@example.com', 'Two', 'second')
    content = outbox.read_text(encoding='utf-8')
    assert content.count('---') == 2

def test_local_mail_outbox_creates_parent_directories(monkeypatch, tmp_path):
    outbox = tmp_path / 'nested' / 'dir' / 'mail.log'
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(LOCAL_MAIL_OUTBOX=str(outbox)))
    mailer.send_email('a@example.com', 'Subj', 'body')
    assert outbox.exists()


# --- production path: config validation --------------------------------

def test_send_password_reset_raises_when_smtp_not_configured_in_production(monkeypatch):
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(ENVIRONMENT='production'))
    with pytest.raises(AppError) as exc:
        mailer.send_password_reset('user@example.com', 'tok')
    assert exc.value.code == 'MAIL_NOT_CONFIGURED'

def test_send_email_raises_when_smtp_not_configured_in_production(monkeypatch):
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(ENVIRONMENT='production'))
    with pytest.raises(AppError) as exc:
        mailer.send_email('user@example.com', 'Subj', 'body')
    assert exc.value.code == 'MAIL_NOT_CONFIGURED'


# --- production path: real SMTP call (mocked) ---------------------------

class _FakeSMTP:
    instances = []

    def __init__(self, host, port, timeout=15):
        self.host, self.port = host, port
        self.started_tls = False
        self.logged_in = None
        self.sent = None
        _FakeSMTP.instances.append(self)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def starttls(self):
        self.started_tls = True

    def login(self, user, pwd):
        self.logged_in = (user, pwd)

    def send_message(self, msg):
        self.sent = msg


def test_send_password_reset_sends_via_smtp_in_production(monkeypatch):
    _FakeSMTP.instances.clear()
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(
        ENVIRONMENT='production', SMTP_HOST='smtp.example.com', SMTP_USERNAME='u',
        SMTP_PASSWORD='p', MAIL_FROM='no-reply@example.com',
    ))
    monkeypatch.setattr(mailer.smtplib, 'SMTP', _FakeSMTP)
    mailer.send_password_reset('user@example.com', 'tok999')
    assert len(_FakeSMTP.instances) == 1
    inst = _FakeSMTP.instances[0]
    assert inst.started_tls is True
    assert inst.logged_in == ('u', 'p')
    assert inst.sent['To'] == 'user@example.com'
    assert inst.sent['From'] == 'no-reply@example.com'

def test_send_email_sends_via_smtp_in_production_without_tls_when_disabled(monkeypatch):
    _FakeSMTP.instances.clear()
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(
        ENVIRONMENT='production', SMTP_HOST='smtp.example.com', SMTP_USERNAME='u',
        SMTP_PASSWORD='p', MAIL_FROM='no-reply@example.com', SMTP_TLS=False,
    ))
    monkeypatch.setattr(mailer.smtplib, 'SMTP', _FakeSMTP)
    mailer.send_email('someone@example.com', 'Hi', 'body text')
    inst = _FakeSMTP.instances[0]
    assert inst.started_tls is False
    assert inst.sent['Subject'] == 'Hi'

def test_send_email_raises_provider_unavailable_on_smtp_failure(monkeypatch):
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(
        ENVIRONMENT='production', SMTP_HOST='smtp.example.com', SMTP_USERNAME='u',
        SMTP_PASSWORD='p', MAIL_FROM='no-reply@example.com',
    ))
    class _BrokenSMTP:
        def __init__(self, *a, **k):
            raise smtplib.SMTPConnectError(421, 'down')
    monkeypatch.setattr(mailer.smtplib, 'SMTP', _BrokenSMTP)
    with pytest.raises(AppError) as exc:
        mailer.send_email('someone@example.com', 'Hi', 'body')
    assert exc.value.code == 'MAIL_PROVIDER_UNAVAILABLE'

def test_send_password_reset_raises_provider_unavailable_on_smtp_failure(monkeypatch):
    monkeypatch.setattr(mailer, 'get_settings', lambda: _fake_settings(
        ENVIRONMENT='production', SMTP_HOST='smtp.example.com', SMTP_USERNAME='u',
        SMTP_PASSWORD='p', MAIL_FROM='no-reply@example.com',
    ))
    class _BrokenSMTP:
        def __init__(self, *a, **k):
            raise OSError('connection refused')
    monkeypatch.setattr(mailer.smtplib, 'SMTP', _BrokenSMTP)
    with pytest.raises(AppError) as exc:
        mailer.send_password_reset('someone@example.com', 'tok')
    assert exc.value.code == 'MAIL_PROVIDER_UNAVAILABLE'
