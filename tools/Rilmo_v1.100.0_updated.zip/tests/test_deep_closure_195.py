from tests.test_p0 import register

def test_payment_operation_allows_sequential_refunds_and_void(client):
    x = register(client, 'closure195@example.com')
    h = {'Authorization': f"Bearer {x['access_token']}"}
    tid = x['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'digital-195', 'title': 'Digital', 'status': 'ACTIVE', 'product_type': 'DIGITAL'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'D195', 'price_amount_minor': 1000, 'currency': 'USD', 'provider': 'mock'}).json()
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    assert client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1}).status_code == 200
    o = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c['id']}).json()
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'order_id': o['id'], 'amount_minor': 1000, 'currency': 'USD', 'provider': 'mock'}).json()
    assert client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h).status_code == 200
    for key, amount in [('refund-1', 100), ('refund-2', 200), ('refund-3', 300)]:
        r = client.post(f'/v1/refunds?tenant_id={tid}', headers={**h, 'Idempotency-Key': key}, json={'order_id': o['id'], 'payment_intent_id': pi['id'], 'amount_minor': amount, 'currency': 'USD'})
        assert r.status_code == 200, r.text

def test_void_endpoint_exists_and_is_authorized(client):
    x = register(client, 'void195@example.com')
    h = {'Authorization': f"Bearer {x['access_token']}"}
    tid = x['tenant']['id']
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'amount_minor': 1000, 'currency': 'USD', 'provider': 'mock'}).json()
    r = client.post(f"/v1/payments/{pi['id']}/void?tenant_id={tid}", headers={**h, 'Idempotency-Key': 'void-1'})
    assert r.status_code == 200
    assert r.json()['status'] == 'VOIDED'

def test_category_parent_cannot_cross_tenant(client):
    a = register(client, 'cat-a195@example.com')
    b = register(client, 'cat-b195@example.com')
    ha = {'Authorization': f"Bearer {a['access_token']}"}
    hb = {'Authorization': f"Bearer {b['access_token']}"}
    parent = client.post(f"/v1/categories?tenant_id={b['tenant']['id']}", headers=hb, json={'slug': 'foreign', 'name': 'Foreign'}).json()
    r = client.post(f"/v1/categories?tenant_id={a['tenant']['id']}", headers=ha, json={'slug': 'child', 'name': 'Child', 'parent_id': parent['id']})
    assert r.status_code == 400

def test_image_pipeline_sanitizes_and_generates_variants():
    from PIL import Image
    from io import BytesIO
    from app.services.media_pipeline import process_image
    src = BytesIO()
    Image.new('RGB', (1000, 700), (12, 34, 56)).save(src, format='PNG')
    result = process_image(src.getvalue())
    assert set(result) == {'thumbnail', 'small', 'medium', 'large', 'original'}
    assert all((data[0][:4] == b'RIFF' for data in result.values()))
