from pathlib import Path

from alembic.script import ScriptDirectory

from app.core.runtime import _alembic_config


def test_alembic_head_is_single_and_ci_does_not_pin_stale_revision():
    script = ScriptDirectory.from_config(_alembic_config())
    heads = script.get_heads()
    assert len(heads) == 1
    ci = Path('.github/workflows/ci.yml').read_text(encoding='utf-8')
    assert "h[0]==\'20260822_0063\'" not in ci
    assert "h[0]=='20260822_0064'" not in ci
