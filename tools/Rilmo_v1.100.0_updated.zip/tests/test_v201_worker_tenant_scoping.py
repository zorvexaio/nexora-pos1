from types import SimpleNamespace

class Q:
    def __init__(self, rows=None): self.rows=list(rows or []); self.filters=[]
    def filter(self,*a,**k): self.filters.extend(a); return self
    def order_by(self,*a,**k): return self
    def limit(self,*a,**k): return self
    def with_for_update(self,*a,**k): return self
    def all(self): return self.rows
    def first(self): return self.rows[0] if self.rows else None
    def filter_by(self,**k): return self

class DB:
    def __init__(self, mapping):
        self.mapping=mapping; self.bind=SimpleNamespace(dialect=SimpleNamespace(name='sqlite')); self.info={}; self.commits=0
    def query(self, cls): return self.mapping.get(cls,Q())
    def commit(self): self.commits += 1
    def rollback(self): pass
    def add(self,x): pass
    def flush(self): pass


def test_notification_delivery_worker_scopes_tenant(monkeypatch):
    import app.worker as w
    row=SimpleNamespace(status='QUEUED',scheduled_at=None,created_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc),channel='sms',tenant_id='tenant-a',error_message=None)
    q=Q([row]); db=DB({w.NotificationDelivery:q})
    seen=[]
    monkeypatch.setattr(w,'set_tenant_context',lambda db,tid: seen.append(tid))
    assert w.process_notification_deliveries(db,10,tenant_id='tenant-a') == 0
    assert seen == ['tenant-a']
    assert len(q.filters) >= 1


def test_whatsapp_worker_scopes_tenant(monkeypatch):
    import app.worker as w
    row=SimpleNamespace(direction='OUTBOUND',status='QUEUED',created_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc),tenant_id='tenant-b',channel_id='x',error_message=None)
    q=Q([row]); db=DB({w.WhatsAppMessage:q})
    seen=[]
    monkeypatch.setattr(w,'set_tenant_context',lambda db,tid: seen.append(tid))
    assert w.process_whatsapp_deliveries(db,10,tenant_id='tenant-b') == 0
    assert seen == ['tenant-b']
    assert len(q.filters) >= 1


def test_workflow_webhook_worker_scopes_tenant(monkeypatch):
    import app.services.workflow_webhooks as ww
    q=Q([]); db=DB({ww.WorkflowWebhookDelivery:q})
    seen=[]
    monkeypatch.setattr('app.core.database.set_tenant_context',lambda db,tid: seen.append(tid))
    assert ww.process_workflow_webhook_deliveries(db,10,tenant_id='tenant-c') == 0
    assert seen == ['tenant-c']
    assert len(q.filters) >= 1


def test_run_once_does_not_use_unscoped_notification_delivery(monkeypatch):
    import app.worker as w
    # Static regression guard: the top-level delivery block must not process tenant-RLS tables.
    src=__import__('inspect').getsource(w.run_once)
    assert "process_notification_deliveries(webhook_db, batch_size=50)" not in src
    assert "process_whatsapp_deliveries(webhook_db, batch_size=50)" not in src
