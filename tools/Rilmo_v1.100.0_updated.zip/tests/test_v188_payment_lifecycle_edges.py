def _merchant_order_paid(client, email, amount=2000):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'M'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'item', 'title': 'Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'SKU-1', 'price_amount_minor': amount, 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=10&reason=test", headers=h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c['id']}).json()
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'order_id': order['id'], 'amount_minor': order['total_minor'], 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h)
    return tid, h, order, pi


# --- refund edge cases -----------------------------------------------

def test_refund_rejects_nonpositive_amount(client):
    tid, h, order, pi = _merchant_order_paid(client, 'refund-neg@example.com')
    r = client.post(f'/v1/refunds?tenant_id={tid}', headers=h, json={
        'order_id': order['id'], 'payment_intent_id': pi['id'], 'amount_minor': 0, 'currency': 'USD', 'provider': 'mock',
    })
    # Rejected either at the schema layer (422) or the business-rule layer (400)
    assert r.status_code in {400, 422}

def test_refund_rejects_currency_mismatch(client):
    tid, h, order, pi = _merchant_order_paid(client, 'refund-ccy@example.com')
    r = client.post(f'/v1/refunds?tenant_id={tid}', headers=h, json={
        'order_id': order['id'], 'payment_intent_id': pi['id'], 'amount_minor': 100, 'currency': 'EUR', 'provider': 'mock',
    })
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'CURRENCY_MISMATCH'

def test_refund_rejects_amount_exceeding_captured_total(client):
    tid, h, order, pi = _merchant_order_paid(client, 'refund-cap2@example.com', amount=1000)
    r = client.post(f'/v1/refunds?tenant_id={tid}', headers=h, json={
        'order_id': order['id'], 'payment_intent_id': pi['id'], 'amount_minor': 999999, 'currency': 'USD', 'provider': 'mock',
    })
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'REFUND_CAP'

def test_refund_rejects_mismatched_order_and_payment(client):
    tid, h, order, pi = _merchant_order_paid(client, 'refund-mismatch@example.com')
    tid2, h2, order2, pi2 = _merchant_order_paid(client, 'refund-mismatch2@example.com')
    r = client.post(f'/v1/refunds?tenant_id={tid}', headers=h, json={
        'order_id': order['id'], 'payment_intent_id': pi2['id'], 'amount_minor': 100, 'currency': 'USD', 'provider': 'mock',
    })
    assert r.status_code in {404, 409}

def test_refund_full_amount_marks_order_and_payment_refunded(client):
    tid, h, order, pi = _merchant_order_paid(client, 'refund-full@example.com', amount=2000)
    r = client.post(f'/v1/refunds?tenant_id={tid}', headers=h, json={
        'order_id': order['id'], 'payment_intent_id': pi['id'], 'amount_minor': order['total_minor'], 'currency': 'USD', 'provider': 'mock',
    })
    assert r.status_code == 200, r.text
    pay = client.get(f"/v1/payments/{pi['id']}?tenant_id={tid}", headers=h)
    if pay.status_code == 200:
        assert pay.json()['status'] == 'REFUNDED'

def test_refund_is_idempotent_with_same_key(client):
    tid, h, order, pi = _merchant_order_paid(client, 'refund-idem@example.com')
    payload = {'order_id': order['id'], 'payment_intent_id': pi['id'], 'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}
    r1 = client.post(f'/v1/refunds?tenant_id={tid}', headers={**h, 'Idempotency-Key': 'refund-once'}, json=payload)
    r2 = client.post(f'/v1/refunds?tenant_id={tid}', headers={**h, 'Idempotency-Key': 'refund-once'}, json=payload)
    assert r1.status_code == 200
    assert r2.status_code == 200
    assert r1.json()['id'] == r2.json()['id']

def test_refund_requires_orders_refund_permission(client):
    m = client.post('/v1/auth/register', json={'email': 'refund-perm-owner@example.com', 'password': 'VerySecurePassword123!'}).json()
    tid, h, order, pi = _merchant_order_paid(client, 'refund-perm2@example.com')
    r = client.post(f'/v1/refunds?tenant_id={tid}', headers={'Authorization': 'Bearer ' + m['access_token']}, json={
        'order_id': order['id'], 'payment_intent_id': pi['id'], 'amount_minor': 100, 'currency': 'USD', 'provider': 'mock',
    })
    assert r.status_code in {403, 404}


# --- void edge cases ----------------------------------------------------

def test_void_rejects_already_captured_payment(client):
    tid, h, order, pi = _merchant_order_paid(client, 'void-captured@example.com')
    r = client.post(f"/v1/payments/{pi['id']}/void?tenant_id={tid}", headers=h)
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'PAYMENT_ALREADY_CAPTURED'

def test_void_on_uncaptured_payment_succeeds(client):
    m = client.post('/v1/auth/register', json={'email': 'void-fresh@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()
    r = client.post(f"/v1/payments/{pi['id']}/void?tenant_id={tid}", headers=h)
    assert r.status_code == 200, r.text

def test_void_is_idempotent_when_already_voided(client):
    m = client.post('/v1/auth/register', json={'email': 'void-twice@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()
    r1 = client.post(f"/v1/payments/{pi['id']}/void?tenant_id={tid}", headers=h)
    r2 = client.post(f"/v1/payments/{pi['id']}/void?tenant_id={tid}", headers=h)
    assert r1.status_code == 200
    assert r2.status_code == 200

def test_void_requires_finance_permission_for_staff_without_it(client):
    m = client.post('/v1/auth/register', json={'email': 'void-perm-owner@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()
    other = client.post('/v1/auth/register', json={'email': 'void-perm-other@example.com', 'password': 'VerySecurePassword123!'}).json()
    r = client.post(f"/v1/payments/{pi['id']}/void?tenant_id={tid}", headers={'Authorization': 'Bearer ' + other['access_token']})
    assert r.status_code in {403, 404}

def test_void_missing_payment_returns_not_found(client):
    m = client.post('/v1/auth/register', json={'email': 'void-missing@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    r = client.post(f'/v1/payments/does-not-exist/void?tenant_id={tid}', headers=h)
    assert r.status_code == 404


# --- capture edge cases --------------------------------------------------

def test_capture_is_idempotent_returns_captured_on_second_call(client):
    m = client.post('/v1/auth/register', json={'email': 'capture-idem@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()
    r1 = client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h)
    r2 = client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h)
    assert r1.status_code == 200
    assert r2.status_code == 200
    assert r2.json()['status'] == 'CAPTURED'

def test_capture_missing_payment_returns_not_found(client):
    m = client.post('/v1/auth/register', json={'email': 'capture-missing@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    r = client.post(f'/v1/payments/does-not-exist/capture?tenant_id={tid}', headers=h)
    assert r.status_code == 404

def test_capture_requires_authentication_or_guest_session(client):
    m = client.post('/v1/auth/register', json={'email': 'capture-noauth@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()
    guest_client = client.__class__(client.app)
    r = guest_client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}")
    assert r.status_code == 403
