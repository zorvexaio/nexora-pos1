from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_production_launch_pack_exists_and_is_fail_closed():
    pack = (ROOT / 'docs' / 'PRODUCTION_LAUNCH_PACK_V1_63.md').read_text()
    preflight = (ROOT / 'scripts' / 'production_preflight.py').read_text()
    assert 'legal/tax/payment' in pack.lower()
    assert 'PRODUCTION_PREFLIGHT_FAIL' in preflight
    assert 'COOKIE_SECURE must be true' in preflight
    assert 'CARD_INSTALLMENT_SAME_PRICE_ONLY' in preflight
    assert 'AI_EXTERNAL_PROVIDER_ALLOWED' in preflight
