from datetime import datetime, timezone
from types import SimpleNamespace

import pytest


def test_monthly_report_unique_race_is_non_fatal(monkeypatch):
    from sqlalchemy.exc import IntegrityError
    import app.worker as worker
    import app.services.advanced as advanced
    monkeypatch.setattr(advanced, 'platform_metrics', lambda *a, **k: {})

    class Query:
        def filter_by(self, **kwargs):
            return self
        def first(self):
            return None
        def all(self):
            return []
        def filter(self, *args, **kwargs):
            return self
        def join(self, *args, **kwargs):
            return self
        def count(self):
            return 0
        def scalar(self):
            return 0

    class DB:
        def __init__(self):
            self.flushed = False
            self.rolled_back = False
        def query(self, *args, **kwargs):
            return Query()
        def add(self, obj):
            pass
        def flush(self):
            self.flushed = True
            raise IntegrityError('INSERT', {}, Exception('unique'))
        def rollback(self):
            self.rolled_back = True
        def commit(self):
            raise AssertionError('must not commit after uniqueness race')

    db = DB()
    fake_now = datetime(2026, 8, 1, tzinfo=timezone.utc)
    monkeypatch.setattr(worker, 'datetime', SimpleNamespace(
        now=lambda tz=None: fake_now,
        strptime=datetime.strptime,
    ))
    monkeypatch.setattr(worker, 'platform_metrics', lambda *a, **k: {}) if hasattr(worker, 'platform_metrics') else None
    # The function imports platform_metrics/send_email locally, so the flush happens
    # before either external side effect and is the important race boundary.
    assert worker.run_platform_monthly_report(db) is False
    assert db.flushed and db.rolled_back


def test_worker_does_not_send_webhooks_inside_event_transaction(monkeypatch):
    """The source must commit the event before starting network delivery."""
    from pathlib import Path
    text = Path('app/worker.py').read_text()
    commit_pos = text.index('db.commit()', text.index('ev.status = \'PROCESSED\''))
    delivery_pos = text.index('process_webhook_deliveries(', commit_pos)
    assert commit_pos < delivery_pos
    assert 'delivery_db = SessionLocal()' in text[commit_pos:delivery_pos + 300]


def test_worker_keeps_workflow_delivery_processing_outside_event_transaction():
    from pathlib import Path
    text = Path('app/worker.py').read_text()
    commit_pos = text.index('db.commit()', text.index('ev.status = \'PROCESSED\''))
    delivery_pos = text.index('process_workflow_webhook_deliveries(', commit_pos)
    assert commit_pos < delivery_pos
    assert 'delivery_db.close()' in text[delivery_pos:delivery_pos + 500]
