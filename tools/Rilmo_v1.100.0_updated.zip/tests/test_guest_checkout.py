from datetime import datetime, timezone

def test_guest_cart_is_tenant_bound_and_checkout_works(client):
    merchant = client.post('/v1/auth/register', json={'email': 'guest-merchant@example.com', 'password': 'VerySecurePassword123!', 'display_name': 'Merchant'}).json()
    h = {'Authorization': 'Bearer ' + merchant['access_token']}
    tid = merchant['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'guest-item', 'title': 'Guest Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'GUEST-1', 'price_amount_minor': 1250, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=3&reason=test", headers=h)
    guest_client = client.__class__(client.app)
    cart_resp = guest_client.post(f'/v1/cart?tenant_id={tid}')
    assert cart_resp.status_code == 200
    assert 'guest_session' in guest_client.cookies
    cart = cart_resp.json()
    add = guest_client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", json={'variant_id': v['id'], 'quantity': 1})
    assert add.status_code == 200
    checkout = guest_client.post(f'/v1/checkout?tenant_id={tid}', json={'cart_id': cart['id'], 'customer_email': 'buyer@example.com', 'customer_name': 'Buyer'})
    assert checkout.status_code == 200, checkout.text
    order = checkout.json()
    assert order['customer_email_snapshot'] == 'buyer@example.com'
    assert order['guest_session_id'] is not None if 'guest_session_id' in order else True

def test_guest_cannot_use_another_guest_cart(client):
    m = client.post('/v1/auth/register', json={'email': 'guest-owner@example.com', 'password': 'VerySecurePassword123!'}).json()
    tid = m['tenant']['id']
    h = {'Authorization': 'Bearer ' + m['access_token']}
    g1 = client.__class__(client.app)
    r = g1.post(f'/v1/cart?tenant_id={tid}')
    cart = r.json()
    g2 = client.__class__(client.app)
    r2 = g2.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", json={'variant_id': 'missing', 'quantity': 1})
    assert r2.status_code in {403, 404}
