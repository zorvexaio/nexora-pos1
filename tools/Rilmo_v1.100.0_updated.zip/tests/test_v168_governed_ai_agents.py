from tests.test_p0 import register
from app.core.database import SessionLocal
from app.models.domain import TenantAIPolicy, AIDailyUsage, Product

def h(x): return {'Authorization': f"Bearer {x['access_token']}"}

def test_ai_policy_defaults_and_can_be_disabled(client):
    x=register(client,'ai-policy-v168@example.com'); tid=x['tenant']['id']
    r=client.get('/v1/ai/policy',params={'tenant_id':tid},headers=h(x)); assert r.status_code==200
    assert r.json()['enabled'] is True and r.json()['customer_agent_enabled'] is True
    r=client.put('/v1/ai/policy',params={'tenant_id':tid},headers=h(x),json={'enabled':False})
    assert r.status_code==200
    r=client.post('/v1/ai/agents/merchant/run',params={'tenant_id':tid,'question':'ما أفضل منتج؟'},headers=h(x)); assert r.status_code==200
    assert r.json()['ai_enabled'] is False and r.json()['provider']=='rules'

def test_ai_agent_has_no_write_tools(client):
    x=register(client,'ai-capabilities-v168@example.com'); tid=x['tenant']['id']
    r=client.get('/v1/ai/agents/merchant/capabilities',params={'tenant_id':tid},headers=h(x)); assert r.status_code==200
    b=r.json(); assert b['write_tools']==[] and 'payment.refund' in b['forbidden_tools'] and 'kyc.read' in b['forbidden_tools']
    assert b['execution_mode']=='PROPOSE_ONLY'

def test_ai_daily_quota_is_tenant_scoped(client):
    x=register(client,'ai-quota-v168@example.com'); tid=x['tenant']['id']
    r=client.put('/v1/ai/policy',params={'tenant_id':tid},headers=h(x),json={'daily_request_limit':1}); assert r.status_code==200
    r1=client.post('/v1/ai/agents/merchant/run',params={'tenant_id':tid,'question':'حلل المتجر'},headers=h(x)); assert r1.status_code==200
    r2=client.post('/v1/ai/agents/merchant/run',params={'tenant_id':tid,'question':'حلل المتجر مرة أخرى'},headers=h(x)); assert r2.status_code==429
    db=SessionLocal(); rows=db.query(AIDailyUsage).filter_by(tenant_id=tid,agent_role='merchant').all(); assert rows[0].requests_count==1 and rows[0].blocked_count==1; db.close()

def test_ai_context_does_not_include_forbidden_financial_or_kyc_fields(client, monkeypatch):
    x=register(client,'ai-context-v168@example.com'); tid=x['tenant']['id']; captured={}
    import app.services.advanced as adv
    def fake(prompt, **kwargs): captured['prompt']=prompt; return '{"answer":"ok","suggested_actions":[],"recommended_product_ids":[]}', 'fake', 'test'
    monkeypatch.setattr(adv, '_bounded_ai_text', fake)
    r=client.post('/v1/ai/agents/merchant/run',params={'tenant_id':tid,'question':'اعطني البيانات'},headers=h(x)); assert r.status_code==200
    p=captured['prompt']; payload=p.split('\n',1)[-1]; assert 'payment.raw' not in payload and 'KYC' not in payload and 'credentials' not in payload and 'secret' not in payload.lower()

def test_ai_policy_audit_and_usage_endpoints(client):
    x=register(client,'ai-audit-v168@example.com'); tid=x['tenant']['id']
    client.post('/v1/ai/agents/merchant/run',params={'tenant_id':tid,'question':'تحليل'},headers=h(x))
    r=client.get('/v1/ai/usage',params={'tenant_id':tid},headers=h(x)); assert r.status_code==200
    assert any(i['agent_role']=='merchant' for i in r.json()['items'])


def test_public_customer_agent_uses_customer_governance_and_hides_product_ids(client):
    from datetime import datetime, timezone
    from app.models.domain import Domain, Storefront, Tenant, Product
    x=register(client,'ai-customer-v168@example.com'); tid=x['tenant']['id']; host=f'customer-ai-{tid[:8]}.test'
    db=SessionLocal(); db.query(Tenant).filter_by(id=tid).update({'status':'ACTIVE'}); sf=db.query(Storefront).filter_by(tenant_id=tid).first(); sf.status='PUBLISHED'
    db.add(Domain(tenant_id=tid, storefront_id=sf.id, hostname=host, verified_at=datetime.now(timezone.utc)))
    p=Product(tenant_id=tid, slug='customer-ai-product', title='Blue Mug', description='Ceramic mug', status='ACTIVE'); db.add(p); db.commit(); pid=p.id; db.close()
    r=client.post(f'/v1/public/storefront/{host}/assistant',json={'question':'ابحث عن كوب أزرق'}); assert r.status_code==200
    assert pid not in r.json().get('recommended_product_ids', [])


def test_product_ai_is_governed_by_merchant_policy(client, monkeypatch):
    x=register(client,'ai-product-governance-v169@example.com'); tid=x['tenant']['id']
    from app.models.domain import Product
    db=SessionLocal(); p=Product(tenant_id=tid,slug='governed-product',title='Governed Product',description='A simple product',status='ACTIVE'); db.add(p); db.commit(); pid=p.id; db.close()
    r=client.put('/v1/ai/policy',params={'tenant_id':tid},headers=h(x),json={'enabled':False}); assert r.status_code==200
    import app.services.advanced as adv
    def forbidden(*args, **kwargs): raise AssertionError('provider must not be called when AI is disabled')
    monkeypatch.setattr(adv, '_bounded_ai_text', forbidden)
    r=client.post('/v1/ai/products/%s/generate'%pid,params={'tenant_id':tid,'apply':'false'},headers=h(x)); assert r.status_code==200
    assert r.json()['provider']=='rules'


def test_public_customer_ai_does_not_send_order_financial_fields(client, monkeypatch):
    from datetime import datetime, timezone
    from app.models.domain import Domain, Storefront, Tenant, Customer, CustomerSession, Order
    from app.core.security import token_hash
    x=register(client,'ai-customer-finance-boundary-v169@example.com'); tid=x['tenant']['id']; host=f'customer-finance-{tid[:8]}.test'
    db=SessionLocal(); db.query(Tenant).filter_by(id=tid).update({'status':'ACTIVE'}); sf=db.query(Storefront).filter_by(tenant_id=tid).first(); sf.status='PUBLISHED'
    db.add(Domain(tenant_id=tid, storefront_id=sf.id, hostname=host, verified_at=datetime.now(timezone.utc)))
    c=Customer(tenant_id=tid,email='buyer-v169@example.com'); db.add(c); db.flush()
    raw='customer-session-v169'; db.add(CustomerSession(tenant_id=tid,customer_id=c.id,token_hash=token_hash(raw),expires_at=datetime.now(timezone.utc).replace(year=2030)))
    o=Order(tenant_id=tid,order_number='ORD-FIN-169',status='CONFIRMED',payment_status='PAID',fulfillment_status='SHIPPED',currency='USD',subtotal_minor=9999,discount_minor=0,shipping_minor=0,tax_minor=0,fee_minor=0,total_minor=9999,customer_id=c.id)
    db.add(o); db.commit(); db.close()
    captured={}
    import app.services.advanced as adv
    def fake(prompt, **kwargs): captured['prompt']=prompt; return '{"answer":"ok","suggested_actions":[],"recommended_product_ids":[]}', 'fake', 'test'
    monkeypatch.setattr(adv, '_bounded_ai_text', fake)
    client.cookies.set('customer_session', raw)
    r=client.post(f'/v1/public/storefront/{host}/assistant',json={'question':'أين طلبي؟'}); assert r.status_code==200
    p=captured['prompt']; assert '9999' not in p and 'payment_status' not in p and 'total_minor' not in p


def test_agent_tool_registry_is_deny_by_default_and_read_only():
    from app.services.advanced import agent_capabilities, execute_agent_tool
    c=agent_capabilities('merchant'); assert 'inventory.summary' in c['read_tools']; assert c['write_tools']==[]
    assert execute_agent_tool('merchant','inventory.summary',context={'inventory_summary':{'active_variants':3}})['active_variants']==3
    import pytest
    with pytest.raises(Exception): execute_agent_tool('merchant','inventory.write',context={})
