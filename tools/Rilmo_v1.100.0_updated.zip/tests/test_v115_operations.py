from tests.test_p0 import register

def headers(x):
    return {'Authorization': f"Bearer {x['access_token']}"}

def test_onboarding_support_workflow_and_tenant_isolation(client):
    a = register(client, 'ops-a@example.com')
    h = headers(a)
    tid = a['tenant']['id']
    r = client.get('/v1/onboarding/status', params={'tenant_id': tid}, headers=h)
    assert r.status_code == 200 and r.json()['total'] >= 6
    r = client.post('/v1/onboarding/complete/store_profile', params={'tenant_id': tid}, json={}, headers=h)
    assert r.status_code == 200
    r = client.post('/v1/support/tickets', params={'tenant_id': tid}, json={'subject': 'Need help', 'body': 'Merchant support request', 'priority': 'HIGH', 'category': 'GENERAL'}, headers=h)
    assert r.status_code == 200
    ticket = r.json()
    assert ticket['ticket_number'].startswith('TKT-')
    r = client.get('/v1/support/tickets', params={'tenant_id': tid}, headers=h)
    assert r.status_code == 200 and r.json()['items']
    r = client.post('/v1/workflows', params={'tenant_id': tid}, json={'slug': 'order-followup', 'name': 'Order followup', 'trigger_event': 'order.created', 'enabled': True, 'steps': []}, headers=h)
    assert r.status_code == 200
    wid = r.json()['id']
    r = client.post(f'/v1/workflows/{wid}/run', params={'tenant_id': tid}, json={'input_payload': {'order_id': 'x'}}, headers=h)
    assert r.status_code == 200 and r.json()['status'] == 'QUEUED'
    b = register(client, 'ops-b@example.com')
    hb = headers(b)
    tidb = b['tenant']['id']
    r = client.get('/v1/support/tickets', params={'tenant_id': tidb}, headers=hb)
    assert r.status_code == 200 and r.json()['items'] == []
    r = client.get('/v1/onboarding/status', params={'tenant_id': tidb}, headers=hb)
    assert r.status_code == 200 and r.json()['completed'] >= 1

def test_onboarding_is_evidence_driven_and_workflow_is_executable(client):
    a = register(client, 'ops-c@example.com')
    h = headers(a)
    tid = a['tenant']['id']
    r = client.post('/v1/onboarding/complete/first_product', params={'tenant_id': tid}, headers=h)
    assert r.status_code == 409
    r = client.get('/v1/themes/starters', params={'tenant_id': tid}, headers=h)
    assert r.status_code == 200 and len(r.json()['items']) >= 5

def test_workflow_run_is_completed_by_worker(client):
    a = register(client, 'ops-worker@example.com')
    h = headers(a)
    tid = a['tenant']['id']
    r = client.post('/v1/workflows', params={'tenant_id': tid}, json={'slug': 'worker-flow', 'name': 'Worker Flow', 'trigger_event': 'order.created', 'enabled': True, 'steps': []}, headers=h)
    assert r.status_code == 200
    wid = r.json()['id']
    r = client.post(f'/v1/workflows/{wid}/run', params={'tenant_id': tid}, json={'input_payload': {}}, headers=h)
    assert r.status_code == 200
    run_id = r.json()['id']
    from app.worker import run_once
    run_once(max_attempts=2)
    from app.core.database import SessionLocal
    from app.models.domain import WorkflowRun
    db = SessionLocal()
    try:
        row = db.get(WorkflowRun, run_id)
        assert row is not None and row.status == 'COMPLETED'
    finally:
        db.close()

def test_support_ticket_numbers_are_collision_resistant(client):
    a = register(client, 'ops-ticket@example.com')
    h = headers(a)
    tid = a['tenant']['id']
    numbers = []
    for i in range(10):
        r = client.post('/v1/support/tickets', params={'tenant_id': tid}, json={'subject': f'Need help {i}', 'body': 'Support request', 'priority': 'NORMAL', 'category': 'GENERAL'}, headers=h)
        assert r.status_code == 200
        numbers.append(r.json()['ticket_number'])
    assert len(numbers) == len(set(numbers))

def test_manual_workflow_run_is_idempotent_and_queue_event_is_unique(client):
    a = register(client, 'ops-workflow-idem@example.com')
    h = headers(a)
    tid = a['tenant']['id']
    r = client.post('/v1/workflows', params={'tenant_id': tid},
        json={'slug': 'manual-idem', 'name': 'Manual Idem', 'trigger_event': 'order.created',
              'enabled': True, 'steps': []}, headers=h)
    assert r.status_code == 200
    wid = r.json()['id']
    request = {'input_payload': {'order_id': 'same-order'}}
    idem = {**h, 'Idempotency-Key': 'manual-run-1'}
    r1 = client.post(f'/v1/workflows/{wid}/run', params={'tenant_id': tid}, json=request, headers=idem)
    assert r1.status_code == 200
    r2 = client.post(f'/v1/workflows/{wid}/run', params={'tenant_id': tid}, json=request, headers=idem)
    assert r2.status_code == 200
    assert r2.json() == r1.json()

    from app.core.database import SessionLocal
    from app.models.domain import OutboxEvent, WorkflowRun
    db = SessionLocal()
    try:
        assert db.query(WorkflowRun).filter_by(tenant_id=tid, workflow_id=wid).count() == 1
        assert db.query(OutboxEvent).filter_by(tenant_id=tid, event_type='workflow.run.queued').count() == 1
        queued = db.query(OutboxEvent).filter_by(tenant_id=tid, event_type='workflow.run.queued').one()
        assert queued.dedupe_key == f'workflow.manual.run.queued:{tid}:{wid}:manual-run-1'
    finally:
        db.close()

