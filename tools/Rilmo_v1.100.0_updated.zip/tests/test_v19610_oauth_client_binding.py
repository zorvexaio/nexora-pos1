import base64, hashlib, urllib.parse, secrets


def _h(x):
    return {'Authorization': 'Bearer ' + x['access_token']}


def _pkce(verifier):
    return base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()


def _app(client_id, secret, slug):
    from app.core.database import SessionLocal
    from app.models.domain import AppDefinition
    from app.core.security import token_hash
    db = SessionLocal()
    try:
        row = AppDefinition(
            name=slug,
            slug=slug,
            client_id=client_id,
            client_secret_hash=token_hash(secret),
            redirect_uris=['https://example.com/cb'],
            scopes=['store.read'],
            status='APPROVED',
        )
        db.add(row)
        db.commit()
        return row.id
    finally:
        db.close()


def test_oauth_authorize_requires_apps_manage(client):
    from tests.test_p0 import register
    owner = register(client, 'v19610-oauth-owner@example.com')
    staff = register(client, 'v19610-oauth-staff@example.com')
    tid = owner['tenant']['id']
    assert client.post(
        '/v1/members', params={'tenant_id': tid}, headers=_h(owner),
        json={'email': staff['user']['email'], 'role': 'staff'}
    ).status_code == 200
    secret = 'secret-' + secrets.token_urlsafe(10)
    _app('client-v19610-perm', secret, 'v19610-perm')
    verifier = 'verifier-' + secrets.token_urlsafe(16)
    challenge = _pkce(verifier)
    r = client.get('/v1/oauth/authorize', params={
        'client_id': 'client-v19610-perm',
        'redirect_uri': 'https://example.com/cb',
        'response_type': 'code',
        'scope': 'store.read',
        'state': 'state',
        'code_challenge': challenge,
        'code_challenge_method': 'S256',
        'tenant_id': tid,
    }, headers=_h(staff), follow_redirects=False)
    assert r.status_code == 302


def test_oauth_refresh_token_is_client_bound(client):
    from tests.test_p0 import register
    owner = register(client, 'v19610-refresh-owner@example.com')
    tid = owner['tenant']['id']
    secret_a = 'secret-a-' + secrets.token_urlsafe(10)
    secret_b = 'secret-b-' + secrets.token_urlsafe(10)
    _app('client-v19610-a', secret_a, 'v19610-a')
    _app('client-v19610-b', secret_b, 'v19610-b')

    verifier = 'verifier-' + secrets.token_urlsafe(16)
    challenge = _pkce(verifier)
    r = client.get('/v1/oauth/authorize', params={
        'client_id': 'client-v19610-a',
        'redirect_uri': 'https://example.com/cb',
        'response_type': 'code',
        'scope': 'store.read',
        'state': 'state',
        'code_challenge': challenge,
        'code_challenge_method': 'S256',
        'tenant_id': tid,
    }, headers=_h(owner), follow_redirects=False)
    assert r.status_code == 302
    code = urllib.parse.parse_qs(urllib.parse.urlsplit(r.headers['location']).query)['code'][0]
    tok = client.post('/v1/oauth/token', data={
        'grant_type': 'authorization_code',
        'client_id': 'client-v19610-a',
        'client_secret': secret_a,
        'code': code,
        'redirect_uri': 'https://example.com/cb',
        'code_verifier': verifier,
    })
    assert tok.status_code == 200
    refresh = tok.json()['refresh_token']
    cross = client.post('/v1/oauth/token', data={
        'grant_type': 'refresh_token',
        'client_id': 'client-v19610-b',
        'client_secret': secret_b,
        'refresh_token': refresh,
    })
    assert cross.status_code == 400
    assert cross.json()['detail']['error']['code'] == 'OAUTH_REFRESH_CLIENT_MISMATCH'

    same = client.post('/v1/oauth/token', data={
        'grant_type': 'refresh_token',
        'client_id': 'client-v19610-a',
        'client_secret': secret_a,
        'refresh_token': refresh,
    })
    assert same.status_code == 200
