from app.services.legal_compliance import policy_for, build_ai_disclosure, validate_dsr_type

def test_2026_eu_ai_transparency_baseline():
    p=policy_for('EU-GDPR')
    assert p['ai_interaction_disclosure_required'] is True
    assert p['ai_generated_marking_required'] is True
    assert p['breach_authority_hours']==72
    assert 'ACCESS' in p['rights']

def test_turkey_transfer_and_dsr_baseline():
    p=policy_for('TR-KVKK')
    assert p['transfer_default']=='ADEQUACY_OR_STANDARD_CONTRACT'
    validate_dsr_type('TR-KVKK','ERASURE')

def test_ai_disclosure_is_machine_readable():
    d=build_ai_disclosure(locale='ar',provider='ollama',model='test')
    assert d['is_ai_generated'] is True
    assert d['machine_readable_marker']=='rilmo:ai-generated:v2'
    assert d['human_review'] is False

def test_rules_fallback_is_not_marked_as_external_generated_model():
    d=build_ai_disclosure(locale='en',provider='rules',model='rules-v3')
    assert d['is_ai_generated'] is False
