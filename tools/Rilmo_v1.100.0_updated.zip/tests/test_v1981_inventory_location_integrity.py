from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_checkout_accepts_explicit_inventory_location_and_rejects_ambiguous_stock():
    # checkout moved to checkout_routes.py in Phase 3 split
    src = (ROOT / 'app/routes/checkout_routes.py').read_text()
    assert "inventory_location_id: Optional[str]" in (ROOT / 'app/schemas/api.py').read_text()
    assert "if data.inventory_location_id:" in src
    assert "INVENTORY_LOCATION_REQUIRED" in src
    assert "INVENTORY_LOCATION_INVALID" in src


def test_inventory_reservation_is_location_aware_and_idempotency_bound_to_location():
    # moved to inventory_routes.py in Phase 3 split
    src = (ROOT / 'app/routes/inventory_routes.py').read_text()
    assert "def reserve(tenant_id: str, variant_id: str, quantity: int, order_id: str, location_id: str | None = None" in src
    assert "'location_id': location_id" in src
    assert "item_q = db.query(InventoryItem).filter_by(tenant_id=tenant_id, variant_id=variant_id)" in src
    assert "item_q.filter_by(location_id=location_id)" in src
    assert "Inventory location is required when a variant exists at multiple locations" in src


def test_inventory_adjustment_location_guard_remains_intact():
    # moved to inventory_routes.py in Phase 3 split
    src = (ROOT / 'app/routes/inventory_routes.py').read_text()
    assert "def adjust_inventory" in src
    assert "INVENTORY_LOCATION_REQUIRED" in src
    assert "item.available + delta < 0" in src
