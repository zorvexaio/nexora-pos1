from app.core.config import Settings
from app.services.advanced import AGENT_TOOL_REGISTRY, agent_capabilities


def test_ai_defaults_fail_closed_and_agent_registry_is_read_only():
    s = Settings()
    assert Settings.model_fields['AI_ENABLED'].default is False
    assert all(spec['mode'] == 'READ_ONLY' for spec in AGENT_TOOL_REGISTRY.values())
    for role in ('customer', 'merchant', 'platform'):
        caps = agent_capabilities(role)
        assert caps['write_tools'] == []
        assert caps['execution_mode'] == 'PROPOSE_ONLY'
