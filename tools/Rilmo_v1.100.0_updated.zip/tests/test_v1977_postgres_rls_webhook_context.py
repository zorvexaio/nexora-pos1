from types import SimpleNamespace

import pytest

from app.core.database import set_tenant_context
from app.routes import webhook_routes as v1  # webhooks moved here in Phase 3 split


def test_iyzico_sets_tenant_context_before_credentials(monkeypatch):
    calls = []

    monkeypatch.setattr(v1, 'resolve_provider_tenant', lambda *a, **k: 'tenant-1')
    monkeypatch.setattr(v1, 'provider_credentials', lambda tenant_id, provider, db: calls.append(('credentials', tenant_id, provider)) or {'secret_key': 's'})
    monkeypatch.setattr(v1, 'set_tenant_context', lambda db, tenant_id: calls.append(('context', tenant_id)))
    monkeypatch.setattr(v1, 'claim_webhook_event', lambda *a, **k: (_ for _ in ()).throw(RuntimeError('stop after routing')))
    import hmac, hashlib
    msg = 's' + 'PAYMENT_API' + 'p1' + '' + 'PENDING'
    signature = hmac.new(b's', msg.encode(), hashlib.sha256).hexdigest()
    monkeypatch.setattr(v1, 'body_hash', lambda body: 'h')

    req = SimpleNamespace(json=lambda: None, headers={'X-IYZ-SIGNATURE-V3': 'bad'})

    import asyncio
    async def run():
        class R:
            headers = {'X-IYZ-SIGNATURE-V3': signature}
            async def json(self):
                return {'paymentId': 'p1', 'status': 'PENDING'}
        return await v1.iyzico_webhook(R(), SimpleNamespace())

    with pytest.raises(RuntimeError, match='stop after routing'):
        asyncio.run(run())

    assert calls[:2] == [('context', 'tenant-1'), ('credentials', 'tenant-1', 'iyzico')]


def test_paddle_rejects_signed_metadata_binding_conflict(monkeypatch):
    monkeypatch.setattr(v1, 'resolve_provider_tenant', lambda *a, **k: 'tenant-bound')
    monkeypatch.setattr(v1, 'claim_webhook_event', lambda **k: pytest.fail('must fail before tenant event claim'))
    monkeypatch.setattr(v1, 'set_tenant_context', lambda *a, **k: pytest.fail('must fail before setting conflicting tenant context'))

    class Req:
        headers = {}
        async def body(self):
            import hmac, hashlib, time, json
            payload = {
                'event_id': 'evt-conflict',
                'event_type': 'subscription.updated',
                'data': {
                    'id': 'sub-conflict',
                    'custom_data': {'tenant_id': 'tenant-claimed'},
                },
            }
            raw = json.dumps(payload, separators=(',', ':')).encode()
            ts = int(time.time())
            secret = 'secret'
            Req.headers = {'Paddle-Signature': f'ts={ts};h1=' + hmac.new(secret.encode(), f'{ts}:'.encode()+raw, hashlib.sha256).hexdigest()}
            return raw

    from app.core.config import get_settings
    s = get_settings()
    monkeypatch.setattr(s, 'PADDLE_WEBHOOK_SECRET', 'secret', raising=False)

    import asyncio
    with pytest.raises(v1.AppError) as exc:
        asyncio.run(v1.paddle_webhook(Req(), SimpleNamespace()))
    assert exc.value.code == 'PROVIDER_REFERENCE_TENANT_CONFLICT'
