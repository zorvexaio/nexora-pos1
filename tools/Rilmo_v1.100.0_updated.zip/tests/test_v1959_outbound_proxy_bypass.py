from pathlib import Path


def test_security_sensitive_http_clients_disable_environment_proxies():
    root = Path(__file__).resolve().parents[1]
    targets = [
        root / 'app/services/shipping.py',
        root / 'app/services/payment_providers.py',
        root / 'app/services/notifications.py',
        root / 'app/services/merchant_trust.py',
        root / 'app/services/advanced.py',
        root / 'app/routes/advanced.py',
        root / 'app/routes/v1.py',
        root / 'app/services/domain_registrar.py',
    ]
    for path in targets:
        text = path.read_text(encoding='utf-8')
        assert 'httpx.Client(' not in text or 'trust_env=False' in text, path.name
        for marker in ("httpx.post(", "httpx.get("):
            if marker in text:
                assert 'trust_env=False' in text, f'{path} contains {marker} without proxy isolation'
