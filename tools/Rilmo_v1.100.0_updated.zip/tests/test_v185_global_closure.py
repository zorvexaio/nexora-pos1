from app.services.legal_compliance import build_ai_disclosure


def test_ai_disclosure_exposes_article_50_engineering_metadata():
    d = build_ai_disclosure(locale='en', provider='ollama', model='test', content_modality='video')
    assert d['is_ai_generated'] is True
    assert d['machine_readable_marker'] == 'rilmo:ai-generated:v2'
    assert d['content_provenance_required'] is True
    assert d['deepfake_disclosure_required'] is True


def test_ai_public_interest_text_requires_human_review_state():
    d = build_ai_disclosure(provider='ollama', model='test', content_modality='text', public_interest_context=True, human_review=False)
    assert d['public_interest_human_review_required'] is True
