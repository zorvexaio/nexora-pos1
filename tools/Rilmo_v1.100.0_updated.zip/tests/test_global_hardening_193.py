from app.security.policy import normalize_hostname, verification_txt_name
from app.services.payment_providers import get_payment_provider
from app.core.config import get_settings

def test_domain_verification_name_normalization():
    assert normalize_hostname('Shop.Example.COM.') == 'shop.example.com'
    assert verification_txt_name('Shop.Example.COM.') == '_unified-commerce-verify.shop.example.com'

def test_production_defaults_do_not_allow_mock(monkeypatch):
    s = get_settings()
    from app.schemas.api import PaymentIn
    assert PaymentIn(amount_minor=100, currency='USD').provider == 'iyzico'

def test_google_oauth_start_is_stateful(client, monkeypatch):
    from app.core.config import get_settings
    s = get_settings()
    monkeypatch.setattr(s, 'GOOGLE_CLIENT_ID', 'client-id')
    monkeypatch.setattr(s, 'GOOGLE_CLIENT_SECRET', 'client-secret')
    monkeypatch.setattr(s, 'GOOGLE_REDIRECT_URI', 'http://localhost:8000/v1/auth/google/callback')
    r = client.get('/v1/auth/google/start')
    assert r.status_code == 200
    body = r.json()
    assert body['authorization_url'].startswith('https://accounts.google.com/o/oauth2/v2/auth?')
    assert 'state=' in body['authorization_url'] and 'nonce=' in body['authorization_url']

def test_google_oauth_state_replay_is_rejected(client, monkeypatch):
    from app.core.config import get_settings
    s = get_settings()
    monkeypatch.setattr(s, 'GOOGLE_CLIENT_ID', 'client-id')
    monkeypatch.setattr(s, 'GOOGLE_CLIENT_SECRET', 'client-secret')
    monkeypatch.setattr(s, 'GOOGLE_REDIRECT_URI', 'http://localhost:8000/v1/auth/google/callback')
    r = client.get('/v1/auth/google/start')
    from urllib.parse import urlparse, parse_qs
    state = parse_qs(urlparse(r.json()['authorization_url']).query)['state'][0]
    client.cookies.delete('oauth_state')
    r2 = client.get('/v1/auth/google/callback', params={'code': 'x', 'state': state})
    assert r2.status_code == 400

def test_domain_dns_proof_is_enforced_when_enabled(client, monkeypatch):
    from app.core.config import get_settings
    import app.routes.tenant_setup_routes as routes  # moved here in Phase 3 split
    s = get_settings()
    monkeypatch.setattr(s, 'DOMAIN_VERIFICATION_MODE', 'dns')
    x = client.post('/v1/auth/register', json={'email': 'dns@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    r = client.post(f'/v1/domains/provision?tenant_id={tid}', headers=h, json={'hostname': 'shop.example.test'})
    assert r.status_code == 200
    body = r.json()
    token = body['verification']['record_value']
    did = body['domain']['id']
    monkeypatch.setattr(routes, 'verify_dns_txt', lambda *a, **k: False)
    bad = client.post(f'/v1/domains/{did}/verify', params={'tenant_id': tid, 'token': token}, headers=h)
    assert bad.status_code == 400
    monkeypatch.setattr(routes, 'verify_dns_txt', lambda *a, **k: True)
    good = client.post(f'/v1/domains/{did}/verify', params={'tenant_id': tid, 'token': token}, headers=h)
    assert good.status_code == 200

def test_google_oauth_requires_nonce_cookie(client, monkeypatch):
    from app.core.config import get_settings
    s = get_settings()
    monkeypatch.setattr(s, 'GOOGLE_CLIENT_ID', 'client-id')
    monkeypatch.setattr(s, 'GOOGLE_CLIENT_SECRET', 'client-secret')
    monkeypatch.setattr(s, 'GOOGLE_REDIRECT_URI', 'http://localhost:8000/v1/auth/google/callback')
    r = client.get('/v1/auth/google/start')
    from urllib.parse import urlparse, parse_qs
    state = parse_qs(urlparse(r.json()['authorization_url']).query)['state'][0]
    client.cookies.delete('oauth_nonce')
    r2 = client.get('/v1/auth/google/callback', params={'code': 'x', 'state': state})
    assert r2.status_code == 400
