from pathlib import Path
from types import SimpleNamespace


def _query_for(rows):
    class Query:
        def filter(self, *args, **kwargs):
            return self
        def order_by(self, *args, **kwargs):
            return self
        def limit(self, *args, **kwargs):
            return self
        def with_for_update(self, *args, **kwargs):
            return self
        def all(self):
            return rows
        def first(self):
            return rows[0] if rows else None
    return Query()


class _DB:
    bind = SimpleNamespace(dialect=SimpleNamespace(name='sqlite'))

    def __init__(self, rows):
        self.rows = rows
        self.commits = 0

    def query(self, model):
        return _query_for(self.rows)

    def commit(self):
        self.commits += 1

    def add(self, obj):
        pass


def test_notification_delivery_commits_processing_before_network(monkeypatch):
    import app.worker as worker
    row = SimpleNamespace(
        status='QUEUED', scheduled_at=None, created_at=None,
        channel='email', template_id=None, tenant_id='t1',
        recipient='a@example.com', payload={'x': 1},
        error_message=None, sent_at=None,
    )
    db = _DB([row])
    calls = []

    def fake_send(*args, **kwargs):
        calls.append(('send', db.commits, row.status))
        assert row.status == 'PROCESSING'
        assert db.commits == 1

    monkeypatch.setattr('app.services.mailer.send_email', fake_send)
    assert worker.process_notification_deliveries(db, 10) == 1
    assert row.status == 'SENT'
    assert db.commits == 2
    assert calls == [('send', 1, 'PROCESSING')]


def test_notification_ambiguous_failure_is_not_auto_retried(monkeypatch):
    import app.worker as worker
    row = SimpleNamespace(
        status='QUEUED', scheduled_at=None, created_at=None,
        channel='email', template_id=None, tenant_id='t1',
        recipient='a@example.com', payload={},
        error_message=None, sent_at=None,
    )
    db = _DB([row])

    def fake_send(*args, **kwargs):
        raise TimeoutError('smtp timeout after accept')

    monkeypatch.setattr('app.services.mailer.send_email', fake_send)
    assert worker.process_notification_deliveries(db, 10) == 0
    assert row.status == 'RECONCILIATION_REQUIRED'
    assert db.commits == 2


def test_whatsapp_delivery_uses_queued_template_metadata(monkeypatch):
    import app.worker as worker
    row = SimpleNamespace(
        status='QUEUED', direction='OUTBOUND', created_at=None,
        tenant_id='t1', channel_id='c1', recipient='+90555', body='hello',
        error_message=None, provider_message_id=None, sent_at=None,
        meta={'template_name': 'order_confirmed', 'template_params': ['ORD-1']},
    )
    channel = SimpleNamespace(id='c1', tenant_id='t1', status='ACTIVE')

    class Query:
        def __init__(self, rows): self._rows = rows
        def filter(self, *args, **kwargs): return self
        def filter_by(self, **kwargs): return self
        def order_by(self, *args, **kwargs): return self
        def limit(self, *args, **kwargs): return self
        def with_for_update(self, *args, **kwargs): return self
        def all(self): return self._rows
        def first(self): return self._rows[0] if self._rows else None

    class DB(_DB):
        def __init__(self): super().__init__([row])
        def query(self, model):
            name = getattr(model, '__name__', '')
            return Query([row] if name == 'WhatsAppMessage' else [channel])

    db = DB()
    seen = {}
    def fake_send(ch, recipient, body, template_name=None, template_params=None):
        seen.update(template_name=template_name, template_params=template_params, channel=ch.id)
        return 'provider-1', {'ok': True}
    monkeypatch.setattr('app.services.advanced.send_whatsapp', fake_send)
    assert worker.process_whatsapp_deliveries(db, 10) == 1
    assert seen == {'template_name': 'order_confirmed', 'template_params': ['ORD-1'], 'channel': 'c1'}
    assert row.status == 'SENT'


def test_worker_event_handlers_do_not_call_external_email_or_whatsapp_directly():
    text = Path('app/worker.py').read_text()
    event_section = text[text.index("if ev.event_type == 'order.confirmed'"):text.index("ev.status = 'PROCESSED'")]
    assert 'send_email(' not in event_section
    assert 'send_whatsapp(' not in event_section
    assert "WhatsAppMessage(" in event_section
    assert "NotificationDelivery" in event_section
