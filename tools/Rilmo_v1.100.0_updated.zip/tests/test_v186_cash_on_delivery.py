def _merchant_with_order(client, email):
    merchant = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'COD Merchant'}).json()
    h = {'Authorization': 'Bearer ' + merchant['access_token']}
    tid = merchant['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'cod-item', 'title': 'COD Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'COD-1', 'price_amount_minor': 5000, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    cart = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': cart['id'], 'customer_email': email, 'customer_name': 'Buyer'}).json()
    return tid, h, order


def test_cod_is_off_by_default_and_rejected_until_merchant_enables_it(client):
    tid, h, order = _merchant_with_order(client, 'cod-default-off@example.com')
    resp = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={
        'provider': 'cod', 'amount_minor': order['total_minor'], 'currency': order['currency'], 'order_id': order['id'],
    })
    assert resp.status_code == 409
    assert resp.json()['detail']['error']['code'] == 'MERCHANT_PAYMENT_ACCOUNT_REQUIRED'


def test_merchant_can_opt_in_to_cod_with_no_credentials_required(client):
    tid, h, order = _merchant_with_order(client, 'cod-optin@example.com')
    enable = client.post(f'/v1/merchant/payment-account/configure?tenant_id={tid}', headers=h, json={'provider': 'cod', 'credentials': {}})
    assert enable.status_code == 200, enable.text
    body = enable.json()
    assert body['provider'] == 'cod'
    assert body['status'] == 'ACTIVE'
    assert body['charges_enabled'] is True

    intent = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={
        'provider': 'cod', 'amount_minor': order['total_minor'], 'currency': order['currency'], 'order_id': order['id'],
    })
    assert intent.status_code == 200, intent.text
    pi = intent.json()
    assert pi['provider'] == 'cod'
    assert pi['status'] == 'PENDING'

    capture = client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h)
    assert capture.status_code == 200, capture.text
    assert capture.json()['status'] == 'CAPTURED'


def test_merchant_can_disable_cod_after_enabling_it(client):
    tid, h, order = _merchant_with_order(client, 'cod-disable@example.com')
    client.post(f'/v1/merchant/payment-account/configure?tenant_id={tid}', headers=h, json={'provider': 'cod', 'credentials': {}})
    off = client.post(f'/v1/merchant/payment-account/cod/disable?tenant_id={tid}', headers=h)
    assert off.status_code == 200, off.text
    assert off.json()['status'] == 'DISABLED'
    assert off.json()['charges_enabled'] is False

    intent = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={
        'provider': 'cod', 'amount_minor': order['total_minor'], 'currency': order['currency'], 'order_id': order['id'],
    })
    assert intent.status_code == 409
    assert intent.json()['detail']['error']['code'] == 'MERCHANT_PAYMENT_ACCOUNT_REQUIRED'


def test_cod_provider_is_a_distinct_class_not_the_forbidden_mock_provider():
    from app.services.payment_providers import get_payment_provider, CashOnDeliveryProvider, MockProvider
    provider = get_payment_provider('cod')
    assert isinstance(provider, CashOnDeliveryProvider)
    assert not isinstance(provider, MockProvider)
    assert provider.name == 'cod'
