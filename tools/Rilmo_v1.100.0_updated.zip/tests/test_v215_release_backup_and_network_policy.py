from pathlib import Path


def test_release_source_has_no_pre_version_backup_files():
    root = Path(__file__).resolve().parents[1]
    leaked = [p for p in (root / 'app').rglob('*') if p.is_file() and '.pre_' in p.name]
    assert leaked == []


def test_release_builder_and_hygiene_reject_pre_version_backup_patterns():
    build_text = (Path(__file__).resolve().parents[1] / 'scripts' / 'build_release.py').read_text()
    hygiene_text = (Path(__file__).resolve().parents[1] / 'scripts' / 'release_hygiene.py').read_text()
    assert 'BAD_BACKUP_PATTERNS' in build_text
    assert 'pre_[0-9]+' in build_text
    assert 'BAD_BACKUP_RE' in hygiene_text
    assert 'pre_[0-9]+' in hygiene_text
