from pathlib import Path
import pytest
from app.services.storage import LocalObjectStore
from app.core.errors import AppError


def test_local_object_store_rejects_traversal(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCAL_MEDIA_ROOT', str(tmp_path))
    store = LocalObjectStore()
    with pytest.raises(AppError):
        store.put('../outside.txt', b'x', 'text/plain')
    assert not (tmp_path.parent / 'outside.txt').exists()


def test_local_object_store_accepts_nested_key(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCAL_MEDIA_ROOT', str(tmp_path))
    store = LocalObjectStore()
    store.put('tenant-a/media/file.txt', b'abc', 'text/plain')
    assert (tmp_path / 'tenant-a/media/file.txt').read_bytes() == b'abc'
from unittest.mock import patch
from app.core.network import validate_outbound_url


def test_outbound_url_rejects_private_dns_resolution(monkeypatch):
    monkeypatch.setenv('ENVIRONMENT', 'staging')
    with patch('app.core.network.socket.getaddrinfo', return_value=[(2, 1, 6, '', ('127.0.0.1', 443))]):
        with pytest.raises(AppError):
            validate_outbound_url('https://example.com/api')


def test_outbound_url_accepts_public_dns(monkeypatch):
    monkeypatch.setenv('ENVIRONMENT', 'staging')
    with patch('app.core.network.socket.getaddrinfo', return_value=[(2, 1, 6, '', ('1.1.1.1', 443))]):
        assert validate_outbound_url('https://example.com/api') == 'https://example.com/api'
