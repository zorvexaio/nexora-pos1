def register(client, email='a@example.com'):
    r = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'A'})
    assert r.status_code == 200
    return r.json()

def test_auth_and_tenant(client):
    x = register(client)
    assert x['access_token']
    assert x['tenant']['status'] == 'PROVISIONING'
    assert 'password_hash' not in x['user']
    r = client.get('/v1/me', headers={'Authorization': f"Bearer {x['access_token']}"})
    assert r.status_code == 200

def test_product_cart_checkout_payment_refund(client):
    x = register(client, 'b@example.com')
    h = {'Authorization': f"Bearer {x['access_token']}"}
    tid = x['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'book', 'title': 'Book', 'status': 'ACTIVE'})
    assert p.status_code == 200
    v = client.post(f"/v1/products/{p.json()['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'BOOK-1', 'price_amount_minor': 1000, 'currency': 'USD', 'provider': 'mock'})
    assert v.status_code == 200
    stock = client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v.json()['id']}&delta=10&reason=test", headers=h)
    assert stock.status_code == 200
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    assert client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id': v.json()['id'], 'quantity': 2}).status_code == 200
    o = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c['id']}).json()
    assert o['total_minor'] == 2000
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'order_id': o['id'], 'amount_minor': 2000, 'currency': 'USD', 'provider': 'mock'}).json()
    assert client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h).status_code == 200
    rr = client.post(f'/v1/refunds?tenant_id={tid}', headers=h, json={'order_id': o['id'], 'payment_intent_id': pi['id'], 'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'})
    assert rr.status_code == 200

def test_refund_cap(client):
    x = register(client, 'c@example.com')
    h = {'Authorization': f"Bearer {x['access_token']}"}
    tid = x['tenant']['id']
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'amount_minor': 100, 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h)
    fake_order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': 'bad'})
    assert fake_order.status_code == 404

def test_security_headers(client):
    r = client.get('/v1/health')
    assert r.status_code == 200
    assert r.headers['x-content-type-options'] == 'nosniff'

def test_logout_revokes_bearer(client):
    x = register(client, 'logout@example.com')
    h = {'Authorization': f"Bearer {x['access_token']}"}
    assert client.get('/v1/me', headers=h).status_code == 200
    assert client.post('/v1/auth/logout', headers=h).status_code == 200
    assert client.get('/v1/me', headers=h).status_code == 403

def test_cross_tenant_idor_blocked(client):
    a = register(client, 'ta@example.com')
    b = register(client, 'tb@example.com')
    ha = {'Authorization': f"Bearer {a['access_token']}"}
    r = client.get(f"/v1/products?tenant_id={b['tenant']['id']}", headers=ha)
    assert r.status_code == 403

def test_idempotency_mismatch(client):
    x = register(client, 'idem@example.com')
    h = {'Authorization': f"Bearer {x['access_token']}"}
    tid = x['tenant']['id']
    p = {'amount_minor': 100, 'currency': 'USD', 'provider': 'mock'}
    r1 = client.post(f'/v1/payments/intents?tenant_id={tid}', headers={**h, 'Idempotency-Key': 'same'}, json=p)
    assert r1.status_code == 200
    r2 = client.post(f'/v1/payments/intents?tenant_id={tid}', headers={**h, 'Idempotency-Key': 'same'}, json={'amount_minor': 200, 'currency': 'USD', 'provider': 'mock'})
    assert r2.status_code == 409

def test_cookie_csrf_boundary(client):
    x = register(client, 'csrf@example.com')
    r = client.post(f'/v1/tenants', json={'slug': 'csrf-tenant', 'name': 'CSRF', 'default_currency': 'USD', 'default_locale': 'ar'})
    assert r.status_code == 403
