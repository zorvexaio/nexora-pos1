import io
import pytest
from PIL import Image


@pytest.fixture(autouse=True)
def _disable_malware_scan(monkeypatch):
    from app.services import malware
    monkeypatch.setattr(malware, 'scan_bytes', lambda content: None)


def _merchant(client, email):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'M'}).json()
    return m['tenant']['id'], {'Authorization': 'Bearer ' + m['access_token']}


def _real_png_bytes(width=800, height=600, color=(255, 0, 0)):
    buf = io.BytesIO()
    Image.new('RGB', (width, height), color).save(buf, format='PNG')
    return buf.getvalue()


# --- non-image upload -----------------------------------------------

def test_upload_non_image_file_creates_single_original_variant(client):
    tid, h = _merchant(client, 'media-nonimg@example.com')
    files = {'file': ('spec.pdf', b'%PDF-1.4 fake pdf content', 'application/pdf')}
    r = client.post(f'/v1/media?tenant_id={tid}', headers=h, files=files)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['mime_type'] == 'application/pdf'
    assert len(body['variants']) == 1
    assert body['variants'][0]['variant'] == 'original'
    assert body['storage_key'] == body['variants'][0]['storage_key']

def test_upload_missing_file_field_returns_error(client):
    tid, h = _merchant(client, 'media-nofile@example.com')
    r = client.post(f'/v1/media?tenant_id={tid}', headers=h, data={'alt_text': 'no file here'})
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'FILE_REQUIRED'

def test_upload_rejects_executable_disguised_as_upload(client):
    tid, h = _merchant(client, 'media-exe@example.com')
    files = {'file': ('malware.exe', b'MZ\x90\x00' + b'\x00' * 20, 'application/octet-stream')}
    r = client.post(f'/v1/media?tenant_id={tid}', headers=h, files=files)
    assert r.status_code == 422
    assert r.json()['detail']['error']['code'] == 'UPLOAD_INVALID'


# --- real image upload: multi-variant generation ---------------------

def test_upload_real_image_creates_all_size_variants_with_correct_original(client):
    tid, h = _merchant(client, 'media-image@example.com')
    files = {'file': ('photo.png', _real_png_bytes(2000, 1500), 'image/png')}
    r = client.post(f'/v1/media?tenant_id={tid}', headers=h, files=files)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['mime_type'] == 'image/webp'
    variant_names = {v['variant'] for v in body['variants']}
    assert variant_names == {'thumbnail', 'small', 'medium', 'large', 'original'}

    # Regression guard for the storage_key selection fix: the MediaAsset's
    # primary storage_key must point at the variant literally named
    # 'original', not whichever entry happened to occupy a hardcoded index.
    original_variant = next(v for v in body['variants'] if v['variant'] == 'original')
    assert body['storage_key'] == original_variant['storage_key']

def test_upload_image_thumbnail_is_smaller_than_original(client):
    tid, h = _merchant(client, 'media-thumbnail@example.com')
    files = {'file': ('photo.png', _real_png_bytes(2000, 1500), 'image/png')}
    r = client.post(f'/v1/media?tenant_id={tid}', headers=h, files=files).json()
    thumb = next(v for v in r['variants'] if v['variant'] == 'thumbnail')
    original = next(v for v in r['variants'] if v['variant'] == 'original')
    assert thumb['width'] < original['width']

def test_upload_rejects_corrupted_image_bytes(client):
    tid, h = _merchant(client, 'media-corrupt@example.com')
    files = {'file': ('broken.png', b'\x89PNG\r\n\x1a\n' + b'garbage-not-a-real-image', 'image/png')}
    r = client.post(f'/v1/media?tenant_id={tid}', headers=h, files=files)
    assert r.status_code == 422
    assert r.json()['detail']['error']['code'] == 'INVALID_IMAGE'


# --- delete ---------------------------------------------------------

def test_delete_media_removes_asset_and_variants(client):
    tid, h = _merchant(client, 'media-delete@example.com')
    files = {'file': ('photo.png', _real_png_bytes(400, 300), 'image/png')}
    uploaded = client.post(f'/v1/media?tenant_id={tid}', headers=h, files=files).json()
    r = client.delete(f"/v1/media/{uploaded['id']}?tenant_id={tid}", headers=h)
    assert r.status_code == 200
    assert r.json()['ok'] is True

def test_delete_media_missing_returns_not_found(client):
    tid, h = _merchant(client, 'media-deletemissing@example.com')
    r = client.delete(f'/v1/media/does-not-exist?tenant_id={tid}', headers=h)
    assert r.status_code == 404
