from app.services.legal_compliance import policy_for, validate_dsr_type


def test_unknown_jurisdiction_is_fail_closed():
    p = policy_for('ZZ-UNKNOWN')
    assert p['unknown_jurisdiction'] is True
    assert p['transfer_default'] == 'BLOCK_UNTIL_JURISDICTION_APPROVAL'
    assert p['ai_interaction_disclosure_required'] is True
    assert p['ai_generated_marking_required'] is True
    assert p['gpc_signal_respected'] is True


def test_dsr_aliases_follow_jurisdiction_vocabulary():
    validate_dsr_type('US-STATE-PRIVACY', 'DELETION')
    validate_dsr_type('TR-KVKK', 'ERASURE')
