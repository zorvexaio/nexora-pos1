import json
import httpx
import pytest
from app.services.payment_providers import IyzicoProvider, PayTRProvider, get_payment_provider
from app.core.config import get_settings

def test_iyzico_checkout_contract(monkeypatch):
    p=IyzicoProvider(api_key='test_key',secret_key='test_secret',base_url='https://mock.iyzico')
    p._post=lambda path,payload: {'status':'success','token':'tok-1','paymentPageUrl':'https://iyzico.example/checkout/tok-1'}
    r=p.create_intent(amount_minor=12500,currency='TRY',tenant_id='t1',order_id='o1',customer={'email':'buyer@example.com','phone':'+905000000001','name':'Buyer'},items=[{'reference_id':'SKU1','quantity':1,'name':'Item','unit_price':125}])
    assert r.provider_payment_id=='tok-1' and r.redirect_url.endswith('tok-1')

def test_paytr_token_contract():
    p=PayTRProvider(merchant_id='mid',merchant_key='key',merchant_salt='salt',base_url='https://mock.paytr')
    token=p.build_token(user_ip='127.0.0.1',merchant_oid='o1',email='buyer@example.com',payment_amount='125.00')
    assert token
    assert p.verify_callback(merchant_oid='o1',status='success',total_amount='12500',provided_hash=__import__('base64').b64encode(__import__('hmac').new(b'key',(b'o1salt' + b'success12500'),__import__('hashlib').sha256).digest()).decode())

def test_mock_provider_requires_explicit_local_or_test(monkeypatch):
    monkeypatch.setenv('ENVIRONMENT','production'); monkeypatch.setenv('ALLOW_LOCAL_MOCK_PAYMENTS','false'); get_settings.cache_clear()
    with pytest.raises(Exception): get_payment_provider('mock')
    monkeypatch.setenv('ENVIRONMENT','development'); monkeypatch.setenv('ALLOW_LOCAL_MOCK_PAYMENTS','true'); get_settings.cache_clear()
    assert get_payment_provider('mock').name=='mock'
    monkeypatch.setenv('ENVIRONMENT','test'); get_settings.cache_clear()


def test_paytr_uses_configured_test_mode_and_request_ip(monkeypatch):
    monkeypatch.setenv('ENVIRONMENT', 'test')
    monkeypatch.setenv('PAYTR_TEST_MODE', 'true')
    get_settings.cache_clear()
    captured = {}
    class Resp:
        status_code = 200
        content = b'{"status":"success","token":"tok"}'
        def json(self): return {"status":"success","token":"tok"}
    class Client:
        def __init__(self, *a, **k): pass
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def post(self, url, data): captured.update(data); return Resp()
    monkeypatch.setattr('httpx.Client', Client)
    p=PayTRProvider(merchant_id='mid',merchant_key='key',merchant_salt='salt',base_url='https://mock.paytr')
    p.create_intent(amount_minor=12500,currency='TRY',tenant_id='t1',order_id='o1',customer={'email':'buyer@example.com','ip_address':'203.0.113.10'},items=[])
    assert captured['user_ip'] == '203.0.113.10'
    assert captured['test_mode'] == '1'
    monkeypatch.setenv('PAYTR_TEST_MODE','false'); get_settings.cache_clear(); captured.clear()
    p2=PayTRProvider(merchant_id='mid',merchant_key='key',merchant_salt='salt',base_url='https://mock.paytr')
    p2.create_intent(amount_minor=12500,currency='TRY',tenant_id='t1',order_id='o1',customer={'email':'buyer@example.com','ip_address':'203.0.113.10'},items=[])
    assert captured['test_mode'] == '0'
