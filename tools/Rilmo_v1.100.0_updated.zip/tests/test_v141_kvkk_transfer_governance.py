from pathlib import Path
from datetime import datetime, timezone
from app.core.database import SessionLocal
from app.models.domain import User, PrivacyTransferRegister

def test_transfer_register_model_requires_evidence_fields_for_strict_kvkk_mechanism():
    db=SessionLocal()
    try:
        row=PrivacyTransferRegister(processor_name='Veriff',destination_country='NL',mechanism='kvkk_standard_contract',data_categories=['identity'],purpose='KYC',contract_reference=None,approval_status='PENDING_REVIEW')
        db.add(row); db.flush()
        assert row.approval_status=='PENDING_REVIEW'
        row.contract_reference='SC-2026-01'
        row.contract_type='KVKK STANDARD CONTRACT'
        row.signed_at=datetime.now(timezone.utc)
        row.signatory_authority_reference='AUTH-123'
        row.approval_status='APPROVED'
        db.flush()
        assert row.approval_status=='APPROVED'
    finally:
        db.rollback(); db.close()

def test_transfer_register_is_not_a_generic_admin_feature():
    # transfer-routes moved to privacy_routes.py in Phase 3 split
    src=Path('app/routes/privacy_routes.py').read_text(encoding='utf-8')

    idx=src.find("@router.post('/platform/privacy/transfer-routes')")
    block=src[idx:idx+2200]
    assert 'current_platform_compliance_officer' in block
    assert 'PRIVACY_TRANSFER_EVIDENCE_REQUIRED' in block
    assert 'approval_status=' in src
