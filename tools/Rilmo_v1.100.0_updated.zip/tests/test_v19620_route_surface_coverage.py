from tests.test_p0 import register


def h(x):
    return {'Authorization': f"Bearer {x['access_token']}"}


def test_zatca_invoice_generation_is_idempotent(client):
    from tests.test_returns import _seed_paid_order
    x = register(client, 'cov20-zatca@example.com')
    headers = h(x)
    tid, order = _seed_paid_order(client, headers)
    payload = {'vat_number': '123456789012345', 'city': 'Riyadh', 'region': 'Riyadh', 'country_code': 'SA'}
    r = client.post(f'/v1/orders/{order["id"]}/zatca/invoice?tenant_id={tid}', headers=headers, json=payload)
    assert r.status_code == 200, r.text
    assert r.json()['status'] == 'GENERATED'
    assert r.json()['sha256']
    again = client.post(f'/v1/orders/{order["id"]}/zatca/invoice?tenant_id={tid}', headers=headers, json=payload)
    assert again.status_code == 200
    assert again.json()['invoice_number'] == r.json()['invoice_number']
    assert again.json()['sha256'] == r.json()['sha256']


def test_marketing_preferences_create_and_update(client):
    x = register(client, 'cov20-marketing@example.com')
    headers = h(x); tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Customer
    db = SessionLocal()
    c = Customer(tenant_id=tid, email='prefs20@example.com')
    db.add(c); db.commit(); cid = c.id; db.close()
    r = client.put(f'/v1/customers/{cid}/marketing-preferences?tenant_id={tid}', headers=headers,
                   json={'email_marketing': True, 'sms_marketing': False, 'whatsapp_marketing': True})
    assert r.status_code == 200
    assert r.json()['email_marketing'] is True
    r2 = client.put(f'/v1/customers/{cid}/marketing-preferences?tenant_id={tid}', headers=headers,
                    json={'email_marketing': False, 'sms_marketing': True, 'whatsapp_marketing': False})
    assert r2.status_code == 200
    assert r2.json()['sms_marketing'] is True


def test_loyalty_balance_empty_account_is_zeroed(client):
    x = register(client, 'cov20-loyalty@example.com')
    headers = h(x); tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Customer
    db = SessionLocal(); c = Customer(tenant_id=tid, email='balance20@example.com'); db.add(c); db.commit(); cid=c.id; db.close()
    r = client.get(f'/v1/loyalty/{cid}?tenant_id={tid}', headers=headers)
    assert r.status_code == 200
    assert r.json() == {'points_balance': 0, 'lifetime_earned': 0, 'lifetime_redeemed': 0}


def test_theme_public_view_after_publish(client):
    x = register(client, 'cov20-theme@example.com')
    headers = h(x); tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Domain, Storefront, Tenant
    db=SessionLocal(); tenant=db.get(Tenant, tid); tenant.status='ACTIVE'; sf=db.query(Storefront).filter_by(tenant_id=tid).first();
    if not sf:
        sf=Storefront(tenant_id=tid, slug='main', status='PUBLISHED'); db.add(sf); db.flush()
    sf.status='PUBLISHED'; host=f'cov20-theme-{tid[:8]}.test'; db.add(Domain(tenant_id=tid, storefront_id=sf.id, hostname=host, verified_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc))); db.commit(); db.close()
    r=client.post(f'/v1/themes?tenant_id={tid}',headers=headers,json={'slug':'cov20modern','name':'Cov20 Modern','settings':{'radius':'12px'}})
    assert r.status_code==200
    assert client.post(f'/v1/themes/assign?tenant_id={tid}',headers=headers,json={'theme_id':r.json()['id']}).status_code==200
    assert client.post(f'/v1/themes/publish?tenant_id={tid}',headers=headers).status_code==200
    public=client.get(f'/v1/public/storefront/{host}/theme')
    assert public.status_code==200


def test_platform_app_lifecycle_and_installation(client):
    from app.core.auth import current_platform_admin
    from app.main import app
    admin=register(client,'cov20-platform@example.com')
    app.dependency_overrides[current_platform_admin]=lambda: admin
    try:
        client.cookies.set('csrf_token','cov20-csrf')
        r=client.post('/v1/apps',headers={'X-CSRF-Token':'cov20-csrf'},json={'name':'Coverage App','slug':'coverage-app','redirect_uris':['https://example.com/cb'],'scopes':['store.read'],'publisher_name':'Coverage'})
        assert r.status_code==200, r.text
        aid=r.json()['id']
        assert client.get('/v1/apps').status_code==200
        assert client.post(f'/v1/apps/{aid}/approve',headers={'X-CSRF-Token':'cov20-csrf'}).status_code==200
    finally:
        app.dependency_overrides.pop(current_platform_admin,None)
    tid=admin['tenant']['id']; headers=h(admin)
    inst=client.post('/v1/apps/install',params={'tenant_id':tid},headers=headers,json={'app_id':aid,'scopes':['store.read']})
    assert inst.status_code==200, inst.text
    iid=inst.json()['installation_id']
    assert client.get('/v1/apps/installations',params={'tenant_id':tid},headers=headers).status_code==200
    rev=client.post(f'/v1/apps/installations/{iid}/revoke',params={'tenant_id':tid},headers=headers)
    assert rev.status_code==200 and rev.json()['status']=='REVOKED'


def test_app_webhook_requires_granted_scope(client):
    from app.core.auth import current_platform_admin
    from app.main import app
    admin=register(client,'cov20-webhook@example.com')
    app.dependency_overrides[current_platform_admin]=lambda: admin
    try:
        client.cookies.set('csrf_token','cov20-csrf2')
        r=client.post('/v1/apps',headers={'X-CSRF-Token':'cov20-csrf2'},json={'name':'Webhook App','slug':'webhook-app','redirect_uris':['https://example.com/cb'],'scopes':['store.read']})
        aid=r.json()['id']; client.post(f'/v1/apps/{aid}/approve',headers={'X-CSRF-Token':'cov20-csrf2'})
    finally:
        app.dependency_overrides.pop(current_platform_admin,None)
    tid=admin['tenant']['id']; headers=h(admin)
    inst=client.post('/v1/apps/install',params={'tenant_id':tid},headers=headers,json={'app_id':aid,'scopes':['store.read']})
    iid=inst.json()['installation_id']
    r=client.post(f'/v1/apps/installations/{iid}/webhooks',params={'tenant_id':tid},headers=headers,json={'event_type':'order.created','endpoint_url':'https://example.com/hook'})
    assert r.status_code==403


def test_turkey_tax_profile_lifecycle(client):
    x=register(client,'cov20-tax@example.com'); headers=h(x); tid=x['tenant']['id']
    r=client.get('/v1/turkey/tax-profiles',params={'tenant_id':tid},headers=headers)
    assert r.status_code==200
    created=client.post('/v1/turkey/tax-profiles',params={'tenant_id':tid},headers=headers,json={'code':'KDV20','name':'VAT 20','kdv_bps':2000,'inclusive':False})
    assert created.status_code==200, created.text
    listed=client.get('/v1/turkey/tax-profiles',params={'tenant_id':tid},headers=headers)
    assert listed.status_code==200
    assert any(x.get('name')=='VAT 20' for x in listed.json())


def test_customer_logout_without_customer_session_is_safe(client):
    x=register(client,'cov20-logout@example.com')
    from app.core.database import SessionLocal
    from app.models.domain import Domain, Storefront, Tenant
    db=SessionLocal(); tid=x['tenant']['id']; tenant=db.get(Tenant,tid); tenant.status='ACTIVE'; sf=db.query(Storefront).filter_by(tenant_id=tid).first();
    if not sf:
        sf=Storefront(tenant_id=tid,slug='main',status='PUBLISHED'); db.add(sf); db.flush()
    host=f'cov20-logout-{tid[:8]}.test'; db.add(Domain(tenant_id=tid,storefront_id=sf.id,hostname=host)); db.commit(); db.close()
    client.cookies.set('csrf_token','cov20-logout-csrf')
    r=client.post(f'/v1/customer/auth/logout?hostname={host}',headers={'X-CSRF-Token':'cov20-logout-csrf'})
    assert r.status_code==200 and r.json()['ok'] is True
