"""Normative T1-T20 regression aliases required by v1.8 Gate A+."""
from .test_security_p0 import (
    test_role_escalation_is_blocked,
    test_platform_admin_cannot_be_impersonated,
    test_session_replay_after_logout_is_rejected,
    test_oauth_linking_cannot_take_over_existing_identity,
    test_password_reset_existence_does_not_leak,
    test_recovery_code_is_single_use_and_hashed,
    test_removed_marketplace_webhooks_do_not_exist,
    test_ssrf_and_upload_policy,
    test_upload_rejects_active_content_and_large_files,
    test_duplicate_capture_does_not_double_charge,
    test_coupon_usage_limit_is_enforced_inside_checkout_transaction,
    test_domain_verification_token_cannot_be_reused,
    test_audit_tampering_is_detectable,
    test_user_secret_not_serialized,
    test_cancel_subscription_revokes_entitlements,
    test_storage_key_is_tenant_prefixed_and_not_cross_deletable,
)
from .test_p0 import test_cross_tenant_idor_blocked, test_cookie_csrf_boundary
from .test_domain_invariants_extra import test_inventory_expiry_releases_stock
from .test_deep_invariants import test_queue_poison_reaches_dlq
import pytest
from app.core.database import SessionLocal, Base, engine

@pytest.fixture(autouse=True)
def isolated_t_case():
    db = SessionLocal()
    for table in reversed(Base.metadata.sorted_tables):
        db.execute(table.delete())
    db.commit()
    db.close()
    yield

def test_T1_cross_tenant_idor(client):
    test_cross_tenant_idor_blocked(client)

def test_T2_role_escalation(client):
    test_role_escalation_is_blocked(client)

def test_T3_platform_admin_impersonation(client):
    test_platform_admin_cannot_be_impersonated(client)

def test_T4_session_fixation_replay(client):
    test_session_replay_after_logout_is_rejected(client)

def test_T5_csrf(client):
    test_cookie_csrf_boundary(client)

def test_T6_oauth_takeover(client):
    test_oauth_linking_cannot_take_over_existing_identity(client)

def test_T7_password_reset_abuse(client):
    test_password_reset_existence_does_not_leak(client)

def test_T8_mfa_recovery_abuse(client):
    test_recovery_code_is_single_use_and_hashed(client)

def test_T9_webhook_forgery_replay(client):
    test_removed_marketplace_webhooks_do_not_exist(client)

def test_T10_ssrf_dns_rebinding_policy(client):
    test_ssrf_and_upload_policy(client)

def test_T11_malicious_upload(client):
    test_upload_rejects_active_content_and_large_files()

def test_T12_duplicate_payment_capture_refund(client):
    test_duplicate_capture_does_not_double_charge(client)

def test_T13_inventory_expiry_race(client):
    test_inventory_expiry_releases_stock(client)

def test_T14_coupon_concurrency(client):
    test_coupon_usage_limit_is_enforced_inside_checkout_transaction(client)

def test_T15_domain_takeover(client):
    test_domain_verification_token_cannot_be_reused(client)

def test_T16_queue_poison_retry_storm(client):
    test_queue_poison_reaches_dlq()

def test_T17_audit_tampering(client):
    test_audit_tampering_is_detectable(client)

def test_T18_secret_leakage(client):
    test_user_secret_not_serialized(client)

def test_T19_stale_entitlement_retention(client):
    test_cancel_subscription_revokes_entitlements(client)

def test_T20_cache_search_storage_tenant_leakage(client):
    test_storage_key_is_tenant_prefixed_and_not_cross_deletable(client)
