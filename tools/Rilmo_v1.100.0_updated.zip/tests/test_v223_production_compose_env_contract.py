from pathlib import Path


def test_production_compose_requires_external_production_env_file():
    text = Path("docker-compose.production.yml").read_text(encoding="utf-8")
    assert "${PRODUCTION_ENV_FILE:?PRODUCTION_ENV_FILE required}" in text
    assert text.count("env_file:") >= 3


def test_production_compose_passes_r2_s3_endpoint_and_region():
    text = Path("docker-compose.production.yml").read_text(encoding="utf-8")
    assert "S3_ENDPOINT_URL: ${S3_ENDPOINT_URL:-}" in text
    assert "S3_REGION: ${S3_REGION:-auto}" in text
