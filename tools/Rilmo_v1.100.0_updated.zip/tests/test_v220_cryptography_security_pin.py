from pathlib import Path


def test_cryptography_pin_is_at_least_50_for_cve_2026_69247():
    runtime = (Path(__file__).resolve().parents[1] / "requirements-runtime.txt").read_text(encoding="utf-8")
    assert "cryptography==50.0.0" in runtime
    assert "cryptography==49.0.0" not in runtime
