import ipaddress
from unittest.mock import patch

import pytest

from app.core.errors import AppError
from app.core.network import validate_outbound_url
from app.security.policy import is_private_ip
from app.services.app_webhooks import _resolve_public_https


def test_outbound_url_rejects_cgnat_dns_resolution(monkeypatch):
    monkeypatch.setenv('ENVIRONMENT', 'staging')
    with patch('app.core.network.socket.getaddrinfo', return_value=[(2, 1, 6, '', ('100.64.0.1', 443))]):
        with pytest.raises(AppError):
            validate_outbound_url('https://example.com/api')


def test_security_policy_treats_cgnat_as_non_global():
    assert is_private_ip('100.64.0.1') is True


def test_app_webhook_resolver_rejects_cgnat(monkeypatch):
    with patch('app.services.app_webhooks.socket.getaddrinfo', return_value=[(2, 1, 6, '', ('100.64.0.1', 443))]):
        assert _resolve_public_https('https://hooks.example.com/events') is None
