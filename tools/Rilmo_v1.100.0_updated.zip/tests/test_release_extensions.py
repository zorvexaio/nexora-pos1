from app.models.domain import Tenant, Product, ProductVariant, Category, ShippingMethod, TaxRate

def register(client, email):
    r = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'Merchant'})
    assert r.status_code == 200, r.text
    return r.json()

def test_dashboard_and_operational_extensions(client):
    x = register(client, 'extensions@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    assert client.get('/v1/dashboard/summary', params={'tenant_id': tid}, headers=h).status_code == 200
    assert client.get('/v1/orders', params={'tenant_id': tid}, headers=h).status_code == 200
    assert client.get('/v1/inventory', params={'tenant_id': tid}, headers=h).status_code == 200
    assert client.get('/v1/categories', params={'tenant_id': tid}, headers=h).status_code == 200
    assert client.get('/v1/media', params={'tenant_id': tid}, headers=h).status_code == 200

def test_mutable_models_have_optimistic_version_columns(client):
    from app.core.database import SessionLocal
    db = SessionLocal()
    try:
        assert all((hasattr(cls, 'version') for cls in (Tenant, Product, ProductVariant, Category, ShippingMethod, TaxRate)))
    finally:
        db.close()

def test_optimistic_version_conflict_is_enforced(client):
    x = register(client, 'version@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    r = client.patch(f'/v1/tenants/{tid}', params={'tenant_id': tid}, headers={**h, 'If-Match': '1'}, json={'name': 'v2'})
    assert r.status_code == 200
    r = client.patch(f'/v1/tenants/{tid}', params={'tenant_id': tid}, headers={**h, 'If-Match': '1'}, json={'name': 'stale'})
    assert r.status_code == 412
    r = client.patch(f'/v1/tenants/{tid}', params={'tenant_id': tid}, headers=h, json={'name': 'missing-header'})
    assert r.status_code == 428
