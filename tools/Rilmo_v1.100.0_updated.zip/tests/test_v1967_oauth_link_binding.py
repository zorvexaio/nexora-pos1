def test_google_link_callback_requires_authenticated_current_user_and_state_binding():
    from pathlib import Path
    # google_link_callback moved to auth_google_routes.py in Phase 3 split
    source = Path("app/routes/auth_google_routes.py").read_text(encoding="utf-8")
    marker = "def google_link_callback(code: str, state: str, request: Request, response: Response,"
    start = source.index(marker)
    end = source.index("@router.post('/auth/identities/link')", start)
    block = source[start:end]
    assert "user=Depends(current_user)" in block
    assert "if st.user_id != user.id:" in block
    assert "OAUTH_LINK_USER_MISMATCH" in block
