import base64, hashlib, hmac, json
from app.services.payment_providers import IyzicoProvider, PayTRProvider

def test_iyzico_v2_authorization_is_hmac_and_base64():
    p = IyzicoProvider(api_key='ak', secret_key='sk', base_url='https://sandbox.example')
    headers = p._auth('/payment/iyzipos/checkoutform/initialize/auth/ecom', '{}')
    assert headers['Authorization'].startswith('IYZWSv2 ')
    decoded = base64.b64decode(headers['Authorization'].split(' ', 1)[1]).decode()
    assert 'apiKey:ak' in decoded and 'randomKey:' in decoded and ('signature:' in decoded)

def test_paytr_callback_signature_matches_official_formula():
    p = PayTRProvider(merchant_id='m', merchant_key='key', merchant_salt='salt', base_url='https://example')
    raw = 'OID1' + 'salt' + 'success' + '100.00'
    sig = base64.b64encode(hmac.new(b'key', raw.encode(), hashlib.sha256).digest()).decode()
    assert p.verify_callback(merchant_oid='OID1', status='success', total_amount='100.00', provided_hash=sig)
    assert not p.verify_callback(merchant_oid='OID1', status='success', total_amount='101.00', provided_hash=sig)

def test_paytr_token_matches_step1_contract():
    p = PayTRProvider(merchant_id='m', merchant_key='key', merchant_salt='salt', base_url='https://example')
    token = p.build_token(user_ip='1.2.3.4', merchant_oid='OID1', email='a@b.com', payment_amount='100.00')
    raw = 'm1.2.3.4OID1a@b.com100.00card0TL10' + 'salt'
    expected = base64.b64encode(hmac.new(b'key', raw.encode(), hashlib.sha256).digest()).decode()
    assert token == expected

def test_turkish_provider_names_are_distinct_and_no_stub_fallback():
    from app.services.payment_providers import get_payment_provider
    assert 'iyzico' in get_payment_provider.__code__.co_consts
    assert 'paytr' in get_payment_provider.__code__.co_consts

def test_paytr_never_accepts_bad_callback_signature():
    from app.services.payment_providers import PayTRProvider
    p = PayTRProvider(merchant_id='m', merchant_key='key', merchant_salt='salt', base_url='https://example')
    assert p.verify_callback(merchant_oid='OID1', status='success', total_amount='100', provided_hash='bad') is False

def test_paytr_refund_builds_documented_hmac_and_posts(monkeypatch):
    from app.services.payment_providers import PayTRProvider
    p = PayTRProvider(merchant_id='m', merchant_key='key', merchant_salt='salt', base_url='https://example')
    seen = {}

    class Resp:
        status_code = 200
        content = b'{"status":"success","reference_no":"R1"}'

        def json(self):
            return {'status': 'success', 'reference_no': 'R1'}

    class Client:

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def post(self, url, data):
            seen['url'] = url
            seen['data'] = data
            return Resp()
    monkeypatch.setattr('httpx.Client', lambda **kwargs: Client())
    result = p.refund('OID1', 1197, 'TRY', 'REF-1')
    assert result.status == 'succeeded'
    assert seen['url'] == 'https://example/odeme/iade'
    raw = 'mOID111.97' + 'salt'
    expected = base64.b64encode(hmac.new(b'key', raw.encode(), hashlib.sha256).digest()).decode()
    assert seen['data']['paytr_token'] == expected
    assert seen['data']['reference_no'] == 'REF-1'
