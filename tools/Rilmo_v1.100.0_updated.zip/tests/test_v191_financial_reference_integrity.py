from app.services.payment_providers import PaymentActionResult


def _merchant(client, email):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'}).json()
    return m['tenant']['id'], {'Authorization': 'Bearer ' + m['access_token']}


def test_capture_fails_closed_when_provider_returns_no_reference(client, monkeypatch):
    tid, h = _merchant(client, 'missing-capture-ref@example.com')
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h,
        json={'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()

    class Provider:
        def capture(self, *args, **kwargs):
            return PaymentActionResult(provider_id='', status='succeeded', raw={})

    monkeypatch.setattr('app.routes.payment_routes.get_payment_provider', lambda _name: Provider())
    r = client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h)
    assert r.status_code == 502
    assert r.json()['detail']['error']['code'] == 'PROVIDER_CAPTURE_REFERENCE_MISSING'


def test_refund_fails_closed_when_provider_returns_no_reference(client, monkeypatch):
    tid, h = _merchant(client, 'missing-refund-ref@example.com')
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h,
        json={'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()
    r = client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h)
    assert r.status_code == 200
    # Payment intents created without an order have no refundable order relation.
    # Create a minimal order-backed payment through the normal checkout path instead.
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'refund-ref', 'title': 'Refund ref', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'REF-1', 'price_amount_minor': 500, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=1&reason=test", headers=h)
    cart = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': cart['id']}).json()
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'order_id': order['id'], 'amount_minor': order['total_minor'], 'currency': 'USD', 'provider': 'mock'}).json()
    r = client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h)
    assert r.status_code == 200
    order_id = order['id']

    class Provider:
        def refund(self, *args, **kwargs):
            return PaymentActionResult(provider_id='', status='succeeded', raw={})

    monkeypatch.setattr('app.routes.payment_routes.get_payment_provider', lambda _name: Provider())
    r = client.post(f'/v1/refunds?tenant_id={tid}', headers=h, json={
        'order_id': order_id, 'payment_intent_id': pi['id'],
        'amount_minor': 500, 'currency': 'USD', 'provider': 'mock',
    })
    assert r.status_code == 502
    assert r.json()['detail']['error']['code'] == 'PROVIDER_REFUND_REFERENCE_MISSING'
