from datetime import datetime, timezone

from app.core.database import SessionLocal
from app.models.domain import Domain, Product, ProductVariant, ShippingMethod, Storefront, Tenant


def _prepare(client, email='unverified-public-v192@example.com'):
    hostname = 'unverified-v192-' + email.split('@')[0].replace('_', '-') + '.example.test'
    r = client.post('/v1/auth/register', json={
        'email': email,
        'password': 'VerySecurePassword123!',
        'display_name': 'Unverified Public',
    })
    assert r.status_code == 200, r.text
    tid = r.json()['tenant']['id']
    db = SessionLocal()
    try:
        t = db.get(Tenant, tid)
        t.status = 'ACTIVE'
        s = db.query(Storefront).filter_by(tenant_id=tid).first()
        s.status = 'PUBLISHED'
        p = Product(tenant_id=tid, storefront_id=s.id, slug='secret-item', status='ACTIVE', title='Secret Item', description='Should stay private until domain verification')
        db.add(p)
        db.flush()
        db.add(ProductVariant(tenant_id=tid, product_id=p.id, sku='SECRET-1', currency='USD', status='ACTIVE', price_amount_minor=1000))
        d = Domain(tenant_id=tid, storefront_id=s.id, hostname=hostname, verified_at=None)
        db.add(d)
        db.add(ShippingMethod(tenant_id=tid, name='Secret Shipping', currency='USD', amount_minor=500, is_active=True))
        db.commit()
        return tid, p.id
    finally:
        db.close()


def test_unverified_domain_cannot_expose_public_storefront(client):
    email = 'unverified-public-v192@example.com'
    _prepare(client, email)
    host = 'unverified-v192-' + email.split('@')[0].replace('_', '-') + '.example.test'
    for path in [
        f'/v1/public/storefront/{host}',
        f'/v1/public/storefront/{host}/shipping-methods?currency=USD',
    ]:
        r = client.get(path)
        assert r.status_code in {404, 503}, (path, r.status_code, r.text)


def test_unverified_domain_cannot_expose_public_product(client):
    _tid, product_id = _prepare(client, 'unverified-product-v192@example.com')
    r = client.get('/v1/public/products/' + product_id, params={'hostname': 'unverified-v192-unverified-product-v192.example.test'})
    assert r.status_code in {404, 503}, r.text


def test_verified_domain_still_exposes_public_storefront_and_product(client):
    email = 'verified-public-v192@example.com'
    _tid, product_id = _prepare(client, email)
    host = 'unverified-v192-' + email.split('@')[0].replace('_', '-') + '.example.test'
    db = SessionLocal()
    try:
        d = db.query(Domain).filter_by(hostname=host).first()
        assert d is not None
        d.verified_at = datetime.now(timezone.utc)
        db.commit()
    finally:
        db.close()
    root = client.get('/v1/public/storefront/' + host)
    assert root.status_code == 200, root.text
    product = client.get('/v1/public/products/' + product_id, params={'hostname': host})
    assert product.status_code == 200, product.text
