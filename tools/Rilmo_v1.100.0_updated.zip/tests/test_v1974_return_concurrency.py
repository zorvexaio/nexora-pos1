from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_return_creation_locks_order_and_order_items():
    s = (ROOT / 'app/routes/order_routes.py').read_text()
    assert "Order).filter_by(id=order_id, tenant_id=tenant_id).with_for_update().first()" in s
    assert "OrderItem).filter_by(id=order_item_id, order_id=order.id,\n            tenant_id=tenant_id).with_for_update().first()" in s


def test_return_creation_aggregates_duplicate_order_items_before_quantity_check():
    s = (ROOT / 'app/routes/order_routes.py').read_text()
    assert "requested_quantities[item.order_item_id] = requested_quantities.get(item.order_item_id, 0) + qty" in s
    assert "for order_item_id, quantity in requested_quantities.items():" in s
    assert "if qty <= 0:" in s
