from datetime import datetime, timezone, timedelta
from app.models.domain import Tenant, PaymentCapture, Refund
from app.routes.worldclass import analytics_revenue_intelligence

class MerchantUser: id='merchant-user'

def test_revenue_intelligence_is_currency_safe(db_session, monkeypatch):
    t=Tenant(slug='ri-1993',name='RI',status='ACTIVE',default_currency='USD'); db_session.add(t); db_session.flush()
    now=datetime.now(timezone.utc)
    db_session.add_all([
        PaymentCapture(tenant_id=t.id,payment_intent_id='pi1',amount_minor=10000,currency='USD',provider_capture_id='cap-ri1',created_at=now-timedelta(days=2)),
        PaymentCapture(tenant_id=t.id,payment_intent_id='pi2',amount_minor=5000,currency='EUR',provider_capture_id='cap-ri2',created_at=now-timedelta(days=2)),
        Refund(tenant_id=t.id,order_id='o1',payment_intent_id='pi1',amount_minor=1000,currency='USD',status='COMPLETED',provider_refund_id='ref-ri1',created_at=now-timedelta(days=1)),
        Refund(tenant_id=t.id,order_id='o2',payment_intent_id='pi2',amount_minor=500,currency='EUR',status='PENDING',provider_refund_id='ref-ri2',created_at=now-timedelta(days=1)),
    ]); db_session.commit()
    monkeypatch.setattr('app.routes.worldclass._perm',lambda *a,**k:None)
    r=analytics_revenue_intelligence(t.id,30,MerchantUser(),db_session)
    assert r['currencies']['USD']['net_revenue_minor']==9000
    assert r['currencies']['EUR']['net_revenue_minor']==5000
    assert r['integrity']['cross_currency_totals_not_computed'] is True

def test_revenue_intelligence_growth_uses_equal_currency_period(db_session, monkeypatch):
    t=Tenant(slug='ri-1993-growth',name='RI growth',status='ACTIVE',default_currency='USD'); db_session.add(t); db_session.flush()
    now=datetime.now(timezone.utc)
    db_session.add(PaymentCapture(tenant_id=t.id,payment_intent_id='pi3',amount_minor=5000,currency='USD',provider_capture_id='cap-ri3',created_at=now-timedelta(days=45)))
    db_session.add(PaymentCapture(tenant_id=t.id,payment_intent_id='pi4',amount_minor=10000,currency='USD',provider_capture_id='cap-ri4',created_at=now-timedelta(days=2)))
    db_session.commit(); monkeypatch.setattr('app.routes.worldclass._perm',lambda *a,**k:None)
    r=analytics_revenue_intelligence(t.id,30,MerchantUser(),db_session)
    assert r['currencies']['USD']['previous_net_revenue_minor']==5000
    assert r['currencies']['USD']['growth_bps']==10000

def test_revenue_intelligence_zero_baseline_is_explicit(db_session, monkeypatch):
    t=Tenant(slug='ri-1993-zero',name='RI zero',status='ACTIVE',default_currency='USD'); db_session.add(t); db_session.flush()
    now=datetime.now(timezone.utc)
    db_session.add(PaymentCapture(tenant_id=t.id,payment_intent_id='pi5',amount_minor=7000,currency='USD',provider_capture_id='cap-ri5',created_at=now-timedelta(days=1)))
    db_session.commit(); monkeypatch.setattr('app.routes.worldclass._perm',lambda *a,**k:None)
    r=analytics_revenue_intelligence(t.id,30,MerchantUser(),db_session)
    assert r['currencies']['USD']['growth_bps'] is None
