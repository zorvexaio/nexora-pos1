from __future__ import annotations

import types

import pytest


def test_sms_provider_and_legacy_wrapper_share_one_contract(monkeypatch):
    from app.services import notifications, sms

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def post(self, url, data=None, headers=None):
            assert "/Messages.json" in url
            assert data["Body"].startswith("Your Unified Global Commerce")
            return types.SimpleNamespace(status_code=201, json=lambda: {"sid": "SM123"})

    settings = types.SimpleNamespace(
        SMS_PROVIDER="twilio", TWILIO_ACCOUNT_SID="AC123", TWILIO_AUTH_TOKEN="tok",
        TWILIO_FROM_NUMBER="+10000000000"
    )
    monkeypatch.setattr(notifications, "get_settings", lambda: settings)
    monkeypatch.setattr(notifications.httpx, "Client", FakeClient)
    sms.send_verification_sms("+905555555555", "ABC123", 10)


def test_sms_provider_fails_closed_when_unconfigured(monkeypatch):
    from app.services import notifications
    settings = types.SimpleNamespace(SMS_PROVIDER="none")
    monkeypatch.setattr(notifications, "get_settings", lambda: settings)
    with pytest.raises(Exception):
        notifications.get_sms_provider().send(to="+1", message="x")


def test_malware_scanner_accepts_ok_and_rejects_detection(monkeypatch):
    from app.services import malware

    class FakeSocket:
        def __init__(self, response):
            self.response = response
            self.sent = []
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def sendall(self, data): self.sent.append(data)
        def recv(self, n): return self.response

    settings = types.SimpleNamespace(MEDIA_SCAN_REQUIRED=True, CLAMAV_HOST="clamav", CLAMAV_PORT=3310, CLAMAV_TIMEOUT_SECONDS=1)
    monkeypatch.setattr(malware, "get_settings", lambda: settings)
    ok = FakeSocket(b"stream: OK\0")
    monkeypatch.setattr(malware.socket, "create_connection", lambda *a, **k: ok)
    malware.scan_bytes(b"hello")
    assert ok.sent[0] == b"zINSTREAM\x00"

    bad = FakeSocket(b"stream: Eicar-Test-Signature FOUND\0")
    monkeypatch.setattr(malware.socket, "create_connection", lambda *a, **k: bad)
    with pytest.raises(Exception):
        malware.scan_bytes(b"evil")


def test_domain_registrar_normalization_and_provider_contract(monkeypatch):
    from app.services import domain_registrar

    with pytest.raises(Exception):
        domain_registrar.normalize_domain("https://example.com/path")
    assert domain_registrar.normalize_domain("Example.COM.") == "example.com"

    settings = types.SimpleNamespace(
        DOMAIN_PROVIDER="cloudflare", DOMAIN_PROVIDER_ACCOUNT_ID="acct",
        DOMAIN_PROVIDER_API_TOKEN="token"
    )
    monkeypatch.setattr(domain_registrar, "get_settings", lambda: settings)

    class Resp:
        status_code = 200
        def json(self):
            return {"result": {"domains": [{"name": "example.com", "registrable": True, "pricing": {"registration_cost": 8.5, "renewal_cost": 9.5}}]}}

    monkeypatch.setattr(domain_registrar.httpx, "post", lambda *a, **k: Resp())
    result = domain_registrar.check_domain("example.com")
    assert result["registrable"] is True
    assert result["registration_cost_minor"] == 850


def test_worker_accepts_auxiliary_outbox_events():
    from app.worker import AUXILIARY_EVENT_TYPES, CANONICAL_HANDLERS
    assert "domain.purchase.payment_captured" in CANONICAL_HANDLERS
    assert "privacy.request.submitted" in AUXILIARY_EVENT_TYPES
    assert "workflow.webhook.requested" in AUXILIARY_EVENT_TYPES
