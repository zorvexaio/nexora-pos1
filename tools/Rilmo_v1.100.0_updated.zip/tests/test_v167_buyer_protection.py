import uuid
from app.core.database import SessionLocal
from app.models.domain import OrderIssueMessage, OrderIssue, Order, PaymentIntent, PaymentCapture

def _merchant(client):
    r=client.post('/v1/auth/register',json={'email':f"bp-{uuid.uuid4().hex}@example.com",'password':'VerySecurePassword123!'})
    return {'Authorization':'Bearer '+r.json()['access_token']}

def _shop_order(client, h):
    t=client.post('/v1/tenants',headers=h,json={'slug':f"bp-{uuid.uuid4().hex[:8]}",'name':'Buyer Protection','default_currency':'USD','default_locale':'en'}).json()['id']
    p=client.post(f'/v1/products?tenant_id={t}',headers=h,json={'slug':'item','title':'Item','status':'ACTIVE'}).json()
    v=client.post(f'/v1/products/{p["id"]}/variants?tenant_id={t}',headers=h,json={'sku':'BP1','price_amount_minor':1000,'currency':'USD'}).json()
    client.post(f'/v1/inventory/adjustments?tenant_id={t}&variant_id={v["id"]}&delta=5&reason=test',headers=h)
    c=client.post(f'/v1/cart?tenant_id={t}',headers=h,json={'currency':'USD'}).json()
    client.post(f'/v1/cart/items?tenant_id={t}&cart_id={c["id"]}',headers=h,json={'variant_id':v['id'],'quantity':1})
    o=client.post(f'/v1/checkout?tenant_id={t}',headers=h,json={'cart_id':c['id'],'customer_email':'buyer@example.com','customer_name':'Buyer'}).json()
    return t,o

def test_issue_conversation_endpoints_and_merchant_refund_path(client, monkeypatch):
    h=_merchant(client); tenant, order=_shop_order(client,h)
    # create issue as merchant-created customer simulation via direct session model is out of scope; test message endpoint model boundary instead
    from app.core.database import SessionLocal
    db=SessionLocal()
    issue=OrderIssue(tenant_id=tenant,order_id=order['id'],customer_id=None,issue_type='REFUND_REQUEST',status='OPEN',customer_message='Refund please',idempotency_key='issue-'+uuid.uuid4().hex)
    db.add(issue); db.commit(); issue_id=issue.id
    db.add(OrderIssueMessage(tenant_id=tenant,issue_id=issue_id,author_type='CUSTOMER',author_id=None,message='Please help'))
    db.commit(); db.close()
    r=client.get(f'/v1/merchant/order-issues/{issue_id}/messages?tenant_id={tenant}',headers=h)
    assert r.status_code==200
    assert r.json()['items'][0]['message']=='Please help'
    r=client.post(f'/v1/merchant/order-issues/{issue_id}/messages?tenant_id={tenant}',headers=h,json={'message':'We will review this','idempotency_key':'msg-'+uuid.uuid4().hex})
    assert r.status_code==200
    r=client.get(f'/v1/merchant/order-issues/{issue_id}/messages?tenant_id={tenant}',headers=h)
    assert len(r.json()['items'])==2
