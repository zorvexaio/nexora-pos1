from datetime import datetime, timezone

from app.core.database import SessionLocal
from app.models.domain import Customer, InventoryItem, InventoryLocation, Order, OrderItem, Product, ProductVariant


def register(client, email):
    r = client.post('/v1/auth/register', json={
        'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'Command Center'
    })
    assert r.status_code == 200, r.text
    return r.json()


def test_command_center_returns_operational_cockpit(client):
    x = register(client, 'command-center-empty@example.com')
    r = client.get('/v1/analytics/command-center', params={'tenant_id': x['tenant']['id']},
                   headers={'Authorization': f"Bearer {x['access_token']}"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['integrity'] == {'currency_safe': True, 'profit_unknown_when_cost_missing': True}
    assert 'currencies' in body and 'operations' in body and 'actions' in body
    assert body['actions'][0]['code'] == 'HEALTHY_OPERATIONS'


def test_command_center_never_mix_currencies(client):
    x = register(client, 'command-center-currency@example.com')
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        for idx, (currency, price, cost) in enumerate([('USD', 1000, 400), ('TRY', 2000, None)]):
            p = Product(tenant_id=tid, slug=f'cc-{idx}', title=f'CC {idx}', status='PUBLISHED', product_type='PHYSICAL')
            db.add(p); db.flush()
            v = ProductVariant(tenant_id=tid, product_id=p.id, sku=f'CC-{idx}', price_amount_minor=price,
                               cost_amount_minor=cost, currency=currency, status='ACTIVE')
            db.add(v); db.flush()
            o = Order(tenant_id=tid, order_number=f'CC-{idx}', status='CONFIRMED', payment_status='PAID',
                      fulfillment_status='FULFILLED', currency=currency, subtotal_minor=price,
                      discount_minor=0, shipping_minor=0, tax_minor=0, fee_minor=0, total_minor=price)
            db.add(o); db.flush()
            db.add(OrderItem(tenant_id=tid, order_id=o.id, variant_id=v.id, sku_snapshot=v.sku,
                             title_snapshot=p.title, quantity=1, unit_price_minor=price,
                             cost_amount_minor=cost, discount_minor=0, tax_minor=0, total_minor=price,
                             currency=currency))
        db.commit()
    finally:
        db.close()
    r = client.get('/v1/analytics/command-center', params={'tenant_id': tid},
                   headers={'Authorization': f"Bearer {x['access_token']}"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['currencies']['USD']['gross_profit_minor'] == 600
    assert body['currencies']['TRY']['gross_profit_minor'] is None
    assert body['integrity']['currency_safe'] is True
    assert any(a['code'] == 'COMPLETE_PRODUCT_COSTS' for a in body['actions'])


def test_command_center_surfaces_stock_and_fulfillment_actions(client):
    x = register(client, 'command-center-ops@example.com')
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        loc = InventoryLocation(tenant_id=tid, name='CC Ops')
        db.add(loc); db.flush()
        p = Product(tenant_id=tid, slug='cc-stock', title='CC Stock', status='PUBLISHED', product_type='PHYSICAL')
        db.add(p); db.flush()
        v = ProductVariant(tenant_id=tid, product_id=p.id, sku='CC-STOCK', price_amount_minor=1000,
                           cost_amount_minor=300, currency='USD', status='ACTIVE')
        db.add(v); db.flush()
        db.add(InventoryItem(tenant_id=tid, variant_id=v.id, location_id=loc.id,
                             on_hand=0, available=0, reserved=0, committed=0, version=1))
        o = Order(tenant_id=tid, order_number='CC-OPS', status='CONFIRMED', payment_status='PAID',
                  fulfillment_status='UNFULFILLED', currency='USD', subtotal_minor=1000,
                  discount_minor=0, shipping_minor=0, tax_minor=0, fee_minor=0, total_minor=1000)
        db.add(o); db.commit()
    finally:
        db.close()
    r = client.get('/v1/analytics/command-center', params={'tenant_id': tid},
                   headers={'Authorization': f"Bearer {x['access_token']}"})
    assert r.status_code == 200, r.text
    codes = {a['code'] for a in r.json()['actions']}
    assert 'RESTOCK_OUT_OF_STOCK' in codes
    assert 'CLEAR_FULFILLMENT_BACKLOG' in codes


def test_command_center_rejects_invalid_window(client):
    x = register(client, 'command-center-window@example.com')
    r = client.get('/v1/analytics/command-center', params={'tenant_id': x['tenant']['id'], 'days': 'abc'},
                   headers={'Authorization': f"Bearer {x['access_token']}"})
    assert r.status_code == 422, r.text
    assert isinstance(r.json().get('detail'), list)


def test_command_center_is_tenant_scoped(client):
    a = register(client, 'command-center-a@example.com')
    b = register(client, 'command-center-b@example.com')
    r = client.get('/v1/analytics/command-center', params={'tenant_id': b['tenant']['id']},
                   headers={'Authorization': f"Bearer {a['access_token']}"})
    assert r.status_code in (403, 404), r.text
