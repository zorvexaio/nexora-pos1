from pathlib import Path

def test_ucp_agent_identity_requires_header_and_bearer_credential():
    src=Path("app/routes/worldclass.py").read_text(encoding="utf-8")
    assert "UCP-Agent" in src and "UCP_AGENT_HEADER_REQUIRED" in src and "UCP_AGENT_AUTH_REQUIRED" in src
    assert "profile_uri" in src and "Bearer" in src

def test_agent_profiles_store_only_secret_hashes_and_return_secret_once():
    model=Path("app/models/domain.py").read_text(encoding="utf-8"); route=Path("app/routes/worldclass.py").read_text(encoding="utf-8"); service=Path("app/services/global_control_plane.py").read_text(encoding="utf-8")
    assert "client_secret_hash" in model and "token_hash(client_secret)" in route and "payload['client_secret'] = client_secret" in route and "token_hash(agent_secret)" in service

def test_ucp_agent_profile_endpoint_is_discoverable():
    src=Path("app/routes/worldclass.py").read_text(encoding="utf-8")
    assert "/.well-known/agent/{client_id}.json" in src and "https://{hostname}/.well-known/agent/{row.client_id}.json" in src

def test_agent_identity_migration_is_on_single_head():
    src=Path("alembic/versions/20260820_0059_agent_ucp_credentials.py").read_text(encoding="utf-8")
    assert 'down_revision = "20260820_0058"' in src
