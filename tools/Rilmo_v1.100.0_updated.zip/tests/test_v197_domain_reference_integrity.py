from types import SimpleNamespace

def test_domain_registration_without_provider_reference_fails_closed(monkeypatch):
    import app.worker as worker
    import app.services.domain_registrar as registrar
    purchase=SimpleNamespace(tenant_id='t1', status='PENDING_PAYMENT', hostname='example.com', years=1,
        customer_price_minor=1000, currency='USD', domain_id='d1', failure_reason=None,
        provider_reference=None, registrant_snapshot={}, completed_at=None)
    class Query:
        def filter_by(self, **kwargs): return self
        def order_by(self,*a,**k): return self
        def first(self): return SimpleNamespace(id='d1', tenant_id='t1')
    class DB:
        def __init__(self): self.info={'captured_amount_minor':1000,'captured_currency':'USD'}; self.commits=0; self.bind=SimpleNamespace(dialect=SimpleNamespace(name='sqlite'))
        def query(self, model): return Query()
        def flush(self): pass
        def commit(self): self.commits += 1
        def add(self,obj): pass
    monkeypatch.setattr(registrar,'check_domain',lambda *a,**k:{'registrable':True})
    monkeypatch.setattr(registrar,'register_domain',lambda *a,**k:{'status':'REGISTERED'})
    db=DB()
    assert worker.process_domain_registration(db,purchase)=='RECONCILIATION_REQUIRED'
    assert purchase.status=='REGISTRATION_RECONCILIATION_REQUIRED'
    assert purchase.provider_reference is None
