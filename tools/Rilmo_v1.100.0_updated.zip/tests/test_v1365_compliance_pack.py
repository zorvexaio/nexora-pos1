from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "docs/compliance/PRIVACY_POLICY_MASTER.md",
    "docs/compliance/TERMS_OF_SERVICE_MASTER.md",
    "docs/compliance/ACCEPTABLE_USE_AND_PROHIBITED_PRODUCTS.md",
    "docs/compliance/DATA_RETENTION_AND_DELETION_SCHEDULE.md",
    "docs/compliance/DATA_PROCESSING_ADDENDUM_MASTER.md",
    "docs/compliance/COOKIE_AND_TRACKING_POLICY.md",
    "docs/compliance/MERCHANT_PRIVACY_COMPLIANCE_GUIDE.md",
    "docs/compliance/LEGAL_JURISDICTION_MATRIX.md",
    "docs/compliance/COMPLIANCE_RELEASE_GATE.md",
    "docs/compliance/SECURITY_AND_PRIVACY_ARCHITECTURE.md",
    "docs/compliance/LEGAL_ENTITY_CONFIGURATION_REQUIRED.md",
    "docs/compliance/compliance_manifest.json",
]
def test_compliance_pack_present():
    for rel in REQUIRED:
        p = ROOT / rel
        assert p.is_file(), rel
        assert p.stat().st_size > 200, rel

def test_public_legal_pages_present():
    for rel in ["app/frontend/privacy.html", "app/frontend/terms.html"]:
        p = ROOT / rel
        assert p.is_file()
        text = p.read_text(encoding="utf-8")
        assert "[الاسم القانوني]" in text or "[يُستكمل" in text
