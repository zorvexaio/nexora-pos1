from datetime import datetime, timezone
from pathlib import Path

from app.core.database import SessionLocal
from app.core.serialization import json_model
from app.models.domain import Domain, Product, ProductVariant, Storefront, InventoryLocation, InventoryItem, POSLocation, Tenant


def register(client, email='v149@example.com'):
    r = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'Worldclass'})
    assert r.status_code == 200, r.text
    return r.json()


def test_weak_generic_serializer_never_exposes_new_sensitive_names():
    from app.models.domain import MerchantPaymentAccount, CarrierAccount, APIKey
    from app.core.serialization import json_model
    p = MerchantPaymentAccount(tenant_id='t', provider='iyzico', credentials_encrypted='SECRET')
    c = CarrierAccount(tenant_id='t', carrier_code='x', api_token_encrypted='SECRET')
    k = APIKey(tenant_id='t', name='x', key_prefix='pk', key_hash='HASH', scopes=[])
    for row in (p, c, k):
        out = json_model(row)
        assert 'credentials_encrypted' not in out
        assert 'api_token_encrypted' not in out
        assert 'key_hash' not in out


def test_b2b_company_catalog_and_assignment(client):
    x = register(client, 'b2b-v149@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    c = client.post('/v1/b2b/companies', params={'tenant_id': tid}, headers=h,
                    json={'name': 'Acme Wholesale', 'external_code': 'ACME-001', 'payment_terms_days': 30,
                          'credit_limit_minor': 500000})
    assert c.status_code == 200, c.text
    cat = client.post('/v1/b2b/catalogs', params={'tenant_id': tid}, headers=h,
                      json={'name': 'Wholesale', 'code': 'WHOLESALE', 'currency': 'USD'})
    assert cat.status_code == 200, cat.text
    ass = client.post(f"/v1/b2b/catalogs/{cat.json()['id']}/assign", params={'tenant_id': tid, 'company_id': c.json()['id']}, headers=h)
    assert ass.status_code == 200, ass.text


def test_pos_location_register_and_cash_session(client):
    x = register(client, 'pos-v149@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    loc = client.post('/v1/pos/locations', params={'tenant_id': tid}, headers=h,
                      json={'code': 'IST-01', 'name': 'Istanbul Store'})
    assert loc.status_code == 200, loc.text
    reg = client.post('/v1/pos/registers', params={'tenant_id': tid}, headers=h,
                      json={'location_id': loc.json()['id'], 'register_code': 'REG-01', 'name': 'Front Register'})
    assert reg.status_code == 200, reg.text
    op = client.post('/v1/pos/sessions/open', params={'tenant_id': tid}, headers=h,
                     json={'register_id': reg.json()['id'], 'opening_cash_minor': 10000})
    assert op.status_code == 200, op.text
    close = client.post(f"/v1/pos/sessions/{op.json()['id']}/close", params={'tenant_id': tid}, headers=h,
                        json={'closing_cash_minor': 10000})
    assert close.status_code == 200, close.text



def test_pos_sale_requires_idempotency_and_is_authoritative(client):
    x = register(client, 'pos-sale-v149@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token'], 'Idempotency-Key': 'pos-sale-001'}
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        sf = db.query(Storefront).filter_by(tenant_id=tid).first()
        invloc = InventoryLocation(tenant_id=tid, name='POS Inventory')
        db.add(invloc); db.flush()
        loc = db.query(POSLocation).filter_by(tenant_id=tid, code='SALE-01').first()
        if not loc:
            loc = POSLocation(tenant_id=tid, code='SALE-01', name='Sale Store', inventory_location_id=invloc.id)
            db.add(loc); db.flush()
        product = Product(tenant_id=tid, slug='pos-sale-widget', title='POS Sale Widget', status='PUBLISHED')
        db.add(product); db.flush()
        variant = ProductVariant(tenant_id=tid, product_id=product.id, sku='POS-SALE-1', price_amount_minor=1250, currency='USD', status='ACTIVE')
        db.add(variant); db.flush()
        db.add(InventoryItem(tenant_id=tid, variant_id=variant.id, location_id=invloc.id, on_hand=10, available=10, reserved=0, committed=0, version=1))
        db.commit(); register_payload={'location_id': loc.id, 'register_code': 'SALE-REG', 'name': 'Sale Register'}; variant_id=variant.id; loc_id=loc.id
    finally:
        db.close()
    reg = client.post('/v1/pos/registers', params={'tenant_id': tid}, headers={'Authorization': 'Bearer ' + x['access_token']}, json=register_payload)
    assert reg.status_code == 200, reg.text
    op = client.post('/v1/pos/sessions/open', params={'tenant_id': tid}, headers={'Authorization': 'Bearer ' + x['access_token']}, json={'register_id': reg.json()['id'], 'opening_cash_minor': 0})
    assert op.status_code == 200, op.text
    sale = client.post(f"/v1/pos/sessions/{op.json()['id']}/sales", params={'tenant_id': tid}, headers=h,
                       json={'currency': 'USD', 'items': [{'variant_id': variant_id, 'quantity': 2, 'unit_price_minor': 1}]})
    assert sale.status_code == 200, sale.text
    assert sale.json()['total_minor'] == 2500
    retry = client.post(f"/v1/pos/sessions/{op.json()['id']}/sales", params={'tenant_id': tid}, headers=h,
                        json={'currency': 'USD', 'items': [{'variant_id': variant_id, 'quantity': 2, 'unit_price_minor': 999999}]})
    assert retry.status_code == 409

def test_experiment_assignment_is_stable(client):
    x = register(client, 'experiment-v149@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    r = client.post('/v1/experiments', params={'tenant_id': tid}, headers=h,
                    json={'key': 'hero', 'name': 'Hero Rollout', 'traffic_bps': 10000,
                          'variants': [{'key': 'control', 'weight_bps': 5000}, {'key': 'ai', 'weight_bps': 5000}]})
    assert r.status_code == 200, r.text
    exid = r.json()['id']
    assert client.patch(f'/v1/experiments/{exid}/status', params={'tenant_id': tid}, headers=h,
                        json={'status': 'ACTIVE'}).status_code == 200
    a = client.post(f'/v1/experiments/{exid}/assign', params={'tenant_id': tid, 'subject_key': 'visitor-1'}, headers=h).json()
    b = client.post(f'/v1/experiments/{exid}/assign', params={'tenant_id': tid, 'subject_key': 'visitor-1'}, headers=h).json()
    assert a['variant_key'] == b['variant_key']


def test_ucp_profile_and_checkout_discovery(client):
    x = register(client, 'ucp-v149@example.com')
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        sf = db.query(Storefront).filter_by(tenant_id=tid).first()
        assert sf
        db.query(Tenant).filter_by(id=tid).update({'status': 'ACTIVE'})
        domain = Domain(tenant_id=tid, storefront_id=sf.id, hostname='ucp-v149.test', verified_at=datetime.now(timezone.utc), is_primary=True)
        db.add(domain)
        db.commit()
    finally:
        db.close()
    well = client.get('/.well-known/ucp')
    assert well.status_code == 200 and well.json()['ucp']['version'] == '2026-04-08'
    profile = client.get('/v1/public/storefront/ucp-v149.test/ucp/profile')
    assert profile.status_code == 200
    db = SessionLocal()
    try:
        product = Product(tenant_id=tid, slug='agentic-widget', title='Agentic Widget', description='A product for agentic checkout', status='PUBLISHED')
        db.add(product); db.flush()
        variant = ProductVariant(tenant_id=tid, product_id=product.id, sku='AGENT-1', price_amount_minor=500, currency='USD', status='ACTIVE')
        db.add(variant); db.commit(); variant_id = variant.id
    finally:
        db.close()
    checkout = client.post('/v1/public/storefront/ucp-v149.test/ucp/checkouts', json={
        'external_session_id': 'agent-1', 'currency': 'USD',
        'line_items': [{'variant_id': variant_id, 'quantity': 2, 'unit_price_minor': 1}],
        'buyer': {'email': 'buyer@example.com'}})
    assert checkout.status_code == 200, checkout.text
    assert checkout.json()['totals']['total_minor'] == 1000
    assert checkout.json()['line_items'][0]['unit_price_minor'] == 500
    retry = client.post('/v1/public/storefront/ucp-v149.test/ucp/checkouts', json={
        'external_session_id': 'agent-1', 'currency': 'USD',
        'line_items': [{'variant_id': variant_id, 'quantity': 2, 'unit_price_minor': 999999}],
        'buyer': {'email': 'buyer@example.com'}})
    assert retry.status_code == 200 and retry.json()['totals']['total_minor'] == 1000
    done = client.post('/v1/public/storefront/ucp-v149.test/ucp/checkouts/agent-1/complete')
    assert done.status_code == 200 and done.json()['status'] == 'completed'


def test_agentic_feed_and_ai_discoverability(client):
    x = register(client, 'feed-v149@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    ai = client.get('/v1/analytics/ai-discoverability', params={'tenant_id': tid}, headers=h)
    assert ai.status_code == 200
    assert 0 <= ai.json()['score'] <= 100
    db = SessionLocal()
    try:
        sf = db.query(Storefront).filter_by(tenant_id=tid).first()
        db.query(Tenant).filter_by(id=tid).update({'status':'ACTIVE'})
        db.add(Domain(tenant_id=tid, storefront_id=sf.id, hostname='feed-v149.test', verified_at=datetime.now(timezone.utc), is_primary=True))
        db.commit()
    finally:
        db.close()
    feed = client.get('/v1/public/storefront/feed-v149.test/feed/ai.json')
    assert feed.status_code == 200
    assert feed.json()['channel'] == 'ai'


def test_worldclass_rls_migration_covers_every_new_tenant_table():
    text = Path('alembic/versions/20260819_0044_worldclass_rls.py').read_text()
    for name in ['b2b_companies','b2b_catalogs','b2b_catalog_items','pos_locations','pos_registers','pos_sessions','commerce_experiments','product_feeds','ucp_checkout_sessions','ucp_events']:
        assert name in text
    assert 'FORCE ROW LEVEL SECURITY' in text
