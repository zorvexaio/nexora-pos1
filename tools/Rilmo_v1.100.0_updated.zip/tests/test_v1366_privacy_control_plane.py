from app.core.database import SessionLocal
import pytest
from app.services.privacy import jurisdiction_for_country, record_consent_event, submit_privacy_request
from app.models.domain import User, PrivacyConsentEvent, PrivacyRequest
from datetime import datetime, timezone


def test_jurisdiction_routing_is_conservative():
    assert jurisdiction_for_country('TR') == 'TR-KVKK'
    assert jurisdiction_for_country('DE') == 'EU-GDPR'
    assert jurisdiction_for_country('GB') == 'UK-GDPR'
    assert jurisdiction_for_country('BR') == 'BR-LGPD'
    assert jurisdiction_for_country('US') == 'US-STATE-PRIVACY'
    assert jurisdiction_for_country('XX') == 'GLOBAL-BASELINE'


@pytest.fixture
def db_session():
    db=SessionLocal()
    try:
        yield db
    finally:
        db.rollback(); db.close()

def test_consent_event_hashes_network_identifiers(db_session):
    u=User(email='privacy@example.com',password_hash='x')
    db_session.add(u); db_session.flush()
    row=record_consent_event(db_session,tenant_id=None,user_id=u.id,customer_id=None,subject_type='USER',subject_id=u.id,
        jurisdiction='TR-KVKK',policy_version='privacy-v1',action='GRANT',
        categories={'marketing':False,'analytics':True},lawful_basis={'analytics':'consent'},source='privacy_center',
        ip='192.0.2.1',user_agent='TestAgent/1.0')
    assert row.ip_hash and row.ip_hash != '192.0.2.1'
    assert row.user_agent_hash and row.user_agent_hash != 'TestAgent/1.0'
    assert row.categories['analytics'] is True
    assert row.categories['marketing'] is False


def test_privacy_request_is_idempotent_per_open_type(db_session):
    u=User(email='dsr@example.com',password_hash='x')
    db_session.add(u); db_session.flush()
    a=submit_privacy_request(db_session,tenant_id=None,user_id=u.id,customer_id=None,request_type='ACCESS',jurisdiction='EU-GDPR')
    b=submit_privacy_request(db_session,tenant_id=None,user_id=u.id,customer_id=None,request_type='ACCESS',jurisdiction='EU-GDPR')
    assert a.id == b.id
    assert a.status == 'SUBMITTED'
