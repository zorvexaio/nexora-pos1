from types import SimpleNamespace


def _settings():
    return SimpleNamespace(
        ENVIRONMENT='production', APP_VERSION='1.95.5', DATABASE_URL='postgresql://x',
        REDIS_URL='redis://redis:6379/0', REDIS_SOCKET_TIMEOUT_SECONDS=0.1,
        CLAMAV_HOST='clamav', CLAMAV_PORT=3310, CLAMAV_TIMEOUT_SECONDS=0.1,
        S3_BUCKET='bucket', S3_ACCESS_KEY_ID='a', S3_SECRET_ACCESS_KEY='s', S3_ENDPOINT_URL='',
    )


def test_ready_requires_object_storage_and_malware_scanner(monkeypatch):
    import app.routes.system_routes as v1  # ready() moved here in Phase 3 split
    monkeypatch.setattr(v1, 'get_settings', _settings)
    class DB:
        def execute(self, *_a, **_k):
            return SimpleNamespace(scalar=lambda: 1, scalar_one=lambda: 1)
    class Redis:
        def ping(self): return True
    class RedisFactory:
        @staticmethod
        def from_url(*_a, **_k): return Redis()
    import sys, types
    monkeypatch.setitem(sys.modules, 'redis', types.SimpleNamespace(Redis=RedisFactory))
    class StoreClient:
        def head_bucket(self, **_k): return True
    class Store:
        bucket='bucket'; client=StoreClient()
    monkeypatch.setattr('app.services.storage.get_object_store', lambda: Store())
    class Sock:
        def __enter__(self): return self
        def __exit__(self, *_a): return False
        def sendall(self, _x): pass
        def recv(self, _n): return b'PONG\\x00'
    import socket
    monkeypatch.setattr(socket, 'create_connection', lambda *_a, **_k: Sock())
    import sys, types
    monkeypatch.setitem(sys.modules, 'app.core.runtime', types.SimpleNamespace(assert_migration_head=lambda _db: None))
    result = v1.ready(DB())
    assert result['checks']['database'] is True
    assert result['checks']['redis'] is True
    assert result['checks']['object_storage'] is True
    assert result['checks']['malware_scanner'] is True


def test_ready_fails_closed_when_object_storage_is_down(monkeypatch):
    import app.routes.system_routes as v1  # ready() moved here in Phase 3 split
    monkeypatch.setattr(v1, 'get_settings', _settings)
    class DB:
        def execute(self, *_a, **_k): return SimpleNamespace(scalar=lambda: 1, scalar_one=lambda: 1)
    class Redis:
        def ping(self): return True
    import sys, types
    monkeypatch.setitem(sys.modules, 'redis', types.SimpleNamespace(Redis=SimpleNamespace(from_url=lambda *_a, **_k: Redis())))
    class StoreClient:
        def head_bucket(self, **_k): raise RuntimeError('down')
    class Store: bucket='bucket'; client=StoreClient()
    monkeypatch.setattr('app.services.storage.get_object_store', lambda: Store())
    class Sock:
        def __enter__(self): return self
        def __exit__(self, *_a): return False
        def sendall(self, _x): pass
        def recv(self, _n): return b'PONG\\x00'
    import socket
    monkeypatch.setattr(socket, 'create_connection', lambda *_a, **_k: Sock())
    import sys, types
    monkeypatch.setitem(sys.modules, 'app.core.runtime', types.SimpleNamespace(assert_migration_head=lambda _db: None))
    try:
        v1.ready(DB())
    except Exception as exc:
        assert getattr(exc, 'status_code', None) == 503
        assert exc.detail['checks']['object_storage'] is False
    else:
        raise AssertionError('ready() must fail closed when object storage is unavailable')
