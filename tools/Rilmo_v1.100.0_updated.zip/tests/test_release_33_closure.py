from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_seo_and_legal_assets_exist():
    frontend = ROOT / "app" / "frontend"
    for name in ["privacy.html", "terms.html", "kvkk.html", "storefront.html", "storefront.js"]:
        assert (frontend / name).is_file()

def test_main_exposes_seo_routes():
    text = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
    assert "@app.get('/robots.txt'" in text
    assert "@app.get('/sitemap.xml'" in text
    assert "/store/{hostname}/product/{slug}" in text

def test_fx_fails_closed_without_live_provider():
    from app.services.fx import FXProvider
    from app.core.errors import AppError
    try:
        FXProvider().quote(base="USD", quote="TRY")
    except AppError as exc:
        assert "FX_NOT_CONFIGURED" in str(exc)
    else:
        raise AssertionError("FX provider must not fabricate exchange rates")


def test_storefront_host_uses_csp_safe_metadata():
    from pathlib import Path
    main = Path('app/main.py').read_text(encoding='utf-8')
    js = Path('app/frontend/storefront.js').read_text(encoding='utf-8')
    assert 'window.__STORE_HOST__' not in main
    assert 'window.__STORE_HOST__' not in js
    assert 'meta[name=store-host]' in js

def test_rilmo_visual_identity_is_custom_and_not_generic_bag():
    frontend = ROOT / 'app' / 'frontend'
    icon = (frontend / 'icon-512.svg').read_text(encoding='utf-8')
    storefront = (frontend / 'storefront.html').read_text(encoding='utf-8')
    dashboard = (frontend / 'index.html').read_text(encoding='utf-8')
    assert 'Rilmo' in icon  # rebranded from Rilmo to Rilmo
    assert 'M112 122h190c47 0 78 30' in icon  # custom geometric R monogram path (was the T path pre-rebrand)
    assert 'src="/icon-192.svg"' in storefront
    assert 'Rilmo' in dashboard  # rebranded from Rilmo to Rilmo
    assert 'store-mark' in storefront


def test_storefront_has_premium_visual_sections_and_social_meta():
    html = (ROOT / 'app' / 'frontend' / 'storefront.html').read_text(encoding='utf-8')
    css = (ROOT / 'app' / 'frontend' / 'storefront.css').read_text(encoding='utf-8')
    for marker in ['og:image', 'twitter:card', 'visual-rail', 'brand-promise', 'stage-monogram']:
        assert marker in (html + css)


def test_dynamic_product_seo_includes_offer_brand_and_social_image():
    text = (ROOT / 'app' / 'main.py').read_text(encoding='utf-8')
    assert "'brand':{'@type':'Brand','name':t.name}" in text
    assert "product_schema['offers']={'@type':'Offer'" in text
    assert 'og:image' in text and 'twitter:card' in text
