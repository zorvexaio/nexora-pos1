import ast
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
ROUTES = [ROOT / 'app' / 'routes' / 'v1.py', ROOT / 'app' / 'routes' / 'advanced.py', ROOT / 'app' / 'routes' / 'worldclass.py', ROOT / 'app' / 'routes' / 'auth_routes.py', ROOT / 'app' / 'routes' / 'product_routes.py', ROOT / 'app' / 'routes' / 'merchant_compliance_routes.py', ROOT / 'app' / 'routes' / 'apps_marketplace_routes.py', ROOT / 'app' / 'routes' / 'theme_routes.py', ROOT / 'app' / 'routes' / 'marketing_routes.py', ROOT / 'app' / 'routes' / 'tenant_setup_routes.py', ROOT / 'app' / 'routes' / 'support_routes.py', ROOT / 'app' / 'routes' / 'workflow_market_routes.py', ROOT / 'app' / 'routes' / 'notification_routes.py', ROOT / 'app' / 'routes' / 'risk_apikey_routes.py', ROOT / 'app' / 'routes' / 'mfa_routes.py', ROOT / 'app' / 'routes' / 'media_routes.py', ROOT / 'app' / 'routes' / 'oauth_routes.py', ROOT / 'app' / 'routes' / 'review_qa_routes.py', ROOT / 'app' / 'routes' / 'member_routes.py', ROOT / 'app' / 'routes' / 'category_routes.py', ROOT / 'app' / 'routes' / 'wishlist_routes.py', ROOT / 'app' / 'routes' / 'tax_routes.py', ROOT / 'app' / 'routes' / 'onboarding_routes.py', ROOT / 'app' / 'routes' / 'shipping_routes.py', ROOT / 'app' / 'routes' / 'inventory_routes.py', ROOT / 'app' / 'routes' / 'customer_routes.py', ROOT / 'app' / 'routes' / 'return_routes.py', ROOT / 'app' / 'routes' / 'billing_routes.py', ROOT / 'app' / 'routes' / 'system_routes.py', ROOT / 'app' / 'routes' / 'order_routes.py', ROOT / 'app' / 'routes' / 'cart_routes.py', ROOT / 'app' / 'routes' / 'turkey_routes.py', ROOT / 'app' / 'routes' / 'domain_purchase_routes.py', ROOT / 'app' / 'routes' / 'platform_trust_routes.py', ROOT / 'app' / 'routes' / 'public_storefront_routes.py', ROOT / 'app' / 'routes' / 'checkout_routes.py', ROOT / 'app' / 'routes' / 'payment_routes.py', ROOT / 'app' / 'routes' / 'auth_google_routes.py', ROOT / 'app' / 'routes' / 'privacy_routes.py', ROOT / 'app' / 'routes' / 'buyer_protection_routes.py', ROOT / 'app' / 'routes' / 'webhook_routes.py']

def _declared_routes():
    rows = []
    for route_file in ROUTES:
        tree = ast.parse(route_file.read_text())
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for dec in node.decorator_list:
                if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute)):
                    continue
                if not (isinstance(dec.func.value, ast.Name) and dec.func.value.id == 'router'):
                    continue
                if dec.func.attr.lower() not in {'get', 'post', 'patch', 'put', 'delete', 'options', 'head'}:
                    continue
                if not dec.args or not isinstance(dec.args[0], ast.Constant):
                    continue
                rows.append((dec.func.attr.upper(), dec.args[0].value, node.name))
    return rows

def test_router_route_keys_are_unique_and_include_current_webhooks():
    rows = _declared_routes()
    keys = [(m, p) for m, p, _ in rows]
    assert len(rows) >= 120
    assert len(keys) == len(set(keys))
    assert ('POST', '/webhooks/iyzico') in keys
    assert ('POST', '/webhooks/paytr') in keys
    assert ('POST', '/webhooks/paddle') in keys

def _iter_routes(routes):
    for route in routes:
        original = getattr(route, 'original_router', None)
        if original is not None and hasattr(original, 'routes'):
            yield from _iter_routes(original.routes)
            continue
        yield route

def test_runtime_fastapi_registry_has_no_duplicate_api_method_paths():
    rows = _declared_routes()
    from app.main import app
    api = [(method, route.path) for route in _iter_routes(app.routes) if getattr(route, 'path', '').startswith('/v1/') for method in getattr(route, 'methods', set()) if method not in {'HEAD', 'OPTIONS'}]
    assert len(api) == len(set(api))
    assert len(api) == len(rows) + 1
