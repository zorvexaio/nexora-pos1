from pathlib import Path
from types import SimpleNamespace


def test_monthly_report_persists_sending_state_before_email(monkeypatch):
    import app.worker as worker
    sent = []
    fake_now = SimpleNamespace(day=1)
    class UserRow:
        email = 'admin@example.com'
    class Query:
        def __init__(self, first=None, all_rows=None): self._first=first; self._all=all_rows or []
        def filter_by(self, **kwargs): return self
        def first(self): return self._first
        def join(self, *args, **kwargs): return self
        def all(self): return self._all
    class DB:
        bind = SimpleNamespace(dialect=SimpleNamespace(name='sqlite'))
        def __init__(self): self.report=None; self.commits=0
        def query(self, model):
            name=getattr(model,'__name__','')
            if name == 'PlatformMonthlyReport': return Query(None if self.report is None else self.report)
            if name == 'User': return Query(None, [UserRow()])
            return Query()
        def add(self, obj): self.report=obj
        def flush(self): pass
        def commit(self): self.commits += 1
        def rollback(self): pass
    db=DB()
    monkeypatch.setattr(worker,'datetime',SimpleNamespace(
        now=lambda tz=None: fake_now_dt,
        strptime=__import__('datetime').datetime.strptime,
    ))
    fake_now_dt=__import__('datetime').datetime(2026,8,1,tzinfo=__import__('datetime').timezone.utc)
    monkeypatch.setattr('app.services.advanced.platform_metrics', lambda *a, **k: {'gmv': 1})
    monkeypatch.setattr('app.services.mailer.send_email', lambda *a, **k: sent.append(db.commits))
    # run_platform_monthly_report uses a separate SessionLocal after sending; static
    # transaction-boundary verification covers the critical ordering here.
    text=Path('app/worker.py').read_text()
    assert text.index("report = PlatformMonthlyReport(period_key=previous, recipients=recipients, metrics=metrics, delivery_status='SENDING')") < text.index('db.commit()', text.index("report = PlatformMonthlyReport"))
    assert text.index('db.commit()', text.index("report = PlatformMonthlyReport")) < text.index('send_email(recipient, subject, body)')


def test_domain_registration_commits_processing_before_external_call(monkeypatch):
    import app.worker as worker
    import app.services.domain_registrar as registrar
    purchase=SimpleNamespace(
        tenant_id='t1', status='PENDING_PAYMENT', hostname='example.com', years=1,
        customer_price_minor=1000, currency='USD', domain_id=None,
        failure_reason=None, provider_reference=None, registrant_snapshot={}, completed_at=None,
    )
    storefront=SimpleNamespace(id='s1', version=1)
    domain=SimpleNamespace(id='d1', tenant_id='t1')
    class Query:
        def __init__(self, first): self._first=first
        def filter_by(self, **kwargs): return self
        def order_by(self, *args, **kwargs): return self
        def first(self): return self._first
    class DB:
        def __init__(self): self.info={'captured_amount_minor':1000,'captured_currency':'USD'}; self.commits=0
        def query(self, model):
            name=getattr(model,'__name__','')
            if name=='Domain': return Query(domain)
            if name=='Storefront': return Query(storefront)
            return Query(None)
        def flush(self): pass
        def commit(self): self.commits += 1
        def add(self,obj): pass
    db=DB(); observed=[]
    monkeypatch.setattr(registrar,'check_domain',lambda *a,**k:{'registrable':True})
    def fake_register(*args,**kwargs):
        observed.append((purchase.status, db.commits))
        return {'status':'REGISTERED','reference':'reg-1'}
    monkeypatch.setattr(registrar,'register_domain',fake_register)
    result=worker.process_domain_registration(db,purchase)
    assert result=='COMPLETED'
    assert observed==[('REGISTRATION_PROCESSING',1)]
    assert purchase.provider_reference=='reg-1'


def test_domain_registration_ambiguous_failure_never_auto_retries(monkeypatch):
    import app.worker as worker
    purchase=SimpleNamespace(status='REGISTRATION_PROCESSING', tenant_id='t1', failure_reason=None)
    class DB:
        def __init__(self): self.commits=0
        def commit(self): self.commits+=1
    db=DB()
    result=worker.process_domain_registration(db,purchase)
    assert result=='RECONCILIATION_REQUIRED'
    assert purchase.status=='REGISTRATION_RECONCILIATION_REQUIRED'
    assert db.commits==1


def test_domain_registration_reconciliation_state_is_idempotent():
    import app.worker as worker
    purchase=SimpleNamespace(status='REGISTRATION_RECONCILIATION_REQUIRED', tenant_id='t1')
    class DB: pass
    assert worker.process_domain_registration(DB(), purchase)=='RECONCILIATION_REQUIRED'
