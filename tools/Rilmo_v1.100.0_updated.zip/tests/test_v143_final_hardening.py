from pathlib import Path
from app.core.config import Settings

def test_impersonation_uses_dedicated_cookie_and_ticket_gate_source():
    src=Path('app/routes/advanced.py').read_text(encoding='utf-8')
    assert 'impersonation_session' in src
    assert 'IMPERSONATION_TICKET_REQUIRED_PRODUCTION' in src
    assert 'ticket_id' in src

def test_impersonation_end_is_not_blocked_by_read_only_session():
    src=Path('app/core/auth.py').read_text(encoding='utf-8')
    assert "request.url.path != '/v1/auth/impersonation/end'" in src

def test_production_requires_explicit_impersonation_ticket_setting():
    s=Settings(IMPERSONATION_TICKET_REQUIRED_PRODUCTION=True)
    assert s.IMPERSONATION_TICKET_REQUIRED_PRODUCTION is True

def test_release_version_matches_expected_major_minor_contract():
    version = Path('VERSION').read_text(encoding='utf-8').strip()
    major, minor, patch = (int(x) for x in version.split('.'))
    assert major == 1
    assert minor >= 47
    assert patch >= 0


def test_impersonation_roundtrip_preserves_employee_session(client):
    from fastapi.testclient import TestClient
    from app.core.database import SessionLocal
    from app.models.domain import PlatformAdmin, MFAFactor
    admin = client.post('/v1/auth/register', json={'email': 'platform-admin@example.com', 'password': 'VerySecurePassword123!'}).json()
    with TestClient(client.app) as target_client:
        target = target_client.post('/v1/auth/register', json={'email': 'target-user@example.com', 'password': 'VerySecurePassword123!'}).json()
    db = SessionLocal()
    try:
        db.add(PlatformAdmin(user_id=admin['user']['id'], platform_role='super_admin'))
        db.add(MFAFactor(user_id=admin['user']['id'], factor_type='TOTP', enabled=True))
        db.commit()
    finally:
        db.close()
    tid = target['tenant']['id']
    h={'Authorization':'Bearer '+admin['access_token']}
    r=client.post(f'/v1/admin/impersonate/{tid}', headers=h, params={'reason':'Support case investigation','ticket_id':'CASE-10482'})
    assert r.status_code == 200, r.text
    employee_session = client.cookies.get('session')
    assert employee_session is not None
    assert client.cookies.get('impersonation_session') is not None
    me=client.get('/v1/me')
    assert me.status_code == 200
    assert me.json()['user']['id'] == target['user']['id']
    imp_csrf = client.cookies.get('impersonation_csrf_token')
    end=client.post('/v1/auth/impersonation/end', headers={'X-CSRF-Token': imp_csrf})
    assert end.status_code == 200, end.text
    assert client.cookies.get('impersonation_session') is None
    assert client.cookies.get('session') == employee_session
    me2=client.get('/v1/me')
    assert me2.status_code == 200
    assert me2.json()['user']['id'] == admin['user']['id']
