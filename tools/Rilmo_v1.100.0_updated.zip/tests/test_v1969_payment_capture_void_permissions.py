def register(client, email):
    r = client.post('/v1/auth/register', json={
        'email': email,
        'password': 'VerySecurePassword123!',
        'display_name': 'Payment Permission Test',
    })
    assert r.status_code == 200, r.text
    return r.json()


def test_capture_requires_authenticated_finance_permission(client):
    r = client.post('/v1/payments/not-a-real-payment/capture', params={'tenant_id': 'missing-tenant'})
    assert r.status_code in {401, 403}


def test_void_requires_authenticated_finance_permission(client):
    r = client.post('/v1/payments/not-a-real-payment/void', params={'tenant_id': 'missing-tenant'})
    assert r.status_code in {401, 403}


def test_staff_without_finance_manage_cannot_capture_or_void(client):
    from app.core.database import SessionLocal
    from app.models.domain import TenantMembership, User
    from app.core.security import hash_password
    x = register(client, 'staff-payment-v1969@example.com')
    tid = x['tenant']['id']
    owner_id = x['user']['id'] if 'user' in x and isinstance(x['user'], dict) else None
    db = SessionLocal()
    try:
        owner = db.get(User, owner_id) if owner_id else db.query(User).filter_by(email='staff-payment-v1969@example.com').first()
        assert owner
        staff = User(email='staff-payment-v1969-staff@example.com', password_hash=hash_password('StaffPassword123!'), status='ACTIVE')
        db.add(staff); db.flush()
        db.add(TenantMembership(tenant_id=tid, user_id=staff.id, role='staff', status='ACTIVE'))
        db.commit(); staff_email = staff.email
    finally:
        db.close()
    r = client.post('/v1/auth/login', json={'email': staff_email, 'password': 'StaffPassword123!'})
    assert r.status_code == 200, r.text
    token = r.json()['access_token']
    headers = {'Authorization': 'Bearer ' + token}
    cap = client.post('/v1/payments/not-a-real-payment/capture', params={'tenant_id': tid}, headers=headers)
    void = client.post('/v1/payments/not-a-real-payment/void', params={'tenant_id': tid}, headers=headers)
    assert cap.status_code == 403
    assert void.status_code == 403
