import base64, hashlib, urllib.parse, secrets


def _h(x):
    return {'Authorization': 'Bearer ' + x['access_token']}


def _pkce(verifier):
    return base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()


def _authorize(client, headers, tid, client_id, verifier, scope):
    r = client.get('/v1/oauth/authorize', params={
        'client_id': client_id,
        'redirect_uri': 'https://example.com/cb',
        'response_type': 'code',
        'scope': scope,
        'state': 'state-' + secrets.token_urlsafe(8),
        'code_challenge': _pkce(verifier),
        'code_challenge_method': 'S256',
        'tenant_id': tid,
    }, headers=headers, follow_redirects=False)
    assert r.status_code == 302
    return urllib.parse.parse_qs(urllib.parse.urlsplit(r.headers['location']).query)['code'][0]


def test_oauth_reauthorization_scope_reduction_revokes_old_credentials(client):
    from tests.test_p0 import register
    from app.core.database import SessionLocal
    from app.models.domain import AppDefinition
    from app.core.security import token_hash

    owner = register(client, 'v1969-scope-owner@example.com')
    tid = owner['tenant']['id']
    secret = 'scope-secret-' + secrets.token_urlsafe(10)
    db = SessionLocal()
    app = AppDefinition(
        name='Scope Reauth App', slug='scope-reauth-' + secrets.token_urlsafe(6),
        client_id='scope-reauth-' + secrets.token_urlsafe(6),
        client_secret_hash=token_hash(secret),
        redirect_uris=['https://example.com/cb'],
        scopes=['store.read', 'orders.read'], status='APPROVED')
    db.add(app); db.commit(); client_id = app.client_id; db.close()

    v1 = 'verifier-' + secrets.token_urlsafe(16)
    code1 = _authorize(client, _h(owner), tid, client_id, v1, 'store.read orders.read')
    t1 = client.post('/v1/oauth/token', data={
        'grant_type':'authorization_code','client_id':client_id,'client_secret':secret,
        'code':code1,'redirect_uri':'https://example.com/cb','code_verifier':v1})
    assert t1.status_code == 200
    old = t1.json()

    # Merchant removes orders.read from the installation grant.
    v2 = 'verifier-' + secrets.token_urlsafe(16)
    code2 = _authorize(client, _h(owner), tid, client_id, v2, 'store.read')
    assert code2

    old_api = client.get('/v1/apps/api/v1/tenant', headers=_h(old))
    assert old_api.status_code == 401
    old_refresh = client.post('/v1/oauth/token', data={
        'grant_type':'refresh_token','client_id':client_id,'client_secret':secret,
        'refresh_token':old['refresh_token']})
    assert old_refresh.status_code == 400
    assert old_refresh.json()['detail']['error']['code'] == 'OAUTH_REFRESH_INVALID'

    t2 = client.post('/v1/oauth/token', data={
        'grant_type':'authorization_code','client_id':client_id,'client_secret':secret,
        'code':code2,'redirect_uri':'https://example.com/cb','code_verifier':v2})
    assert t2.status_code == 200
    assert t2.json()['scope'] == 'store.read'
