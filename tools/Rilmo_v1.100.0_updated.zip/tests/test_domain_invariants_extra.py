from app.services.order_state import transition
from app.core.errors import AppError
from types import SimpleNamespace

def test_order_state_machine_rejects_invalid_transition():
    o = SimpleNamespace(status='DELIVERED')
    try:
        transition(o, 'CANCELLED')
    except AppError as exc:
        assert 'ORDER_STATE_INVALID' in str(exc)
    else:
        raise AssertionError('invalid transition accepted')

def test_order_state_machine_accepts_forward_flow():
    o = SimpleNamespace(status='PENDING_PAYMENT')
    transition(o, 'CONFIRMED')
    transition(o, 'PROCESSING')
    transition(o, 'SHIPPED')
    transition(o, 'DELIVERED')
    transition(o, 'FULFILLED')
    assert o.status == 'FULFILLED'

def test_inventory_expiry_releases_stock(client):
    from datetime import datetime, timezone, timedelta
    from app.core.database import SessionLocal
    from app.models.domain import InventoryItem, InventoryReservation
    x = client.post('/v1/auth/register', json={'email': 'expiry@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'expiry', 'title': 'Expiry', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'EXP-1', 'price_amount_minor': 100, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=2&reason=test", headers=h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    o = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c['id']}).json()
    db = SessionLocal()
    r = db.query(InventoryReservation).filter_by(order_id=o['id']).first()
    r.expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
    db.commit()
    db.close()
    from app.worker import release_expired_reservations
    db = SessionLocal()
    assert release_expired_reservations(db) >= 1
    db.close()
    db = SessionLocal()
    item = db.query(InventoryItem).filter_by(variant_id=v['id'], tenant_id=tid).first()
    assert item.available == 2 and item.reserved == 0
    db.close()
