import uuid
from app.core.database import SessionLocal
from app.models.domain import OrderIssue


def _register(client, email):
    r = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'})
    assert r.status_code == 200, r.text
    return r.json(), {'Authorization': 'Bearer ' + r.json()['access_token']}


def _paid_order(client, tid, owner_h):
    p = client.post(f'/v1/products?tenant_id={tid}', headers=owner_h,
                    json={'slug': f'perm-{uuid.uuid4().hex[:8]}', 'title': 'Refund Item', 'status': 'ACTIVE'}).json()
    v = client.post(f'/v1/products/{p["id"]}/variants?tenant_id={tid}', headers=owner_h,
                    json={'sku': f'PERM-{uuid.uuid4().hex[:8]}', 'price_amount_minor': 1000, 'currency': 'USD'}).json()
    client.post(f'/v1/inventory/adjustments?tenant_id={tid}&variant_id={v["id"]}&delta=5&reason=test', headers=owner_h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=owner_h, json={'currency': 'USD'}).json()
    client.post(f'/v1/cart/items?tenant_id={tid}&cart_id={c["id"]}', headers=owner_h,
                json={'variant_id': v['id'], 'quantity': 1})
    o = client.post(f'/v1/checkout?tenant_id={tid}', headers=owner_h,
                    json={'cart_id': c['id'], 'customer_email': f'buyer-{uuid.uuid4().hex}@example.com', 'customer_name': 'Buyer'}).json()
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=owner_h,
                     json={'order_id': o['id'], 'amount_minor': o['total_minor'], 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f'/v1/payments/{pi["id"]}/capture?tenant_id={tid}', headers=owner_h,
                json={'amount_minor': o['total_minor'], 'currency': 'USD'})
    return tid, o


def test_staff_cannot_trigger_refund_via_order_issue_resolution(client):
    owner_data, owner_h = _register(client, f'owner-{uuid.uuid4().hex}@example.com')
    tid = owner_data['tenant']['id']
    tid, order = _paid_order(client, tid, owner_h)
    staff_email = f'staff-{uuid.uuid4().hex}@example.com'
    _staff_data, staff_h = _register(client, staff_email)
    add = client.post(f'/v1/members?tenant_id={tid}', headers=owner_h,
                      json={'email': staff_email, 'role': 'staff'})
    assert add.status_code == 200, add.text

    db = SessionLocal()
    issue = OrderIssue(tenant_id=tid, order_id=order['id'], customer_id=None,
                       issue_type='REFUND_REQUEST', status='OPEN', customer_message='Refund',
                       idempotency_key='issue-'+uuid.uuid4().hex)
    db.add(issue); db.commit(); issue_id = issue.id; db.close()

    blocked = client.patch(f'/v1/merchant/order-issues/{issue_id}?tenant_id={tid}',
                           headers=staff_h, json={'action': 'RESOLVE_REFUND', 'message': 'Refund requested'})
    assert blocked.status_code == 403, blocked.text

    allowed = client.patch(f'/v1/merchant/order-issues/{issue_id}?tenant_id={tid}',
                           headers=owner_h, json={'action': 'RESOLVE_REFUND', 'message': 'Refund approved'})
    assert allowed.status_code == 200, allowed.text
