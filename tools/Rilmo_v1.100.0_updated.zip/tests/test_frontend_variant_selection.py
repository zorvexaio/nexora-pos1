from pathlib import Path


def test_storefront_variant_selection_contract_is_wired():
    source = Path('app/frontend/storefront.js').read_text(encoding='utf-8')
    assert "e.target.closest('[data-variant]')" in source
    assert "picked=variants.find(x=>String(x.id)===String(variant.dataset.variant))" in source
    assert "x.classList.toggle('active',active)" in source
    assert "x.setAttribute('aria-pressed',active?'true':'false')" in source
    assert "add.dataset.addDetail=picked.id" in source
    assert "picked.sale_price_minor ?? picked.price_amount_minor" in source
