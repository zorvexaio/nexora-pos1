from datetime import datetime, timezone
from app.services.global_readiness import APP_STORE_POLICY, DEFAULT_MARKETS, readiness_summary
from app.core.config import get_settings

def test_app_store_policies_distinguish_physical_and_digital():
    assert APP_STORE_POLICY['apple']['physical_goods']['payment_method'] != APP_STORE_POLICY['apple']['digital_goods']['payment_method']
    assert APP_STORE_POLICY['google_play']['physical_goods']['allowed'] is True
    assert APP_STORE_POLICY['google_play']['digital_goods']['allowed'] is True

def test_default_global_markets_cover_core_regions():
    assert {'TR','SA','EU','US','GB'} <= set(DEFAULT_MARKETS)

def test_external_ai_is_disabled_by_default():
    s=get_settings()
    assert s.AI_EXTERNAL_PROVIDER_ALLOWED is False
    assert s.AI_PROVIDER.lower() == 'ollama'

def test_installment_policy_is_same_price():
    s=get_settings()
    assert s.CARD_INSTALLMENT_SAME_PRICE_ONLY is True
    assert s.CARD_INSTALLMENT_MAX_COUNT >= 0
