from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_all_payment_mutations_stop_when_same_effect_is_in_progress():
    # CAPTURE/REFUND/VOID moved to payment_routes.py in Phase 3 split
    text = (ROOT / 'app/routes/payment_routes.py').read_text()
    marker = "if state == 'IN_PROGRESS':\n        raise AppError(409, 'PAYMENT_OPERATION_IN_PROGRESS'"
    # CAPTURE, REFUND and VOID must all honor the operation serialization barrier.
    assert text.count(marker) >= 3


def test_payment_operation_active_index_is_unique_in_model():
    text = (ROOT / 'app/models/domain.py').read_text()
    assert "Index('uq_payment_operation_active'" in text
    assert "unique=True" in text
    assert "status IN ('PENDING','PROVIDER_PENDING')" in text


def test_provider_capture_replay_cannot_promote_partial_payment_to_captured():
    text = (ROOT / 'app/routes/webhook_routes.py').read_text()  # moved here in Phase 3 split
    marker = "A replayed provider capture must be observationally idempotent"
    assert marker in text
    assert "captured_total = db.query(PaymentCapture)" in text
    assert "pi.status = 'CAPTURED' if int(captured_total) == int(pi.amount_minor) else 'PARTIALLY_CAPTURED'" in text
