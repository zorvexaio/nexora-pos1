from pathlib import Path

def test_payment_intent_model_binds_to_ucp_checkout():
    src=Path("app/models/domain.py").read_text(encoding="utf-8")
    assert "ucp_checkout_session_id" in src
    assert "ForeignKey('ucp_checkout_sessions.id')" in src

def test_payment_creation_requires_exact_open_ucp_target():
    src=Path("app/routes/payment_routes.py").read_text(encoding="utf-8")  # payments moved here in Phase 3 split
    assert "UCP_CHECKOUT_NOT_OPEN" in src
    assert "UCP_PAYMENT_AMOUNT_MISMATCH" in src
    assert "ucp_checkout_session_id=(ucp_checkout.id if ucp_checkout else None)" in src

def test_ucp_completion_requires_bound_payment_intent():
    src=Path("app/routes/worldclass.py").read_text(encoding="utf-8")
    assert "UCP_PAYMENT_CHECKOUT_MISMATCH" in src
    assert "UCP_PAYMENT_AMOUNT_MISMATCH" in src
    assert "pi.ucp_checkout_session_id != row.id" in src

def test_new_migration_is_single_head_chain():
    src=Path("alembic/versions/20260820_0058_ucp_payment_binding.py").read_text(encoding="utf-8")
    assert 'down_revision = "20260820_0057"' in src
