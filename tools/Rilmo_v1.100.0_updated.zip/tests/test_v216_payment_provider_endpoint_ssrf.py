import pytest


def test_production_payment_provider_ignores_tenant_supplied_base_url(monkeypatch):
    import app.services.payment_providers as mod
    settings = mod.get_settings()
    monkeypatch.setattr(settings, 'ENVIRONMENT', 'production')
    monkeypatch.setattr(settings, 'IYZICO_API_BASE', 'https://api.iyzipay.com')
    p = mod.get_payment_provider('iyzico', {
        'api_key': 'k', 'secret_key': 's', 'base_url': 'http://169.254.169.254/latest'
    })
    assert p.base == 'https://api.iyzipay.com'


def test_local_test_can_use_custom_payment_provider_endpoint(monkeypatch):
    import app.services.payment_providers as mod
    settings = mod.get_settings()
    monkeypatch.setattr(settings, 'ENVIRONMENT', 'test')
    p = mod.get_payment_provider('paytr', {
        'merchant_id': 'm', 'merchant_key': 'k', 'merchant_salt': 's',
        'base_url': 'http://127.0.0.1:9999'
    })
    assert p.base == 'http://127.0.0.1:9999'
