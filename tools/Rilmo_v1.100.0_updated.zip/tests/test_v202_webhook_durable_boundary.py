from types import SimpleNamespace
from datetime import datetime, timezone, timedelta


def test_domain_registrar_never_falls_back_to_hostname(monkeypatch):
    import app.services.domain_registrar as dr
    class R:
        status_code=200
        def json(self): return {"result": {"domain_name": "example.com"}}
    monkeypatch.setattr(dr.httpx, 'post', lambda *a, **k: R())
    monkeypatch.setattr(dr, '_cf_headers', lambda: {})
    monkeypatch.setattr(dr, 'get_settings', lambda: SimpleNamespace(DOMAIN_PROVIDER='cloudflare', DOMAIN_PROVIDER_ACCOUNT_ID='a', DOMAIN_PROVIDER_API_TOKEN='t'))
    result=dr.register_domain('example.com', {'registrant_first_name':'a','registrant_last_name':'b','registrant_email':'a@b.com','registrant_phone':'+1','country_code':'US','city':'x','address_line1':'y'},1)
    assert result['reference'] == ''


def test_app_webhook_processing_is_committed_before_network(monkeypatch):
    import app.services.app_webhooks as aw
    row=SimpleNamespace(status='PENDING', attempt_count=0, next_attempt_at=datetime.now(timezone.utc), created_at=datetime.now(timezone.utc), endpoint_url='https://example.com', subscription_id='s', event_id='e', tenant_id='t', last_error=None, delivered_at=None, processing_started_at=None)
    class Q:
        def __init__(self, first_obj=None, rows=None): self.first_obj=first_obj; self.rows=rows if rows is not None else [row]
        def filter(self,*a,**k): return self
        def filter_by(self,*a,**k): return self
        def order_by(self,*a,**k): return self
        def limit(self,*a,**k): return self
        def with_for_update(self,*a,**k): return self
        def all(self): return self.rows
        def first(self): return self.first_obj
    class DB:
        bind=SimpleNamespace(dialect=SimpleNamespace(name='sqlite'))
        def query(self, model):
            name = getattr(model, '__name__', '')
            if name == 'AppWebhookDelivery': return Q(rows=[row])
            if name == 'AppWebhookSubscription': return Q(first_obj=SimpleNamespace(secret_encrypted='x', status='ACTIVE'))
            if name == 'OutboxEvent': return Q(first_obj=SimpleNamespace(id='e', event_type='order.created', schema_version=1, occurred_at=datetime.now(timezone.utc), payload={'x':1}, tenant_id='t'))
            return Q()
        def commit(self): self.commits=getattr(self,'commits',0)+1
        def flush(self): pass
    db=DB()
    monkeypatch.setattr(aw, '_public_https', lambda u: True)
    monkeypatch.setattr(aw, 'decrypt_secret', lambda s: 'secret')
    monkeypatch.setattr(aw, '_post_pinned', lambda *a, **k: (200,b'',{}))
    # structural guarantee: the network call must happen after PROCESSING commit
    events=[]
    orig_commit=db.commit
    def commit(): events.append(('commit',row.status)); orig_commit()
    db.commit=commit
    aw.process_webhook_deliveries(db,1)
    assert events[0] == ('commit','PROCESSING')
    assert row.status == 'SUCCEEDED'


def test_stale_app_webhook_processing_moves_to_reconciliation(monkeypatch):
    import app.services.app_webhooks as aw
    row=SimpleNamespace(status='PROCESSING', processing_started_at=datetime.now(timezone.utc)-timedelta(hours=2), tenant_id='t', last_error=None)
    class Q:
        def filter(self,*a,**k): return self
        def all(self): return [row]
    class DB:
        bind=SimpleNamespace(dialect=SimpleNamespace(name='sqlite'))
        def query(self, model): return Q()
        def commit(self): self.committed=True
    db=DB()
    assert aw.recover_stale_webhook_deliveries(db, stale_seconds=3600, tenant_id='t') == 1
    assert row.status == 'RECONCILIATION_REQUIRED'
    assert row.processing_started_at is None
