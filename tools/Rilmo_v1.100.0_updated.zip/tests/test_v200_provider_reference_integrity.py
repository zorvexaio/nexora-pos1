import pytest
from app.services.payment_providers import IyzicoProvider, PayTRProvider


def test_iyzico_refund_uses_refund_specific_reference(monkeypatch):
    p = IyzicoProvider(api_key='k', secret_key='s', base_url='https://mock')
    p._post = lambda path, payload: {
        'status': 'success', 'paymentId': 'pay-1', 'refundHostReference': 'refund-abc',
        'price': 10, 'currency': 'TRY'
    }
    r = p.refund('pay-1', 1000, 'TRY', idempotency_key='idem-1')
    assert r.provider_id == 'refund-abc'


def test_iyzico_refund_fails_closed_without_refund_reference():
    p = IyzicoProvider(api_key='k', secret_key='s', base_url='https://mock')
    p._post = lambda path, payload: {'status': 'success', 'paymentId': 'pay-1', 'price': 10, 'currency': 'TRY'}
    with pytest.raises(Exception) as exc:
        p.refund('pay-1', 1000, 'TRY')
    assert 'REFUND_REFERENCE_MISSING' in str(exc.value)


def test_iyzico_cancel_uses_cancel_specific_reference():
    p = IyzicoProvider(api_key='k', secret_key='s', base_url='https://mock')
    p._post = lambda path, payload: {
        'status': 'success', 'paymentId': 'pay-1', 'cancelHostReference': 'cancel-abc'
    }
    r = p.void('pay-1', idempotency_key='idem-1')
    assert r.provider_id == 'cancel-abc'


def test_paytr_refund_requires_reference_echo():
    p = PayTRProvider(merchant_id='mid', merchant_key='key', merchant_salt='salt', base_url='https://mock')
    class Resp:
        status_code = 200
        content = b'{"status":"success"}'
        def json(self): return {'status':'success'}
    class Client:
        def __init__(self, *a, **k): pass
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def post(self, *a, **k): return Resp()
    import httpx
    old = httpx.Client
    httpx.Client = Client
    try:
        with pytest.raises(Exception) as exc:
            p.refund('order-1', 1000, 'TRY', idempotency_key='refund-key')
        assert 'REFUND_REFERENCE_MISSING' in str(exc.value)
    finally:
        httpx.Client = old

def test_domain_registrar_does_not_fabricate_reference_on_empty_result(monkeypatch):
    import app.services.domain_registrar as dr
    class Resp:
        status_code = 200
        def json(self): return {'result': {}}
    class Client:
        pass
    monkeypatch.setattr(dr, '_cf_headers', lambda: {})
    monkeypatch.setattr(dr.httpx, 'post', lambda *a, **k: Resp())
    monkeypatch.setattr(dr, 'get_settings', lambda: type('S', (), {
        'DOMAIN_PROVIDER':'cloudflare', 'DOMAIN_PROVIDER_ACCOUNT_ID':'acct', 'DOMAIN_PROVIDER_API_TOKEN':'tok'
    })())
    result = dr.register_domain('example.com', {
        'registrant_first_name':'A','registrant_last_name':'B','registrant_email':'a@example.com',
        'registrant_phone':'+905000000000','country_code':'TR','city':'Konya','address_line1':'x'
    }, 1)
    assert result['status'] == 'REGISTRATION_PENDING'
    assert result['reference'] == ''
