from datetime import datetime, timezone
from app.models.domain import Tenant, Product, ProductVariant, InventoryItem, InventoryLocation
from app.routes.worldclass import analytics_pricing_intelligence

class MerchantUser: id='merchant-user'


def _seed(db):
    t=Tenant(slug='pi-1994-' + __import__('uuid').uuid4().hex[:8],name='Pricing',status='ACTIVE',default_currency='TRY'); db.add(t); db.flush()
    p1=Product(tenant_id=t.id,slug='healthy',title='Healthy',status='PUBLISHED',product_type='PHYSICAL')
    p2=Product(tenant_id=t.id,slug='under-cost',title='Under cost',status='PUBLISHED',product_type='PHYSICAL')
    p3=Product(tenant_id=t.id,slug='missing-cost',title='Missing cost',status='PUBLISHED',product_type='PHYSICAL')
    db.add_all([p1,p2,p3]); db.flush()
    v1=ProductVariant(tenant_id=t.id,product_id=p1.id,sku='H',price_amount_minor=10000,cost_amount_minor=7000,currency='TRY',status='ACTIVE')
    v2=ProductVariant(tenant_id=t.id,product_id=p2.id,sku='U',price_amount_minor=6000,cost_amount_minor=7000,currency='TRY',status='ACTIVE')
    v3=ProductVariant(tenant_id=t.id,product_id=p3.id,sku='M',price_amount_minor=9000,cost_amount_minor=None,currency='TRY',status='ACTIVE')
    db.add_all([v1,v2,v3]); db.commit()
    return t


def test_pricing_intelligence_flags_margin_breaches(db_session, monkeypatch):
    t=_seed(db_session); monkeypatch.setattr('app.routes.worldclass._perm',lambda *a,**k:None)
    r=analytics_pricing_intelligence(t.id,2000,MerchantUser(),db_session)
    rows={x['sku']:x for x in r['items']}
    assert rows['H']['status']=='HEALTHY'
    assert rows['H']['recommended_min_price_minor']==8750
    assert rows['U']['status']=='UNDER_COST'
    assert rows['U']['gap_to_target_minor']==2750
    assert rows['M']['status']=='MISSING_COST'
    assert r['integrity']['cross_currency_aggregation']==False


def test_pricing_intelligence_bounds_margin_and_currency_buckets(db_session, monkeypatch):
    t=_seed(db_session)
    p=Product(tenant_id=t.id,slug='euro',title='Euro',status='PUBLISHED',product_type='PHYSICAL'); db_session.add(p); db_session.flush()
    v=ProductVariant(tenant_id=t.id,product_id=p.id,sku='E',price_amount_minor=100,cost_amount_minor=50,currency='EUR',status='ACTIVE')
    db_session.add(v); db_session.commit(); monkeypatch.setattr('app.routes.worldclass._perm',lambda *a,**k:None)
    r=analytics_pricing_intelligence(t.id,2500,MerchantUser(),db_session)
    assert set(r['currencies'])=={'TRY','EUR'}
    assert all(0 <= x['target_margin_bps'] <= 10000 for x in r['items'])
