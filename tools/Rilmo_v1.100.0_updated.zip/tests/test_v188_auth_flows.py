import time


def _register(client, email, password='VerySecurePassword123!'):
    r = client.post('/v1/auth/register', json={'email': email, 'password': password, 'display_name': 'Test User'})
    assert r.status_code == 200, r.text
    return r.json()


# --- login ---------------------------------------------------------------

def test_login_rejects_wrong_password(client):
    _register(client, 'login-wrong-pw@example.com', 'CorrectPassword123!')
    r = client.post('/v1/auth/login', json={'email': 'login-wrong-pw@example.com', 'password': 'WrongPassword999!'})
    assert r.status_code == 403

def test_login_rejects_unknown_email(client):
    r = client.post('/v1/auth/login', json={'email': 'no-such-user@example.com', 'password': 'Whatever123!'})
    assert r.status_code == 403

def test_login_succeeds_with_correct_credentials(client):
    _register(client, 'login-ok@example.com', 'CorrectPassword123!')
    r = client.post('/v1/auth/login', json={'email': 'login-ok@example.com', 'password': 'CorrectPassword123!'})
    assert r.status_code == 200
    assert r.json()['access_token']

def test_login_is_case_insensitive_on_email(client):
    _register(client, 'CaseTest@Example.com', 'CorrectPassword123!')
    r = client.post('/v1/auth/login', json={'email': 'casetest@example.com', 'password': 'CorrectPassword123!'})
    assert r.status_code == 200

def test_login_rate_limit_blocks_after_repeated_failures(client):
    _register(client, 'login-ratelimit@example.com', 'CorrectPassword123!')
    last = None
    for _ in range(15):
        last = client.post('/v1/auth/login', json={'email': 'login-ratelimit@example.com', 'password': 'WrongPassword!'})
    assert last.status_code in {403, 429}


# --- logout / sessions -----------------------------------------------------

def test_logout_then_reuse_token_is_rejected(client):
    x = _register(client, 'logout-reuse@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    assert client.get('/v1/me', headers=h).status_code == 200
    assert client.post('/v1/auth/logout', headers=h).status_code == 200
    assert client.get('/v1/me', headers=h).status_code == 403

def test_list_sessions_shows_current_session(client):
    x = _register(client, 'sessions-list@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    r = client.get('/v1/auth/sessions', headers=h)
    assert r.status_code == 200
    items = r.json()['items']
    assert len(items) >= 1
    assert any(i['current'] for i in items)

def test_revoke_session_by_id_then_it_disappears_from_list(client):
    x = _register(client, 'sessions-revoke@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    login2 = client.post('/v1/auth/login', json={'email': 'sessions-revoke@example.com', 'password': 'VerySecurePassword123!'})
    h2 = {'Authorization': 'Bearer ' + login2.json()['access_token']}
    sessions = client.get('/v1/auth/sessions', headers=h).json()['items']
    other_session = next(s for s in sessions if not s['current'])
    r = client.delete(f"/v1/auth/sessions/{other_session['id']}", headers=h)
    assert r.status_code == 200
    remaining = client.get('/v1/auth/sessions', headers=h).json()['items']
    assert other_session['id'] not in {s['id'] for s in remaining}

def test_revoke_nonexistent_session_returns_not_found(client):
    x = _register(client, 'sessions-revoke-missing@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    r = client.delete('/v1/auth/sessions/does-not-exist', headers=h)
    assert r.status_code == 404


# --- me ---------------------------------------------------------------

def test_me_returns_user_and_memberships(client):
    x = _register(client, 'me-endpoint@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    r = client.get('/v1/me', headers=h)
    assert r.status_code == 200
    body = r.json()
    assert body['user']['email'] == 'me-endpoint@example.com'
    assert body['is_platform_admin'] is False
    assert len(body['memberships']) >= 1


# --- password reset ---------------------------------------------------------

def test_password_reset_request_does_not_leak_account_existence(client):
    _register(client, 'reset-exists@example.com')
    r1 = client.post('/v1/auth/password-reset/request', json={'email': 'reset-exists@example.com'})
    r2 = client.post('/v1/auth/password-reset/request', json={'email': 'reset-does-not-exist@example.com'})
    assert r1.status_code == 200
    assert r2.status_code == 200
    assert r1.json() == r2.json() == {'ok': True}

def test_password_reset_confirm_rejects_invalid_token(client):
    r = client.post('/v1/auth/password-reset/confirm', json={'token': 'not-a-real-token', 'password': 'NewPassword123!'})
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'RESET_INVALID'

def test_password_reset_confirm_full_flow_revokes_existing_sessions(client):
    from app.core.database import SessionLocal
    from app.core.security import token_hash
    from app.models.domain import PasswordResetToken, User

    x = _register(client, 'reset-full-flow@example.com', 'OldPassword123!')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    assert client.get('/v1/me', headers=h).status_code == 200

    client.post('/v1/auth/password-reset/request', json={'email': 'reset-full-flow@example.com'})

    db = SessionLocal()
    user = db.query(User).filter_by(email='reset-full-flow@example.com').first()
    reset_row = db.query(PasswordResetToken).filter_by(user_id=user.id, used_at=None).order_by(PasswordResetToken.expires_at.desc()).first()
    db.close()

    # We cannot recover the raw reset token from the DB (only its hash is stored),
    # so exercise the endpoint's validation path with a token whose hash we control.
    import secrets
    raw_token = secrets.token_urlsafe(32)
    db = SessionLocal()
    row = db.get(PasswordResetToken, reset_row.id)
    row.token_hash = token_hash(raw_token)
    db.commit()
    db.close()

    confirm = client.post('/v1/auth/password-reset/confirm', json={'token': raw_token, 'password': 'BrandNewPassword123!'})
    assert confirm.status_code == 200, confirm.text

    # old session must now be revoked
    assert client.get('/v1/me', headers=h).status_code == 403

    # new password logs in successfully
    relogin = client.post('/v1/auth/login', json={'email': 'reset-full-flow@example.com', 'password': 'BrandNewPassword123!'})
    assert relogin.status_code == 200

def test_password_reset_confirm_rejects_already_used_token(client):
    from app.core.database import SessionLocal
    from app.core.security import token_hash
    from app.models.domain import PasswordResetToken, User
    import secrets

    _register(client, 'reset-reuse@example.com', 'OldPassword123!')
    client.post('/v1/auth/password-reset/request', json={'email': 'reset-reuse@example.com'})

    db = SessionLocal()
    user = db.query(User).filter_by(email='reset-reuse@example.com').first()
    reset_row = db.query(PasswordResetToken).filter_by(user_id=user.id, used_at=None).order_by(PasswordResetToken.expires_at.desc()).first()
    raw_token = secrets.token_urlsafe(32)
    row = db.get(PasswordResetToken, reset_row.id)
    row.token_hash = token_hash(raw_token)
    db.commit()
    db.close()

    first = client.post('/v1/auth/password-reset/confirm', json={'token': raw_token, 'password': 'FirstNewPassword123!'})
    assert first.status_code == 200
    second = client.post('/v1/auth/password-reset/confirm', json={'token': raw_token, 'password': 'SecondNewPassword123!'})
    assert second.status_code == 400
