import os
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[1]


def _compose():
    return yaml.safe_load((ROOT / "docker-compose.production.yml").read_text(encoding="utf-8"))


def test_production_compose_is_runnable_shape():
    data = _compose()
    services = data["services"]
    for name in ("db", "redis", "migrate", "api", "worker", "clamav"):
        assert name in services
    assert services["db"]["image"].startswith("postgres:18.6")
    assert services["redis"]["image"].startswith("redis:8.10.0")
    assert services["api"]["build"]["context"] == "."
    assert services["worker"]["build"]["context"] == "."
    assert services["api"]["command"] == ["python", "scripts/run_server.py"]
    assert services["worker"]["command"] == ["python", "-m", "app.worker"]
    assert services["migrate"]["command"] == ["alembic", "upgrade", "head"]


def test_production_compose_migration_is_before_api_and_worker():
    data = _compose()["services"]
    assert data["migrate"]["depends_on"]["db"]["condition"] == "service_healthy"
    assert data["api"]["depends_on"]["migrate"]["condition"] == "service_completed_successfully"
    assert data["worker"]["depends_on"]["migrate"]["condition"] == "service_completed_successfully"


def test_production_compose_has_no_host_database_or_redis_ports():
    data = _compose()["services"]
    assert "ports" not in data["db"]
    assert "ports" not in data["redis"]
    assert data["db"]["healthcheck"]
    assert data["redis"]["healthcheck"]


def test_migration_mode_is_fail_closed_to_postgres(monkeypatch):
    monkeypatch.setenv("ENVIRONMENT", "production")
    monkeypatch.setenv("MIGRATION_MODE", "true")
    monkeypatch.setenv("DATABASE_URL", "sqlite:////tmp/should-not-work.db")
    from app.core.config import Settings
    with pytest.raises(RuntimeError, match="MIGRATION_MODE requires PostgreSQL"):
        Settings().validate_runtime()


def test_migration_mode_does_not_bypass_non_migration_runtime_validation(monkeypatch):
    monkeypatch.setenv("ENVIRONMENT", "production")
    monkeypatch.setenv("MIGRATION_MODE", "false")
    monkeypatch.setenv("DATABASE_URL", "sqlite:////tmp/should-not-work.db")
    from app.core.config import Settings
    with pytest.raises(RuntimeError, match="LEGAL_ENTITY_NAME must be configured"):
        Settings().validate_runtime()
