from datetime import datetime, timezone
import hashlib, hmac, json


def _register(client, email):
    return client.post('/v1/auth/register', json={
        'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'Trusted Merchant',
        'phone': '+905551112233', 'legal_name': 'Trusted Merchant Ltd', 'country_code': 'TR',
        'city': 'Istanbul', 'address_line1': 'Test Street 1'
    }).json()


def test_identity_start_requires_explicit_consent(client, monkeypatch):
    from app.core.database import SessionLocal
    x=_register(client,'kyc-consent-v1364@example.com'); tid=x['tenant']['id']
    csrf=client.cookies.get('csrf_token'); r=client.post(f'/v1/merchant/identity/start?tenant_id={tid}',headers={'X-CSRF-Token':csrf},json={'country_code':'TR','full_name':'Trusted Merchant','confirm_terms':False})
    assert r.status_code==400 and r.json()['detail']['error']['code']=='IDENTITY_CONSENT_REQUIRED'
    from app.services import merchant_trust
    monkeypatch.setattr(merchant_trust, '_provider', lambda: merchant_trust.MockIdentityProvider(__import__('app.core.config',fromlist=['get_settings']).get_settings()))
    csrf=client.cookies.get('csrf_token'); r=client.post(f'/v1/merchant/identity/start?tenant_id={tid}',headers={'X-CSRF-Token':csrf},json={'country_code':'TR','full_name':'Trusted Merchant','confirm_terms':True})
    assert r.status_code==200
    assert r.json()['verification']['provider']=='mock'


def test_identity_approval_unlocks_kyc_but_risk_gate_remains_deterministic(client, monkeypatch):
    from app.services.merchant_trust import apply_identity_decision
    from app.core.database import SessionLocal
    x=_register(client,'kyc-approve-v1364@example.com'); tid=x['tenant']['id']; user=x['user']['id']
    db=SessionLocal()
    try:
        from app.models.domain import MerchantIdentityVerification
        row=MerchantIdentityVerification(tenant_id=tid,user_id=user,provider='mock',external_id='mock-approved',status='STARTED',started_at=datetime.now(timezone.utc),created_at=datetime.now(timezone.utc),updated_at=datetime.now(timezone.utc))
        db.add(row); db.commit()
        assert apply_identity_decision(db,provider='mock',external_id='mock-approved',event_id='evt-1',decision='APPROVED') is True
        db.expire_all()
        from app.models.domain import MerchantProfile
        profile=db.query(MerchantProfile).filter_by(tenant_id=tid).one()
        assert profile.kyc_status=='VERIFIED'
        assert profile.identity_status=='VERIFIED'
        assert profile.payout_hold is False
    finally:
        db.close()


def test_veriff_webhook_signature_is_required(client, monkeypatch):
    monkeypatch.setenv('MERCHANT_KYC_PROVIDER','veriff')
    r=client.post('/v1/merchant/identity/veriff/webhook',headers={'x-hmac-signature':'bad','x-auth-client':'bad'},content=b'{}')
    assert r.status_code==401

def test_veriff_signed_webhook_applies_decision(client, monkeypatch):
    from app.core.database import SessionLocal
    from app.models.domain import MerchantIdentityVerification, MerchantProfile
    from app.services.merchant_trust import verify_hmac_sha256
    from app.core.config import get_settings
    from datetime import datetime, timezone
    x=_register(client,'kyc-webhook-v1364@example.com'); tid=x['tenant']['id']; uid=x['user']['id']
    db=SessionLocal()
    try:
        row=MerchantIdentityVerification(tenant_id=tid,user_id=uid,provider='veriff',external_id='veriff-evt',status='STARTED',started_at=datetime.now(timezone.utc),created_at=datetime.now(timezone.utc),updated_at=datetime.now(timezone.utc))
        db.add(row); db.commit()
    finally:
        db.close()
    # The test environment uses a deterministic shared secret; override settings cache by patching service signature dependency.
    from app.routes import merchant_compliance_routes as mcr
    monkeypatch.setattr(mcr, 'get_settings', lambda: type('S', (), {'MERCHANT_KYC_PROVIDER':'veriff','VERIFF_SHARED_SECRET':'test-veriff-secret','VERIFF_API_KEY':'test-key','MAX_WEBHOOK_BODY_BYTES':1024*1024})())
    payload={'id':'event-1364','verification':{'id':'veriff-evt','status':'approved'}}
    raw=json.dumps(payload,separators=(',',':')).encode()
    sig=hmac.new(b'test-veriff-secret',raw,hashlib.sha256).hexdigest()
    r=client.post('/v1/merchant/identity/veriff/webhook',content=raw,headers={'x-hmac-signature':sig,'x-auth-client':'test-key'})
    assert r.status_code==200
    db=SessionLocal()
    try:
        profile=db.query(MerchantProfile).filter_by(tenant_id=tid).one()
        assert profile.kyc_status=='VERIFIED' and profile.identity_status=='VERIFIED'
    finally:
        db.close()


def test_terminal_kyc_decision_cannot_regress_from_out_of_order_webhook(client):
    from app.core.database import SessionLocal
    from app.models.domain import MerchantIdentityVerification, MerchantProfile
    from app.services.merchant_trust import apply_identity_decision
    from datetime import datetime, timezone
    x=_register(client,'kyc-ordering-v1364@example.com'); tid=x['tenant']['id']; uid=x['user']['id']
    db=SessionLocal()
    try:
        row=MerchantIdentityVerification(tenant_id=tid,user_id=uid,provider='mock',external_id='ordered-1',status='STARTED',started_at=datetime.now(timezone.utc),created_at=datetime.now(timezone.utc),updated_at=datetime.now(timezone.utc))
        db.add(row); db.commit()
        assert apply_identity_decision(db,provider='mock',external_id='ordered-1',event_id='evt-new',decision='DECLINED')
        assert apply_identity_decision(db,provider='mock',external_id='ordered-1',event_id='evt-old',decision='APPROVED')
        db.expire_all()
        profile=db.query(MerchantProfile).filter_by(tenant_id=tid).one()
        assert profile.kyc_status=='DECLINED' and profile.identity_status=='REJECTED' and profile.payout_hold is True
    finally:
        db.close()
