from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_password_reset_token_query_is_locked_before_consumption():
    # Moved to auth_routes.py when auth endpoints were extracted out of the
    # v1.py monolith (Phase 3 split) — same code, new location.
    s = (ROOT / 'app/routes/auth_routes.py').read_text()
    needle = "PasswordResetToken).filter_by(token_hash=token_hash(data.token),\n        used_at=None).with_for_update().first()"
    assert needle in s

def test_merchant_phone_verification_query_is_locked_before_consumption():
    # merchant phone verification moved to merchant_compliance_routes.py (Phase 3 split)
    s = (ROOT / 'app/routes/merchant_compliance_routes.py').read_text()
    needle = "MerchantPhoneVerification).filter_by(tenant_id=tenant_id,used_at=None).order_by(MerchantPhoneVerification.created_at.desc()).with_for_update().first()"
    assert needle in s

def test_request_id_is_bounded_and_validated():
    s = (ROOT / 'app/main.py').read_text()
    assert "len(supplied_request_id) <= 128" in s
    assert "c.isalnum() or c in '-._:'" in s
