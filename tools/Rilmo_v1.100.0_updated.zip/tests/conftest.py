import os
from pathlib import Path
import os
DB = Path(os.environ.get('TEST_DB_PATH', f'/tmp/rilmo_test_{os.getpid()}.db'))
try:
    DB.unlink()
except FileNotFoundError:
    pass
os.environ['ENVIRONMENT'] = 'test'
os.environ['DATABASE_URL'] = f'sqlite:///{DB}'
os.environ['SECRET_KEY'] = 'test-secret-32-bytes-long'
os.environ['DOMAIN_VERIFICATION_MODE'] = 'token'
# Tests intentionally enable the AI code path; production defaults remain fail-closed.
os.environ['AI_ENABLED'] = 'true'
from fastapi.testclient import TestClient
import pytest
from app.core.database import Base, engine
from app.models.domain import RateLimitCounter
from app.main import app

@pytest.fixture(scope='session', autouse=True)
def schema():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)
    # Ensure SQLite connections are released before deleting the temporary DB.
    # This is essential for long suites where TestClient exercises multiple threads.
    engine.dispose()
    try:
        DB.unlink()
    except FileNotFoundError:
        pass

@pytest.fixture
def client():
    db = __import__('app.core.database', fromlist=['SessionLocal']).SessionLocal()
    db.query(RateLimitCounter).delete()
    db.commit()
    db.close()
    with TestClient(app) as test_client:
        yield test_client

@pytest.fixture
def db_session():
    from app.core.database import SessionLocal
    db = SessionLocal()
    try:
        yield db
    finally:
        db.rollback()
        db.close()
