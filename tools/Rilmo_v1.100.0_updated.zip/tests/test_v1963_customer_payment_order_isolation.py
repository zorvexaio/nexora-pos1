from datetime import datetime, timedelta, timezone
import secrets


def _merchant_and_order(client, email):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h,
                    json={'slug': 'payment-isolation', 'title': 'Payment Isolation', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h,
                    json={'sku': 'PAY-ISO-1', 'price_amount_minor': 900, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h,
                json={'variant_id': v['id'], 'quantity': 1})
    o = client.post(f'/v1/checkout?tenant_id={tid}', headers=h,
                    json={'cart_id': c['id'], 'customer_email': 'customer-owner@example.com'}).json()
    return tid, h, o


def _attach_customer_session(client, tid, customer_id):
    from app.core.database import SessionLocal
    from app.core.security import token_hash
    from app.models.domain import CustomerSession
    raw = secrets.token_urlsafe(32)
    db = SessionLocal()
    db.add(CustomerSession(tenant_id=tid, customer_id=customer_id,
                           token_hash=token_hash(raw),
                           expires_at=datetime.now(timezone.utc) + timedelta(days=7)))
    db.commit()
    db.close()
    client.cookies.clear()
    client.cookies.set('customer_session', raw)
    client.cookies.set('csrf_token', 'test-csrf-token')


def test_customer_cannot_create_payment_intent_for_another_customers_order(client):
    from app.core.database import SessionLocal
    from app.models.domain import Customer, Order

    tid, merchant_headers, order = _merchant_and_order(client, 'payment-isolation-merchant@example.com')
    db = SessionLocal()
    owner = Customer(tenant_id=tid, email='order-owner@example.com')
    attacker = Customer(tenant_id=tid, email='order-attacker@example.com')
    db.add_all([owner, attacker])
    db.flush()
    db.query(Order).filter_by(id=order['id'], tenant_id=tid).update({'customer_id': owner.id})
    owner_id, attacker_id = owner.id, attacker.id
    db.commit()
    db.close()

    _attach_customer_session(client, tid, attacker_id)
    r = client.post(
        f"/v1/payments/intents?tenant_id={tid}",
        headers={'X-CSRF-Token': 'test-csrf-token'},
        json={'order_id': order['id'], 'amount_minor': order['total_minor'], 'currency': 'USD', 'provider': 'mock'},
    )
    assert r.status_code == 403, r.text


def test_customer_can_create_payment_intent_for_their_own_order(client):
    from app.core.database import SessionLocal
    from app.models.domain import Customer, Order

    tid, merchant_headers, order = _merchant_and_order(client, 'payment-own-merchant@example.com')
    db = SessionLocal()
    owner = Customer(tenant_id=tid, email='owner@example.com')
    db.add(owner)
    db.flush()
    db.query(Order).filter_by(id=order['id'], tenant_id=tid).update({'customer_id': owner.id})
    owner_id = owner.id
    db.commit()
    db.close()

    _attach_customer_session(client, tid, owner_id)
    r = client.post(
        f"/v1/payments/intents?tenant_id={tid}",
        headers={'X-CSRF-Token': 'test-csrf-token'},
        json={'order_id': order['id'], 'amount_minor': order['total_minor'], 'currency': 'USD', 'provider': 'mock'},
    )
    assert r.status_code == 200, r.text
