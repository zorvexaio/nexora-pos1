from pathlib import Path

from app.core.database import SessionLocal
from app.models.domain import Tenant, WorkflowDefinition, WorkflowRun, OutboxEvent
import app.worker as worker


def test_workflow_run_has_durable_source_event_and_unique_contract():
    src = Path('app/models/domain.py').read_text()
    assert "UniqueConstraint('tenant_id', 'workflow_id', 'source_event_id', name='uq_workflow_run_source_event')" in src
    assert "source_event_id: Mapped[str | None] = mapped_column(ForeignKey('outbox_events.id'), index=True)" in src


def test_trigger_event_workflow_creates_run_and_queue_event(db_session):
    tenant = Tenant(slug='automation-1991', name='Automation 1991', status='ACTIVE', default_currency='USD')
    db_session.add(tenant)
    db_session.flush()
    wf = WorkflowDefinition(tenant_id=tenant.id, slug='order-followup', name='Order Followup',
        trigger_event='order.created', enabled=True, steps=[])
    db_session.add(wf)
    db_session.flush()
    ev = OutboxEvent(tenant_id=tenant.id, aggregate_type='order', aggregate_id='order-1',
        event_type='order.created', schema_version=1, payload={'order_id': 'order-1'}, status='PENDING')
    db_session.add(ev)
    db_session.flush()
    created = worker._trigger_event_workflows(db_session, ev)
    assert created == 1
    run = db_session.query(WorkflowRun).filter_by(tenant_id=tenant.id, workflow_id=wf.id, source_event_id=ev.id).one()
    assert run.status == 'QUEUED'
    assert run.input_payload['event_id'] == ev.id
    queued = db_session.query(OutboxEvent).filter_by(aggregate_id=run.id, event_type='workflow.run.queued').one()
    assert queued.payload['source_event_id'] == ev.id


def test_trigger_event_workflow_is_idempotent(db_session):
    tenant = Tenant(slug='automation-1991-idem', name='Automation 1991 Idem', status='ACTIVE', default_currency='USD')
    db_session.add(tenant); db_session.flush()
    wf = WorkflowDefinition(tenant_id=tenant.id, slug='repeat-safe', name='Repeat Safe',
        trigger_event='payment.captured', enabled=True, steps=[])
    db_session.add(wf); db_session.flush()
    ev = OutboxEvent(tenant_id=tenant.id, aggregate_type='payment', aggregate_id='pay-1',
        event_type='payment.captured', schema_version=1, payload={'payment_id': 'pay-1'}, status='PENDING')
    db_session.add(ev); db_session.flush()
    assert worker._trigger_event_workflows(db_session, ev) == 1
    db_session.commit()
    assert worker._trigger_event_workflows(db_session, ev) == 0
    assert db_session.query(WorkflowRun).filter_by(tenant_id=tenant.id, workflow_id=wf.id, source_event_id=ev.id).count() == 1
    assert db_session.query(OutboxEvent).filter_by(tenant_id=tenant.id, aggregate_type='workflow_run', event_type='workflow.run.queued').count() == 1
    # Replaying the same source event repeatedly must not enqueue duplicate work.
    assert worker._trigger_event_workflows(db_session, ev) == 0
    assert worker._trigger_event_workflows(db_session, ev) == 0
    assert db_session.query(OutboxEvent).filter_by(tenant_id=tenant.id, aggregate_type='workflow_run', event_type='workflow.run.queued').count() == 1


def test_workflow_trigger_never_recurses_on_workflow_queue_event(db_session):
    tenant = Tenant(slug='automation-1991-rec', name='Automation 1991 Rec', status='ACTIVE', default_currency='USD')
    db_session.add(tenant); db_session.flush()
    ev = OutboxEvent(tenant_id=tenant.id, aggregate_type='workflow_run', aggregate_id='run-1',
        event_type='workflow.run.queued', schema_version=1, payload={}, status='PENDING')
    db_session.add(ev); db_session.flush()
    assert worker._trigger_event_workflows(db_session, ev) == 0


def test_workflow_queue_event_has_durable_outbox_dedupe_key(db_session):
    tenant = Tenant(slug='automation-1991-outbox-dedupe', name='Automation Outbox Dedupe', status='ACTIVE', default_currency='USD')
    db_session.add(tenant); db_session.flush()
    wf = WorkflowDefinition(tenant_id=tenant.id, slug='outbox-dedupe', name='Outbox Dedupe',
        trigger_event='order.created', enabled=True, steps=[])
    db_session.add(wf); db_session.flush()
    ev = OutboxEvent(tenant_id=tenant.id, aggregate_type='order', aggregate_id='order-dedupe',
        event_type='order.created', schema_version=1, payload={}, status='PENDING')
    db_session.add(ev); db_session.flush()
    assert worker._trigger_event_workflows(db_session, ev) == 1
    queued = db_session.query(OutboxEvent).filter_by(tenant_id=tenant.id, event_type='workflow.run.queued').one()
    assert queued.dedupe_key == f'workflow.run.queued:{tenant.id}:{wf.id}:{ev.id}'
