from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parents[1]


def test_merchant_gate_requires_business_verification_and_verified_payouts():
    text = (ROOT / 'app' / 'routes' / 'v1.py').read_text()
    assert "MERCHANT_KYB_REQUIRED" in text
    assert "MERCHANT_PAYMENT_ONBOARDING_REQUIRED" in text
    assert "charges_enabled=True,payouts_enabled=True" in text
    assert "kyb_status == 'VERIFIED'" in text


def test_payment_configuration_cannot_enable_charges_by_entering_credentials():
    # payment-account routes moved to merchant_compliance_routes.py in Phase 3 split
    text = (ROOT / 'app' / 'routes' / 'merchant_compliance_routes.py').read_text()
    start = text.index("@router.post('/merchant/payment-account/configure')")
    end = text.index("@router.get('/merchant/payment-accounts')", start)
    body = text[start:end]
    assert "row.status='PENDING'" in body
    assert "row.charges_enabled=False" in body
    assert "row.payouts_enabled=False" in body
    assert "Credentials stored; payment-provider onboarding and verification are required" in body


def test_merchant_profile_schema_contains_real_business_identity_fields():
    text = (ROOT / 'app' / 'schemas' / 'api.py').read_text()
    for field in ('registration_number', 'business_registry_country', 'beneficial_owner_name', 'beneficial_owner_country'):
        assert field in text


def test_profile_update_resets_kyb_after_material_identity_change():
    # merchant profile update moved to merchant_compliance_routes.py (Phase 3 split)
    text = (ROOT / 'app' / 'routes' / 'merchant_compliance_routes.py').read_text()
    assert "profile.kyb_status='NOT_STARTED'" in text
    assert "profile.kyb_evidence_hash=None" in text


def test_kyb_submission_does_not_store_raw_documents():
    text = (ROOT / 'app' / 'routes' / 'merchant_compliance_routes.py').read_text()
    assert "kyb_evidence_hash=hashlib.sha256(data.evidence_reference.encode()).hexdigest()" in text
    assert "merchant.kyb.submitted" in text
    assert "The store remains unavailable for selling until verification is approved." in text
