from app.core.config import get_settings

def test_production_direct_identity_link_guard_is_present():
    from pathlib import Path
    # link_identity moved to auth_google_routes.py in Phase 3 split
    src = Path('app/routes/auth_google_routes.py').read_text()
    assert 'DIRECT_IDENTITY_LINK_DISABLED' in src
    assert "ENVIRONMENT != 'test'" in src

def test_product_translations_roundtrip(client):
    from tests.test_p0 import register
    x = register(client, 'translation@example.com')
    h = {'Authorization': f"Bearer {x['access_token']}"}
    tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Entitlement
    db = SessionLocal(); db.add(Entitlement(tenant_id=tid, feature_key='max_languages', value_type='integer', value_integer=13, value_boolean=None, version=1)); db.commit(); db.close()
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'phone', 'title': 'Phone', 'status': 'ACTIVE'}).json()
    r = client.put(f"/v1/products/{p['id']}/translations/fr?tenant_id={tid}", headers=h, json={'name': 'Téléphone', 'description': 'Un téléphone'})
    assert r.status_code == 200 and r.json()['name'] == 'Téléphone'
    rows = client.get(f"/v1/products/{p['id']}/translations?tenant_id={tid}", headers=h).json()['items']
    assert rows[0]['locale'] == 'fr'

def test_guest_payment_capture_path_is_rejected(client):
    merchant = client.post('/v1/auth/register', json={'email': 'guest-pay@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + merchant['access_token']}
    tid = merchant['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'pay-item', 'title': 'Pay Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'PAY-1', 'price_amount_minor': 500, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=2&reason=test", headers=h)
    g = client.__class__(client.app)
    cart = g.post(f'/v1/cart?tenant_id={tid}').json()
    g.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", json={'variant_id': v['id'], 'quantity': 1})
    order = g.post(f'/v1/checkout?tenant_id={tid}', json={'cart_id': cart['id'], 'customer_email': 'buyer-pay@example.com'}).json()
    pi = g.post(f'/v1/payments/intents?tenant_id={tid}', headers={'Idempotency-Key': 'guest-pay-intent'}, json={'order_id': order['id'], 'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()
    cap = g.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers={'Idempotency-Key': 'guest-capture-1'})
    assert cap.status_code == 403, cap.text
