"""Structural regression tests for generic ORM serialization.

These tests intentionally inspect every mapped model instead of checking for
literal strings in a blocklist.  Adding a new secret-like ORM column therefore
fails CI until the serializer's structural policy covers it.
"""
from __future__ import annotations

import re

from app.core.serialization import EXPLICIT_SENSITIVE_FIELDS, SENSITIVE_FIELD_PATTERN, audit_event_view, json_model
from app.models.domain import Base
from app.routes import v1
from app.services import advanced


def test_generic_serializer_is_single_canonical_implementation():
    assert v1.json_model is json_model
    assert advanced.json_model is json_model


def test_sensitive_field_policy_is_structural_and_fail_closed():
    for model in Base.__subclasses__():
        obj = model()
        serialized = json_model(obj)
        for column in model.__table__.columns:
            name = column.name
            structurally_sensitive = bool(SENSITIVE_FIELD_PATTERN.search(name))
            explicitly_sensitive = name in EXPLICIT_SENSITIVE_FIELDS
            if structurally_sensitive or explicitly_sensitive:
                assert name not in serialized, f'{model.__name__}.{name} leaked through json_model()'


def test_all_secret_like_schema_columns_are_covered_by_policy():
    # Keep the test itself independent from the application's explicit list:
    # the pattern is the forward-looking safety net for future schema changes.
    future_sensitive = re.compile(
        r'(?:hash|secret|encrypted|credential|token(?!_prefix)|api[_-]?key|private[_-]?key|biometric|raw_document|passport|selfie)',
        re.I,
    )
    for model in Base.__subclasses__():
        for column in model.__table__.columns:
            if future_sensitive.search(column.name):
                assert SENSITIVE_FIELD_PATTERN.search(column.name) or column.name in EXPLICIT_SENSITIVE_FIELDS, (
                    f'New sensitive-looking field {model.__name__}.{column.name} is not covered by serializer policy'
                )
                assert column.name not in json_model(model())


def test_token_prefix_remains_serializable_as_non_secret_display_metadata():
    class Probe:
        __table__ = type('Table', (), {'columns': [type('Column', (), {'name': 'token_prefix'})()]})()
        token_prefix = 'tok_live_abc'

    assert json_model(Probe()) == {'token_prefix': 'tok_live_abc'}


def test_all_sqlalchemy_registry_mappers_use_structural_sensitive_policy():
    """Use the SQLAlchemy registry, not class inheritance, to cover every mapped model."""
    from app.core.database import Base as DBBase

    mappers = list(DBBase.registry.mappers)
    assert mappers, 'SQLAlchemy mapper registry unexpectedly empty'
    for mapper in mappers:
        model = mapper.class_
        serialized = json_model(model())
        for column in mapper.columns:
            if SENSITIVE_FIELD_PATTERN.search(column.key) or column.key in EXPLICIT_SENSITIVE_FIELDS:
                assert column.key not in serialized, f'{model.__name__}.{column.key} leaked'


def test_sensitive_serializer_has_single_definition():
    """Prevent future route/service-local serializers from bypassing the canonical policy."""
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    definitions = []
    for path in root.joinpath('app').rglob('*.py'):
        text = path.read_text(encoding='utf-8')
        if path.as_posix().endswith('/app/core/serialization.py'):
            continue
        if re.search(r'(?m)^def\s+json_model\s*\(', text):
            definitions.append(str(path))
    assert not definitions, f'Non-canonical json_model definition found: {definitions}'


def test_audit_chain_hashes_are_explicitly_public_only_in_audit_view():
    from app.models.domain import AuditEvent
    event = AuditEvent(
        id='audit-1', tenant_id='tenant-1', actor_id='user-1', action='test',
        prev_hash='a' * 64, event_hash='b' * 64,
    )
    generic = json_model(event)
    assert 'prev_hash' not in generic
    assert 'event_hash' not in generic
    public = audit_event_view(event)
    assert public['prev_hash'] == 'a' * 64
    assert public['event_hash'] == 'b' * 64


def test_admin_audit_route_uses_dedicated_audit_serializer():
    from pathlib import Path
    # moved to platform_trust_routes.py in Phase 3 split
    text = (Path(__file__).resolve().parents[1] / 'app/routes/platform_trust_routes.py').read_text(encoding='utf-8')
    start = text.index("@router.get('/admin/audit')")
    block = text[start:start + 500]
    assert 'audit_event_view' in block
    assert 'json_model(x)' not in block


def test_admin_audit_endpoint_exposes_chain_hashes_without_exposing_nested_secrets(client):
    from app.core.database import SessionLocal
    from app.models.domain import AuditEvent
    from app.core.auth import current_platform_admin
    from app.main import app

    db = SessionLocal()
    db.add(AuditEvent(
        tenant_id='tenant-audit', actor_id='user-audit', action='security.test',
        prev_hash='a' * 64, event_hash='b' * 64,
        before_data={'api_token_encrypted': 'ciphertext', 'status': 'OLD'},
        after_data={'key_hash': 'digest', 'status': 'NEW'},
    ))
    db.commit()
    db.close()

    app.dependency_overrides[current_platform_admin] = lambda: object()
    try:
        response = client.get('/v1/admin/audit')
    finally:
        app.dependency_overrides.pop(current_platform_admin, None)

    assert response.status_code == 200
    row = next(x for x in response.json() if x['action'] == 'security.test')
    assert row['prev_hash'] == 'a' * 64
    assert row['event_hash'] == 'b' * 64
    assert row['before_data']['api_token_encrypted'] == '[REDACTED]'
    assert row['after_data']['key_hash'] == '[REDACTED]'
    assert row['before_data']['status'] == 'OLD'
