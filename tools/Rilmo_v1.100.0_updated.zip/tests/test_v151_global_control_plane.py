from pathlib import Path
from datetime import datetime, timezone, timedelta
ROOT = Path(__file__).resolve().parents[1]

def _register(client, email):
    r = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'Control Plane'})
    assert r.status_code == 200, r.text
    return r.json()

def test_global_control_plane_models_and_migration():
    text = (ROOT / 'app/models/domain.py').read_text()
    for name in ['AgentProfile', 'AgentActionAudit', 'TenantRegionPolicy', 'FinancialReconciliationRun', 'FinancialReconciliationMismatch']:
        assert f'class {name}(' in text
    mig = (ROOT / 'alembic/versions/20260819_0046_global_control_plane.py').read_text()
    for table in ['agent_profiles','agent_action_audits','tenant_region_policies','financial_reconciliation_runs','financial_reconciliation_mismatches']:
        assert f"'{table}'" in mig
    assert 'ENABLE ROW LEVEL SECURITY' in mig and 'FORCE ROW LEVEL SECURITY' in mig and 'CREATE POLICY' in mig

def test_agent_scope_gate_and_idempotency(client):
    x = _register(client, 'agent-v151@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    r = client.post('/v1/agents', params={'tenant_id': tid}, headers=h, json={
        'client_id':'agent-demo','slug':'agent-demo','name':'Demo Agent','scopes':['checkout:complete']})
    assert r.status_code == 200, r.text
    p = client.get('/v1/agents', params={'tenant_id': tid}, headers=h)
    assert p.status_code == 200 and p.json()['items'][0]['client_id'] == 'agent-demo'
    denied = client.get('/v1/public/storefront/nonexistent/agent-policy', params={'client_id':'agent-demo'})
    assert denied.status_code in (404, 400)

def test_region_policy_is_fail_closed_and_explicit(client):
    x = _register(client, 'region-v151@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    bad = client.put('/v1/governance/region-policy', params={'tenant_id':tid}, headers=h, json={
        'home_region':'eu-west-1','allowed_regions':['us-east-1'],'residency_mode':'HOME_REGION_ONLY','cross_border_transfer_allowed':False})
    assert bad.status_code == 409
    good = client.put('/v1/governance/region-policy', params={'tenant_id':tid}, headers=h, json={
        'home_region':'eu-west-1','allowed_regions':['eu-west-1'],'residency_mode':'HOME_REGION_ONLY','cross_border_transfer_allowed':False})
    assert good.status_code == 200
    assert good.json()['home_region'] == 'eu-west-1'

def test_financial_reconciliation_is_deterministic(client):
    x = _register(client, 'recon-v151@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    start = datetime.now(timezone.utc) - timedelta(days=1)
    end = datetime.now(timezone.utc) + timedelta(days=1)
    r = client.post('/v1/finance/reconciliation/run', params={'tenant_id':tid}, headers=h, json={
        'period_start':start.isoformat(),'period_end':end.isoformat(),'currency':'USD'})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['status'] == 'MATCHED'
    r2 = client.post('/v1/finance/reconciliation/run', params={'tenant_id':tid}, headers=h, json={
        'period_start':start.isoformat(),'period_end':end.isoformat(),'currency':'USD'})
    assert r2.status_code == 200
    assert r2.json()['id'] == body['id']

def test_public_agent_policy_never_exposes_secrets(client):
    x = _register(client, 'agent-public-v151@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    host = f"{x['tenant']['slug']}.example.com"
    created = client.post('/v1/agents', params={'tenant_id':tid}, headers=h, json={
        'client_id':'agent-public','slug':'agent-public','name':'Public Agent','scopes':['catalog:read'], 'allowed_countries':['TR']})
    assert created.status_code == 200
    p = client.get('/v1/public/storefront/' + host + '/agent-policy', params={'client_id':'agent-public'})
    assert p.status_code in (200,404)
    if p.status_code == 200:
        payload = p.json()
        assert 'client_secret' not in payload and 'access_token' not in payload

def test_agent_rate_limit_is_enforced(client):
    x = _register(client, 'agent-limit-v151@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    r = client.post('/v1/agents', params={'tenant_id':tid}, headers=h, json={
        'client_id':'agent-limit','slug':'agent-limit','name':'Rate Limited Agent','scopes':['checkout:complete'],'rate_limit_per_minute':1})
    assert r.status_code == 200
    created_secret = r.json()['client_secret']
    from app.core.database import SessionLocal
    from app.services.global_control_plane import authorize_agent_action
    db = SessionLocal()
    try:
        a1,_ = authorize_agent_action(db, tid, 'agent-limit', created_secret, 'checkout.complete', 'test', 'r1', 'hash1', 'idem-1')
        assert a1.client_id == 'agent-limit'
        db.commit()
        try:
            authorize_agent_action(db, tid, 'agent-limit', created_secret, 'checkout.complete', 'test', 'r2', 'hash2', 'idem-2')
            assert False, 'expected rate limit'
        except Exception as exc:
            assert getattr(exc, 'status_code', None) == 429
            db.rollback()
    finally:
        db.close()

def test_reconciliation_checks_payment_reference_when_present(client):
    x = _register(client, 'recon-payment-v151@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    start = datetime.now(timezone.utc) - timedelta(days=1)
    end = datetime.now(timezone.utc) + timedelta(days=1)
    r = client.post('/v1/finance/reconciliation/run', params={'tenant_id':tid}, headers=h, json={
        'period_start':start.isoformat(),'period_end':end.isoformat(),'currency':'USD'})
    assert r.status_code == 200
    assert r.json()['status'] == 'MATCHED'
