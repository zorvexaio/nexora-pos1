def test_change_plan_uses_real_billing_state_machine(client):
    from app.core.database import SessionLocal
    from app.models.domain import Plan, PlanVersion, Subscription

    x = client.post('/v1/auth/register', json={
        'email': 'change-plan-billing-bypass-2@example.com',
        'password': 'VerySecurePassword123!'
    }).json()
    headers = {'Authorization': 'Bearer ' + x['access_token']}
    tenant_id = x['tenant']['id']

    db = SessionLocal()
    plan = db.query(Plan).filter_by(code='growth', is_active=True).first()
    pv = db.query(PlanVersion).filter_by(plan_id=plan.id, is_current=True).first()
    db.close()
    assert pv is not None

    r = client.post(
        f'/v1/subscription/change-plan?tenant_id={tenant_id}',
        headers=headers,
        json={'plan_version_id': pv.id},
    )
    assert r.status_code == 200, r.text

    db = SessionLocal()
    active = db.query(Subscription).filter_by(tenant_id=tenant_id, status='active').first()
    db.close()
    assert active is not None
    # The compatibility route must materialize the same provider state as
    # /subscriptions; the old implementation left these fields unset.
    assert active.billing_provider in {'mock', 'paddle'}
    assert active.provider_subscription_id
