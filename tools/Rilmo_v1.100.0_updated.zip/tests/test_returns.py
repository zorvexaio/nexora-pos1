from app.models.domain import ReturnRequest, ReturnItem, Order, OrderItem
import pytest

@pytest.fixture
def merchant_headers(client):
    x = client.post('/v1/auth/register', json={'email': f"returns-merchant-{__import__('uuid').uuid4().hex}@example.com", 'password': 'VerySecurePassword123!'}).json()
    return {'Authorization': 'Bearer ' + x['access_token']}

def _seed_paid_order(client, headers):
    tid = client.post('/v1/tenants', headers=headers, json={'slug': f"returns-shop-{__import__('uuid').uuid4().hex[:8]}", 'name': 'Returns Shop', 'default_currency': 'USD', 'default_locale': 'ar'}).json()['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=headers, json={'slug': 'returnable', 'title': 'Returnable', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=headers, json={'sku': 'RET-1', 'price_amount_minor': 1000, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=2&reason=test", headers=headers)
    cart = client.post(f'/v1/cart?tenant_id={tid}', headers=headers, json={'currency': 'USD'}).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", headers=headers, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=headers, json={'cart_id': cart['id'], 'customer_email': 'buyer@example.com', 'customer_name': 'Buyer'}).json()
    pay = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=headers, json={'order_id': order['id'], 'amount_minor': order['total_minor'], 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/payments/{pay['id']}/capture?tenant_id={tid}", headers=headers, json={'amount_minor': order['total_minor'], 'currency': 'USD'})
    return (tid, order)

def test_return_request_decision_flow(client, merchant_headers):
    tid, order = _seed_paid_order(client, merchant_headers)
    db = __import__('app.core.database', fromlist=['SessionLocal']).SessionLocal()
    oi = db.query(OrderItem).filter_by(order_id=order['id'], tenant_id=tid).first()
    db.close()
    resp = client.post(f"/v1/orders/{order['id']}/returns?tenant_id={tid}", headers=merchant_headers, json={'type': 'REFUND', 'reason_code': 'DAMAGED', 'items': [{'order_item_id': oi.id, 'quantity': 1}], 'idempotency_key': 'return-test-0001'})
    assert resp.status_code == 200, resp.text
    r = resp.json()
    assert r['status'] == 'REQUESTED'
    d = client.post(f"/v1/returns/{r['id']}/decision?tenant_id={tid}", headers=merchant_headers, json={'approved': True}).json()
    assert d['status'] == 'APPROVED'
    again = client.post(f"/v1/orders/{order['id']}/returns?tenant_id={tid}", headers=merchant_headers, json={'type': 'REFUND', 'reason_code': 'DAMAGED', 'items': [{'order_item_id': oi.id, 'quantity': 1}], 'idempotency_key': 'return-test-0001'}).json()
    assert again['id'] == r['id']

def test_return_overlapping_quantity_is_blocked(client, merchant_headers):
    tid, order = _seed_paid_order(client, merchant_headers)
    db = __import__('app.core.database', fromlist=['SessionLocal']).SessionLocal()
    oi = db.query(OrderItem).filter_by(order_id=order['id'], tenant_id=tid).first()
    db.close()
    payload = {'type': 'REFUND', 'reason_code': 'OTHER', 'items': [{'order_item_id': oi.id, 'quantity': 1}], 'idempotency_key': 'return-test-0002'}
    r = client.post(f"/v1/orders/{order['id']}/returns?tenant_id={tid}", headers=merchant_headers, json=payload)
    assert r.status_code == 200
    d = client.post(f"/v1/returns/{r.json()['id']}/decision?tenant_id={tid}", headers=merchant_headers, json={'approved': False})
    assert d.status_code == 200
    payload['idempotency_key'] = 'return-test-0003'
    r2 = client.post(f"/v1/orders/{order['id']}/returns?tenant_id={tid}", headers=merchant_headers, json=payload)
    assert r2.status_code == 200

def test_return_duplicate_order_item_entries_are_aggregated(client, merchant_headers):
    tid, order = _seed_paid_order(client, merchant_headers)
    db = __import__('app.core.database', fromlist=['SessionLocal']).SessionLocal()
    oi = db.query(OrderItem).filter_by(order_id=order['id'], tenant_id=tid).first()
    db.close()
    payload = {
        'type': 'REFUND',
        'reason_code': 'OTHER',
        'items': [
            {'order_item_id': oi.id, 'quantity': 1},
            {'order_item_id': oi.id, 'quantity': 1},
        ],
        'idempotency_key': 'return-duplicate-items-0001',
    }
    r = client.post(f"/v1/orders/{order['id']}/returns?tenant_id={tid}", headers=merchant_headers, json=payload)
    assert r.status_code == 409, r.text
    assert 'RETURN_QUANTITY_EXCEEDED' in r.text
