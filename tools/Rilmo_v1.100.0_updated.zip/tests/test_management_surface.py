from tests.test_release_extensions import register

def test_management_surface_and_analytics(client):
    x = register(client, 'surface@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Entitlement
    db = SessionLocal(); db.add(Entitlement(tenant_id=tid, feature_key='advanced_analytics', value_type='boolean', value_boolean=True, value_integer=None, version=1)); db.commit(); db.close()
    for path in ['/customers', '/categories', '/shipping-methods', '/reviews', '/questions', '/analytics/sales', '/settings/commerce']:
        r = client.get('/v1' + path, params={'tenant_id': tid}, headers=h)
        assert r.status_code == 200, (path, r.text)

def test_dashboard_locale_assets_and_frontend(client):
    r = client.get('/')
    assert r.status_code == 200 and 'Unified Commerce' in r.text
    js = client.get('/app.js')
    css = client.get('/styles.css')
    assert js.status_code == 200 and 'customers' in js.text and ('analytics' in js.text)
    assert css.status_code == 200 and 'page-head' in css.text
