from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_payment_user_agent_matches_current_release():
    # Behavioral check: the header sent on real requests must reflect the
    # live VERSION file, not a hardcoded literal that goes stale on bump.
    from app.services.payment_providers import IyzicoProvider
    from app.core.config import get_settings
    current_version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    assert get_settings().APP_VERSION == current_version
    provider = IyzicoProvider(api_key="k", secret_key="s", base_url="https://example.com")
    headers = provider._auth("/payments")
    assert headers["User-Agent"] == f"UnifiedGlobalCommerce/{current_version}"
    src = Path("app/services/payment_providers.py").read_text()
    assert "UnifiedGlobalCommerce/1." + "64" not in src


def test_pos_open_register_has_db_level_uniqueness():
    model = Path("app/models/domain.py").read_text()
    migration = Path("alembic/versions/20260823_0066_pos_session_open_uniqueness.py").read_text()
    assert "uq_pos_session_open_register" in model
    assert "status = 'OPEN'" in model
    assert "uq_pos_session_open_register" in migration
    assert "postgresql_where" in migration and "sqlite_where" in migration
