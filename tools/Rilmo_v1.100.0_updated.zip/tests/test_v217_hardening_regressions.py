from datetime import datetime, timedelta, timezone

import pytest


def test_payment_provider_direct_constructor_ignores_custom_base_in_production(monkeypatch):
    import app.services.payment_providers as mod

    settings = mod.get_settings()
    monkeypatch.setattr(settings, 'ENVIRONMENT', 'production')
    monkeypatch.setattr(settings, 'IYZICO_API_BASE', 'https://api.iyzipay.com')
    monkeypatch.setattr(settings, 'PAYTR_API_BASE', 'https://www.paytr.com')

    iyz = mod.IyzicoProvider(
        api_key='k', secret_key='s', base_url='http://169.254.169.254/latest'
    )
    paytr = mod.PayTRProvider(
        merchant_id='m', merchant_key='k', merchant_salt='s', base_url='http://127.0.0.1:9'
    )
    assert iyz.base == 'https://api.iyzipay.com'
    assert paytr.base == 'https://www.paytr.com'


def test_workflow_endpoint_rejects_control_chars_and_non_https(monkeypatch):
    import app.services.workflow_webhooks as mod

    for url, expected in (('http://example.com/hook', 'WORKFLOW_WEBHOOK_INVALID'), ('https://example.com/hook\n', 'WORKFLOW_WEBHOOK_INVALID')):
        with pytest.raises(mod.AppError) as exc:
            mod.validate_endpoint(url)
        assert exc.value.code == expected


def test_workflow_endpoint_rejects_mixed_public_and_private_dns(monkeypatch):
    import app.services.workflow_webhooks as mod

    monkeypatch.setattr(
        mod.socket,
        'getaddrinfo',
        lambda *args, **kwargs: [
            (2, 1, 6, '', ('93.184.216.34', 443)),
            (2, 1, 6, '', ('169.254.169.254', 443)),
        ],
    )
    with pytest.raises(mod.AppError) as exc:
        mod.validate_endpoint('https://example.com/hook')
    assert exc.value.code == 'WEBHOOK_ENDPOINT_BLOCKED'


def test_stable_variant_validates_traffic_and_fails_safe_on_empty_weights():
    from app.services.worldclass import stable_variant
    from app.core.errors import AppError

    assert stable_variant('visitor-1', [{'key': 'control', 'weight_bps': 0}], 10000) == 'control'
    with pytest.raises(AppError) as exc:
        stable_variant('visitor-1', [{'key': 'control', 'weight_bps': 10000}], 10001)
    assert exc.value.code == 'EXPERIMENT_TRAFFIC_INVALID'


def test_storefront_metrics_bounds_days_and_filters_window(db_session):
    from app.models.domain import LiveStorefrontEvent, Order, Storefront, Tenant
    from app.services.worldclass import storefront_metrics

    now = datetime.now(timezone.utc)
    tenant = Tenant(name='Metrics v217', slug='metrics-v217')
    db_session.add(tenant)
    db_session.flush()
    tenant_id = tenant.id
    storefront = Storefront(tenant_id=tenant_id, name='Metrics Store', slug='metrics', status='PUBLISHED')
    db_session.add(storefront)
    db_session.flush()
    recent = LiveStorefrontEvent(tenant_id=tenant_id, storefront_id=storefront.id, visitor_key_hash='v1', event_type='page_view', created_at=now - timedelta(days=1))
    old = LiveStorefrontEvent(tenant_id=tenant_id, storefront_id=storefront.id, visitor_key_hash='v2', event_type='page_view', created_at=now - timedelta(days=400))
    db_session.add_all([recent, old])
    db_session.add(Order(tenant_id=tenant_id, storefront_id=storefront.id, order_number='V217-0001', status='PAID', currency='USD', subtotal_minor=1250, total_minor=1250, created_at=now - timedelta(days=1)))
    db_session.commit()

    out = storefront_metrics(db_session, tenant_id, 9999)
    assert out['window_days'] == 365
    assert out['visits'] == 1
    assert out['purchases'] == 1
    assert out['revenue_minor'] == 1250


def test_catalog_for_agent_excludes_inactive_variants_and_normalizes_output(db_session):
    from app.models.domain import Product, ProductVariant
    from app.services.worldclass import catalog_for_agent

    tenant_id = 'tenant-catalog-v217'
    p = Product(tenant_id=tenant_id, slug='active-feed', title='Active', status='PUBLISHED')
    db_session.add(p)
    db_session.flush()
    db_session.add_all([
        ProductVariant(tenant_id=tenant_id, product_id=p.id, sku='ACTIVE', price_amount_minor=1000, currency='USD', status='ACTIVE'),
        ProductVariant(tenant_id=tenant_id, product_id=p.id, sku='INACTIVE', price_amount_minor=900, currency='USD', status='INACTIVE'),
    ])
    db_session.commit()

    rows = catalog_for_agent(db_session, tenant_id, country_code='tr', locale='TR', limit=9999)
    assert len(rows) == 1
    assert rows[0]['sku'] == 'ACTIVE'
    assert rows[0]['country_code'] == 'TR'
    assert rows[0]['locale'] == 'tr'


def test_global_readiness_route_executes_without_undefined_uid(client):
    from datetime import datetime
    from app.core.auth import current_platform_admin
    from app.main import app
    from app.models.domain import User
    from app.core.database import SessionLocal

    db = SessionLocal()
    try:
        admin = User(email=f'v217-readiness-{datetime.now().timestamp()}@example.com', password_hash='x')
        db.add(admin)
        db.commit()
        db.refresh(admin)
    finally:
        db.close()
    app.dependency_overrides[current_platform_admin] = lambda: admin
    try:
        r = client.get('/v1/platform/global-readiness')
    finally:
        app.dependency_overrides.pop(current_platform_admin, None)
    assert r.status_code == 200, r.text
    assert r.json()['status'] == 'EXTERNAL_EVIDENCE_REQUIRED'


def test_public_dsa_notice_executes_without_undefined_uid(client):
    r = client.post('/v1/public/dsa/notice', json={
        'content_type': 'PRODUCT',
        'content_id': 'prod-v217',
        'reason_code': 'ILLEGAL_CONTENT',
        'description': 'This is a sufficiently detailed report for the public DSA notice path.',
    })
    assert r.status_code == 200, r.text
    assert r.json()['status'] == 'SUBMITTED'
