from datetime import datetime, timezone, timedelta
from app.models.domain import Tenant, Customer, Order, Refund
from app.routes.worldclass import analytics_customer_intelligence
class MerchantUser: id = "merchant-user"

def test_customer_intelligence_segments_and_currency_buckets(db_session, monkeypatch):
    tenant=Tenant(slug="ci-1992",name="CI 1992",status="ACTIVE",default_currency="USD"); db_session.add(tenant); db_session.flush()
    c=Customer(tenant_id=tenant.id,email="a@example.com",first_name="A"); db_session.add(c); db_session.flush(); now=datetime.now(timezone.utc)
    for i in range(5):
        db_session.add(Order(tenant_id=tenant.id,customer_id=c.id,order_number=f"CI-{i}",status="CONFIRMED",payment_status="PAID",fulfillment_status="FULFILLED",currency="USD",subtotal_minor=1000,discount_minor=0,shipping_minor=0,tax_minor=0,fee_minor=0,total_minor=1000,created_at=now-timedelta(days=i*3)))
    db_session.flush(); oid=db_session.query(Order).filter_by(order_number="CI-0").one().id
    db_session.add(Refund(tenant_id=tenant.id,order_id=oid,payment_intent_id="pi-ci",amount_minor=200,currency="USD",status="COMPLETED")); db_session.commit()
    monkeypatch.setattr("app.routes.worldclass._perm",lambda *a,**k:None)
    result=analytics_customer_intelligence(tenant.id,365,MerchantUser(),db_session)
    assert result["customers_with_orders"]==1 and result["segments"]["CHAMPION"]==1
    assert result["by_currency"]["USD"]["net_revenue_minor"]==4800 and result["repeat_customer_rate_bps"]==10000
    assert result["integrity"]["cross_currency_ltv_not_computed"] is True

def test_customer_intelligence_does_not_mix_refund_currency(db_session, monkeypatch):
    tenant=Tenant(slug="ci-1992-fx",name="CI 1992 FX",status="ACTIVE",default_currency="USD"); db_session.add(tenant); db_session.flush()
    c=Customer(tenant_id=tenant.id,email="fx@example.com"); db_session.add(c); db_session.flush(); now=datetime.now(timezone.utc)
    order=Order(tenant_id=tenant.id,customer_id=c.id,order_number="FX-1",status="CONFIRMED",payment_status="PAID",fulfillment_status="FULFILLED",currency="USD",subtotal_minor=1000,discount_minor=0,shipping_minor=0,tax_minor=0,fee_minor=0,total_minor=1000,created_at=now); db_session.add(order); db_session.flush()
    db_session.add(Refund(tenant_id=tenant.id,order_id=order.id,payment_intent_id="pi-fx",amount_minor=500,currency="EUR",status="COMPLETED")); db_session.commit()
    monkeypatch.setattr("app.routes.worldclass._perm",lambda *a,**k:None)
    result=analytics_customer_intelligence(tenant.id,365,MerchantUser(),db_session)
    assert result["by_currency"]["USD"]["net_revenue_minor"]==1000
