from pathlib import Path

from app.core.runtime import _alembic_config
from alembic.script import ScriptDirectory


def test_alembic_repository_has_single_current_head():
    script = ScriptDirectory.from_config(_alembic_config())
    assert script.get_heads() and len(script.get_heads()) == 1
    assert script.get_current_head() == script.get_heads()[0]


def test_release_version_matches_version_file():
    version = Path('VERSION').read_text(encoding='utf-8').strip()
    assert version and version.count('.') == 2
    assert version[0].isdigit()
