from pathlib import Path
from app.models.domain import Tenant, CommerceExperiment, CommerceExperimentAssignment, CommerceExperimentObservation
from app.routes.worldclass import experiment_observe, experiment_results

class MerchantUser: id='exp-merchant'

def test_experiment_observation_model_and_migration_are_tenant_scoped():
    src=Path('app/models/domain.py').read_text()
    mig=Path('alembic/versions/20260909_0073_experiment_observations.py').read_text()
    assert "__tablename__ = 'commerce_experiment_observations'" in src
    assert "UniqueConstraint('tenant_id', 'experiment_id', 'subject_key', 'metric_key', name='uq_commerce_experiment_observation_once')" in src
    assert "revision = '0073'" in mig
    assert "down_revision = '0072'" in mig
    assert 'ALTER TABLE commerce_experiment_observations ENABLE ROW LEVEL SECURITY' in mig
    assert 'ALTER TABLE commerce_experiment_observations FORCE ROW LEVEL SECURITY' in mig

def test_experiment_observe_is_idempotent_and_uses_assignment_variant(db_session, monkeypatch):
    t=Tenant(slug='exp-1997-idem',name='Exp',status='ACTIVE',default_currency='USD'); db_session.add(t); db_session.flush()
    ex=CommerceExperiment(tenant_id=t.id,key='hero',name='Hero',status='ACTIVE',traffic_bps=10000,variants=[{'key':'control','weight_bps':5000},{'key':'new','weight_bps':5000}],target_metric='purchase'); db_session.add(ex); db_session.flush()
    assignment=CommerceExperimentAssignment(tenant_id=t.id,experiment_id=ex.id,subject_key='s1',variant_key='new'); db_session.add(assignment); db_session.commit()
    monkeypatch.setattr('app.routes.worldclass._perm',lambda *a,**k:None)
    a=experiment_observe(ex.id,t.id,{'subject_key':'s1','metric_key':'purchase','value_numeric':1},MerchantUser(),db_session)
    b=experiment_observe(ex.id,t.id,{'subject_key':'s1','metric_key':'purchase','value_numeric':99},MerchantUser(),db_session)
    assert a['duplicate'] is False
    assert b['duplicate'] is True
    assert b['observation']['variant_key']=='new'
    assert float(b['observation']['value_numeric'])==1

def test_experiment_results_reports_rates_by_variant_and_window(db_session, monkeypatch):
    t=Tenant(slug='exp-1997-results',name='Exp results',status='ACTIVE',default_currency='USD'); db_session.add(t); db_session.flush()
    ex=CommerceExperiment(tenant_id=t.id,key='price',name='Price',status='ACTIVE',traffic_bps=10000,variants=[{'key':'control','weight_bps':5000},{'key':'new','weight_bps':5000}],target_metric='purchase'); db_session.add(ex); db_session.flush()
    assignments=[]
    for i in range(10):
        variant='control' if i<5 else 'new'
        a=CommerceExperimentAssignment(tenant_id=t.id,experiment_id=ex.id,subject_key=f's{i}',variant_key=variant); db_session.add(a); assignments.append((a,variant))
    db_session.flush()
    for i,(a,variant) in enumerate(assignments):
        for metric in (['purchase'] if (variant=='new' and i==5) or (variant=='control' and i==0) else []):
            db_session.add(CommerceExperimentObservation(tenant_id=t.id,experiment_id=ex.id,assignment_id=a.id,subject_key=a.subject_key,variant_key=variant,metric_key=metric,value_numeric=1,metadata_json={}))
    db_session.commit(); monkeypatch.setattr('app.routes.worldclass._perm',lambda *a,**k:None)
    r=experiment_results(ex.id,t.id,30,MerchantUser(),db_session)
    assert r['assignments']=={'control':5,'new':5}
    assert r['metrics']['purchase']['control']['observers']==1
    assert r['metrics']['purchase']['new']['observers']==1
    assert r['metrics']['purchase']['control']['conversion_rate_bps']==2000
    assert r['metrics']['purchase']['new']['conversion_rate_bps']==2000
