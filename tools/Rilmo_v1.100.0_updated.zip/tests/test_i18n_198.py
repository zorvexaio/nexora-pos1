import json
from pathlib import Path

def test_all_locales_complete_against_english():
    packs = json.loads(Path('app/frontend/locales.json').read_text())
    expected = set(packs['en'])
    assert set(packs) == {'ar', 'en', 'tr', 'fr', 'de', 'es', 'pt', 'it', 'ru', 'zh', 'ja', 'ko', 'hi'}
    for lang, values in packs.items():
        assert expected <= set(values), f'{lang} missing locale keys: {sorted(expected - set(values))}'
        assert all((isinstance(v, str) and v.strip() for v in values.values()))

def test_locale_asset_is_served(client):
    r = client.get('/locales.json')
    assert r.status_code == 200
    payload = r.json()
    assert len(payload) == 13 and all((isinstance(v, dict) for v in payload.values()))
