import os
from pathlib import Path
from unittest.mock import Mock

import pytest

from app.core.config import Settings
from app.core.database import SessionLocal
from app.services import core


def test_app_version_reads_single_source(monkeypatch):
    monkeypatch.setenv('APP_VERSION', '')
    s = Settings(APP_VERSION='', DATABASE_URL='sqlite:///./test.db')
    s.validate_runtime()
    assert s.APP_VERSION == Path('VERSION').read_text().strip()


def test_redis_rate_limit_uses_hashed_key(monkeypatch):
    calls = {}
    fake = Mock()
    def _eval(script, n, key, window):
        calls['args'] = (script, n, key, window)
        return 1
    fake.eval.side_effect = _eval
    fake_settings = Mock(REDIS_URL='redis://example.test:6379/0', REDIS_KEY_PREFIX='rilmo:rl:', REDIS_SOCKET_TIMEOUT_SECONDS=1, ENVIRONMENT='test')
    monkeypatch.setattr('app.core.config.get_settings', lambda: fake_settings)
    import sys, types
    fake_module = types.SimpleNamespace(Redis=types.SimpleNamespace(from_url=lambda *a, **k: fake))
    monkeypatch.setitem(sys.modules, 'redis', fake_module)
    db = SessionLocal()
    try:
        core.enforce_rate_limit(db, 'auth:secret@email.test', 10)
    finally:
        db.close()
    key = calls['args'][2]
    assert 'secret@email.test' not in key
    assert key.startswith('rilmo:rl:')


def test_redis_backend_failure_fails_closed_in_production(monkeypatch):
    monkeypatch.setenv('REDIS_URL', 'redis://example.test:6379/0')
    monkeypatch.setenv('ENVIRONMENT', 'production')
    monkeypatch.setenv('DATABASE_URL', 'postgresql+psycopg://x:y@db:5432/x')
    import sys, types
    fake_redis = types.SimpleNamespace(from_url=lambda *a, **k: (_ for _ in ()).throw(RuntimeError('down')))
    monkeypatch.setitem(sys.modules, 'redis', types.SimpleNamespace(Redis=fake_redis))
    # Use a fake settings object to isolate this test from unrelated production requirements.
    fake_settings = Mock(ENVIRONMENT='production', REDIS_URL='redis://example.test:6379/0', REDIS_KEY_PREFIX='rilmo:rl:', REDIS_SOCKET_TIMEOUT_SECONDS=1)
    monkeypatch.setattr('app.core.config.get_settings', lambda: fake_settings)
    db = SessionLocal()
    try:
        with pytest.raises(Exception) as exc:
            core.enforce_rate_limit(db, 'test', 1)
        assert getattr(exc.value, 'code', '') == 'RATE_LIMIT_BACKEND_UNAVAILABLE' or 'RATE_LIMIT_BACKEND_UNAVAILABLE' in str(exc.value)
    finally:
        db.close()
