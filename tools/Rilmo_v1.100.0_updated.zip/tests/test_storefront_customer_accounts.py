from app.core.database import SessionLocal
from app.models.domain import Domain, Storefront, Tenant


def _publish(client, email='customer-merchant@example.com'):
    hostname = 'shop-' + email.split('@')[0].replace('_','-') + '.example.test'
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'Merchant'}).json()
    tid = m['tenant']['id']
    db = SessionLocal()
    s = db.query(Storefront).filter_by(tenant_id=tid).first()
    t = db.get(Tenant, tid)
    d = db.query(Domain).filter_by(tenant_id=tid).first()
    if not d:
        d = Domain(tenant_id=tid, storefront_id=s.id, hostname=hostname, verified_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc))
        db.add(d)
    else:
        d.hostname = hostname; d.verified_at = __import__('datetime').datetime.now(__import__('datetime').timezone.utc)
    t.status = 'ACTIVE'; s.status = 'PUBLISHED'
    db.commit(); db.close()
    return tid


def test_storefront_customer_email_login_and_cart_session(client):
    tid = _publish(client)
    c = client.__class__(client.app)
    start = c.post(f'/v1/public/storefront/shop-customer-merchant.example.test/auth/email/start', json={'email': 'buyer@example.com'})
    assert start.status_code == 200
    from pathlib import Path
    outbox = Path('.local/mail.outbox.log').read_text(encoding='utf-8')
    code = outbox.split('Your sign-in code is ')[-1].split('.')[0]
    verify = c.post('/v1/public/storefront/shop-customer-merchant.example.test/auth/email/verify', json={'email': 'buyer@example.com', 'code': code})
    assert verify.status_code == 200, verify.text
    assert 'customer_session' in c.cookies
    session = c.get('/v1/public/storefront/shop-customer-merchant.example.test/customer/session').json()
    assert session['authenticated'] is True
    cart = c.get(f'/v1/cart?tenant_id={tid}').json()
    assert cart['cart'] is None
    created = c.post(f'/v1/cart?tenant_id={tid}', json={'currency': 'USD'}, headers={'X-CSRF-Token': c.cookies.get('csrf_token')})
    assert created.status_code == 200
    c.post(f'/v1/public/storefront/shop-customer-merchant.example.test/auth/logout', headers={'X-CSRF-Token': c.cookies.get('csrf_token')})
    assert 'customer_session' not in c.cookies


def test_customer_cookie_mutation_requires_csrf(client):
    c = client.__class__(client.app)
    c.cookies.set('customer_session', 'dummy-customer-session')
    r = c.post('/v1/public/storefront/shop-nonexistent.example.test/auth/logout', headers={'Origin': 'https://evil.example'})
    assert r.status_code == 403
    assert r.json()['error']['code'] == 'CSRF_VALIDATION_FAILED'


def test_customer_cookie_mutation_allows_same_origin_csrf_header(client):
    c = client.__class__(client.app)
    c.cookies.set('customer_session', 'dummy-customer-session')
    c.cookies.set('csrf_token', 'csrf-test-token')
    r = c.post('/v1/public/storefront/shop-nonexistent.example.test/auth/logout', headers={
        'Origin': 'http://testserver', 'X-CSRF-Token': 'csrf-test-token'
    })
    assert r.status_code != 403 or r.json().get('error', {}).get('code') != 'CSRF_VALIDATION_FAILED'
