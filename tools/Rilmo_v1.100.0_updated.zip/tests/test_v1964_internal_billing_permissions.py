from tests.test_p0 import register

def h(x):
    return {"Authorization": f"Bearer {x['access_token']}"}

def test_compat_subscription_route_requires_billing_manage(client):
    from app.core.database import SessionLocal
    from app.models.domain import TenantMembership, Plan, PlanVersion
    x = register(client, 'compat-billing-perm@example.com')
    tid = x['tenant']['id']
    db = SessionLocal(); m = db.query(TenantMembership).filter_by(tenant_id=tid, user_id=x['user']['id']).first(); m.role = 'viewer'
    pv = db.query(PlanVersion).join(Plan).filter(Plan.is_active == True, PlanVersion.is_current == True).first(); db.commit(); db.close()
    r = client.post(f'/v1/subscription/subscribe?tenant_id={tid}', headers=h(x), json={'plan_version_id': pv.id})
    assert r.status_code == 403, r.text

def test_canonical_subscription_route_still_requires_billing_manage(client):
    from app.core.database import SessionLocal
    from app.models.domain import TenantMembership, Plan, PlanVersion
    x = register(client, 'canonical-billing-perm@example.com')
    tid = x['tenant']['id']
    db = SessionLocal(); m = db.query(TenantMembership).filter_by(tenant_id=tid, user_id=x['user']['id']).first(); m.role = 'viewer'
    pv = db.query(PlanVersion).join(Plan).filter(Plan.is_active == True, PlanVersion.is_current == True).first(); db.commit(); db.close()
    r = client.post(f'/v1/subscriptions?tenant_id={tid}', headers=h(x), json={'plan_version_id': pv.id})
    assert r.status_code == 403, r.text
