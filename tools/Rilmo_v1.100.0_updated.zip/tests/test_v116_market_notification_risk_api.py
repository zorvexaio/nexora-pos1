from app.models.domain import Market, NotificationTemplate, NotificationDelivery, RiskAssessment, APIKey

def test_v116_models_registered():
    names = {x.__tablename__ for x in [Market, NotificationTemplate, NotificationDelivery, RiskAssessment, APIKey]}
    assert names == {'markets', 'notification_templates', 'notification_deliveries', 'risk_assessments', 'api_keys'}

def test_api_key_secret_is_hashed():
    raw = 'ugc_test_secret'
    from app.core.security import token_hash
    assert token_hash(raw) != raw

def test_notification_idempotency_constraint_exists():
    assert any((c.name == 'uq_notification_delivery_idem' for c in NotificationDelivery.__table__.constraints))

def test_market_tenant_code_unique():
    assert any((c.name == 'uq_market_tenant_code' or ('tenant_id' in {x.name for x in c.columns} and 'code' in {x.name for x in c.columns}) for c in Market.__table__.constraints))
