from tests.test_p0 import register
from app.core.database import SessionLocal
from app.models.domain import Domain, Storefront, Product
from app.services.advanced import assistant_answer

def h(x):
    return {"Authorization": f"Bearer {x['access_token']}"}

def test_server_ai_defaults_to_ollama():
    from app.core.config import get_settings
    s=get_settings()
    assert s.AI_PROVIDER == 'ollama'
    assert s.AI_BASE_URL.startswith('http://ollama')
    assert s.AI_SERVER_ONLY is True

def test_public_storefront_assistant_is_tenant_scoped(client):
    x = register(client, 'v156a@example.com')
    tid = x['tenant']['id']
    db = SessionLocal()
    from app.models.domain import Tenant
    db.query(Tenant).filter_by(id=tid).update({'status':'ACTIVE'})
    sf = db.query(Storefront).filter_by(tenant_id=tid).first()
    if not sf:
        sf = Storefront(tenant_id=tid, slug='main', status='PUBLISHED')
        db.add(sf); db.flush()
    sf.status = 'PUBLISHED'
    domain = Domain(tenant_id=tid, storefront_id=sf.id, hostname=f'shop-v156a-{tid[:8]}.test', verified_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc))
    db.add(domain)
    product = Product(tenant_id=tid, slug='blue-mug', title='Blue Mug', description='Ceramic mug')
    db.add(product); db.commit(); db.close()
    r = client.post(f'/v1/public/storefront/shop-v156a-{tid[:8]}.test/assistant', json={'question':'ابحث عن كوب أزرق'})
    assert r.status_code == 200
    assert product.id in r.json().get('recommended_product_ids', []) or r.json().get('answer')

def test_public_storefront_assistant_bounds_input(client):
    x = register(client, 'v156b@example.com')
    r = client.post('/v1/public/storefront/no-such-domain.test/assistant', json={'question':'x'*701})
    assert r.status_code in (404, 413)
