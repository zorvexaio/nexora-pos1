"""Phase 2 SEO closure — regression guard.

Before this fix, /product/{slug} (custom domain) emitted Product JSON-LD with
Offer/Brand/AggregateRating, but the platform-hosted equivalents
/store/{hostname} and /store/{hostname}/product/{slug} emitted no JSON-LD at
all. Search engines therefore had zero rich-result eligibility for any
merchant still on a *.rilmo subdomain instead of a verified custom domain —
silently excluding every merchant who hasn't bought a domain yet.

This test locks in that all four public storefront HTML routes are built
from the same _render_seo_page() helper, so head-tag/JSON-LD drift between
them can't reappear without this test failing.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_seo_head_injection_has_single_shared_helper():
    text = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
    assert "def _render_seo_page(" in text
    # Every public HTML route must delegate to the shared helper rather than
    # hand-rolling its own <head> string (the original source of the drift).
    for route_fn in (
        "def _custom_domain_store(",
        "def custom_domain_product(",
        "def public_store_html(",
        "def public_product_html(",
    ):
        idx = text.index(route_fn)
        # the next call to _render_seo_page must appear before the next "def "
        next_def = text.index("\ndef ", idx + 1)
        following_decorator = text.find("\n@app.get", idx + 1)
        boundary = min(x for x in (next_def, following_decorator) if x != -1)
        body = text[idx:boundary]
        assert "_render_seo_page(" in body, f"{route_fn} no longer uses the shared SEO helper"


def test_platform_store_routes_pass_jsonld_argument():
    text = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
    idx = text.index("def public_store_html(")
    end = text.index("def public_product_html(")
    body = text[idx:end]
    assert "jsonld=schema" in body, "public_store_html must emit Store JSON-LD like the custom-domain route does"

    idx2 = text.index("def public_product_html(")
    body2 = text[idx2:idx2 + 4000]
    assert "jsonld=product_schema" in body2, "public_product_html must emit Product JSON-LD like the custom-domain route does"
