from pathlib import Path
import yaml
import pytest

ROOT = Path(__file__).resolve().parents[1]


def test_api_healthcheck_uses_ready_endpoint():
    data = yaml.safe_load((ROOT / 'docker-compose.production.yml').read_text(encoding='utf-8'))
    command = data['services']['api']['healthcheck']['test']
    joined = ' '.join(str(x) for x in command)
    assert '/v1/ready' in joined
    assert '/v1/health' not in joined


def test_production_runtime_requires_paddle_api_key(monkeypatch):
    from app.core.config import Settings
    env = {
        'ENVIRONMENT':'production','APP_VERSION':'1.95.8','LEGAL_ENTITY_NAME':'Rilmo','PRIVACY_CONTACT_EMAIL':'privacy@example.com',
        'PRIVACY_POLICY_VERSION':'1','TERMS_EFFECTIVE_DATE':'2026-08-22','DATABASE_URL':'postgresql://x','SECRET_KEY':'x'*40,
        'ENCRYPTION_KEY':'y'*40,'WEBHOOK_SECRET':'z'*40,'COOKIE_SECURE':'true','ALLOWED_HOSTS':'app.example.com','CORS_ORIGINS':'https://app.example.com',
        'TRUSTED_ORIGINS':'https://app.example.com','FORWARDED_ALLOW_IPS':'10.0.0.1','PUBLIC_BASE_URL':'https://app.example.com',
        'BILLING_PROVIDER':'paddle','S3_BUCKET':'b','S3_ACCESS_KEY_ID':'a','S3_SECRET_ACCESS_KEY':'s','PADDLE_WEBHOOK_SECRET':'w',
        'GOOGLE_CLIENT_ID':'g','GOOGLE_CLIENT_SECRET':'gs','GOOGLE_REDIRECT_URI':'https://app.example.com/callback','DOMAIN_VERIFICATION_MODE':'dns',
        'SMTP_HOST':'smtp.example.com','SMTP_USERNAME':'u','SMTP_PASSWORD':'p','MAIL_FROM':'noreply@example.com','CLAMAV_HOST':'clamav',
        'SMS_PROVIDER':'twilio','TWILIO_ACCOUNT_SID':'sid','TWILIO_AUTH_TOKEN':'tok','TWILIO_FROM_NUMBER':'+15555555555',
        'WHATSAPP_APP_SECRET':'wa','APP_WEBHOOK_ALLOWED_HOSTS':'hooks.example.com','REDIS_URL':'redis://redis:6379/0',
        'MERCHANT_KYC_PROVIDER':'veriff','VERIFF_API_BASE_URL':'https://stationapi.veriff.com','VERIFF_API_KEY':'vk','VERIFF_SHARED_SECRET':'vs',
        'AI_PROVIDER':'ollama','AI_BASE_URL':'http://ollama:11434','AI_SERVER_ONLY':'true','AI_EXTERNAL_PROVIDER_ALLOWED':'false',
        'S3_ENDPOINT_URL':'','S3_REGION':'auto','AI_ENABLED':'false','REQUIRE_MERCHANT_IDENTITY':'true',
    }
    for k,v in env.items(): monkeypatch.setenv(k,v)
    monkeypatch.delenv('PADDLE_API_KEY', raising=False)
    with pytest.raises(RuntimeError, match='PADDLE_API_KEY'):
        Settings().validate_runtime()


def test_production_preflight_enforces_kyc_and_billing():
    text = (ROOT / 'scripts/production_preflight.py').read_text(encoding='utf-8')
    assert 'BILLING_PROVIDER must be paddle in production' in text
    assert 'MERCHANT_KYC_PROVIDER must be veriff in production' in text
    assert 'VERIFF_SHARED_SECRET' in text


def test_staging_smoke_is_fail_closed_and_checks_readiness():
    text = (ROOT / 'scripts/staging_smoke.py').read_text(encoding='utf-8')
    assert 'ipaddress.ip_address' in text
    assert 'is_global' in text
    assert 'follow_redirects=False' in text
    assert 'client.get("/v1/ready")' in text
    assert 'target resolves to non-global address' in text
