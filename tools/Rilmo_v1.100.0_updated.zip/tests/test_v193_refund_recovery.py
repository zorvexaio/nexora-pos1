from app.services.payment_providers import PaymentActionResult


def _merchant(client, email):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'}).json()
    return m['tenant']['id'], {'Authorization': 'Bearer ' + m['access_token']}


def _order_payment(client, tid, headers, slug='refund-recovery', sku='RR-1'):
    p = client.post(f'/v1/products?tenant_id={tid}', headers=headers,
        json={'slug': slug, 'title': 'Refund recovery', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=headers,
        json={'sku': sku, 'price_amount_minor': 500, 'currency': 'USD'}).json()
    assert client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=1&reason=test", headers=headers).status_code == 200
    cart = client.post(f'/v1/cart?tenant_id={tid}', headers=headers).json()
    assert client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", headers=headers,
        json={'variant_id': v['id'], 'quantity': 1}).status_code == 200
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=headers,
        json={'cart_id': cart['id']}).json()
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=headers,
        json={'order_id': order['id'], 'amount_minor': order['total_minor'], 'currency': 'USD', 'provider': 'mock'}).json()
    assert client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=headers).status_code == 200
    return order, pi


def test_refund_retry_with_same_provider_reference_is_idempotent(client, monkeypatch):
    tid, headers = _merchant(client, 'refund-recovery@example.com')
    order, pi = _order_payment(client, tid, headers)
    calls = {'n': 0}

    class Provider:
        def refund(self, *args, **kwargs):
            calls['n'] += 1
            return PaymentActionResult(provider_id='refund-provider-123', status='succeeded', raw={})

    monkeypatch.setattr('app.routes.payment_routes.get_payment_provider', lambda _name: Provider())

    # The first refund persists locally. The second call uses a new idempotency key
    # but the provider returns the same reference, simulating a retry/recovery path.
    first = client.post(f'/v1/refunds?tenant_id={tid}', headers=headers, json={
        'order_id': order['id'], 'payment_intent_id': pi['id'],
        'amount_minor': 250, 'currency': 'USD', 'provider': 'mock',
    })
    assert first.status_code == 200

    second = client.post(f'/v1/refunds?tenant_id={tid}', headers={**headers, 'Idempotency-Key': 'different-refund-op'}, json={
        'order_id': order['id'], 'payment_intent_id': pi['id'],
        'amount_minor': 250, 'currency': 'USD', 'provider': 'mock',
    })
    assert second.status_code == 200
    assert second.json()['id'] == first.json()['id']
    assert calls['n'] == 2


def test_refund_provider_reference_cannot_bind_to_different_payment(client, monkeypatch):
    tid, headers = _merchant(client, 'refund-reference-reuse@example.com')
    order1, pi1 = _order_payment(client, tid, headers)
    order2, pi2 = _order_payment(client, tid, headers, slug='refund-reference-reuse-2', sku='RR-2')

    class Provider:
        def refund(self, *args, **kwargs):
            return PaymentActionResult(provider_id='shared-ref', status='succeeded', raw={})

    monkeypatch.setattr('app.routes.payment_routes.get_payment_provider', lambda _name: Provider())

    first = client.post(f'/v1/refunds?tenant_id={tid}', headers=headers, json={
        'order_id': order1['id'], 'payment_intent_id': pi1['id'],
        'amount_minor': 500, 'currency': 'USD', 'provider': 'mock',
    })
    assert first.status_code == 200

    second = client.post(f'/v1/refunds?tenant_id={tid}', headers={**headers, 'Idempotency-Key': 'different-refund-op'}, json={
        'order_id': order2['id'], 'payment_intent_id': pi2['id'],
        'amount_minor': 500, 'currency': 'USD', 'provider': 'mock',
    })
    assert second.status_code == 409
    assert second.json()['detail']['error']['code'] == 'PROVIDER_REFUND_REFERENCE_REUSED'
