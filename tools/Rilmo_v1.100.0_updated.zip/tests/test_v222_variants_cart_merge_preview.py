def _merchant(client, email):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'M'}).json()
    return m['tenant']['id'], {'Authorization': 'Bearer ' + m['access_token']}


# --- storefront preview token --------------------------------------

def test_storefront_preview_token_returns_signed_token(client):
    tid, h = _merchant(client, 'preview-token@example.com')
    client.post(f'/v1/storefront?tenant_id={tid}', headers=h, json={'name': 'My Store'})
    r = client.post(f'/v1/storefront/preview-token?tenant_id={tid}', headers=h)
    assert r.status_code == 200, r.text
    body = r.json()
    assert '.' in body['preview_token']
    assert body['expires_in'] == 900

def test_storefront_preview_token_missing_storefront_returns_not_found(client):
    tid, h = _merchant(client, 'preview-token-missing@example.com')
    from app.core.database import SessionLocal
    from app.models.domain import Storefront
    db = SessionLocal()
    db.query(Storefront).filter_by(tenant_id=tid).delete()
    db.commit()
    db.close()
    r = client.post(f'/v1/storefront/preview-token?tenant_id={tid}', headers=h)
    assert r.status_code == 404


# --- variant patch ---------------------------------------------------

def _product_and_variant(client, tid, h):
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'var-item', 'title': 'Var Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'VAR-1', 'price_amount_minor': 1000, 'currency': 'USD'}).json()
    return p, v

def test_patch_variant_updates_price_and_currency(client):
    tid, h = _merchant(client, 'variant-patch@example.com')
    p, v = _product_and_variant(client, tid, h)
    r = client.patch(f"/v1/products/{p['id']}/variants/{v['id']}?tenant_id={tid}", headers={**h, 'If-Match': str(v['version'])},
        json={'price_amount_minor': 2500, 'currency': 'eur'})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['price_amount_minor'] == 2500
    assert body['currency'] == 'EUR'

def test_patch_variant_rejects_negative_price_by_clamping_to_zero(client):
    tid, h = _merchant(client, 'variant-patch-negprice@example.com')
    p, v = _product_and_variant(client, tid, h)
    r = client.patch(f"/v1/products/{p['id']}/variants/{v['id']}?tenant_id={tid}", headers={**h, 'If-Match': str(v['version'])},
        json={'price_amount_minor': -500})
    assert r.status_code == 200
    assert r.json()['price_amount_minor'] == 0

def test_patch_variant_missing_returns_not_found(client):
    tid, h = _merchant(client, 'variant-patch-missing@example.com')
    p, v = _product_and_variant(client, tid, h)
    r = client.patch(f"/v1/products/{p['id']}/variants/does-not-exist?tenant_id={tid}", headers=h, json={'sku': 'X'})
    assert r.status_code == 404

def test_patch_variant_updates_sku_and_status(client):
    tid, h = _merchant(client, 'variant-patch-sku@example.com')
    p, v = _product_and_variant(client, tid, h)
    r = client.patch(f"/v1/products/{p['id']}/variants/{v['id']}?tenant_id={tid}", headers={**h, 'If-Match': str(v['version'])},
        json={'sku': 'NEW-SKU', 'status': 'INACTIVE'})
    assert r.status_code == 200
    assert r.json()['sku'] == 'NEW-SKU'
    assert r.json()['status'] == 'INACTIVE'


# --- variant delete ----------------------------------------------------

def test_delete_variant_marks_inactive(client):
    tid, h = _merchant(client, 'variant-delete@example.com')
    p, v = _product_and_variant(client, tid, h)
    r = client.delete(f"/v1/products/{p['id']}/variants/{v['id']}?tenant_id={tid}", headers=h)
    assert r.status_code == 200
    assert r.json()['ok'] is True

def test_delete_variant_missing_returns_not_found(client):
    tid, h = _merchant(client, 'variant-delete-missing@example.com')
    p, v = _product_and_variant(client, tid, h)
    r = client.delete(f"/v1/products/{p['id']}/variants/does-not-exist?tenant_id={tid}", headers=h)
    assert r.status_code == 404


# --- cart merge -------------------------------------------------------

def test_merge_cart_combines_distinct_items(client):
    tid, h = _merchant(client, 'cart-merge@example.com')
    p1 = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'merge-item1', 'title': 'Merge Item 1', 'status': 'ACTIVE'}).json()
    v1 = client.post(f"/v1/products/{p1['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'MRG-1', 'price_amount_minor': 500, 'currency': 'USD'}).json()
    p2 = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'merge-item2', 'title': 'Merge Item 2', 'status': 'ACTIVE'}).json()
    v2 = client.post(f"/v1/products/{p2['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'MRG-2', 'price_amount_minor': 700, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v1['id']}&delta=5&reason=test", headers=h)
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v2['id']}&delta=5&reason=test", headers=h)

    target = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={target['id']}", headers=h, json={'variant_id': v1['id'], 'quantity': 1})
    source = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={source['id']}", headers=h, json={'variant_id': v2['id'], 'quantity': 2})

    r = client.post(f"/v1/cart/merge?tenant_id={tid}&target_cart_id={target['id']}&source_cart_id={source['id']}", headers=h)
    assert r.status_code == 200, r.text
    fetched = client.get(f"/v1/cart?tenant_id={tid}&cart_id={target['id']}", headers=h).json()
    variant_ids = {i['variant_id'] for i in fetched['items']}
    assert variant_ids == {v1['id'], v2['id']}

def test_merge_cart_combines_quantities_for_same_variant(client):
    tid, h = _merchant(client, 'cart-merge-same@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'merge-same', 'title': 'Merge Same', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'MRG-SAME', 'price_amount_minor': 500, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=10&reason=test", headers=h)

    target = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={target['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 2})
    source = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={source['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 3})

    r = client.post(f"/v1/cart/merge?tenant_id={tid}&target_cart_id={target['id']}&source_cart_id={source['id']}", headers=h)
    assert r.status_code == 200, r.text
    fetched = client.get(f"/v1/cart?tenant_id={tid}&cart_id={target['id']}", headers=h).json()
    assert len(fetched['items']) == 1
    assert fetched['items'][0]['quantity'] == 5

def test_merge_cart_same_cart_id_returns_unchanged(client):
    tid, h = _merchant(client, 'cart-merge-self@example.com')
    cart = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    r = client.post(f"/v1/cart/merge?tenant_id={tid}&target_cart_id={cart['id']}&source_cart_id={cart['id']}", headers=h)
    assert r.status_code == 200
    assert r.json()['id'] == cart['id']

def test_merge_cart_missing_cart_returns_not_found(client):
    tid, h = _merchant(client, 'cart-merge-missing@example.com')
    cart = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    r = client.post(f"/v1/cart/merge?tenant_id={tid}&target_cart_id={cart['id']}&source_cart_id=does-not-exist", headers=h)
    assert r.status_code == 404

def test_merge_cart_is_idempotent(client):
    tid, h = _merchant(client, 'cart-merge-idem@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'merge-idem', 'title': 'Merge Idem', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'MRG-IDEM', 'price_amount_minor': 500, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    target = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    source = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={source['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})

    key = {'Idempotency-Key': 'merge-once'}
    first = client.post(f"/v1/cart/merge?tenant_id={tid}&target_cart_id={target['id']}&source_cart_id={source['id']}", headers={**h, **key})
    second = client.post(f"/v1/cart/merge?tenant_id={tid}&target_cart_id={target['id']}&source_cart_id={source['id']}", headers={**h, **key})
    assert first.status_code == 200
    assert second.status_code == 200


# --- POST /v1/orders (checkout alias) -----------------------------------

def test_create_order_from_checkout_alias_works(client):
    tid, h = _merchant(client, 'orders-alias@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'alias-item', 'title': 'Alias Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'ALIAS-1', 'price_amount_minor': 1200, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    cart = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    r = client.post(f'/v1/orders?tenant_id={tid}', headers=h, json={'cart_id': cart['id']})
    assert r.status_code == 200, r.text
    assert r.json()['total_minor'] == 1200
