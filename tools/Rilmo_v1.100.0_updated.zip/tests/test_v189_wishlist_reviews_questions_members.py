def _merchant(client, email):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'M'}).json()
    return m['tenant']['id'], {'Authorization': 'Bearer ' + m['access_token']}


def _delivered_order_with_product(client, tid, h):
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'reviewed-item', 'title': 'Reviewed Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'REV-1', 'price_amount_minor': 1000, 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c['id']}).json()
    return p, order


# --- wishlist ---------------------------------------------------------

def test_create_wishlist_is_idempotent_for_same_user(client):
    tid, h = _merchant(client, 'wishlist-create@example.com')
    w1 = client.post(f'/v1/wishlist?tenant_id={tid}', headers=h)
    w2 = client.post(f'/v1/wishlist?tenant_id={tid}', headers=h)
    assert w1.status_code == 200
    assert w2.status_code == 200
    assert w1.json()['id'] == w2.json()['id']

def test_add_wishlist_item_succeeds(client):
    tid, h = _merchant(client, 'wishlist-add@example.com')
    client.post(f'/v1/wishlist?tenant_id={tid}', headers=h)
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'wish-item', 'title': 'Wish Item', 'status': 'ACTIVE'}).json()
    r = client.post(f'/v1/wishlist/items?tenant_id={tid}', headers=h, json={'product_id': p['id']})
    assert r.status_code == 200
    assert r.json()['ok'] is True

def test_add_wishlist_item_twice_reports_duplicate(client):
    tid, h = _merchant(client, 'wishlist-dup@example.com')
    client.post(f'/v1/wishlist?tenant_id={tid}', headers=h)
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'wish-item2', 'title': 'Wish Item 2', 'status': 'ACTIVE'}).json()
    client.post(f'/v1/wishlist/items?tenant_id={tid}', headers=h, json={'product_id': p['id']})
    r2 = client.post(f'/v1/wishlist/items?tenant_id={tid}', headers=h, json={'product_id': p['id']})
    assert r2.status_code == 200
    assert r2.json()['duplicate'] is True

def test_add_wishlist_item_missing_product_returns_not_found(client):
    tid, h = _merchant(client, 'wishlist-missing@example.com')
    client.post(f'/v1/wishlist?tenant_id={tid}', headers=h)
    r = client.post(f'/v1/wishlist/items?tenant_id={tid}', headers=h, json={'product_id': 'does-not-exist'})
    assert r.status_code == 404

def test_add_wishlist_item_without_wishlist_created_first_fails(client):
    tid, h = _merchant(client, 'wishlist-nowishlist@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'wish-item3', 'title': 'Wish Item 3', 'status': 'ACTIVE'}).json()
    r = client.post(f'/v1/wishlist/items?tenant_id={tid}', headers=h, json={'product_id': p['id']})
    assert r.status_code == 404


# --- reviews -----------------------------------------------------------

def test_review_requires_delivered_order(client):
    tid, h = _merchant(client, 'review-nodelivery@example.com')
    p, order = _delivered_order_with_product(client, tid, h)
    r = client.post(f'/v1/reviews?tenant_id={tid}', headers=h, json={
        'product_id': p['id'], 'order_id': order['id'], 'rating': 5, 'body': 'Great!',
    })
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'VERIFIED_PURCHASE_REQUIRED'

def test_review_succeeds_for_delivered_order_containing_product(client):
    from app.core.database import SessionLocal
    from app.models.domain import Order

    tid, h = _merchant(client, 'review-delivered@example.com')
    p, order = _delivered_order_with_product(client, tid, h)
    db = SessionLocal()
    db.query(Order).filter_by(id=order['id']).update({'status': 'DELIVERED'})
    db.commit()
    db.close()

    r = client.post(f'/v1/reviews?tenant_id={tid}', headers=h, json={
        'product_id': p['id'], 'order_id': order['id'], 'rating': 5, 'body': 'Excellent product!',
    })
    assert r.status_code == 200, r.text
    assert r.json()['rating'] == 5

def test_review_rejects_duplicate_for_same_order_and_product(client):
    from app.core.database import SessionLocal
    from app.models.domain import Order

    tid, h = _merchant(client, 'review-dup@example.com')
    p, order = _delivered_order_with_product(client, tid, h)
    db = SessionLocal()
    db.query(Order).filter_by(id=order['id']).update({'status': 'DELIVERED'})
    db.commit()
    db.close()

    client.post(f'/v1/reviews?tenant_id={tid}', headers=h, json={'product_id': p['id'], 'order_id': order['id'], 'rating': 4, 'body': 'Good'})
    r2 = client.post(f'/v1/reviews?tenant_id={tid}', headers=h, json={'product_id': p['id'], 'order_id': order['id'], 'rating': 5, 'body': 'Again'})
    assert r2.status_code == 409
    assert r2.json()['detail']['error']['code'] == 'REVIEW_EXISTS'

def test_review_rejects_product_not_in_order(client):
    from app.core.database import SessionLocal
    from app.models.domain import Order

    tid, h = _merchant(client, 'review-wrongproduct@example.com')
    p1, order = _delivered_order_with_product(client, tid, h)
    other_product = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'unrelated-item', 'title': 'Unrelated', 'status': 'ACTIVE'}).json()
    db = SessionLocal()
    db.query(Order).filter_by(id=order['id']).update({'status': 'DELIVERED'})
    db.commit()
    db.close()

    r = client.post(f'/v1/reviews?tenant_id={tid}', headers=h, json={
        'product_id': other_product['id'], 'order_id': order['id'], 'rating': 5, 'body': 'nope',
    })
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'PRODUCT_NOT_IN_ORDER'


# --- product questions -----------------------------------------------

def test_ask_question_succeeds(client):
    tid, h = _merchant(client, 'question-ask@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'q-item', 'title': 'Q Item', 'status': 'ACTIVE'}).json()
    r = client.post(f'/v1/questions?tenant_id={tid}', headers=h, json={'product_id': p['id'], 'body': 'Does this ship internationally?'})
    assert r.status_code == 200, r.text
    assert r.json()['body'] == 'Does this ship internationally?'

def test_ask_question_missing_product_returns_not_found(client):
    tid, h = _merchant(client, 'question-missing@example.com')
    r = client.post(f'/v1/questions?tenant_id={tid}', headers=h, json={'product_id': 'nope', 'body': 'Hello?'})
    assert r.status_code == 404


# --- members -----------------------------------------------------------

def test_members_lists_owner_with_user_details(client):
    tid, h = _merchant(client, 'members-owner@example.com')
    r = client.get(f'/v1/members?tenant_id={tid}', headers=h)
    assert r.status_code == 200
    members_list = r.json()
    assert len(members_list) >= 1
    assert members_list[0]['user']['email'] == 'members-owner@example.com'

def test_members_requires_staff_manage_permission(client):
    owner_tid, owner_h = _merchant(client, 'members-perm-owner@example.com')
    other = client.post('/v1/auth/register', json={'email': 'members-perm-other@example.com', 'password': 'VerySecurePassword123!'}).json()
    other_h = {'Authorization': 'Bearer ' + other['access_token']}
    r = client.get(f'/v1/members?tenant_id={owner_tid}', headers=other_h)
    assert r.status_code == 403


# --- entitlements / subscription (non-Paddle default path) ----------------

def test_entitlements_empty_for_new_tenant(client):
    tid, h = _merchant(client, 'entitlements-empty@example.com')
    r = client.get(f'/v1/entitlements?tenant_id={tid}', headers=h)
    assert r.status_code == 200
    assert r.json() == []

def test_subscription_reports_none_when_no_active_subscription(client):
    tid, h = _merchant(client, 'subscription-none@example.com')
    r = client.get(f'/v1/subscription?tenant_id={tid}', headers=h)
    assert r.status_code == 200
    assert r.json() == {'subscription': None}
