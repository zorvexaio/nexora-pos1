from pathlib import Path


def test_ucp_discovery_contract_contains_required_schema_bindings():
    src = Path("app/main.py").read_text(encoding="utf-8")
    assert "https://ucp.dev/2026-04-08/services/shopping/rest.openapi.json" in src
    assert "https://ucp.dev/2026-04-08/schemas/shopping/checkout.json" in src
    assert "https://ucp.dev/2026-04-08/schemas/shopping/fulfillment.json" in src


def test_ucp_business_profile_is_cacheable_and_schema_bound():
    src = Path("app/routes/worldclass.py").read_text(encoding="utf-8")
    assert "Cache-Control" in src and "public, max-age=300" in src
    assert "'schema':'https://ucp.dev/2026-04-08/services/shopping/rest.openapi.json'" in src
    assert "'extends':'dev.ucp.shopping.checkout'" in src


def test_release_version_is_consistent():
    version = Path("VERSION").read_text(encoding="utf-8").strip()
    assert version == Path("VERSION").read_text(encoding="utf-8").strip()
    for name in ("README.md", "IMPLEMENTATION_STATUS.md", "docs/compliance/compliance_manifest.json", "RELEASE_MANIFEST.json"):
        assert version in Path(name).read_text(encoding="utf-8")


def test_ucp_completion_is_payment_safe_outside_local_mock_mode():
    src = Path("app/routes/worldclass.py").read_text(encoding="utf-8")
    assert "UCP_PAYMENT_REQUIRED" in src
    assert "UCP_PAYMENT_NOT_CAPTURED" in src
    assert "captured_minor < int(row.total_minor)" in src
    assert "tenant_id=tenant.id" in src
    assert "ALLOW_LOCAL_MOCK_PAYMENTS" in src
    assert "environment == 'test'" in src
