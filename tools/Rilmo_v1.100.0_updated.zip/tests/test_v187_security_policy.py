import pytest
from app.security.policy import (
    is_private_ip, validate_outbound_url, validate_upload,
    normalize_hostname, verification_txt_name, hmac_compare,
)


# --- is_private_ip -----------------------------------------------------

@pytest.mark.parametrize('ip', ['127.0.0.1', '10.0.0.1', '192.168.1.1', '169.254.1.1', '0.0.0.0', '224.0.0.1'])
def test_is_private_ip_flags_all_non_routable_ranges(ip):
    assert is_private_ip(ip) is True

def test_is_private_ip_allows_public_ip():
    assert is_private_ip('8.8.8.8') is False

def test_is_private_ip_returns_false_for_non_ip_string():
    assert is_private_ip('not-an-ip') is False


# --- validate_outbound_url ------------------------------------------------

def test_validate_outbound_url_rejects_disallowed_scheme():
    with pytest.raises(ValueError):
        validate_outbound_url('ftp://example.com/file')

def test_validate_outbound_url_rejects_missing_hostname():
    with pytest.raises(ValueError):
        validate_outbound_url('https:///path')

def test_validate_outbound_url_rejects_host_not_in_allowlist():
    with pytest.raises(ValueError):
        validate_outbound_url('https://evil.com', allowed_hosts={'good.com'})

def test_validate_outbound_url_allows_host_in_allowlist(monkeypatch):
    import socket
    monkeypatch.setattr(socket, 'getaddrinfo', lambda *a, **k: [(socket.AF_INET, None, None, '', ('93.184.216.34', 443))])
    result = validate_outbound_url('https://good.com/path', allowed_hosts={'good.com'})
    assert 'good.com' in result

def test_validate_outbound_url_rejects_localhost():
    with pytest.raises(ValueError):
        validate_outbound_url('http://localhost/admin')

def test_validate_outbound_url_rejects_metadata_host():
    with pytest.raises(ValueError):
        validate_outbound_url('http://metadata.google.internal/latest')

def test_validate_outbound_url_rejects_private_ip_literal():
    with pytest.raises(ValueError):
        validate_outbound_url('http://192.168.1.1/x')

def test_validate_outbound_url_rejects_dns_rebinding_to_private_ip(monkeypatch):
    import socket
    monkeypatch.setattr(socket, 'getaddrinfo', lambda *a, **k: [(socket.AF_INET, None, None, '', ('10.0.0.5', 443))])
    with pytest.raises(ValueError):
        validate_outbound_url('https://rebind.example.com')

def test_validate_outbound_url_rejects_dns_resolution_failure(monkeypatch):
    import socket
    def _raise(*a, **k):
        raise socket.gaierror('no such host')
    monkeypatch.setattr(socket, 'getaddrinfo', _raise)
    with pytest.raises(ValueError):
        validate_outbound_url('https://does-not-resolve.example.com')

def test_validate_outbound_url_normalizes_trailing_dot_and_lowercases(monkeypatch):
    import socket
    monkeypatch.setattr(socket, 'getaddrinfo', lambda *a, **k: [(socket.AF_INET, None, None, '', ('93.184.216.34', 443))])
    result = validate_outbound_url('https://GOOD.COM./path', allowed_hosts={'good.com'})
    assert result.startswith('https://good.com')


# --- validate_upload --------------------------------------------------

def test_validate_upload_accepts_normal_image():
    assert validate_upload(filename='photo.jpg', content_type='image/jpeg', size_bytes=1024, magic=b'\xff\xd8\xff') is True

def test_validate_upload_rejects_zero_or_negative_size():
    with pytest.raises(ValueError):
        validate_upload(filename='a.jpg', content_type='image/jpeg', size_bytes=0, magic=b'\xff\xd8')

def test_validate_upload_rejects_oversized_file():
    with pytest.raises(ValueError):
        validate_upload(filename='a.jpg', content_type='image/jpeg', size_bytes=11 * 1024 * 1024, magic=b'\xff\xd8')

@pytest.mark.parametrize('ext', ['svg', 'html', 'htm', 'js', 'mjs', 'php', 'exe', 'dll'])
def test_validate_upload_rejects_executable_extensions(ext):
    with pytest.raises(ValueError):
        validate_upload(filename=f'file.{ext}', content_type='application/octet-stream', size_bytes=100, magic=b'\x00')

@pytest.mark.parametrize('ct', ['text/html', 'image/svg+xml', 'application/javascript', 'text/javascript'])
def test_validate_upload_rejects_active_content_types(ct):
    with pytest.raises(ValueError):
        validate_upload(filename='file.dat', content_type=ct, size_bytes=100, magic=b'\x00')

def test_validate_upload_rejects_zip_magic_bytes():
    with pytest.raises(ValueError):
        validate_upload(filename='file.dat', content_type='application/octet-stream', size_bytes=100, magic=b'PK\x03\x04')

def test_validate_upload_rejects_windows_executable_magic():
    with pytest.raises(ValueError):
        validate_upload(filename='file.dat', content_type='application/octet-stream', size_bytes=100, magic=b'MZ\x90\x00')

def test_validate_upload_rejects_elf_executable_magic():
    with pytest.raises(ValueError):
        validate_upload(filename='file.dat', content_type='application/octet-stream', size_bytes=100, magic=b'\x7fELF')

def test_validate_upload_rejects_xml_svg_combo():
    with pytest.raises(ValueError):
        validate_upload(filename='a.svg', content_type='image/whatever', size_bytes=100, magic=b'<?xml')


# --- hostname normalization / DNS verification ---------------------------

def test_normalize_hostname_lowercases_and_strips_trailing_dot():
    assert normalize_hostname('Example.COM.') == 'example.com'

def test_normalize_hostname_rejects_double_dot():
    with pytest.raises(ValueError):
        normalize_hostname('example..com')

def test_normalize_hostname_rejects_leading_dot():
    with pytest.raises(ValueError):
        normalize_hostname('.example.com')

def test_normalize_hostname_rejects_invalid_characters():
    with pytest.raises(ValueError):
        normalize_hostname('exa mple.com!')

def test_normalize_hostname_rejects_overlong_hostname():
    with pytest.raises(ValueError):
        normalize_hostname('a' * 254 + '.com')

def test_verification_txt_name_uses_expected_prefix_format():
    assert verification_txt_name('example.com') == '_unified-commerce-verify.example.com'

def test_verification_txt_name_accepts_custom_prefix():
    assert verification_txt_name('example.com', prefix='_custom') == '_custom.example.com'

def test_hmac_compare_matches_equal_values_ignoring_surrounding_whitespace():
    assert hmac_compare(' token123 ', 'token123') is True

def test_hmac_compare_rejects_different_values():
    assert hmac_compare('token123', 'token124') is False
