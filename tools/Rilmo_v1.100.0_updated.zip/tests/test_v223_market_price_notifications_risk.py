def _merchant(client, email):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'M'}).json()
    return m['tenant']['id'], {'Authorization': 'Bearer ' + m['access_token']}


# --- market price ------------------------------------------------------

def test_set_market_price_creates_new_entry(client):
    tid, h = _merchant(client, 'marketprice-create@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'mp-item', 'title': 'MP Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'MP-1', 'price_amount_minor': 1000, 'currency': 'USD'}).json()
    market = client.post(f'/v1/markets?tenant_id={tid}', headers=h, json={'code': 'de', 'name': 'Germany', 'country_code': 'de', 'currency': 'eur', 'locale': 'de-DE'}).json()
    r = client.post(f"/v1/markets/{market['id']}/prices?tenant_id={tid}", headers=h, json={'variant_id': v['id'], 'amount_minor': 1500, 'currency': 'EUR'})
    assert r.status_code == 200, r.text
    assert r.json()['market'] == 'DE'
    assert r.json()['amount_minor'] == 1500

def test_set_market_price_updates_existing_entry(client):
    tid, h = _merchant(client, 'marketprice-update@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'mp-item2', 'title': 'MP Item 2', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'MP-2', 'price_amount_minor': 1000, 'currency': 'USD'}).json()
    market = client.post(f'/v1/markets?tenant_id={tid}', headers=h, json={'code': 'gb', 'name': 'UK', 'country_code': 'gb', 'currency': 'gbp', 'locale': 'en-GB'}).json()
    client.post(f"/v1/markets/{market['id']}/prices?tenant_id={tid}", headers=h, json={'variant_id': v['id'], 'amount_minor': 1200, 'currency': 'GBP'})
    r2 = client.post(f"/v1/markets/{market['id']}/prices?tenant_id={tid}", headers=h, json={'variant_id': v['id'], 'amount_minor': 1800, 'currency': 'GBP'})
    assert r2.status_code == 200
    assert r2.json()['amount_minor'] == 1800

def test_set_market_price_missing_market_returns_not_found(client):
    tid, h = _merchant(client, 'marketprice-missing@example.com')
    r = client.post(f'/v1/markets/does-not-exist/prices?tenant_id={tid}', headers=h, json={'variant_id': 'x', 'amount_minor': 1000, 'currency': 'USD'})
    assert r.status_code == 404

def test_set_market_price_rejects_currency_mismatch(client):
    tid, h = _merchant(client, 'marketprice-badcurrency@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'mp-item3', 'title': 'MP Item 3', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'MP-3', 'price_amount_minor': 1000, 'currency': 'USD'}).json()
    market = client.post(f'/v1/markets?tenant_id={tid}', headers=h, json={'code': 'fr', 'name': 'France', 'country_code': 'fr', 'currency': 'eur', 'locale': 'fr-FR'}).json()
    r = client.post(f"/v1/markets/{market['id']}/prices?tenant_id={tid}", headers=h, json={'variant_id': v['id'], 'amount_minor': 1000, 'currency': 'USD'})
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'MARKET_CURRENCY_MISMATCH'


# --- notification templates --------------------------------------------

def test_create_notification_template_succeeds(client):
    tid, h = _merchant(client, 'notiftemplate-create@example.com')
    r = client.post(f'/v1/notification-templates?tenant_id={tid}', headers=h, json={
        'code': 'order_confirmed', 'channel': 'email', 'locale': 'en', 'subject': 'Order confirmed', 'body': 'Thanks!',
    })
    assert r.status_code == 200, r.text
    assert r.json()['code'] == 'order_confirmed'

def test_create_notification_template_rejects_unsupported_channel(client):
    tid, h = _merchant(client, 'notiftemplate-badchannel@example.com')
    r = client.post(f'/v1/notification-templates?tenant_id={tid}', headers=h, json={
        'code': 'x', 'channel': 'carrier_pigeon', 'locale': 'en', 'body': 'x',
    })
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'NOTIFICATION_CHANNEL_UNSUPPORTED'

def test_list_notification_templates_returns_created_items(client):
    tid, h = _merchant(client, 'notiftemplate-list@example.com')
    client.post(f'/v1/notification-templates?tenant_id={tid}', headers=h, json={
        'code': 'welcome', 'channel': 'sms', 'locale': 'en', 'body': 'Welcome!',
    })
    r = client.get(f'/v1/notification-templates?tenant_id={tid}', headers=h)
    assert r.status_code == 200
    codes = {t['code'] for t in r.json()['items']}
    assert 'welcome' in codes


# --- send notification --------------------------------------------------

def test_send_email_notification_succeeds(client):
    tid, h = _merchant(client, 'notifsend-email@example.com')
    r = client.post(f'/v1/notifications/send?tenant_id={tid}', headers=h, json={
        'channel': 'email', 'recipient': 'someone@example.com', 'payload': {'x': 1}, 'idempotency_key': 'notif-key-001',
    })
    assert r.status_code == 200, r.text
    assert r.json()['status'] == 'QUEUED'

def test_send_notification_is_idempotent(client):
    tid, h = _merchant(client, 'notifsend-idem@example.com')
    payload = {'channel': 'email', 'recipient': 'someone@example.com', 'payload': {}, 'idempotency_key': 'notif-key-002'}
    first = client.post(f'/v1/notifications/send?tenant_id={tid}', headers=h, json=payload)
    second = client.post(f'/v1/notifications/send?tenant_id={tid}', headers=h, json=payload)
    assert first.status_code == 200
    assert second.status_code == 200
    assert first.json()['id'] == second.json()['id']

def test_send_notification_missing_template_returns_not_found(client):
    tid, h = _merchant(client, 'notifsend-missingtemplate@example.com')
    r = client.post(f'/v1/notifications/send?tenant_id={tid}', headers=h, json={
        'channel': 'email', 'recipient': 'someone@example.com', 'template_id': 'does-not-exist',
        'payload': {}, 'idempotency_key': 'notif-key-003',
    })
    assert r.status_code == 404

def test_send_notification_uses_valid_template(client):
    tid, h = _merchant(client, 'notifsend-withtemplate@example.com')
    tmpl = client.post(f'/v1/notification-templates?tenant_id={tid}', headers=h, json={
        'code': 'shipped', 'channel': 'email', 'locale': 'en', 'body': 'Your order shipped',
    }).json()
    r = client.post(f'/v1/notifications/send?tenant_id={tid}', headers=h, json={
        'channel': 'email', 'recipient': 'someone@example.com', 'template_id': tmpl['id'],
        'payload': {}, 'idempotency_key': 'notif-key-004',
    })
    assert r.status_code == 200, r.text
    assert r.json()['template_id'] == tmpl['id']

def test_send_sms_notification_rejects_when_no_entitlement_exists(client):
    tid, h = _merchant(client, 'notifsend-smsquota@example.com')
    r = client.post(f'/v1/notifications/send?tenant_id={tid}', headers=h, json={
        'channel': 'sms', 'recipient': '+15551234567', 'payload': {}, 'idempotency_key': 'notif-key-sms-001',
    })
    assert r.status_code == 402
    assert r.json()['detail']['error']['code'] == 'PLAN_FEATURE_REQUIRED'

def test_send_sms_notification_succeeds_when_entitlement_grants_quota(client):
    from app.core.database import SessionLocal
    from app.models.domain import Entitlement
    tid, h = _merchant(client, 'notifsend-smsquota-ok@example.com')
    db = SessionLocal()
    db.add(Entitlement(tenant_id=tid, feature_key='sms_monthly', value_type='integer', value_integer=100, version=1))
    db.commit()
    db.close()
    r = client.post(f'/v1/notifications/send?tenant_id={tid}', headers=h, json={
        'channel': 'sms', 'recipient': '+15551234567', 'payload': {}, 'idempotency_key': 'notif-key-sms-002',
    })
    assert r.status_code == 200, r.text

def test_send_sms_notification_rejects_when_monthly_quota_exhausted(client):
    from app.core.database import SessionLocal
    from app.models.domain import Entitlement, NotificationDelivery
    from datetime import datetime, timezone
    import uuid
    tid, h = _merchant(client, 'notifsend-smsquota-exhausted@example.com')
    db = SessionLocal()
    db.add(Entitlement(tenant_id=tid, feature_key='sms_monthly', value_type='integer', value_integer=1, version=1))
    db.add(NotificationDelivery(tenant_id=tid, channel='sms', recipient='+15550000000', status='SENT',
        idempotency_key=uuid.uuid4().hex, payload={}, created_at=datetime.now(timezone.utc)))
    db.commit()
    db.close()
    r = client.post(f'/v1/notifications/send?tenant_id={tid}', headers=h, json={
        'channel': 'sms', 'recipient': '+15551234567', 'payload': {}, 'idempotency_key': 'notif-key-sms-003',
    })
    assert r.status_code == 402
    assert r.json()['detail']['error']['code'] == 'PLAN_LIMIT_REACHED'


# --- order risk ---------------------------------------------------------

def test_get_order_risk_missing_returns_not_found(client):
    tid, h = _merchant(client, 'risk-missing@example.com')
    r = client.get(f'/v1/risk/orders/does-not-exist?tenant_id={tid}', headers=h)
    assert r.status_code == 404

def test_get_order_risk_returns_assessment_when_present(client):
    from app.core.database import SessionLocal
    from app.models.domain import RiskAssessment
    tid, h = _merchant(client, 'risk-present@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'risk-item', 'title': 'Risk Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'RISK-1', 'price_amount_minor': 1000, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    cart = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': cart['id']}).json()

    db = SessionLocal()
    row = RiskAssessment(tenant_id=tid, order_id=order['id'], score=42, decision='REVIEW', reasons=['ip_mismatch'])
    db.add(row)
    db.commit()
    db.close()
    r = client.get(f"/v1/risk/orders/{order['id']}?tenant_id={tid}", headers=h)
    assert r.status_code == 200
    assert r.json()['score'] == 42
    assert r.json()['decision'] == 'REVIEW'
