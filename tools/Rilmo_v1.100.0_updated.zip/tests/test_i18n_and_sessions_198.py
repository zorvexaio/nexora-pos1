from pathlib import Path
import re, json

def _locale_keys():
    s = Path('app/frontend/app.js').read_text()
    langs = ['ar', 'en', 'tr', 'fr', 'de', 'es', 'pt', 'it', 'ru', 'zh', 'ja', 'ko', 'hi']
    out = {}
    for lang in langs:
        m = re.search('\\b' + lang + ':\\{(.*?)\\}(?:,|\\);)', s, re.S)
        assert m, f'missing locale {lang}'
        out[lang] = set(re.findall('([A-Za-z_$][\\w$]*):', m.group(1)))
    return out

def test_all_dashboard_locales_have_core_keys():
    keys = _locale_keys()
    required = {'title', 'login', 'products', 'orders', 'customers', 'inventory', 'settings', 'security', 'search', 'save', 'create', 'refresh'}
    for lang, vals in keys.items():
        assert required <= vals or lang not in {'fr', 'de', 'es', 'pt', 'it', 'ru', 'zh', 'ja', 'ko', 'hi'}
