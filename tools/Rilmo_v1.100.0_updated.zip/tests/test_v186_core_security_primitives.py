import time
from datetime import datetime, timedelta, timezone

from app.core.security import (
    hash_password, verify_password, random_token, token_hash, hmac_sha256,
    create_platform_jwt, decode_platform_jwt,
    encrypt_secret, decrypt_secret,
    totp_secret, totp_code, verify_totp,
    verify_timestamped_signature,
)


# --- password hashing --------------------------------------------------

def test_password_hash_roundtrip_and_wrong_password_rejected():
    hashed = hash_password('CorrectHorseBattery1!')
    assert hashed != 'CorrectHorseBattery1!'
    assert verify_password('CorrectHorseBattery1!', hashed) is True
    assert verify_password('WrongPassword', hashed) is False


# --- basic token helpers -------------------------------------------------

def test_random_token_is_unique_and_urlsafe():
    a = random_token()
    b = random_token()
    assert a != b
    assert len(a) > 20

def test_token_hash_is_deterministic_sha256():
    assert token_hash('abc') == token_hash('abc')
    assert token_hash('abc') != token_hash('abd')

def test_hmac_sha256_changes_with_secret():
    sig1 = hmac_sha256(b'payload', 'secret-one')
    sig2 = hmac_sha256(b'payload', 'secret-two')
    assert sig1 != sig2
    assert hmac_sha256(b'payload', 'secret-one') == sig1


# --- platform JWT ---------------------------------------------------------

def test_platform_jwt_roundtrip():
    token = create_platform_jwt('user-123')
    payload = decode_platform_jwt(token)
    assert payload is not None
    assert payload['sub'] == 'user-123'
    assert payload['scope'] == 'platform'

def test_platform_jwt_rejects_tampered_payload():
    token = create_platform_jwt('user-123')
    head, body, sig = token.split('.')
    tampered = head + '.' + body[:-1] + ('A' if body[-1] != 'A' else 'B') + '.' + sig
    assert decode_platform_jwt(tampered) is None

def test_platform_jwt_rejects_wrong_number_of_segments():
    assert decode_platform_jwt('only.two') is None
    assert decode_platform_jwt('') is None

def test_platform_jwt_rejects_garbage_input():
    assert decode_platform_jwt('not-a-real-token') is None
    assert decode_platform_jwt('a.b.c') is None

def test_platform_jwt_rejects_expired_token(monkeypatch):
    import app.core.security as sec
    real_datetime = sec.datetime

    class FrozenPast(real_datetime):
        @classmethod
        def now(cls, tz=None):
            return real_datetime(2020, 1, 1, tzinfo=timezone.utc)

    monkeypatch.setattr(sec, 'datetime', FrozenPast)
    token = create_platform_jwt('user-expired')
    monkeypatch.setattr(sec, 'datetime', real_datetime)
    assert decode_platform_jwt(token) is None


# --- secret encryption -----------------------------------------------------

def test_encrypt_decrypt_secret_roundtrip():
    ciphertext = encrypt_secret('super-secret-credentials')
    assert ciphertext != 'super-secret-credentials'
    assert decrypt_secret(ciphertext) == 'super-secret-credentials'

def test_encrypt_secret_is_not_deterministic_but_decrypts_consistently():
    c1 = encrypt_secret('same-value')
    c2 = encrypt_secret('same-value')
    assert c1 != c2  # Fernet includes random IV/timestamp
    assert decrypt_secret(c1) == decrypt_secret(c2) == 'same-value'


# --- TOTP ------------------------------------------------------------------

def test_totp_secret_generates_valid_base32():
    import base64
    secret = totp_secret()
    padded = secret + '=' * ((8 - len(secret) % 8) % 8)
    base64.b32decode(padded, casefold=True)  # raises if invalid

def test_totp_code_is_six_digits_and_stable_within_window():
    secret = totp_secret()
    counter = int(time.time()) // 30
    code_a = totp_code(secret, counter)
    code_b = totp_code(secret, counter)
    assert code_a == code_b
    assert len(code_a) == 6
    assert code_a.isdigit()

def test_verify_totp_accepts_current_code():
    secret = totp_secret()
    code = totp_code(secret)
    assert verify_totp(secret, code) is True

def test_verify_totp_rejects_wrong_code():
    secret = totp_secret()
    assert verify_totp(secret, '000000') is False or totp_code(secret) == '000000'
    other_secret = totp_secret()
    assert verify_totp(secret, totp_code(other_secret)) is False

def test_verify_totp_rejects_malformed_input():
    secret = totp_secret()
    assert verify_totp(secret, 'abcdef') is False
    assert verify_totp(secret, '12345') is False
    assert verify_totp(secret, '1234567') is False

def test_verify_totp_accepts_adjacent_window_code():
    secret = totp_secret()
    counter = int(time.time()) // 30
    previous_code = totp_code(secret, counter - 1)
    assert verify_totp(secret, previous_code, window=1) is True

def test_verify_totp_rejects_code_outside_window():
    secret = totp_secret()
    counter = int(time.time()) // 30
    far_code = totp_code(secret, counter - 5)
    assert verify_totp(secret, far_code, window=1) is False


# --- webhook timestamped signature verification -----------------------------

def test_verify_timestamped_signature_accepts_valid_signature():
    secret = 'webhook-secret'
    body = b'{"event":"payment.succeeded"}'
    ts = str(int(datetime.now(timezone.utc).timestamp()))
    sig = hmac_sha256(f'{ts}.'.encode() + body, secret)
    assert verify_timestamped_signature(body, sig, secret, ts) is True

def test_verify_timestamped_signature_rejects_wrong_secret():
    body = b'{"event":"payment.succeeded"}'
    ts = str(int(datetime.now(timezone.utc).timestamp()))
    sig = hmac_sha256(f'{ts}.'.encode() + body, 'right-secret')
    assert verify_timestamped_signature(body, sig, 'wrong-secret', ts) is False

def test_verify_timestamped_signature_rejects_tampered_body():
    secret = 'webhook-secret'
    ts = str(int(datetime.now(timezone.utc).timestamp()))
    sig = hmac_sha256(f'{ts}.'.encode() + b'original-body', secret)
    assert verify_timestamped_signature(b'tampered-body', sig, secret, ts) is False

def test_verify_timestamped_signature_rejects_stale_timestamp():
    secret = 'webhook-secret'
    body = b'{"event":"payment.succeeded"}'
    old_ts = str(int((datetime.now(timezone.utc) - timedelta(seconds=600)).timestamp()))
    sig = hmac_sha256(f'{old_ts}.'.encode() + body, secret)
    assert verify_timestamped_signature(body, sig, secret, old_ts, tolerance_seconds=300) is False

def test_verify_timestamped_signature_rejects_non_numeric_timestamp():
    secret = 'webhook-secret'
    body = b'payload'
    sig = hmac_sha256(b'not-a-timestamp.' + body, secret)
    assert verify_timestamped_signature(body, sig, secret, 'not-a-timestamp') is False

def test_verify_timestamped_signature_accepts_within_custom_tolerance():
    secret = 'webhook-secret'
    body = b'payload'
    ts = str(int((datetime.now(timezone.utc) - timedelta(seconds=100)).timestamp()))
    sig = hmac_sha256(f'{ts}.'.encode() + body, secret)
    assert verify_timestamped_signature(body, sig, secret, ts, tolerance_seconds=120) is True
