from app.core.database import SessionLocal
from app.models.domain import Entitlement, Product


def register(client, email):
    r = client.post('/v1/auth/register', json={
        'email': email,
        'password': 'VerySecurePassword123!',
        'display_name': 'Entitlement Test',
    })
    assert r.status_code == 200, r.text
    return r.json()


def grant(tenant_id, feature_key, *, integer=None, boolean=None):
    db = SessionLocal()
    try:
        db.add(Entitlement(
            tenant_id=tenant_id,
            feature_key=feature_key,
            value_type='integer' if integer is not None else 'boolean',
            value_integer=integer,
            value_boolean=boolean,
            version=1,
        ))
        db.commit()
    finally:
        db.close()


def make_product(tenant_id, slug='entitlement-widget'):
    db = SessionLocal()
    try:
        p = Product(tenant_id=tenant_id, slug=slug, title='Entitlement Widget', status='PUBLISHED')
        db.add(p)
        db.commit()
        return p.id
    finally:
        db.close()


def test_product_translation_enforces_max_languages(client):
    x = register(client, 'max-language-v1968@example.com')
    tid = x['tenant']['id']
    grant(tid, 'max_languages', integer=1)
    pid = make_product(tid, 'max-language-widget')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    first = client.put(f'/v1/products/{pid}/translations/ar', params={'tenant_id': tid}, headers=h,
                       json={'name': 'عربي'})
    assert first.status_code == 200, first.text
    second = client.put(f'/v1/products/{pid}/translations/tr', params={'tenant_id': tid}, headers=h,
                        json={'name': 'Türkçe'})
    assert second.status_code == 402
    assert second.json()['detail']['error']['code'] == 'PLAN_LIMIT_REACHED'


def test_sales_analytics_requires_advanced_analytics_entitlement(client):
    x = register(client, 'analytics-entitlement-v1968@example.com')
    tid = x['tenant']['id']
    h = {'Authorization': 'Bearer ' + x['access_token']}
    r = client.get('/v1/analytics/sales', params={'tenant_id': tid}, headers=h)
    assert r.status_code == 402
    assert r.json()['detail']['error']['code'] == 'PLAN_FEATURE_REQUIRED'


def test_sales_analytics_allows_scale_entitlement(client):
    x = register(client, 'analytics-allowed-v1968@example.com')
    tid = x['tenant']['id']
    grant(tid, 'advanced_analytics', boolean=True)
    h = {'Authorization': 'Bearer ' + x['access_token']}
    r = client.get('/v1/analytics/sales', params={'tenant_id': tid}, headers=h)
    assert r.status_code == 200, r.text
