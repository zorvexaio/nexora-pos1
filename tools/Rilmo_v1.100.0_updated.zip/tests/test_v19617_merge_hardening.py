
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_release_version_and_payment_user_agents_are_current():
    version = (ROOT / "VERSION").read_text().strip()
    from app.core.config import get_settings
    assert get_settings().APP_VERSION == version
    text = (ROOT / "app/services/payment_providers.py").read_text()
    # User-agent is derived dynamically from APP_VERSION; assert the derivation
    # sites are present and no stale hardcoded literal version has crept back in.
    assert "'UnifiedGlobalCommerce/' + get_settings().APP_VERSION" in text
    assert "'UnifiedGlobalCommerce/' + s.APP_VERSION" in text
    import re
    assert not re.search(r"UnifiedGlobalCommerce/\d+\.\d+(\.\d+)?", text)


def test_shipping_endpoint_paths_reject_dot_segments_and_query_data():
    text = (ROOT / "app/services/shipping.py").read_text()
    assert "dot-segments" in text
    assert "parsed.query or parsed.fragment" in text
    assert "seg in {'.', '..'}" in text


def test_inventory_adjustment_is_location_aware_and_preserves_available_invariant():
    # moved to inventory_routes.py in Phase 3 split
    text = (ROOT / "app/routes/inventory_routes.py").read_text()
    assert "location_id: str | None = None" in text
    assert "INVENTORY_LOCATION_REQUIRED" in text
    assert "item.available + delta < 0" in text
    assert "'location_id': location_id" in text


def test_inventory_database_model_enforces_nonnegative_available():
    text = (ROOT / "app/models/domain.py").read_text()
    assert "CheckConstraint('available>=0')" in text
    migration = (ROOT / "alembic/versions/20260825_0067_inventory_available_invariant.py").read_text()
    assert "available >= 0" in migration
    assert 'revision = "20260825_0067"' in migration


def test_paytr_failure_callback_cannot_downgrade_terminal_payment():
    text = (ROOT / "app/routes/webhook_routes.py").read_text()  # paytr webhook moved here in Phase 3 split
    marker = "Provider callbacks can arrive late or out of order."
    assert marker in text
    start = text.index(marker)
    block = text[start:start+900]
    assert "CAPTURED" in block
    assert "PARTIALLY_CAPTURED" in block
    assert "REFUNDED" in block
    assert "VOIDED" in block


def test_pos_open_session_db_invariant_remains_present():
    text = (ROOT / "alembic/versions/20260823_0066_pos_session_open_uniqueness.py").read_text()
    assert "uq_pos_session_open_register" in text
    assert "status = 'OPEN'" in text
