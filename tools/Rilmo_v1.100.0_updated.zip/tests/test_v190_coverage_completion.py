from app.core.database import SessionLocal
from app.models.domain import MerchantProfile

def test_register_with_merchant_profile_fields_does_not_reference_undefined_email(client):
    r = client.post("/v1/auth/register", json={
        "email": "profile-fields@example.com",
        "password": "VerySecurePassword123!",
        "display_name": "Profile Merchant",
        "legal_name": "Profile Merchant LLC",
        "country_code": "tr",
        "city": "Istanbul",
        "address_line1": "Main Street 1",
        "phone": "+905551112233",
    })
    assert r.status_code == 200, r.text
    tid = r.json()["tenant"]["id"]
    db = SessionLocal()
    try:
        profile = db.query(MerchantProfile).filter_by(tenant_id=tid).first()
        assert profile is not None
        assert profile.legal_name == "Profile Merchant LLC"
        assert profile.country_code == "TR"
        assert profile.city == "Istanbul"
    finally:
        db.close()

import base64, hashlib, hmac, json
from app.core.security import encrypt_secret
from app.models.domain import PaymentIntent, MerchantPaymentAccount
from app.services.core import bind_provider_tenant


def _register(client, email):
    r = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'})
    assert r.status_code == 200, r.text
    return r.json()


def test_iyzico_signed_success_cannot_capture_wrong_amount(client):
    account = _register(client, 'iyzico-mismatch@example.com')
    tid = account['tenant']['id']
    db = SessionLocal()
    try:
        db.add(MerchantPaymentAccount(
            tenant_id=tid, provider='iyzico', status='ACTIVE', charges_enabled=True,
            payouts_enabled=True,
            credentials_encrypted=encrypt_secret(json.dumps({'secret_key': 'unit-secret'})),
        ))
        pi = PaymentIntent(
            tenant_id=tid, provider='iyzico', provider_payment_id='iyz-pid-1',
            amount_minor=1000, currency='TRY', status='PENDING',
        )
        db.add(pi); db.commit(); bind_provider_tenant(db, provider=pi.provider, external_id=pi.provider_payment_id, tenant_id=tid); db.commit()
    finally:
        db.close()
    body = {
        'iyziEventType': 'PAYMENT_API', 'paymentId': 'iyz-pid-1',
        'paymentConversationId': 'iyz-pid-1', 'status': 'SUCCESS',
        'paidPrice': '20.00', 'currency': 'TRY',
    }
    sig = hmac.new(b'unit-secret', b'unit-secretPAYMENT_APIiyz-pid-1iyz-pid-1SUCCESS', hashlib.sha256).hexdigest()
    r = client.post('/v1/webhooks/iyzico', json=body, headers={'X-IYZ-SIGNATURE-V3': sig})
    assert r.status_code == 409
    db = SessionLocal()
    try:
        row = db.query(PaymentIntent).filter_by(id=pi.id).one()
        assert row.status == 'PENDING'
    finally:
        db.close()


def test_paytr_signed_success_cannot_capture_wrong_amount(client):
    account = _register(client, 'paytr-mismatch@example.com')
    tid = account['tenant']['id']
    db = SessionLocal()
    try:
        db.add(MerchantPaymentAccount(
            tenant_id=tid, provider='paytr', status='ACTIVE', charges_enabled=True,
            payouts_enabled=True,
            credentials_encrypted=encrypt_secret(json.dumps({
                'merchant_id': 'mid', 'merchant_key': 'key', 'merchant_salt': 'salt'
            })),
        ))
        pi = PaymentIntent(
            tenant_id=tid, provider='paytr', provider_payment_id='paytr-oid-1',
            amount_minor=1000, currency='TRY', status='PENDING',
        )
        db.add(pi); db.commit(); bind_provider_tenant(db, provider=pi.provider, external_id=pi.provider_payment_id, tenant_id=tid); db.commit()
    finally:
        db.close()
    status, total = 'success', '20.00'
    raw = b'paytr-oid-1' + b'salt' + status.encode() + total.encode()
    digest = base64.b64encode(hmac.new(b'key', raw, hashlib.sha256).digest()).decode()
    r = client.post('/v1/webhooks/paytr', data={
        'merchant_oid': 'paytr-oid-1', 'status': status, 'total_amount': total, 'hash': digest,
    })
    assert r.status_code == 409
    db = SessionLocal()
    try:
        row = db.query(PaymentIntent).filter_by(id=pi.id).one()
        assert row.status == 'PENDING'
    finally:
        db.close()


def test_iyzico_signed_success_materializes_capture_and_ledger(client):
    account = _register(client, 'iyzico-success@example.com')
    tid = account['tenant']['id']
    db = SessionLocal()
    try:
        db.add(MerchantPaymentAccount(
            tenant_id=tid, provider='iyzico', status='ACTIVE', charges_enabled=True,
            payouts_enabled=True,
            credentials_encrypted=encrypt_secret(json.dumps({'secret_key': 'unit-secret'})),
        ))
        pi = PaymentIntent(
            tenant_id=tid, provider='iyzico', provider_payment_id='iyz-pid-success',
            amount_minor=1000, currency='TRY', status='PENDING',
        )
        db.add(pi); db.commit(); pi_id = pi.id; bind_provider_tenant(db, provider=pi.provider, external_id=pi.provider_payment_id, tenant_id=tid); db.commit()
    finally:
        db.close()
    body = {
        'iyziEventType': 'PAYMENT_API', 'paymentId': 'iyz-pid-success',
        'paymentConversationId': 'iyz-pid-success', 'status': 'SUCCESS',
        'paidPrice': '10.00', 'currency': 'TRY',
    }
    sig = hmac.new(b'unit-secret', b'unit-secretPAYMENT_APIiyz-pid-successiyz-pid-successSUCCESS', hashlib.sha256).hexdigest()
    r = client.post('/v1/webhooks/iyzico', json=body, headers={'X-IYZ-SIGNATURE-V3': sig})
    assert r.status_code == 200, r.text
    from app.models.domain import PaymentCapture, JournalEntry, JournalLine
    db = SessionLocal()
    try:
        row = db.query(PaymentIntent).filter_by(id=pi_id).one()
        assert row.status == 'CAPTURED'
        caps = db.query(PaymentCapture).filter_by(payment_intent_id=pi_id).all()
        assert len(caps) == 1 and caps[0].amount_minor == 1000
        je = db.query(JournalEntry).filter_by(tenant_id=tid, reference_type='merchant_sale', reference_id=pi_id).one()
        lines = db.query(JournalLine).filter_by(journal_entry_id=je.id).all()
        assert sum(x.debit_minor for x in lines) == sum(x.credit_minor for x in lines) == 1000
    finally:
        db.close()


def test_paytr_signed_success_materializes_capture_and_ledger(client):
    account = _register(client, 'paytr-success@example.com')
    tid = account['tenant']['id']
    db = SessionLocal()
    try:
        db.add(MerchantPaymentAccount(
            tenant_id=tid, provider='paytr', status='ACTIVE', charges_enabled=True,
            payouts_enabled=True,
            credentials_encrypted=encrypt_secret(json.dumps({
                'merchant_id': 'mid', 'merchant_key': 'key', 'merchant_salt': 'salt'
            })),
        ))
        pi = PaymentIntent(
            tenant_id=tid, provider='paytr', provider_payment_id='paytr-oid-success',
            amount_minor=1000, currency='TRY', status='PENDING',
        )
        db.add(pi); db.commit(); pi_id = pi.id; bind_provider_tenant(db, provider=pi.provider, external_id=pi.provider_payment_id, tenant_id=tid); db.commit()
    finally:
        db.close()
    status, total = 'success', '10.00'
    raw = b'paytr-oid-success' + b'salt' + status.encode() + total.encode()
    digest = base64.b64encode(hmac.new(b'key', raw, hashlib.sha256).digest()).decode()
    r = client.post('/v1/webhooks/paytr', data={
        'merchant_oid': 'paytr-oid-success', 'status': status, 'total_amount': total, 'hash': digest,
    })
    assert r.status_code == 200, r.text
    from app.models.domain import PaymentCapture, JournalEntry, JournalLine
    db = SessionLocal()
    try:
        row = db.query(PaymentIntent).filter_by(id=pi_id).one()
        assert row.status == 'CAPTURED'
        caps = db.query(PaymentCapture).filter_by(payment_intent_id=pi_id).all()
        assert len(caps) == 1 and caps[0].amount_minor == 1000
        je = db.query(JournalEntry).filter_by(tenant_id=tid, reference_type='merchant_sale', reference_id=pi_id).one()
        lines = db.query(JournalLine).filter_by(journal_entry_id=je.id).all()
        assert sum(x.debit_minor for x in lines) == sum(x.credit_minor for x in lines) == 1000
    finally:
        db.close()
