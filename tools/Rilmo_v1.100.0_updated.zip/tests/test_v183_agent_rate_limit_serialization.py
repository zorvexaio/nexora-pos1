from pathlib import Path


def test_agent_authorization_locks_profile_before_rate_limit_count():
    src = Path('app/services/global_control_plane.py').read_text(encoding='utf-8')
    assert ".filter_by(tenant_id=tenant_id, client_id=agent_client_id, status='ACTIVE')\n        .with_for_update()" in src


def test_agent_idempotency_is_resolved_before_rate_limit():
    src = Path('app/services/global_control_plane.py').read_text(encoding='utf-8')
    existing = "existing = db.query(AgentActionAudit).filter_by(tenant_id=tenant_id, agent_profile_id=profile.id, idempotency_key=idempotency_key).first()"
    assert src.index(existing) < src.index("minute_floor = datetime.now(timezone.utc).replace(second=0, microsecond=0)")
