from pathlib import Path
from datetime import datetime, timezone, timedelta
from app.core.database import SessionLocal
from app.services.privacy import create_privacy_access_grant, open_privacy_incident
from app.models.domain import User, Tenant, TenantMembership, MerchantProfile, MerchantIdentityVerification, MerchantReviewCase, PlatformAdmin
from app.routes import v1


def test_privacy_models_are_present_and_raw_document_fields_are_absent():
    names = set(v1.SENSITIVE_FIELDS)
    assert 'provider_metadata' in names
    assert 'provider_access_reference' in names
    assert not any(name in {'passport_image','id_document','selfie_image','biometric_template','raw_document_url'} for name in names)


def test_privacy_access_grant_is_case_bound_and_time_limited():
    db = SessionLocal()
    try:
        u=User(email='compliance@example.com',password_hash='x')
        db.add(u); db.flush()
        t=Tenant(slug='privacy-test-zz',name='Privacy Test')
        db.add(t); db.flush()
        db.add(TenantMembership(tenant_id=t.id,user_id=u.id,role='owner'))
        mp=MerchantProfile(tenant_id=t.id,legal_name='Merchant',phone='x',country_code='TR',city='Istanbul',address_line1='x',identity_status='VERIFIED',kyc_status='VERIFIED')
        db.add(mp); db.flush()
        v=MerchantIdentityVerification(tenant_id=t.id,user_id=u.id,provider='veriff',external_id='ver_x',status='COMPLETED')
        db.add(v); db.flush()
        c=MerchantReviewCase(tenant_id=t.id,verification_id=v.id,open_reason='REGULATORY_REVIEW',status='OPEN',priority='HIGH')
        db.add(c); db.flush()
        row=create_privacy_access_grant(db,tenant_id=t.id,verification_id=v.id,case_id=c.id,requester_user_id=u.id,purpose='Regulatory review',ticket_ref='CASE-10482',provider_access_reference='veriff:case:10482',ip='203.0.113.3',ttl_minutes=15)
        assert row.expires_at > row.granted_at
        assert row.expires_at <= row.granted_at + timedelta(minutes=15)
        assert row.ip_hash != '203.0.113.3'
    finally:
        db.rollback(); db.close()


def test_tr_incident_has_jurisdiction_specific_72h_deadline():
    db=SessionLocal()
    try:
        row=open_privacy_incident(db,jurisdiction='TR-KVKK',severity='HIGH',data_categories=['identity'],affected_subjects_estimate=2)
        delta=row.authority_due_at-row.detected_at
        assert 71.9 <= delta.total_seconds()/3600 <= 72.1
    finally:
        db.rollback(); db.close()


def test_privacy_page_contains_user_facing_boundary_language():
    text=Path('app/frontend/privacy.html').read_text(encoding='utf-8')
    assert '[الاسم القانوني]' in text
    assert 'لا تكون وثائق الهوية' in text
    assert 'إلغاء الوصول' in text
    assert 'طلب الحذف' in text

def test_privacy_incident_progression_and_portability_payload():
    from app.services.privacy import update_privacy_incident, privacy_export_payload, submit_privacy_request
    db=SessionLocal()
    try:
        u=User(email='export@example.com',password_hash='x',display_name='Export User')
        db.add(u); db.flush()
        inc=open_privacy_incident(db,jurisdiction='TR-KVKK')
        update_privacy_incident(db,incident_id=inc.id,actor_user_id=u.id,status='CONTAINED',containment_notes='Access isolated')
        update_privacy_incident(db,incident_id=inc.id,actor_user_id=u.id,status='NOTIFICATION_PENDING',notification_decision='PENDING')
        assert inc.status=='NOTIFICATION_PENDING'
        req=submit_privacy_request(db,tenant_id=None,user_id=u.id,customer_id=None,request_type='PORTABILITY',jurisdiction='TR-KVKK')
        req.status='READY'
        payload=privacy_export_payload(db,user_id=u.id)
        assert payload['user']['email']=='export@example.com'
        assert 'raw_document' not in str(payload).lower()
    finally:
        db.rollback(); db.close()
