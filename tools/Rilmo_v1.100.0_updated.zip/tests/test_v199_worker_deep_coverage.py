from datetime import datetime, timezone, timedelta
from types import SimpleNamespace

import pytest


class Q:
    def __init__(self, rows=None, first_value=None):
        self.rows = list(rows or [])
        self.first_value = first_value
    def filter(self, *a, **k): return self
    def filter_by(self, **k): return self
    def order_by(self, *a, **k): return self
    def limit(self, *a, **k): return self
    def with_for_update(self, *a, **k): return self
    def all(self): return self.rows
    def first(self): return self.first_value if self.first_value is not None else (self.rows[0] if self.rows else None)
    def join(self, *a, **k): return self
    def count(self): return len(self.rows)
    def update(self, values, synchronize_session=False):
        for r in self.rows:
            for k,v in values.items(): setattr(r,k,v)
        return len(self.rows)

class DB:
    def __init__(self, mapping=None):
        self.mapping = mapping or {}
        self.bind = SimpleNamespace(dialect=SimpleNamespace(name='sqlite'))
        self.info = {}
        self.commits = 0
        self.rollbacks = 0
        self.added = []
        self.deleted = []
    def query(self, cls): return self.mapping.get(cls, Q())
    def commit(self): self.commits += 1
    def rollback(self): self.rollbacks += 1
    def add(self, x): self.added.append(x)
    def delete(self, x): self.deleted.append(x)
    def flush(self): pass


def test_claim_events_marks_processing(monkeypatch):
    import app.worker as w
    ev1 = SimpleNamespace(id='a', status='PENDING', next_attempt_at=None)
    ev2 = SimpleNamespace(id='b', status='PROCESSING', next_attempt_at=datetime.now(timezone.utc)-timedelta(seconds=1))
    db=DB({w.OutboxEvent: Q([ev1,ev2])})
    assert w._claim_events(db, 10, 30, 't1') == ['a','b']
    assert ev1.status == ev2.status == 'PROCESSING'
    assert db.commits == 1


def test_release_reservation_missing_inventory_marks_failed():
    import app.worker as w
    r=SimpleNamespace(status='ACTIVE', expires_at=datetime.now(timezone.utc)-timedelta(1), inventory_item_id='i', tenant_id='t', quantity=2, order_id='o')
    db=DB({w.InventoryReservation:Q([r]), w.InventoryItem:Q([]), w.Order:Q([])})
    assert w.release_expired_reservations(db, tenant_id='t') == 0
    assert r.status == 'RELEASE_FAILED'


def test_release_reservation_releases_and_cancels_pending_order():
    import app.worker as w
    r=SimpleNamespace(status='ACTIVE', expires_at=datetime.now(timezone.utc)-timedelta(1), inventory_item_id='i', tenant_id='t', quantity=2, order_id='o')
    inv=SimpleNamespace(reserved=5, available=0, on_hand=10, committed=3, version=1)
    order=SimpleNamespace(id='o', status='PENDING_PAYMENT', payment_status='PENDING')
    db=DB({w.InventoryReservation:Q([r]), w.InventoryItem:Q([inv]), w.Order:Q([order])})
    assert w.release_expired_reservations(db, tenant_id='t') == 1
    assert r.status == 'RELEASED' and inv.reserved == 3 and inv.available == 4
    assert order.status == 'CANCELLED' and order.payment_status == 'EXPIRED'


def test_cleanup_guest_and_open_expired_cart():
    import app.worker as w
    now=datetime.now(timezone.utc)
    g=SimpleNamespace(id='g', expires_at=now-timedelta(1))
    cart=SimpleNamespace(status='OPEN', expires_at=now-timedelta(1), updated_at=None)
    db=DB({w.GuestSession:Q([g]), w.Cart:Q([cart])})
    assert w.cleanup_guest_state(db, tenant_id='t') == 1
    assert cart.status == 'EXPIRED' and g in db.deleted


def test_notification_non_email_fails(monkeypatch):
    import app.worker as w
    row=SimpleNamespace(status='QUEUED', scheduled_at=None, created_at=datetime.now(timezone.utc), channel='sms', error_message=None)
    db=DB({w.NotificationDelivery:Q([row])})
    assert w.process_notification_deliveries(db) == 0
    assert row.status == 'FAILED'


def test_notification_ambiguous_mail_failure(monkeypatch):
    import app.worker as w
    row=SimpleNamespace(status='QUEUED', scheduled_at=None, created_at=datetime.now(timezone.utc), channel='email', error_message=None, template_id=None, tenant_id='t', recipient='a@example.com', payload={'x':1})
    db=DB({w.NotificationDelivery:Q([row]), w.NotificationTemplate:Q([])})
    import app.services.mailer as mailer
    monkeypatch.setattr(mailer,'send_email',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('smtp timeout')))
    assert w.process_notification_deliveries(db) == 0
    assert row.status == 'RECONCILIATION_REQUIRED'


def test_whatsapp_missing_channel_fails():
    import app.worker as w
    row=SimpleNamespace(direction='OUTBOUND', status='QUEUED', created_at=datetime.now(timezone.utc), channel_id='c', tenant_id='t', error_message=None)
    db=DB({w.WhatsAppMessage:Q([row]), w.WhatsAppChannel:Q([])})
    assert w.process_whatsapp_deliveries(db) == 0
    assert row.status == 'FAILED'


def test_whatsapp_missing_provider_reference_reconciles(monkeypatch):
    import app.worker as w
    row=SimpleNamespace(direction='OUTBOUND', status='QUEUED', created_at=datetime.now(timezone.utc), channel_id='c', tenant_id='t', error_message=None, recipient='1', body='x', meta={})
    ch=SimpleNamespace(id='c', tenant_id='t', status='ACTIVE')
    db=DB({w.WhatsAppMessage:Q([row]), w.WhatsAppChannel:Q([ch])})
    import app.services.advanced as adv
    monkeypatch.setattr(adv,'send_whatsapp',lambda *a,**k:(None,{}))
    assert w.process_whatsapp_deliveries(db) == 0
    assert row.status == 'RECONCILIATION_REQUIRED'


def test_workflow_supported_steps(monkeypatch):
    import app.worker as w
    run=SimpleNamespace(id='r', workflow_id='wf', tenant_id='t', input_payload={'customer_id':'c'}, status='QUEUED', output_payload=None, started_at=None, completed_at=None)
    wf=SimpleNamespace(enabled=True, steps=[
        {'type':'TAG_CUSTOMER','tag':' vip '}, {'type':'SEND_EMAIL'}, {'type':'CREATE_COUPON'}, {'type':'WEBHOOK'}])
    db=DB()
    # Function imports WorkflowDefinition locally.
    from app.models.domain import WorkflowDefinition
    db.mapping[WorkflowDefinition]=Q([wf])
    w._execute_workflow(db,run)
    assert run.status=='COMPLETED' and len(run.output_payload['steps'])==4


def test_workflow_loyalty_step(monkeypatch):
    import app.worker as w
    from app.models.domain import WorkflowDefinition, LoyaltyAccount
    run=SimpleNamespace(id='r', workflow_id='wf', tenant_id='t', input_payload={'customer_id':'c'}, status='QUEUED', output_payload=None, started_at=None, completed_at=None)
    wf=SimpleNamespace(enabled=True, steps=[{'type':'ADD_LOYALTY_POINTS','points':5,'customer_id':'c'}])
    acct=SimpleNamespace(id='a', points_balance=10, lifetime_earned=20)
    db=DB({WorkflowDefinition:Q([wf]), LoyaltyAccount:Q([acct])})
    w._execute_workflow(db,run)
    assert acct.points_balance==15 and acct.lifetime_earned==25


def test_workflow_invalid_step_fails():
    import app.worker as w
    from app.models.domain import WorkflowDefinition
    run=SimpleNamespace(id='r', workflow_id='wf', tenant_id='t', input_payload={}, status='QUEUED', output_payload=None, started_at=None, completed_at=None)
    wf=SimpleNamespace(enabled=True, steps=[{'type':'NOPE'}])
    db=DB({WorkflowDefinition:Q([wf])})
    with pytest.raises(RuntimeError, match='Unsupported workflow step'):
        w._execute_workflow(db,run)


def test_domain_registration_state_guards(monkeypatch):
    import app.worker as w
    db=DB()
    for status, expected in [('COMPLETED','NOOP'),('REGISTERED','NOOP'),('REGISTRATION_PENDING','NOOP'),('REGISTRATION_RECONCILIATION_REQUIRED','RECONCILIATION_REQUIRED')]:
        p=SimpleNamespace(status=status, tenant_id='t')
        assert w.process_domain_registration(db,p)==expected


def test_domain_registration_processing_becomes_reconciliation():
    import app.worker as w
    p=SimpleNamespace(status='REGISTRATION_PROCESSING', tenant_id='t', failure_reason=None)
    db=DB()
    assert w.process_domain_registration(db,p)=='RECONCILIATION_REQUIRED'
    assert p.status=='REGISTRATION_RECONCILIATION_REQUIRED'


def test_domain_registration_invalid_state():
    import app.worker as w
    p=SimpleNamespace(status='CANCELLED', tenant_id='t')
    with pytest.raises(RuntimeError, match='Invalid domain purchase state'):
        w.process_domain_registration(DB(),p)


def test_domain_registration_success_and_reference_required(monkeypatch):
    import app.worker as w
    from app.models.domain import Domain, Storefront
    p=SimpleNamespace(status='PENDING_PAYMENT', tenant_id='t', customer_price_minor=1000, currency='USD', hostname='shop.example.com', years=1, registrant_snapshot={'name':'x'}, domain_id=None, provider_reference=None, completed_at=None, failure_reason=None)
    storefront=SimpleNamespace(id='sf', version=1, status='PUBLISHED')
    db=DB({Domain:Q([]), Storefront:Q([storefront])})
    db.info={'captured_amount_minor':1000,'captured_currency':'USD'}
    monkeypatch.setattr(w, 'datetime', __import__('datetime').datetime)
    import app.services.domain_registrar as reg
    monkeypatch.setattr(reg,'check_domain',lambda h:{'registrable':True})
    monkeypatch.setattr(reg,'register_domain',lambda *a,**k:{'status':'REGISTERED','reference':'REG-1'})
    out=w.process_domain_registration(db,p)
    assert out=='COMPLETED' and p.provider_reference=='REG-1'
    # Missing provider reference must reconcile instead of completing.
    p2=SimpleNamespace(**p.__dict__)
    p2.status='PENDING_PAYMENT'; p2.provider_reference=None; p2.domain_id=None; p2.completed_at=None; p2.failure_reason=None
    db2=DB({Domain:Q([]), Storefront:Q([storefront])}); db2.info={'captured_amount_minor':1000,'captured_currency':'USD'}
    monkeypatch.setattr(reg,'register_domain',lambda *a,**k:{'status':'REGISTERED'})
    assert w.process_domain_registration(db2,p2)=='RECONCILIATION_REQUIRED'
    assert p2.status=='REGISTRATION_RECONCILIATION_REQUIRED'


def test_domain_registration_capture_mismatch_is_rejected(monkeypatch):
    import app.worker as w
    p=SimpleNamespace(status='PENDING_PAYMENT', tenant_id='t', customer_price_minor=1000, currency='USD')
    db=DB(); db.info={'captured_amount_minor':999,'captured_currency':'USD'}
    with pytest.raises(RuntimeError, match='capture amount/currency mismatch'):
        w.process_domain_registration(db,p)
