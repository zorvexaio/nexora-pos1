from tests.test_p0 import register

def h(x):
    return {"Authorization": f"Bearer {x['access_token']}"}

def test_whatsapp_configuration_requires_signature_secret(client):
    x = register(client, 'wa131@example.com')
    tid = x['tenant']['id']
    r = client.post(f'/v1/whatsapp/configure?tenant_id={tid}', headers=h(x), json={
        'access_token': 'token', 'phone_number_id': '123', 'verify_token': 'verify'
    })
    assert r.status_code == 400
    assert 'required' in r.text.lower()

def test_ai_assistant_input_is_bounded(client):
    x = register(client, 'ai131@example.com')
    tid = x['tenant']['id']
    r = client.post(f'/v1/ai/assistant?tenant_id={tid}', headers=h(x), json={})
    # question is required by FastAPI before application-level validation
    assert r.status_code in (400, 422)

def test_media_validation_errors_are_client_errors(client):
    x = register(client, 'media131@example.com')
    tid = x['tenant']['id']
    files = {'file': ('x.svg', b'<svg></svg>', 'image/svg+xml')}
    r = client.post(f'/v1/media?tenant_id={tid}', headers=h(x), files=files)
    assert r.status_code in (400, 422)



def test_ai_apply_requires_product_write_permission(client):
    x = register(client, 'ai-perm131@example.com')
    tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import Product, TenantMembership
    db = SessionLocal()
    p = Product(tenant_id=tid, slug='perm-product', title='Perm Product', status='ACTIVE')
    db.add(p); db.commit(); pid = p.id
    membership = db.query(TenantMembership).filter_by(tenant_id=tid, user_id=x['user']['id']).first()
    membership.role = 'viewer'
    db.commit(); db.close()
    r = client.post(f'/v1/ai/products/{pid}/generate?tenant_id={tid}&apply=true', headers=h(x))
    assert r.status_code == 403


def test_landing_write_requires_storefront_write_permission(client):
    x = register(client, 'landing-perm131@example.com')
    tid = x['tenant']['id']
    from app.core.database import SessionLocal
    from app.models.domain import TenantMembership
    db = SessionLocal(); membership = db.query(TenantMembership).filter_by(tenant_id=tid, user_id=x['user']['id']).first(); membership.role = 'viewer'; db.commit(); db.close()
    r = client.post(f'/v1/landing-pages?tenant_id={tid}', headers=h(x), json={'slug': 'viewer-page', 'title': 'Viewer'})
    assert r.status_code == 403


def test_mfa_login_requires_second_factor_and_challenge_is_one_time(client):
    from app.core.database import SessionLocal
    from app.core.security import decrypt_secret, totp_code
    from app.models.domain import MFAFactor
    x = register(client, 'mfa-login@example.com')
    tid = x['tenant']['id']
    db = SessionLocal()
    factor = MFAFactor(user_id=x['user']['id'], factor_type='TOTP',
                       secret_encrypted=__import__('app.core.security', fromlist=['encrypt_secret']).encrypt_secret('JBSWY3DPEHPK3PXP'),
                       enabled=True)
    db.add(factor); db.commit(); db.close()
    # Password is correct, but no authenticated session may be issued yet.
    client.post('/v1/auth/logout', headers=h(x))
    r = client.post('/v1/auth/login', json={'email': 'mfa-login@example.com', 'password': 'VerySecurePassword123!'})
    assert r.status_code == 200
    body = r.json()
    assert body['mfa_required'] is True and body['challenge']
    challenge = body['challenge']
    v = client.post('/v1/auth/mfa/verify-login', json={'challenge': challenge, 'code': totp_code('JBSWY3DPEHPK3PXP')})
    assert v.status_code == 200 and v.json().get('access_token')
    # The challenge is single-use even if the token is replayed immediately.
    replay = client.post('/v1/auth/mfa/verify-login', json={'challenge': challenge, 'code': totp_code('JBSWY3DPEHPK3PXP')})
    assert replay.status_code == 403
