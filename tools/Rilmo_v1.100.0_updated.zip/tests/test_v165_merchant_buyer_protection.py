from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def test_publish_is_blocked_until_kyb_and_payment_ready():
    text=(ROOT/'app/routes/v1.py').read_text()
    assert "MERCHANT_KYB_REQUIRED" in text
    assert "MERCHANT_PAYMENT_ONBOARDING_REQUIRED" in text
    assert "status='ACTIVE',charges_enabled=True,payouts_enabled=True" in text


def test_payment_configuration_is_pending_until_provider_approval():
    # payment-account routes moved to merchant_compliance_routes.py in Phase 3 split
    text=(ROOT/'app/routes/merchant_compliance_routes.py').read_text()
    start=text.index("@router.post('/merchant/payment-account/configure')")
    end=text.index("@router.get('/merchant/payment-accounts')",start)
    body=text[start:end]
    assert "row.status='PENDING'" in body
    assert "row.charges_enabled=False" in body
    assert "row.payouts_enabled=False" in body


def test_customer_cancel_and_order_issue_routes_exist():
    # moved to buyer_protection_routes.py in Phase 3 split
    text=(ROOT/'app/routes/buyer_protection_routes.py').read_text()
    assert "@router.post('/customer/orders/{order_id}/cancel')" in text
    assert "@router.post('/customer/orders/{order_id}/issues')" in text
    assert "@router.patch('/merchant/order-issues/{issue_id}')" in text


def test_customer_cancel_is_idempotent_and_refund_is_provider_driven():
    text=(ROOT/'app/routes/buyer_protection_routes.py').read_text()
    assert "existing=db.query(OrderIssue).filter_by(tenant_id=tenant_id,idempotency_key=key).first()" in text
    assert "provider_refund_id=result.provider_id" in text
    assert "idempotency_key=op_key" in text


def test_kyb_submission_hashes_reference_and_does_not_store_raw_documents():
    # merchant KYB submission moved to merchant_compliance_routes.py (Phase 3 split)
    text=(ROOT/'app/routes/merchant_compliance_routes.py').read_text()
    assert "kyb_evidence_hash=hashlib.sha256(data.evidence_reference.encode()).hexdigest()" in text
    assert "merchant.kyb.submitted" in text
