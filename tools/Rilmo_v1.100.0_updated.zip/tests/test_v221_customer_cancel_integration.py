import secrets
from datetime import datetime, timedelta, timezone


def _customer_session_client(client, tid, order_id=None):
    """Create a real Customer + CustomerSession row and attach the session
    cookie to the test client, exactly matching customer_session_actor's
    expected token_hash format. If order_id is given, link that order to
    the new customer (checkout in this test suite runs as the merchant
    owner, which doesn't auto-link a storefront customer record)."""
    from app.core.database import SessionLocal
    from app.core.security import token_hash
    from app.models.domain import Customer, CustomerSession, Order

    db = SessionLocal()
    customer = Customer(tenant_id=tid, email='shopper@example.com')
    db.add(customer)
    db.flush()
    if order_id:
        db.query(Order).filter_by(id=order_id, tenant_id=tid).update({'customer_id': customer.id})
    raw_token = secrets.token_urlsafe(32)
    db.add(CustomerSession(tenant_id=tid, customer_id=customer.id, token_hash=token_hash(raw_token),
        expires_at=datetime.now(timezone.utc) + timedelta(days=7)))
    db.commit()
    customer_id = customer.id
    db.close()
    client.cookies.set('customer_session', raw_token)
    client.cookies.set('csrf_token', 'test-csrf-token')
    return customer_id


def _merchant_order_for_customer(client, email, amount=3000):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'cancel-item', 'title': 'Cancel Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'CANCEL-1', 'price_amount_minor': amount, 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c['id']}).json()
    return tid, h, order


def test_customer_cancel_requires_login(client):
    tid, h, order = _merchant_order_for_customer(client, 'cancel-nologin@example.com')
    client.cookies.clear()  # drop the merchant 'session' cookie set by /auth/register
    r = client.post(f"/v1/customer/orders/{order['id']}/cancel?tenant_id={tid}", json={'reason': 'changed my mind', 'idempotency_key': 'test-key-001'})
    assert r.status_code == 401
    assert r.json()['detail']['error']['code'] == 'CUSTOMER_LOGIN_REQUIRED'

def test_customer_cancel_missing_order_returns_not_found(client):
    tid, h, order = _merchant_order_for_customer(client, 'cancel-missingorder@example.com')
    client.cookies.clear()
    _customer_session_client(client, tid, order['id'])
    r = client.post(f'/v1/customer/orders/does-not-exist/cancel?tenant_id={tid}', json={'reason': 'test', 'idempotency_key': 'test-key-002'},
        headers={'X-CSRF-Token': 'test-csrf-token'})
    assert r.status_code == 404

def test_customer_cancel_unpaid_order_voids_payment(client):
    tid, h, order = _merchant_order_for_customer(client, 'cancel-unpaid@example.com')
    client.cookies.clear()
    _customer_session_client(client, tid, order['id'])
    r = client.post(f"/v1/customer/orders/{order['id']}/cancel?tenant_id={tid}", json={'reason': 'no longer needed', 'idempotency_key': 'test-key-003'},
        headers={'X-CSRF-Token': 'test-csrf-token'})
    assert r.status_code == 200, r.text
    assert r.json()['status'] == 'CANCELLED'
    assert r.json()['order_status'] == 'CANCELLED'

def test_customer_cancel_paid_order_triggers_refund(client):
    tid, h, order = _merchant_order_for_customer(client, 'cancel-paid@example.com', amount=4000)
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'order_id': order['id'], 'amount_minor': order['total_minor'], 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/payments/{pi['id']}/capture?tenant_id={tid}", headers=h)
    client.cookies.clear()
    _customer_session_client(client, tid, order['id'])
    r = client.post(f"/v1/customer/orders/{order['id']}/cancel?tenant_id={tid}", json={'reason': 'wrong item', 'idempotency_key': 'test-key-004'},
        headers={'X-CSRF-Token': 'test-csrf-token'})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['status'] == 'REFUNDED'
    assert body['refund_amount_minor'] == 4000

def test_customer_cancel_is_idempotent_on_same_key(client):
    tid, h, order = _merchant_order_for_customer(client, 'cancel-idempotent@example.com')
    client.cookies.clear()
    _customer_session_client(client, tid, order['id'])
    payload = {'reason': 'test', 'idempotency_key': 'same-key-123'}
    csrf_headers = {'X-CSRF-Token': 'test-csrf-token'}
    first = client.post(f"/v1/customer/orders/{order['id']}/cancel?tenant_id={tid}", json=payload, headers=csrf_headers)
    second = client.post(f"/v1/customer/orders/{order['id']}/cancel?tenant_id={tid}", json=payload, headers=csrf_headers)
    assert first.status_code == 200, first.text
    assert second.status_code == 200
    assert first.json()['issue_id'] == second.json()['issue_id']

def test_customer_cancel_rejects_when_window_closed(client):
    from app.core.database import SessionLocal
    from app.models.domain import Order

    tid, h, order = _merchant_order_for_customer(client, 'cancel-windowclosed@example.com')
    db = SessionLocal()
    db.query(Order).filter_by(id=order['id']).update({'status': 'FULFILLED'})
    db.commit()
    db.close()
    client.cookies.clear()
    _customer_session_client(client, tid, order['id'])
    r = client.post(f"/v1/customer/orders/{order['id']}/cancel?tenant_id={tid}", json={'reason': 'too late', 'idempotency_key': 'test-key-005'},
        headers={'X-CSRF-Token': 'test-csrf-token'})
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'CUSTOMER_CANCEL_WINDOW_CLOSED'
