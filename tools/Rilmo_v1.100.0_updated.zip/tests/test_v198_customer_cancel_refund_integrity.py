from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_customer_cancel_refund_fails_closed_without_provider_reference():
    text = (ROOT / 'app/routes/buyer_protection_routes.py').read_text()
    start = text.index("@router.post('/customer/orders/{order_id}/cancel')")
    end = text.index("@router.post('/customer/orders/{order_id}/issues')", start)  # cancel_order moved to buyer_protection_routes.py in Phase 3 split
    body = text[start:end]
    assert "if not result.provider_id:" in body
    assert "PROVIDER_REFUND_REFERENCE_MISSING" in body
    assert "reconciliation required" in body


def test_customer_cancel_refund_recovers_same_provider_reference_idempotently():
    text = (ROOT / 'app/routes/buyer_protection_routes.py').read_text()
    start = text.index("@router.post('/customer/orders/{order_id}/cancel')")
    end = text.index("@router.post('/customer/orders/{order_id}/issues')", start)  # cancel_order moved to buyer_protection_routes.py in Phase 3 split
    body = text[start:end]
    assert "existing_refund = db.query(Refund).filter_by(tenant_id=tenant_id, provider_refund_id=result.provider_id).with_for_update().first()" in body
    assert "PROVIDER_REFUND_REFERENCE_REUSED" in body
