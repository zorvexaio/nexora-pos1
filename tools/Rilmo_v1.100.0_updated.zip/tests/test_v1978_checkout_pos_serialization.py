from pathlib import Path


def test_checkout_locks_cart_before_consuming_it():
    # checkout moved to checkout_routes.py in Phase 3 split
    src = Path('app/routes/checkout_routes.py').read_text()
    needle = "db.query(Cart).filter_by(id=data.cart_id, tenant_id=tenant_id, status='OPEN').with_for_update().first()"
    assert needle in src


def test_pos_sale_and_close_lock_session_row():
    src = Path('app/routes/worldclass.py').read_text()
    assert "session=db.query(POSSession).filter_by(id=session_id,tenant_id=tenant_id,status='OPEN').with_for_update().first()" in src
    assert "row=db.query(POSSession).filter_by(id=session_id,tenant_id=tenant_id,status='OPEN').with_for_update().first()" in src
