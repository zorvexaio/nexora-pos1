from pathlib import Path


def test_forwarded_allow_ips_is_explicit_in_production():
    text = Path('app/core/config.py').read_text()
    assert 'FORWARDED_ALLOW_IPS' in text
    assert "FORWARDED_ALLOW_IPS must explicitly trust only" in text


def test_docker_uses_managed_server_entrypoint():
    text = Path('Dockerfile').read_text()
    assert 'scripts/run_server.py' in text
    assert '--proxy-headers' not in text


def test_dead_stripe_dependency_removed():
    text = Path('requirements.txt').read_text()
    assert not any(line.startswith('stripe==') for line in text.splitlines())


def test_editor_artifact_removed():
    assert not Path('app/routes/v1.py.tmp').exists()


def test_rls_runtime_gate_exists_and_checks_bypassrls():
    text = Path('scripts/postgres_runtime_security_gate.py').read_text()
    assert 'rolbypassrls' in text
    assert 'relforcerowsecurity' in text


def test_webhook_dns_pinning_is_present():
    text = Path('app/services/app_webhooks.py').read_text()
    assert '_resolve_public_https' in text
    assert '_PinnedBackend' in text
    assert 'SyncBackend' in text


def test_backup_restore_rehearsal_exists():
    path = Path('scripts/backup_restore_rehearsal.sh')
    assert path.exists()
    assert 'pg_dump' in path.read_text()
    assert 'secure_backup.py' in path.read_text()
