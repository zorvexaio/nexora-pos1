from pathlib import Path


def test_local_runtime_contract_files_exist():
    assert Path('docker-compose.yml').exists()
    assert Path('.env.example').exists()
    assert Path('scripts/seed_demo.py').exists()
    assert Path('scripts/local_runtime_smoke.py').exists()
    assert Path('Makefile').exists()


def test_compose_no_longer_requires_external_secret_placeholders():
    compose = Path('docker-compose.yml').read_text()
    assert ':?' not in compose
    assert 'ALLOW_LOCAL_MOCK_PAYMENTS' in compose
    assert 'postgresql+psycopg://commerce:commerce@db:5432/commerce' in compose


def test_readme_contains_zero_to_browser_path():
    readme = Path('README.md').read_text()
    for marker in ('docker compose up -d --build', 'seed_demo.py', 'localhost:8000/store/demo.localhost', 'local_runtime_smoke.py'):
        assert marker in readme
