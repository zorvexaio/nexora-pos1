from datetime import datetime, timezone

from app.core.database import SessionLocal
from app.models.domain import Domain, LiveStorefrontEvent, Product, Storefront, Tenant


def _merchant(client, email, hostname):
    r = client.post('/v1/auth/register', json={
        'email': email,
        'password': 'VerySecurePassword123!',
        'display_name': 'Event Tenant',
    })
    assert r.status_code == 200, r.text
    tid = r.json()['tenant']['id']
    db = SessionLocal()
    try:
        t = db.get(Tenant, tid)
        t.status = 'ACTIVE'
        s = db.query(Storefront).filter_by(tenant_id=tid).first()
        s.status = 'PUBLISHED'
        d = Domain(tenant_id=tid, storefront_id=s.id, hostname=hostname,
                   verified_at=datetime.now(timezone.utc))
        p = Product(tenant_id=tid, storefront_id=s.id, slug='event-product',
                    status='ACTIVE', title='Event Product')
        db.add_all([d, p])
        db.commit()
        return tid, s.id, p.id
    finally:
        db.close()


def test_live_event_rejects_foreign_tenant_product(client):
    _tid_a, _sid_a, product_a = _merchant(
        client, 'event-a-v1921@example.com', 'event-a-v1921.example.test')
    tid_b, _sid_b, _product_b = _merchant(
        client, 'event-b-v1921@example.com', 'event-b-v1921.example.test')

    csrf = client.cookies.get('csrf_token')
    r = client.post('/v1/public/storefront/event-b-v1921.example.test/events', headers={'X-CSRF-Token': csrf} if csrf else {}, json={
        'event_type': 'product_view',
        'product_id': product_a,
        'path': '/products/event-product',
    })
    assert r.status_code == 400
    body = r.json(); assert (body.get('error') or body.get('detail', {}).get('error', {})).get('code') == 'LIVE_EVENT_PRODUCT_INVALID'

    db = SessionLocal()
    try:
        assert db.query(LiveStorefrontEvent).filter_by(
            tenant_id=tid_b, product_id=product_a).count() == 0
    finally:
        db.close()


def test_live_event_accepts_own_storefront_product(client):
    tid, _sid, product_id = _merchant(
        client, 'event-own-v1921@example.com', 'event-own-v1921.example.test')
    csrf = client.cookies.get('csrf_token')
    r = client.post('/v1/public/storefront/event-own-v1921.example.test/events', headers={'X-CSRF-Token': csrf} if csrf else {}, json={
        'event_type': 'product_view',
        'product_id': product_id,
        'path': '/products/event-product',
    })
    assert r.status_code == 200, r.text

    db = SessionLocal()
    try:
        row = db.query(LiveStorefrontEvent).filter_by(
            tenant_id=tid, product_id=product_id).first()
        assert row is not None
    finally:
        db.close()
