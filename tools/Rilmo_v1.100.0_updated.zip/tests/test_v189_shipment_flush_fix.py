def test_create_shipment_with_configured_carrier_succeeds_and_has_real_id(client, monkeypatch):
    from app.core.database import SessionLocal
    from app.models.domain import CarrierAccount
    from app.services import shipping as shipping_module

    m = client.post('/v1/auth/register', json={'email': 'shipment-flush@example.com', 'password': 'VerySecurePassword123!', 'display_name': 'M'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'ship-item', 'title': 'Ship Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'SHIP-1', 'price_amount_minor': 1000, 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c['id']}).json()

    from app.core.security import encrypt_secret
    db = SessionLocal()
    db.add(CarrierAccount(tenant_id=tid, carrier_code='fastship', status='ACTIVE',
        api_base_url='https://carrier.example.com', api_token_encrypted=encrypt_secret('fake-token')))
    db.commit()
    db.close()

    monkeypatch.setattr(shipping_module, 'validate_outbound_url', lambda url, **kw: url)
    monkeypatch.setattr(shipping_module.ConfiguredCarrier, 'create_shipment',
        lambda self, **kw: {'shipment_id': 'CARRIER-123', 'tracking_number': 'TRACK-999', 'label_url': 'https://labels.example.com/1', 'status': 'CREATED'})

    r = client.post(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=h, json={
        'carrier_code': 'fastship', 'service_code': 'standard',
        'origin': {'country': 'US', 'city': 'Austin', 'postal_code': '78701'},
        'destination': {'country': 'US', 'city': 'Dallas', 'postal_code': '75201'},
        'parcels': [{'weight_kg': 1.0, 'length_cm': 10, 'width_cm': 10, 'height_cm': 10}],
    })
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['id']  # must be a real UUID, not None — this is exactly what the flush bug broke
    assert body['order_id'] == order['id']
    assert body['tracking_number'] == 'TRACK-999'

    listing = client.get(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=h)
    assert listing.status_code == 200
    assert any(s['id'] == body['id'] for s in listing.json()['items'])
