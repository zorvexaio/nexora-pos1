from datetime import timedelta
from pathlib import Path
from app.core.database import SessionLocal
from app.models.domain import User, Tenant, TenantMembership, MerchantProfile, MerchantIdentityVerification, PrivacyIncident
from app.services.privacy import safe_merchant_verification_view, safe_merchant_profile_view, update_privacy_incident, open_privacy_incident
from app.services.core import audit

def test_kyc_view_masks_external_reference_and_hides_provider_metadata():
    u=User(email='owner-v140@example.com',password_hash='x')
    t=Tenant(slug='safe-kyc-v140',name='Safe KYC')
    db=SessionLocal()
    try:
        db.add(u); db.add(t); db.flush()
        v=MerchantIdentityVerification(tenant_id=t.id,user_id=u.id,provider='veriff',external_id='veriff-secret-123456',status='APPROVED',verification_url='https://example.invalid/session')
        db.add(v); db.flush()
        view=safe_merchant_verification_view(v,viewer_user_id='other-user')
        assert view['verification_id_masked'] == 'veri…3456'
        assert view['next_action_url'] is None
        owner_view=safe_merchant_verification_view(v,viewer_user_id=u.id)
        assert owner_view['next_action_url'] == v.verification_url
        assert 'provider_metadata' not in view and 'external_id' not in view
    finally:
        db.rollback(); db.close()

def test_support_profile_view_masks_tax_id_and_private_contact():
    db=SessionLocal()
    try:
        t=Tenant(slug='safe-profile-v140',name='Safe Profile')
        db.add(t); db.flush()
        p=MerchantProfile(tenant_id=t.id,legal_name='Merchant',phone='+905551112233',country_code='TR',city='Istanbul',address_line1='Secret St',postal_code='34000',tax_id='1234567890',identity_status='VERIFIED',kyc_status='VERIFIED')
        db.add(p); db.flush()
        view=safe_merchant_profile_view(p,viewer_role='staff',include_private=False)
        assert view['phone'] is None and view['address_line1'] is None
        assert view['tax_id_masked'] == '12…90'
        assert 'tax_id' not in view
        owner=safe_merchant_profile_view(p,viewer_role='owner',include_private=True)
        assert owner['tax_id']=='1234567890'
    finally:
        db.rollback(); db.close()

def test_privacy_incident_state_machine_forces_remediation_and_notification_decision():
    db=SessionLocal()
    try:
        u=User(email='incident-v140@example.com',password_hash='x'); db.add(u); db.flush()
        inc=open_privacy_incident(db,jurisdiction='TR-KVKK',severity='HIGH')
        update_privacy_incident(db,incident_id=inc.id,actor_user_id=u.id,status='CONTAINED')
        update_privacy_incident(db,incident_id=inc.id,actor_user_id=u.id,status='ASSESSED')
        update_privacy_incident(db,incident_id=inc.id,actor_user_id=u.id,status='NOTIFICATION_PENDING',notification_decision='PENDING')
        try:
            update_privacy_incident(db,incident_id=inc.id,actor_user_id=u.id,status='NOTIFIED')
            raise AssertionError('notification decision was bypassed')
        except Exception as exc:
            assert getattr(exc,'code',None) == 'PRIVACY_NOTIFICATION_DECISION_REQUIRED'
        update_privacy_incident(db,incident_id=inc.id,actor_user_id=u.id,status='NOTIFIED',notification_decision='AUTHORITY')
        update_privacy_incident(db,incident_id=inc.id,actor_user_id=u.id,status='REMEDIATED')
        update_privacy_incident(db,incident_id=inc.id,actor_user_id=u.id,status='CLOSED')
        assert inc.status=='CLOSED'
    finally:
        db.rollback(); db.close()

def test_privacy_security_documents_anchor_current_standards():
    matrix=Path('docs/SECURITY_ASVS_5_API_TOP10_MATRIX.md').read_text(encoding='utf-8')
    assert 'OWASP Top 10:2025' in matrix
    assert 'ASVS 5.0.0' in matrix
    kvkk=Path('docs/KVKK_TECHNICAL_CONTROL_MATRIX.md').read_text(encoding='utf-8')
    assert 'standard contract' in kvkk.lower() or 'standart sözleşme' in kvkk.lower()
