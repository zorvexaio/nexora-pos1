import pytest
from datetime import datetime, timedelta, timezone

from app.core.database import SessionLocal
from app.core.auth import current_platform_admin
from app.core.errors import AppError
from app.main import app
from app.models.domain import User, GlobalMarketProfile, GlobalLaunchEvidence
from app.services.global_readiness import (
    seed_default_market_profiles, readiness_summary, require_market_ready,
    APP_STORE_POLICY, DEFAULT_MARKETS,
)


def _platform_admin_user():
    db = SessionLocal()
    u = User(email=f'admin-{datetime.now().timestamp()}@example.com', password_hash='x')
    db.add(u)
    db.commit()
    db.refresh(u)
    db.close()
    return u


@pytest.fixture()
def db():
    s = SessionLocal()
    yield s
    s.close()


# --- seeding ---------------------------------------------------------------

def test_seed_default_market_profiles_creates_all_default_markets(db):
    changed = seed_default_market_profiles(db, lambda: __import__('uuid').uuid4().hex, lambda: datetime.now(timezone.utc))
    assert changed is True
    keys = {m.market_key for m in db.query(GlobalMarketProfile).all()}
    for expected in DEFAULT_MARKETS:
        assert expected in keys

def test_seed_default_market_profiles_is_idempotent(db):
    seed_default_market_profiles(db, lambda: __import__('uuid').uuid4().hex, lambda: datetime.now(timezone.utc))
    count_after_first = db.query(GlobalMarketProfile).count()
    changed_second = seed_default_market_profiles(db, lambda: __import__('uuid').uuid4().hex, lambda: datetime.now(timezone.utc))
    assert changed_second is False
    assert db.query(GlobalMarketProfile).count() == count_after_first

def test_seed_creates_app_store_distribution_policy_for_every_market_and_sku(db):
    from app.models.domain import AppStoreDistributionPolicy
    seed_default_market_profiles(db, lambda: __import__('uuid').uuid4().hex, lambda: datetime.now(timezone.utc))
    rows = db.query(AppStoreDistributionPolicy).all()
    expected_count = len(DEFAULT_MARKETS) * sum(len(skus) for skus in APP_STORE_POLICY.values())
    assert len(rows) == expected_count


# --- readiness_summary -------------------------------------------------------

def test_readiness_summary_reports_not_ready_with_missing_requirements(db):
    seed_default_market_profiles(db, lambda: __import__('uuid').uuid4().hex, lambda: datetime.now(timezone.utc))
    summary = readiness_summary(db, market_key='SA')
    assert len(summary) == 1
    row = summary[0]
    assert row['market_key'] == 'SA'
    assert row['ready'] is False
    assert set(row['missing_requirements']) == {
        'SA-ZATCA-EINVOICE', 'SA-VAT-LEGAL-REVIEW', 'SA-CONSUMER-COMMERCE-LEGAL-REVIEW',
    }

def test_readiness_summary_becomes_ready_once_all_evidence_verified_and_statuses_set(db):
    seed_default_market_profiles(db, lambda: __import__('uuid').uuid4().hex, lambda: datetime.now(timezone.utc))
    market = db.query(GlobalMarketProfile).filter_by(market_key='GB').first()
    for code in DEFAULT_MARKETS['GB']['requirements']:
        db.add(GlobalLaunchEvidence(market_key='GB', requirement_code=code, status='VERIFIED', verified_at=datetime.now(timezone.utc)))
    market.legal_review_status = 'VERIFIED'
    market.tax_invoicing_status = 'VERIFIED'
    market.payments_status = 'VERIFIED'
    market.data_transfer_status = 'VERIFIED'
    market.app_store_status = 'VERIFIED'
    db.commit()
    summary = readiness_summary(db, market_key='GB')
    assert summary[0]['ready'] is True
    assert summary[0]['missing_requirements'] == []

def test_readiness_summary_treats_expired_evidence_as_missing(db):
    seed_default_market_profiles(db, lambda: __import__('uuid').uuid4().hex, lambda: datetime.now(timezone.utc))
    market = db.query(GlobalMarketProfile).filter_by(market_key='US').first()
    for code in DEFAULT_MARKETS['US']['requirements']:
        db.add(GlobalLaunchEvidence(
            market_key='US', requirement_code=code, status='VERIFIED',
            verified_at=datetime.now(timezone.utc),
            expires_at=datetime.now(timezone.utc) - timedelta(days=1),  # already expired
        ))
    market.legal_review_status = 'VERIFIED'
    market.tax_invoicing_status = 'VERIFIED'
    market.payments_status = 'VERIFIED'
    market.data_transfer_status = 'VERIFIED'
    market.app_store_status = 'VERIFIED'
    db.commit()
    summary = readiness_summary(db, market_key='US')
    assert summary[0]['ready'] is False
    assert len(summary[0]['missing_requirements']) == len(DEFAULT_MARKETS['US']['requirements'])


# --- require_market_ready gate ------------------------------------------------

def test_require_market_ready_blocks_unready_market(db):
    seed_default_market_profiles(db, lambda: __import__('uuid').uuid4().hex, lambda: datetime.now(timezone.utc))
    with pytest.raises(AppError) as exc:
        require_market_ready(db, 'TR')
    assert exc.value.code == 'MARKET_NOT_READY'
    assert exc.value.status_code == 428

def test_require_market_ready_blocks_market_with_no_profile_at_all(db):
    with pytest.raises(AppError) as exc:
        require_market_ready(db, 'ZZ')
    assert exc.value.code == 'MARKET_NOT_READY'


# --- API surface: /v1/platform/global-readiness ------------------------------

def test_global_readiness_endpoint_reports_external_evidence_required(client):
    admin = _platform_admin_user()
    app.dependency_overrides[current_platform_admin] = lambda: admin
    try:
        resp = client.get('/v1/platform/global-readiness')
    finally:
        app.dependency_overrides.pop(current_platform_admin, None)
    assert resp.status_code == 200
    body = resp.json()
    assert body['status'] == 'EXTERNAL_EVIDENCE_REQUIRED'
    assert len(body['markets']) == len(DEFAULT_MARKETS)

def test_global_readiness_evidence_endpoint_records_reviewer_and_status(client):
    admin = _platform_admin_user()
    app.dependency_overrides[current_platform_admin] = lambda: admin
    try:
        client.get('/v1/platform/global-readiness')  # seeds markets first
        resp = client.post('/v1/platform/global-readiness/evidence', json={
            'market_key': 'gb', 'requirement_code': 'GB-UK-GDPR-LEGAL-REVIEW',
            'status': 'verified', 'evidence_ref': 'legal-memo-2026-08-20.pdf',
        })
    finally:
        app.dependency_overrides.pop(current_platform_admin, None)
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body['market_key'] == 'GB'
    assert body['status'] == 'VERIFIED'
    assert body['reviewer_user_id'] == admin.id

def test_global_readiness_evidence_endpoint_rejects_invalid_status(client):
    admin = _platform_admin_user()
    app.dependency_overrides[current_platform_admin] = lambda: admin
    try:
        resp = client.post('/v1/platform/global-readiness/evidence', json={
            'market_key': 'GB', 'requirement_code': 'GB-UK-GDPR-LEGAL-REVIEW', 'status': 'DEFINITELY_DONE',
        })
    finally:
        app.dependency_overrides.pop(current_platform_admin, None)
    assert resp.status_code == 400
    assert resp.json()['detail']['error']['code'] == 'GLOBAL_EVIDENCE_INVALID'
