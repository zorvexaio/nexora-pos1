
def _register(client, email):
    x = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'}).json()
    return x, {'Authorization': 'Bearer ' + x['access_token']}


def _add(client, tid, owner_h, email, role='staff'):
    x, _ = _register(client, email)
    r = client.post(f'/v1/members?tenant_id={tid}', headers=owner_h,
                    json={'email': email, 'role': role})
    assert r.status_code == 200, r.text
    return x, r.json()


def test_staff_cannot_grant_admin_or_owner(client):
    owner, owner_h = _register(client, 'v1966-owner@example.com')
    tid = owner['tenant']['id']
    staff, _member = _add(client, tid, owner_h, 'v1966-staff@example.com', 'staff')
    target, _ = _register(client, 'v1966-target@example.com')
    staff_h = {'Authorization': 'Bearer ' + staff['access_token']}
    for role in ('admin', 'owner'):
        r = client.post(f'/v1/members?tenant_id={tid}', headers=staff_h,
                        json={'email': target['user']['email'], 'role': role})
        assert r.status_code == 403


def test_admin_cannot_grant_owner(client):
    owner, owner_h = _register(client, 'v1966-owner2@example.com')
    tid = owner['tenant']['id']
    admin, _member = _add(client, tid, owner_h, 'v1966-admin@example.com', 'admin')
    target, _ = _register(client, 'v1966-target2@example.com')
    admin_h = {'Authorization': 'Bearer ' + admin['access_token']}
    r = client.post(f'/v1/members?tenant_id={tid}', headers=admin_h,
                    json={'email': target['user']['email'], 'role': 'owner'})
    assert r.status_code == 403


def test_staff_cannot_promote_self_to_admin(client):
    owner, owner_h = _register(client, 'v1966-owner3@example.com')
    tid = owner['tenant']['id']
    staff, member = _add(client, tid, owner_h, 'v1966-staff3@example.com', 'staff')
    staff_h = {'Authorization': 'Bearer ' + staff['access_token']}
    r = client.patch(f"/v1/members/{member['id']}?tenant_id={tid}", headers=staff_h,
                     json={'role': 'admin'})
    assert r.status_code == 403
