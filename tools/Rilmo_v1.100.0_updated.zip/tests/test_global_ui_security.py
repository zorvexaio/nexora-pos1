from app.models.domain import Session as SessionModel

def test_session_revoke_endpoint(client):
    r = client.post('/v1/auth/register', json={'email': 'sessionx@example.com', 'password': 'very-secure-password-123', 'display_name': 'Session User'})
    assert r.status_code == 200
    token = r.json()['access_token']
    rr = client.get('/v1/auth/sessions', headers={'Authorization': f'Bearer {token}'})
    assert rr.status_code == 200 and rr.json()['items']
    sid = rr.json()['items'][0]['id']
    dr = client.delete(f'/v1/auth/sessions/{sid}', headers={'Authorization': f'Bearer {token}'})
    assert dr.status_code == 200
    me = client.get('/v1/me', headers={'Authorization': f'Bearer {token}'})
    assert me.status_code == 403

def test_public_search_has_locale_parameter(client):
    r = client.get('/v1/public/storefront/example.invalid/search?q=x&locale=ar')
    assert r.status_code == 404


def test_jsonld_escape_prevents_script_breakout():
    from app.main import _safe_jsonld
    payload = {'name': '</script><img src=x onerror=alert(1)>'}
    encoded = _safe_jsonld(payload)
    assert '</script>' not in encoded.lower()
    assert '\\u003c/script\\u003e' in encoded

