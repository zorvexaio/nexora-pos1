from pathlib import Path


def test_0065_tenant_rls_closure_covers_sensitive_post_baseline_tables():
    migration = Path("alembic/versions/20260822_0065_tenant_rls_closure.py").read_text(encoding="utf-8")
    expected = {
        "customer_identities",
        "customer_sessions",
        "customer_login_codes",
        "storefront_oauth_states",
        "merchant_profiles",
        "merchant_phone_verifications",
        "tenant_reviews",
        "trust_reports",
        "merchant_trust_scores",
        "domain_purchases",
        "order_issues",
        "order_issue_messages",
    }
    for table in expected:
        assert f'"{table}"' in migration
        assert 'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY' in migration
        assert 'ALTER TABLE {table} FORCE ROW LEVEL SECURITY' in migration
        assert 'CREATE POLICY {table}_tenant_isolation ON {table}' in migration


def test_customer_session_actor_binds_tenant_context_before_lookup():
    source = Path("app/core/guest.py").read_text(encoding="utf-8")
    fn = source.split("def customer_session_actor", 1)[1].split("def commerce_actor", 1)[0]
    assert "set_tenant_context(db, tenant_id)" in fn.split("raw = request.cookies.get('customer_session')", 1)[0]
