from app.services.payment_providers import PaymentActionResult


def _merchant(client):
    m = client.post('/v1/auth/register', json={'email': 'void-ref@example.com', 'password': 'VerySecurePassword123!'}).json()
    return m['tenant']['id'], {'Authorization': 'Bearer ' + m['access_token']}


def test_void_fails_closed_when_provider_returns_no_reference(client, monkeypatch):
    tid, headers = _merchant(client)
    pi = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=headers,
        json={'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()

    class Provider:
        def void(self, *args, **kwargs):
            return PaymentActionResult(provider_id='', status='succeeded', raw={})

    monkeypatch.setattr('app.routes.payment_routes.get_payment_provider', lambda _name: Provider())
    r = client.post(f'/v1/payments/{pi["id"]}/void?tenant_id={tid}', headers=headers)
    assert r.status_code == 502
    assert r.json()['detail']['error']['code'] == 'PROVIDER_VOID_REFERENCE_MISSING'

    retry = client.post(f'/v1/payments/{pi["id"]}/void?tenant_id={tid}', headers={**headers, 'Idempotency-Key': 'void-retry'})
    assert retry.status_code == 502
    assert retry.json()['detail']['error']['code'] == 'PROVIDER_VOID_REFERENCE_MISSING'
