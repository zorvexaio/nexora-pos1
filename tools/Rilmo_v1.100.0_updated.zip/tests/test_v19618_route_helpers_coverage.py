from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from app.core.errors import AppError
import app.routes.v1 as v1


def test_tenant_scope_delegates_to_context_binding(monkeypatch):
    sentinel = object()
    called = {}
    def fake_bind(tenant_id, user, db):
        called.update(tenant_id=tenant_id, user=user, db=db)
        return sentinel
    monkeypatch.setattr(v1, 'bind_tenant_context', fake_bind)
    user = object(); db = object()
    assert v1.tenant_scope('tenant-1', user, db) is sentinel
    assert called == {'tenant_id': 'tenant-1', 'user': user, 'db': db}


def test_provider_credentials_empty_when_account_missing_or_without_credentials():
    db = MagicMock()
    query = db.query.return_value
    query.filter_by.return_value.first.return_value = None
    assert v1.provider_credentials('t1', 'paytr', db) == {}
    row = SimpleNamespace(credentials_encrypted=None)
    query.filter_by.return_value.first.return_value = row
    assert v1.provider_credentials('t1', 'paytr', db) == {}


def test_provider_credentials_decrypts_json(monkeypatch):
    db = MagicMock()
    row = SimpleNamespace(credentials_encrypted='encrypted')
    db.query.return_value.filter_by.return_value.first.return_value = row
    monkeypatch.setattr(v1, 'decrypt_secret', lambda value: '{"merchant_id":"m1","key":"k1"}')
    assert v1.provider_credentials('t1', 'paytr', db) == {'merchant_id': 'm1', 'key': 'k1'}


def test_provider_credentials_invalid_ciphertext_fails_closed(monkeypatch):
    db = MagicMock()
    row = SimpleNamespace(credentials_encrypted='encrypted')
    db.query.return_value.filter_by.return_value.first.return_value = row
    monkeypatch.setattr(v1, 'decrypt_secret', lambda value: (_ for _ in ()).throw(ValueError('bad secret')))
    with pytest.raises(AppError) as exc:
        v1.provider_credentials('t1', 'paytr', db)
    assert exc.value.status_code == 500
    assert exc.value.code == 'PROVIDER_CREDENTIALS_INVALID'


def test_assert_cart_owner_customer_and_guest_boundaries():
    db = MagicMock()
    cart = SimpleNamespace(guest_session_id='guest-1', customer_id=None, tenant_id='t1')
    with pytest.raises(AppError):
        v1.assert_cart_owner(cart, None, SimpleNamespace(id='other'), db)
    v1.assert_cart_owner(cart, None, SimpleNamespace(id='guest-1'), db)

    customer = SimpleNamespace(email='Buyer@Example.com')
    db.query.return_value.filter_by.return_value.first.return_value = customer
    cart = SimpleNamespace(guest_session_id=None, customer_id='c1', tenant_id='t1')
    actor = SimpleNamespace(email='buyer@example.com')
    v1.assert_cart_owner(cart, actor, None, db)
    db.query.return_value.filter_by.return_value.first.return_value = None
    with pytest.raises(AppError):
        v1.assert_cart_owner(cart, actor, None, db)


def test_assert_cart_owner_missing_cart_is_not_found():
    with pytest.raises(AppError):
        v1.assert_cart_owner(None, None, None, MagicMock())


def test_require_if_match_validates_required_and_integer_and_version():
    obj = SimpleNamespace(version=3)
    with pytest.raises(AppError) as exc:
        v1.require_if_match(obj, None)
    assert exc.value.status_code == 428
    with pytest.raises(AppError) as exc:
        v1.require_if_match(obj, 'abc')
    assert exc.value.status_code == 400
    with pytest.raises(AppError) as exc:
        v1.require_if_match(obj, '2')
    assert exc.value.status_code == 412
    v1.require_if_match(obj, '"3"')
    assert obj.version == 4


def test_idempotency_helpers_cover_create_replay_and_mismatch(monkeypatch):
    db = MagicMock()
    rec = SimpleNamespace(status='COMPLETED', response_body='cached', response_status=200)
    monkeypatch.setattr(v1, 'idem', lambda *args: (rec, True))
    assert v1.idem_start(db, 't1', 'a1', 'ep', 'key', {'x': 1}) is rec
    monkeypatch.setattr(v1, 'idem', lambda *args: (None, True))
    assert v1.idem_start(db, 't1', 'a1', 'ep', 'key', {'x': 1}) is None
    monkeypatch.setattr(v1, 'idem', lambda *args: (None, False))
    with pytest.raises(AppError) as exc:
        v1.idem_start(db, 't1', 'a1', 'ep', 'key', {'x': 2})
    assert exc.value.status_code == 409
    assert v1.idem_start(db, 't1', 'a1', 'ep', None, {'x': 1}) is None


def test_idem_return_finalizes_when_record_exists():
    db = MagicMock()
    rec = SimpleNamespace()
    calls = {}
    def fake_finalize(record, body, status):
        calls.update(record=record, body=body, status=status)
    import app.routes.v1 as module
    old = module.finalize_idem
    module.finalize_idem = fake_finalize
    try:
        body = {'ok': True}
        assert module.idem_return(rec, body, 201, db) is body
        assert calls == {'record': rec, 'body': body, 'status': 201}
        assert module.idem_return(None, body, 200, db) is body
    finally:
        module.finalize_idem = old
