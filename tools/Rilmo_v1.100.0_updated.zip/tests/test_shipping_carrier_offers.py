from app.models.domain import ShippingMethod


def register(client, email):
    r = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'Merchant'})
    assert r.status_code == 200, r.text
    return r.json()


def test_store_can_select_change_carrier_and_publish_free_shipping_offer(client):
    x = register(client, 'shipping-offers@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    r = client.post(f'/v1/shipping-methods?tenant_id={tid}', headers=h, json={
        'name': 'DHL Express', 'carrier_code': 'dhl', 'service_code': 'express',
        'amount_minor': 2500, 'currency': 'USD', 'free_shipping': True,
        'free_shipping_threshold_minor': 10000, 'offer_label': 'Free shipping over $100',
        'estimated_days_min': 2, 'estimated_days_max': 5,
    })
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['carrier_code'] == 'dhl'
    assert body['free_shipping'] is True

    rows = client.get(f'/v1/shipping-methods?tenant_id={tid}', headers=h)
    assert rows.status_code == 200
    assert rows.json()['items'][0]['carrier_name'] == 'DHL'

    rid = body['id']
    r = client.patch(f'/v1/shipping-methods/{rid}?tenant_id={tid}', headers={**h, 'If-Match': '1'}, json={
        'name': 'UPS Standard', 'carrier_code': 'ups', 'service_code': 'standard',
        'amount_minor': 1500, 'currency': 'USD', 'free_shipping': False,
        'offer_label': 'Fast delivery', 'estimated_days_min': 3, 'estimated_days_max': 6,
    })
    assert r.status_code == 200, r.text
    assert r.json()['carrier_code'] == 'ups'
    assert r.json()['free_shipping'] is False


def test_shipping_offer_rules_are_enforced(client):
    x = register(client, 'shipping-rules@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    r = client.post(f'/v1/shipping-methods?tenant_id={tid}', headers=h, json={
        'name': 'Invalid threshold', 'carrier_code': 'dhl', 'amount_minor': 1000,
        'currency': 'USD', 'free_shipping': False, 'free_shipping_threshold_minor': 5000,
    })
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'FREE_SHIPPING_THRESHOLD_REQUIRES_FREE_SHIPPING'

def test_shipping_model_contains_carrier_and_offer_fields(client):
    assert hasattr(ShippingMethod, 'carrier_code')
    assert hasattr(ShippingMethod, 'free_shipping')
    assert hasattr(ShippingMethod, 'free_shipping_threshold_minor')
    assert hasattr(ShippingMethod, 'offer_label')
