import socket
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest
from app.core.errors import AppError
from app.services import workflow_webhooks as ww


def test_validate_endpoint_rejects_host_not_in_allowlist(monkeypatch):
    monkeypatch.setattr(ww, 'get_settings', lambda: SimpleNamespace(APP_WEBHOOK_ALLOWED_HOSTS='good.example.com'))
    with pytest.raises(AppError) as exc:
        ww.validate_endpoint('https://evil.example.com/hook')
    assert exc.value.code == 'WEBHOOK_ENDPOINT_BLOCKED'

def test_validate_endpoint_rejects_when_no_public_address_resolves(monkeypatch):
    monkeypatch.setattr(ww, 'get_settings', lambda: SimpleNamespace(APP_WEBHOOK_ALLOWED_HOSTS=''))
    monkeypatch.setattr(ww.socket, 'getaddrinfo', lambda *a, **k: [])
    with pytest.raises(AppError) as exc:
        ww.validate_endpoint('https://example.com/hook')
    assert exc.value.code == 'WEBHOOK_ENDPOINT_BLOCKED'


def test_materialize_workflow_webhook_is_idempotent_for_same_run_and_step(db_session):
    from app.models.domain import Tenant

    tenant = Tenant(name='WF Webhook Tenant', slug='wf-webhook-tenant')
    db_session.add(tenant)
    db_session.commit()

    event = SimpleNamespace(tenant_id=tenant.id, payload={
        'url': 'https://example.com/hook', 'workflow_run_id': 'run-1', 'step_position': 1, 'payload': {'a': 1},
    })
    first = ww.materialize_workflow_webhook(db_session, event)
    second = ww.materialize_workflow_webhook(db_session, event)
    assert first.id == second.id


def test_recover_stale_workflow_webhook_deliveries_marks_reconciliation_required(db_session):
    from app.models.domain import Tenant, WorkflowWebhookDelivery

    tenant = Tenant(name='Stale WF Tenant', slug='stale-wf-tenant')
    db_session.add(tenant)
    db_session.flush()
    row = WorkflowWebhookDelivery(
        tenant_id=tenant.id, workflow_run_id='run-stale', step_position=1,
        endpoint_url='https://example.com/hook', payload={}, status='PROCESSING',
        attempt_count=1, processing_started_at=datetime.now(timezone.utc) - timedelta(hours=2),
    )
    db_session.add(row)
    db_session.commit()

    count = ww.recover_stale_workflow_webhook_deliveries(db_session, stale_seconds=3600, tenant_id=tenant.id)
    assert count == 1
    db_session.refresh(row)
    assert row.status == 'RECONCILIATION_REQUIRED'
    assert row.processing_started_at is None
    assert 'reconciliation' in row.last_error.lower()

def test_recover_stale_workflow_webhook_deliveries_ignores_recent_processing(db_session):
    from app.models.domain import Tenant, WorkflowWebhookDelivery

    tenant = Tenant(name='Fresh WF Tenant', slug='fresh-wf-tenant')
    db_session.add(tenant)
    db_session.flush()
    row = WorkflowWebhookDelivery(
        tenant_id=tenant.id, workflow_run_id='run-fresh', step_position=1,
        endpoint_url='https://example.com/hook', payload={}, status='PROCESSING',
        attempt_count=1, processing_started_at=datetime.now(timezone.utc),
    )
    db_session.add(row)
    db_session.commit()

    count = ww.recover_stale_workflow_webhook_deliveries(db_session, stale_seconds=3600, tenant_id=tenant.id)
    assert count == 0


def _pending_delivery(db_session, **overrides):
    from app.models.domain import Tenant, WorkflowWebhookDelivery, WorkflowStepRun
    tenant = Tenant(name='Process WF Tenant ' + str(overrides.get('workflow_run_id', 'x')), slug='process-wf-' + str(overrides.get('workflow_run_id', 'x')))
    db_session.add(tenant)
    db_session.flush()
    step = WorkflowStepRun(tenant_id=tenant.id, workflow_run_id=overrides.get('workflow_run_id', 'run-x'),
        position=1, status='RUNNING', step_type='webhook')
    db_session.add(step)
    defaults = dict(tenant_id=tenant.id, workflow_run_id='run-x', step_position=1,
        endpoint_url='https://example.com/hook', payload={'k': 'v'}, status='PENDING', attempt_count=0)
    defaults.update(overrides)
    row = WorkflowWebhookDelivery(**defaults)
    db_session.add(row)
    db_session.commit()
    return row

def test_process_workflow_webhook_deliveries_marks_succeeded_on_2xx(db_session, monkeypatch):
    row = _pending_delivery(db_session, workflow_run_id='run-success')
    monkeypatch.setattr(ww, 'validate_endpoint', lambda url: url)
    monkeypatch.setattr(ww, '_post_pinned', lambda *a, **k: (200, {}, b'ok'))
    sent = ww.process_workflow_webhook_deliveries(db_session, batch_size=10)
    assert sent == 1
    db_session.refresh(row)
    assert row.status == 'SUCCEEDED'
    assert row.delivered_at is not None
    assert row.last_error is None

def test_process_workflow_webhook_deliveries_retries_on_non_2xx_below_max_attempts(db_session, monkeypatch):
    row = _pending_delivery(db_session, workflow_run_id='run-retry')
    monkeypatch.setattr(ww, 'validate_endpoint', lambda url: url)
    monkeypatch.setattr(ww, '_post_pinned', lambda *a, **k: (500, {}, b'error'))
    monkeypatch.setattr(ww, 'get_settings', lambda: SimpleNamespace(APP_WEBHOOK_MAX_ATTEMPTS=8))
    sent = ww.process_workflow_webhook_deliveries(db_session, batch_size=10)
    assert sent == 0
    db_session.refresh(row)
    assert row.status == 'RETRY'
    assert 'HTTP 500' in row.last_error
    assert row.next_attempt_at is not None

def test_process_workflow_webhook_deliveries_marks_failed_after_max_attempts(db_session, monkeypatch):
    row = _pending_delivery(db_session, workflow_run_id='run-failed', attempt_count=7)
    monkeypatch.setattr(ww, 'validate_endpoint', lambda url: url)
    monkeypatch.setattr(ww, '_post_pinned', lambda *a, **k: (500, {}, b'error'))
    monkeypatch.setattr(ww, 'get_settings', lambda: SimpleNamespace(APP_WEBHOOK_MAX_ATTEMPTS=8))
    sent = ww.process_workflow_webhook_deliveries(db_session, batch_size=10)
    assert sent == 0
    db_session.refresh(row)
    assert row.status == 'FAILED'
    assert row.next_attempt_at is None
