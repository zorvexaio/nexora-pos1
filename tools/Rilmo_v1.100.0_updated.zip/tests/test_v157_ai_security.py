from app.core.config import Settings


def test_server_only_ai_rejects_external_endpoint_in_production():
    s = Settings(ENVIRONMENT="production", APP_VERSION="1.58.0", LEGAL_ENTITY_NAME="Rilmo",
                 PRIVACY_CONTACT_EMAIL="privacy@example.com", PRIVACY_POLICY_VERSION="1",
                 TERMS_EFFECTIVE_DATE="2026-08-19", DATABASE_URL="postgresql+psycopg://u:p@db/x",
                 SECRET_KEY="x"*40, ENCRYPTION_KEY="y"*40, WEBHOOK_SECRET="z"*40,
                 COOKIE_SECURE=True, ALLOWED_HOSTS="shop.example", CORS_ORIGINS="https://shop.example",
                 TRUSTED_ORIGINS="https://shop.example", FORWARDED_ALLOW_IPS="10.0.0.1",
                 PUBLIC_BASE_URL="https://shop.example", S3_BUCKET="b", S3_ACCESS_KEY_ID="a",
                 S3_SECRET_ACCESS_KEY="s", PADDLE_WEBHOOK_SECRET="p", GOOGLE_CLIENT_ID="g",
                 GOOGLE_CLIENT_SECRET="g", SMTP_HOST="smtp", SMTP_USERNAME="u", SMTP_PASSWORD="p",
                 MAIL_FROM="noreply@example.com", REDIS_URL="redis://redis:6379/0",
                 APP_WEBHOOK_ALLOWED_HOSTS="hooks.example", AI_BASE_URL="https://evil.example/ollama",
                 AI_SERVER_ONLY=True)
    try:
        s.validate_runtime()
    except RuntimeError as exc:
        assert 'internal Ollama endpoint' in str(exc)
    else:
        raise AssertionError('external AI endpoint was accepted in server-only production mode')


def test_server_only_ai_accepts_internal_ollama_endpoint():
    s = Settings(ENVIRONMENT="production", APP_VERSION="1.58.0", LEGAL_ENTITY_NAME="Rilmo",
                 PRIVACY_CONTACT_EMAIL="privacy@example.com", PRIVACY_POLICY_VERSION="1",
                 TERMS_EFFECTIVE_DATE="2026-08-19", DATABASE_URL="postgresql+psycopg://u:p@db/x",
                 SECRET_KEY="x"*40, ENCRYPTION_KEY="y"*40, WEBHOOK_SECRET="z"*40,
                 COOKIE_SECURE=True, ALLOWED_HOSTS="shop.example", CORS_ORIGINS="https://shop.example",
                 TRUSTED_ORIGINS="https://shop.example", FORWARDED_ALLOW_IPS="10.0.0.1",
                 PUBLIC_BASE_URL="https://shop.example", S3_BUCKET="b", S3_ACCESS_KEY_ID="a",
                 S3_SECRET_ACCESS_KEY="s", PADDLE_WEBHOOK_SECRET="p", GOOGLE_CLIENT_ID="g",
                 GOOGLE_CLIENT_SECRET="g", SMTP_HOST="smtp", SMTP_USERNAME="u", SMTP_PASSWORD="p",
                 MAIL_FROM="noreply@example.com", REDIS_URL="redis://redis:6379/0",
                 APP_WEBHOOK_ALLOWED_HOSTS="hooks.example", AI_BASE_URL="http://ollama:11434",
                 AI_SERVER_ONLY=True)
    try:
        s.validate_runtime()
    except RuntimeError as exc:
        if 'internal Ollama endpoint' in str(exc):
            raise AssertionError(str(exc))
