from app.services.core import bind_provider_tenant, resolve_provider_tenant
from app.models.domain import ProviderTenantBinding
from app.core.database import SessionLocal


def test_provider_reference_binding_is_tenant_routed(client):
    a = client.post('/v1/auth/register', json={'email': 'bind-a@example.com', 'password': 'VerySecurePassword123!'}).json()
    b = client.post('/v1/auth/register', json={'email': 'bind-b@example.com', 'password': 'VerySecurePassword123!'}).json()
    db = SessionLocal()
    bind_provider_tenant(db, provider='iyzico', external_id='payment-A', tenant_id=a['tenant']['id'])
    db.commit()
    assert resolve_provider_tenant(db, provider='iyzico', external_id='payment-A') == a['tenant']['id']
    assert resolve_provider_tenant(db, provider='iyzico', external_id='payment-B') is None
    db.close()


def test_provider_reference_rebinding_to_other_tenant_is_rejected(client):
    from app.core.errors import AppError
    a = client.post('/v1/auth/register', json={'email': 'bind-c@example.com', 'password': 'VerySecurePassword123!'}).json()
    b = client.post('/v1/auth/register', json={'email': 'bind-d@example.com', 'password': 'VerySecurePassword123!'}).json()
    db = SessionLocal()
    bind_provider_tenant(db, provider='paytr', external_id='merchant-oid-1', tenant_id=a['tenant']['id'])
    db.commit()
    try:
        bind_provider_tenant(db, provider='paytr', external_id='merchant-oid-1', tenant_id=b['tenant']['id'])
        assert False, 'expected provider reference tenant conflict'
    except AppError as exc:
        assert exc.code == 'PROVIDER_REFERENCE_TENANT_CONFLICT'
    finally:
        db.rollback(); db.close()


def test_payment_creation_persists_provider_route_binding(client, monkeypatch):
    from app.services import payment_providers
    from app.services.payment_providers import PaymentCreateResult
    user = client.post('/v1/auth/register', json={'email': 'bind-pay@example.com', 'password': 'VerySecurePassword123!'}).json()
    tid = user['tenant']['id']; h={'Authorization':'Bearer '+user['access_token']}
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug':'bind-pay','title':'Bind Pay','status':'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku':'BP-1','price_amount_minor':1000,'currency':'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=2&reason=test", headers=h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id':v['id'],'quantity':1})
    o = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id':c['id']}).json()
    monkeypatch.setattr(payment_providers.MockProvider, 'create_intent', lambda self, **kw: PaymentCreateResult(provider_payment_id='mock-route-1', client_secret='cs', raw={'id':'mock-route-1'}, redirect_url=None))
    r=client.post('/v1/payments/intents', params={'tenant_id':tid}, headers=h, json={'order_id':o['id'],'amount_minor':1000,'currency':'USD','provider':'mock','idempotency_key':'bind-pay-1'})
    assert r.status_code==200, r.text
    db=SessionLocal()
    assert db.query(ProviderTenantBinding).filter_by(provider='mock',external_id='mock-route-1',tenant_id=tid).count()==1
    db.close()
