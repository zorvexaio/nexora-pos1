from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def test_platform_ecosystem_models_present():
    text = (ROOT / 'app/models/domain.py').read_text()
    for name in ['AppListing', 'AppReview', 'WorkflowStepRun', 'CommerceEventSchema', 'CommerceEventSubscription']:
        assert f'class {name}(' in text

def test_platform_ecosystem_routes_present():
    text = (ROOT / 'app/routes/worldclass.py').read_text()
    for route in ['/public/apps/catalog', '/apps/{app_id}/listing', '/apps/{app_id}/reviews', '/workflows/{workflow_id}/execute', '/commerce/events/schemas']:
        assert route in text

def test_workflow_engine_is_fail_closed():
    text = (ROOT / 'app/services/platform_ecosystem.py').read_text()
    assert 'ALLOWED_STEPS' in text and 'WEBHOOK' in text
    assert "startswith('https://')" in text

def test_workflow_steps_have_explicit_run_state():
    text = (ROOT / 'app/models/domain.py').read_text()
    assert 'class WorkflowStepRun(Base):' in text
    assert "UniqueConstraint('workflow_run_id', 'position')" in text

def test_rls_migration_covers_new_tenant_tables():
    text = (ROOT / 'alembic/versions/20260819_0045_platform_ecosystem.py').read_text()
    for table in ['app_reviews', 'workflow_step_runs', 'commerce_event_subscriptions']:
        assert f"'{table}'" in text
    assert 'ENABLE ROW LEVEL SECURITY' in text
    assert 'FORCE ROW LEVEL SECURITY' in text
    assert 'CREATE POLICY' in text

def test_public_marketplace_never_returns_oauth_secrets():
    text = (ROOT / 'app/routes/worldclass.py').read_text()
    section = text[text.find("@router.get('/public/apps/catalog')"):text.find("@router.post('/apps/{app_id}/listing')")]
    assert 'client_secret' not in section
    assert 'access_token' not in section


def register_local(client, email):
    response = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'Platform'})
    assert response.status_code == 200, response.text
    return response.json()


def test_workflow_execution_persists_per_step_and_is_auditable(client):
    from app.core.database import SessionLocal
    from app.models.domain import WorkflowDefinition
    x = register_local(client, 'workflow-v150@example.com')
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        w = WorkflowDefinition(
            tenant_id=tid,
            slug='welcome-coupon',
            name='Welcome Coupon',
            trigger_event='customer.created',
            enabled=True,
            steps=[{'type':'CREATE_COUPON','code':'WELCOME150','percentage_bps':1500,'usage_limit':100}],
        )
        db.add(w)
        db.commit()
        workflow_id = w.id
    finally:
        db.close()
    res = client.post(f'/v1/workflows/{workflow_id}/execute', params={'tenant_id': tid}, headers=h, json={'input_payload': {}})
    assert res.status_code == 200, res.text
    run_id = res.json()['id']
    assert res.json()['status'] == 'COMPLETED'
    steps = client.get(f'/v1/workflows/{workflow_id}/runs/{run_id}/steps', params={'tenant_id': tid}, headers=h)
    assert steps.status_code == 200
    assert steps.json()['items'][0]['status'] == 'COMPLETED'
    assert steps.json()['items'][0]['step_type'] == 'CREATE_COUPON'


def test_public_app_marketplace_catalog_is_read_only_and_secret_free(client):
    from datetime import datetime, timezone
    from app.core.database import SessionLocal
    from app.models.domain import AppDefinition, AppListing
    db = SessionLocal()
    try:
        app_def = AppDefinition(
            name='Global Analytics', slug='global-analytics-v150', client_id='ugc-test-v150-client',
            client_secret_hash='hash-only', redirect_uris=[], scopes=['orders:read'], status='APPROVED', publisher_name='Rilmo Labs')
        db.add(app_def); db.flush()
        db.add(AppListing(
            app_id=app_def.id, category='ANALYTICS', description='Executive analytics', pricing_model='FREE',
            monthly_price_minor=0, currency='USD', supported_locales=['ar','en'], supported_countries=['TR','SA'],
            featured=True, status='PUBLISHED', published_at=datetime.now(timezone.utc)))
        db.commit()
    finally:
        db.close()
    res = client.get('/v1/public/apps/catalog', params={'country_code':'TR','locale':'ar'})
    assert res.status_code == 200, res.text
    item = res.json()['items'][0]
    assert item['slug'] == 'global-analytics-v150'
    assert 'client_secret' not in item and 'access_token' not in item
