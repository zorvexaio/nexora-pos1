from app.core.database import SessionLocal
from app.models.domain import Entitlement


def register(client, email):
    r = client.post('/v1/auth/register', json={
        'email': email,
        'password': 'VerySecurePassword123!',
        'display_name': 'API Key Test',
    })
    assert r.status_code == 200, r.text
    return r.json()


def grant_api_access(tenant_id):
    db = SessionLocal()
    try:
        db.add(Entitlement(
            tenant_id=tenant_id,
            feature_key='api_access',
            value_type='boolean',
            value_boolean=True,
            value_integer=None,
            version=1,
        ))
        db.commit()
    finally:
        db.close()


def test_api_key_creation_requires_api_access_entitlement(client):
    x = register(client, 'api-entitlement-v1968@example.com')
    tid = x['tenant']['id']
    h = {'Authorization': 'Bearer ' + x['access_token']}
    r = client.post('/v1/api-keys', params={'tenant_id': tid}, headers=h,
                    json={'name': 'integration', 'scopes': ['tenant.read']})
    assert r.status_code == 402
    assert r.json()['detail']['error']['code'] == 'PLAN_FEATURE_REQUIRED'


def test_api_key_creation_rejects_unsupported_scope(client):
    x = register(client, 'api-scope-v1968@example.com')
    tid = x['tenant']['id']
    grant_api_access(tid)
    h = {'Authorization': 'Bearer ' + x['access_token']}
    r = client.post('/v1/api-keys', params={'tenant_id': tid}, headers=h,
                    json={'name': 'integration', 'scopes': ['*']})
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'API_KEY_SCOPE_INVALID'


def test_api_key_creation_allows_known_scope_when_entitled(client):
    x = register(client, 'api-allowed-v1968@example.com')
    tid = x['tenant']['id']
    grant_api_access(tid)
    h = {'Authorization': 'Bearer ' + x['access_token']}
    r = client.post('/v1/api-keys', params={'tenant_id': tid}, headers=h,
                    json={'name': 'integration', 'scopes': ['tenant.read', 'tenant.read']})
    assert r.status_code == 200, r.text
    assert r.json()['scopes'] == ['tenant.read']
