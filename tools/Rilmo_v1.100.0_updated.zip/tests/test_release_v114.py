from app.main import app

def _iter_routes(routes):
    for route in routes:
        original = getattr(route, 'original_router', None)
        if original is not None and hasattr(original, 'routes'):
            yield from _iter_routes(original.routes)
            continue
        yield route

def test_v114_return_routes_are_registered():
    routes = {(method, r.path) for r in _iter_routes(app.routes) if getattr(r, 'path', '').startswith('/v1/') for method in getattr(r, 'methods', set()) if method not in {'HEAD', 'OPTIONS'}}
    assert ('POST', '/v1/orders/{order_id}/returns') in routes
    assert ('GET', '/v1/orders/{order_id}/returns') in routes
    assert ('POST', '/v1/returns/{return_id}/decision') in routes
    assert ('POST', '/v1/returns/{return_id}/refund') in routes
