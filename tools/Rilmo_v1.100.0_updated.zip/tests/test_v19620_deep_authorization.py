from tests.test_p0 import register


def _auth(client, email, password='VerySecurePassword123!'):
    r = client.post('/v1/auth/login', json={'email': email, 'password': password})
    assert r.status_code == 200, r.text
    return r


def test_viewer_cannot_start_merchant_phone_or_identity_verification(client):
    owner = register(client, 'owner-authz-v19620@example.com')
    tenant_id = owner['tenant']['id']
    viewer = register(client, 'viewer-authz-v19620@example.com')
    # The newly registered user's tenant is separate; use its user identity in the owner's tenant.
    r = client.post('/v1/auth/login', json={'email': 'owner-authz-v19620@example.com', 'password': 'VerySecurePassword123!'})
    assert r.status_code == 200
    owner_db = __import__('app.core.database', fromlist=['SessionLocal']).SessionLocal()
    try:
        from app.models.domain import User
        target = owner_db.query(User).filter_by(email='viewer-authz-v19620@example.com').first()
        assert target is not None
    finally:
        owner_db.close()
    csrf = client.cookies.get('csrf_token')
    headers = {'X-CSRF-Token': csrf} if csrf else {}
    add = client.post(f'/v1/members?tenant_id={tenant_id}', headers=headers, json={'email': 'viewer-authz-v19620@example.com', 'role': 'viewer'})
    assert add.status_code == 200, add.text
    _auth(client, 'viewer-authz-v19620@example.com')
    csrf = client.cookies.get('csrf_token')
    headers = {'X-CSRF-Token': csrf} if csrf else {}
    phone = client.post(f'/v1/merchant/phone/send?tenant_id={tenant_id}', headers=headers, json={'phone': '+905551112233'})
    assert phone.status_code == 403, phone.text
    identity = client.post(f'/v1/merchant/identity/start?tenant_id={tenant_id}', headers=headers,
                           json={'country_code': 'TR', 'full_name': 'Viewer User', 'confirm_terms': True})
    assert identity.status_code == 403, identity.text


def test_whatsapp_webhook_rejects_invalid_json_after_signature(client):
    import hashlib, hmac
    from app.core.database import SessionLocal
    from app.core.security import encrypt_secret, token_hash
    from app.models.domain import WhatsAppChannel

    x = register(client, 'whatsapp-invalid-json-v19620@example.com')
    tenant_id = x['tenant']['id']
    secret = 'invalid-json-secret-v19620'
    db = SessionLocal()
    try:
        db.add(WhatsAppChannel(tenant_id=tenant_id, phone_number_id='123456',
            access_token_encrypted=encrypt_secret('access-token'), app_secret_encrypted=encrypt_secret(secret),
            verify_token_hash=token_hash('verify-token'), status='ACTIVE'))
        db.commit()
    finally:
        db.close()
    raw = b'not-json'
    sig = 'sha256=' + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    r = client.post(f'/v1/whatsapp/webhook/{tenant_id}', content=raw,
                    headers={'X-Hub-Signature-256': sig, 'Content-Type': 'application/json'})
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'WHATSAPP_WEBHOOK_INVALID_JSON'
