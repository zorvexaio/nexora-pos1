from datetime import datetime, timezone
from app.core.database import SessionLocal
from app.core.auth import current_platform_compliance_officer
from app.main import app
from app.models.domain import User, PrivacyRequest, PrivacyIncident, PrivacyTransferRegister


def _compliance_officer():
    from types import SimpleNamespace
    db = SessionLocal()
    u = User(email=f'officer-{datetime.now().timestamp()}@example.com', password_hash='x')
    db.add(u)
    db.commit()
    db.refresh(u)
    user_id = u.id
    db.close()
    return SimpleNamespace(user_id=user_id, platform_role='compliance_officer')


def _as_officer(client_call):
    officer = _compliance_officer()
    app.dependency_overrides[current_platform_compliance_officer] = lambda: officer
    try:
        return client_call(officer)
    finally:
        app.dependency_overrides.pop(current_platform_compliance_officer, None)


# --- mark export ready --------------------------------------------------

def test_mark_privacy_export_ready_updates_status(client):
    db = SessionLocal()
    row = PrivacyRequest(request_type='PORTABILITY', status='PROCESSING')
    db.add(row)
    db.commit()
    request_id = row.id
    db.close()

    def call(officer):
        return client.post(f'/v1/platform/privacy/requests/{request_id}/ready')
    r = _as_officer(call)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['status'] == 'READY'
    assert body['ready_at']

def test_mark_privacy_export_ready_missing_request_returns_not_found(client):
    def call(officer):
        return client.post('/v1/platform/privacy/requests/does-not-exist/ready')
    r = _as_officer(call)
    assert r.status_code == 404

def test_mark_privacy_export_ready_wrong_request_type_returns_not_found(client):
    db = SessionLocal()
    row = PrivacyRequest(request_type='ERASURE', status='PROCESSING')
    db.add(row)
    db.commit()
    request_id = row.id
    db.close()

    def call(officer):
        return client.post(f'/v1/platform/privacy/requests/{request_id}/ready')
    r = _as_officer(call)
    assert r.status_code == 404


# --- privacy incident update -----------------------------------------

def test_update_privacy_incident_valid_transition_succeeds(client):
    db = SessionLocal()
    row = PrivacyIncident(jurisdiction='EU', status='DETECTED', severity='HIGH')
    db.add(row)
    db.commit()
    incident_id = row.id
    db.close()

    def call(officer):
        return client.post(f'/v1/platform/privacy/incidents/{incident_id}', json={'status': 'CONTAINED', 'containment_notes': 'Isolated affected systems'})
    r = _as_officer(call)
    assert r.status_code == 200, r.text
    assert r.json()['status'] == 'CONTAINED'

def test_update_privacy_incident_rejects_invalid_transition(client):
    db = SessionLocal()
    row = PrivacyIncident(jurisdiction='EU', status='DETECTED', severity='HIGH')
    db.add(row)
    db.commit()
    incident_id = row.id
    db.close()

    def call(officer):
        return client.post(f'/v1/platform/privacy/incidents/{incident_id}', json={'status': 'CLOSED'})
    r = _as_officer(call)
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'PRIVACY_INCIDENT_TRANSITION_INVALID'

def test_update_privacy_incident_rejects_invalid_status_value(client):
    db = SessionLocal()
    row = PrivacyIncident(jurisdiction='EU', status='DETECTED', severity='LOW')
    db.add(row)
    db.commit()
    incident_id = row.id
    db.close()

    def call(officer):
        return client.post(f'/v1/platform/privacy/incidents/{incident_id}', json={'status': 'NOT_A_REAL_STATUS'})
    r = _as_officer(call)
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'PRIVACY_INCIDENT_STATUS_INVALID'

def test_update_privacy_incident_missing_returns_not_found(client):
    def call(officer):
        return client.post('/v1/platform/privacy/incidents/does-not-exist', json={'status': 'CONTAINED'})
    r = _as_officer(call)
    assert r.status_code == 404


# --- transfer route registration ---------------------------------------

def test_register_transfer_route_requires_core_fields(client):
    def call(officer):
        return client.post('/v1/platform/privacy/transfer-routes', json={})
    r = _as_officer(call)
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'PRIVACY_TRANSFER_INPUT_INVALID'

def test_register_transfer_route_requires_evidence_for_strict_mechanism(client):
    def call(officer):
        return client.post('/v1/platform/privacy/transfer-routes', json={
            'processor_name': 'Acme Cloud', 'destination_country': 'US',
            'mechanism': 'standard_contract', 'purpose': 'hosting', 'data_categories': ['identity'],
        })
    r = _as_officer(call)
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'PRIVACY_TRANSFER_EVIDENCE_REQUIRED'

def test_register_transfer_route_succeeds_with_full_evidence(client):
    def call(officer):
        return client.post('/v1/platform/privacy/transfer-routes', json={
            'processor_name': 'Acme Cloud', 'destination_country': 'us',
            'mechanism': 'standard_contract', 'purpose': 'hosting', 'data_categories': ['identity'],
            'contract_reference': 'SC-001', 'signed_at': '2026-01-01T00:00:00Z', 'signatory_authority_reference': 'AUTH-1',
        })
    r = _as_officer(call)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['approval_status'] == 'APPROVED'
    assert body['destination_country'] == 'US'

def test_register_transfer_route_without_strict_mechanism_auto_approves(client):
    def call(officer):
        return client.post('/v1/platform/privacy/transfer-routes', json={
            'processor_name': 'Acme Cloud', 'destination_country': 'GB',
            'mechanism': 'adequacy_decision', 'purpose': 'hosting', 'data_categories': ['identity'],
        })
    r = _as_officer(call)
    assert r.status_code == 200, r.text
    assert r.json()['approval_status'] == 'APPROVED'

def test_register_transfer_route_rejects_invalid_country_code(client):
    def call(officer):
        return client.post('/v1/platform/privacy/transfer-routes', json={
            'processor_name': 'Acme Cloud', 'destination_country': 'USA',
            'mechanism': 'adequacy_decision', 'purpose': 'hosting', 'data_categories': ['identity'],
        })
    r = _as_officer(call)
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'PRIVACY_TRANSFER_INPUT_INVALID'
