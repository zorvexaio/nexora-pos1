from datetime import datetime, timezone, timedelta

from tests.test_p0 import register


def headers(x):
    return {'Authorization': f"Bearer {x['access_token']}"}


def test_order_item_cost_snapshot_is_model_field(db_session):
    from app.models.domain import OrderItem
    assert 'cost_amount_minor' in OrderItem.__table__.columns
    assert OrderItem.__table__.c.cost_amount_minor.nullable is True


def test_profitability_uses_historical_cost_snapshot_not_current_catalog_cost(client):
    from app.core.database import SessionLocal
    from app.models.domain import Order, OrderItem, Product, ProductVariant

    x = register(client, 'profitability-v1982@example.com')
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        product = Product(tenant_id=tid, slug='historical-cost-product', title='Historical Cost Product', status='PUBLISHED')
        db.add(product); db.flush()
        variant = ProductVariant(tenant_id=tid, product_id=product.id, sku='HIST-COST-1',
                                 price_amount_minor=1000, cost_amount_minor=300, currency='USD', status='ACTIVE')
        db.add(variant); db.flush()
        order = Order(tenant_id=tid, order_number='ORD-HIST-COST-1', status='CONFIRMED',
                      payment_status='CAPTURED', fulfillment_status='FULFILLED', currency='USD',
                      subtotal_minor=2000, discount_minor=0, shipping_minor=0, tax_minor=0,
                      fee_minor=0, total_minor=2000, created_at=datetime.now(timezone.utc))
        db.add(order); db.flush()
        db.add(OrderItem(tenant_id=tid, order_id=order.id, variant_id=variant.id,
                         sku_snapshot=variant.sku, title_snapshot=product.title, quantity=2,
                         unit_price_minor=1000, cost_amount_minor=300, discount_minor=0,
                         tax_minor=0, total_minor=2000, currency='USD'))
        variant.cost_amount_minor = 900
        db.commit()
    finally:
        db.close()

    r = client.get(f'/v1/analytics/profitability?tenant_id={tid}&days=30', headers=headers(x))
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['merchandise_revenue_minor'] == 2000
    assert body['known_cogs_minor'] == 600
    assert body['gross_profit_minor'] == 1400
    assert body['gross_margin_bps'] == 7000
    assert body['cost_coverage_bps'] == 10000


def test_profitability_surfaces_missing_historical_cost_instead_of_fabricating(client):
    from app.core.database import SessionLocal
    from app.models.domain import Order, OrderItem, Product, ProductVariant

    x = register(client, 'profitability-missing-cost-v1982@example.com')
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        product = Product(tenant_id=tid, slug='legacy-cost-product', title='Legacy Cost Product', status='PUBLISHED')
        db.add(product); db.flush()
        variant = ProductVariant(tenant_id=tid, product_id=product.id, sku='LEGACY-COST-1',
                                 price_amount_minor=1500, cost_amount_minor=500, currency='USD', status='ACTIVE')
        db.add(variant); db.flush()
        order = Order(tenant_id=tid, order_number='ORD-MISSING-COST-1', status='CONFIRMED',
                      payment_status='CAPTURED', fulfillment_status='FULFILLED', currency='USD',
                      subtotal_minor=1500, discount_minor=0, shipping_minor=0, tax_minor=0,
                      fee_minor=0, total_minor=1500, created_at=datetime.now(timezone.utc))
        db.add(order); db.flush()
        db.add(OrderItem(tenant_id=tid, order_id=order.id, variant_id=variant.id,
                         sku_snapshot=variant.sku, title_snapshot=product.title, quantity=1,
                         unit_price_minor=1500, cost_amount_minor=None, discount_minor=0,
                         tax_minor=0, total_minor=1500, currency='USD'))
        db.commit()
    finally:
        db.close()

    r = client.get(f'/v1/analytics/profitability?tenant_id={tid}&days=30', headers=headers(x))
    assert r.status_code == 200, r.text
    body = r.json()
    assert body['known_cogs_minor'] == 0
    assert body['gross_profit_minor'] is None
    assert body['gross_margin_bps'] is None
    assert body['known_gross_profit_minor'] == 1500
    assert body['missing_cost_units'] == 1
    assert body['cost_coverage_bps'] == 0
