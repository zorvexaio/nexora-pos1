from datetime import datetime, timezone

def test_ucp_agent_runtime_identity_and_profile_binding(client):
    reg = client.post('/v1/auth/register', json={'email':'ucp-agent-runtime-v181@example.com','password':'VerySecurePassword123!','display_name':'Agent Runtime'})
    assert reg.status_code == 200, reg.text
    h={'Authorization':'Bearer '+reg.json()['access_token']}
    tid=reg.json()['tenant']['id']
    host='ucp-agent-runtime-v181.example.test'
    from app.core.database import SessionLocal
    from app.models.domain import Domain, Storefront, Tenant, Product, ProductVariant
    db=SessionLocal()
    try:
        sf=db.query(Storefront).filter_by(tenant_id=tid).first()
        db.query(Tenant).filter_by(id=tid).update({'status':'ACTIVE'})
        db.add(Domain(tenant_id=tid, storefront_id=sf.id, hostname=host, verified_at=datetime.now(timezone.utc), is_primary=True))
        product=Product(tenant_id=tid, slug='runtime-agent-product', title='Runtime Agent Product', status='PUBLISHED'); db.add(product); db.flush()
        variant=ProductVariant(tenant_id=tid, product_id=product.id, sku='RUNTIME-1', price_amount_minor=100, currency='USD', status='ACTIVE'); db.add(variant); db.commit(); variant_id=variant.id
    finally:
        db.close()
    created=client.post('/v1/agents', params={'tenant_id':tid}, headers=h, json={'client_id':'runtime-agent','slug':'runtime-agent','name':'Runtime Agent','scopes':['checkout:complete']})
    assert created.status_code == 200, created.text
    secret=created.json()['client_secret']
    listed=client.get('/v1/agents', params={'tenant_id':tid}, headers=h)
    assert listed.status_code == 200
    assert 'client_secret' not in listed.json()['items'][0] and 'client_secret_hash' not in listed.json()['items'][0]
    profile=client.get(f'/v1/public/storefront/{host}/.well-known/agent/runtime-agent.json')
    assert profile.status_code == 200, profile.text
    assert profile.json()['agent_client_id']=='runtime-agent'
    checkout=client.post(f'/v1/public/storefront/{host}/ucp/checkouts', json={'external_session_id':'runtime-1','currency':'USD','line_items':[{'variant_id':variant_id,'quantity':1}],'buyer':{'country_code':'US'}})
    assert checkout.status_code == 200, checkout.text
    headers={'Authorization':'Bearer '+secret,'UCP-Agent':f'profile="https://{host}/.well-known/agent/runtime-agent.json"','Idempotency-Key':'runtime-ucp-1'}
    complete=client.post(f'/v1/public/storefront/{host}/ucp/checkouts/runtime-1/complete', params={'agent_client_id':'runtime-agent'}, headers=headers)
    assert complete.status_code == 200, complete.text
    assert complete.json()['status'].upper()=='COMPLETED'
