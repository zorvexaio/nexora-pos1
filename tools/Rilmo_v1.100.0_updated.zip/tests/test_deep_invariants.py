import ast, pathlib, re
from datetime import datetime, timezone, timedelta
ROOT = pathlib.Path(__file__).resolve().parents[1]

def test_no_production_sqlite_fallback():
    text = (ROOT / 'app/core/config.py').read_text()
    assert 'SQLite is forbidden in production' in text

def test_canonical_event_aliases_are_not_emitted_by_core():
    text = (ROOT / 'app/services/core.py').read_text()
    assert 'payment_intent.created' in text
    assert 'payment.intent.created' in text

def test_audit_chain_is_tenant_scoped():
    text = (ROOT / 'app/services/core.py').read_text()
    assert 'AuditEvent.tenant_id' in text and 'tenant_id' in text and 'filter' in text

def test_worker_has_claim_state_and_dlq():
    text = (ROOT / 'app/worker.py').read_text()
    assert 'ev.status' in text and 'PROCESSING' in text
    assert 'DeadLetterEvent' in text
    assert 'next_attempt_at' in text

def test_transaction_matrix_is_documented():
    docs = (ROOT / 'docs').read_text() if (ROOT / 'docs').is_file() else ''
    deep = (ROOT / 'docs/DEEP_AUDIT_REPORT.md').read_text()
    assert 'transaction' in deep.lower()

def test_all_models_have_primary_key():
    mod = ast.parse((ROOT / 'app/models/domain.py').read_text())
    classes = [n for n in mod.body if isinstance(n, ast.ClassDef)]
    for cls in classes:
        if any((isinstance(x, ast.Assign) and any((isinstance(t, ast.Name) and t.id == '__tablename__' for t in x.targets)) for x in cls.body)):
            src = ast.get_source_segment((ROOT / 'app/models/domain.py').read_text(), cls) or ''
            assert 'primary_key=True' in src, cls.name

def test_no_plaintext_secret_serialization_marker():
    text = (ROOT / 'app/routes/v1.py').read_text()
    # token_hash usage moved out to the individual route modules in the
    # Phase 3 split; v1.py itself still defines the sensitive-field marker.
    routes_dir_text = ''.join((p.read_text() for p in (ROOT / 'app/routes').glob('*.py')))
    assert 'SENSITIVE_FIELDS' in text and 'token_hash' in routes_dir_text

def test_p0_gate_t1_t20_inventory_exists():
    spec = (ROOT / 'docs/ULTIMATE_DEEP_AUDIT.md').read_text()
    for x in range(1, 21):
        assert f'T{x}' in spec

def test_queue_poison_reaches_dlq():
    from app.core.database import SessionLocal
    from app.models.domain import OutboxEvent, DeadLetterEvent, Tenant
    from app.worker import run_once
    db = SessionLocal()
    tenant = Tenant(slug='poison-test', name='Poison Test')
    db.add(tenant)
    db.flush()
    ev = OutboxEvent(tenant_id=tenant.id, aggregate_type='test', aggregate_id='poison', event_type='unknown.poison', payload={}, status='PENDING', attempt_count=0)
    db.add(ev)
    db.commit()
    db.close()
    run_once(max_attempts=1)
    db = SessionLocal()
    assert db.query(DeadLetterEvent).filter_by(source_event_id=ev.id).count() == 1
    db.close()

def test_capture_posts_balanced_merchant_settlement_ledger(client):
    x = client.post('/v1/auth/register', json={'email': 'ledger-balance@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    pi = client.post('/v1/payments/intents', headers=h, params={'tenant_id': tid}, json={'amount_minor': 250, 'currency': 'USD', 'provider': 'mock'}).json()
    assert client.post(f"/v1/payments/{pi['id']}/capture", headers=h, params={'tenant_id': tid}).status_code == 200
    from app.core.database import SessionLocal
    from app.models.domain import JournalEntry, JournalLine
    db = SessionLocal()
    je = db.query(JournalEntry).filter_by(tenant_id=tid, reference_type='merchant_sale', reference_id=pi['id']).first()
    assert je
    d, c = db.query(__import__('sqlalchemy').func.sum(JournalLine.debit_minor), __import__('sqlalchemy').func.sum(JournalLine.credit_minor)).filter_by(journal_entry_id=je.id).one()
    assert int(d) == 250 and int(c) == 250
    db.close()

def test_rls_bypass_guards_are_not_client_settable():
    from pathlib import Path
    text = Path('alembic/versions/20260816_0013_rls_bypass_elimination.py').read_text()
    assert "current_setting('app.worker', true) = 'on'" not in text.split('def upgrade():', 1)[1].split('def downgrade():', 1)[0]
    assert 'provider_ingest_events' in text

def test_unresolved_provider_event_uses_quarantine_table():
    from app.models.domain import ProviderIngestEvent
    assert ProviderIngestEvent.__tablename__ == 'provider_ingest_events'
    assert not hasattr(ProviderIngestEvent, 'tenant_id')

def test_payment_operation_serializes_different_effects(client):
    from app.core.database import SessionLocal
    from app.models.domain import PaymentIntent
    from app.services.core import begin_payment_operation
    from app.core.errors import AppError
    import pytest
    x = client.post('/v1/auth/register', json={'email': 'op-lock@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    pi = client.post('/v1/payments/intents', headers=h, params={'tenant_id': tid}, json={'amount_minor': 250, 'currency': 'USD', 'provider': 'mock'}).json()
    db = SessionLocal()
    op, state = begin_payment_operation(db, tid, pi['id'], 'CAPTURE', 'client-key-1', amount_minor=250, currency='USD')
    db.commit()
    assert state == 'CREATED'
    with pytest.raises(AppError) as exc:
        begin_payment_operation(db, tid, pi['id'], 'CAPTURE', 'client-key-2', amount_minor=250, currency='USD')
    assert exc.value.detail['error']['code'] == 'PAYMENT_OPERATION_IN_PROGRESS'
    same, state2 = begin_payment_operation(db, tid, pi['id'], 'CAPTURE', 'client-key-1', amount_minor=250, currency='USD')
    assert same.id == op.id and state2 == 'IN_PROGRESS'
    db.rollback()
    db.close()


def test_payment_idempotency_rejects_same_key_with_different_parameters(client):
    from app.core.database import SessionLocal
    from app.services.core import begin_payment_operation
    from app.core.errors import AppError
    x = client.post('/v1/auth/register', json={'email': 'idem-mismatch@example.com', 'password': 'VerySecurePassword123!'}).json()
    tid = x['tenant']['id']
    from app.core.database import SessionLocal
    db = SessionLocal()
    pi_id = client.post('/v1/payments/intents', headers={'Authorization': 'Bearer ' + x['access_token']},
        params={'tenant_id': tid}, json={'amount_minor': 500, 'currency': 'USD', 'provider': 'mock'}).json()['id']
    op, state = begin_payment_operation(db, tid, pi_id, 'REFUND', 'same-key', amount_minor=100, currency='USD')
    db.commit()
    assert state == 'CREATED'
    try:
        begin_payment_operation(db, tid, pi_id, 'REFUND', 'same-key', amount_minor=200, currency='USD')
        assert False, 'idempotency key reuse with different amount must fail'
    except AppError as exc:
        assert exc.detail['error']['code'] == 'IDEMPOTENCY_REQUEST_MISMATCH'
    db.rollback(); db.close()
