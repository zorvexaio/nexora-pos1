from app.core.database import SessionLocal
from app.services.core import claim_webhook_event
from app.core.errors import AppError
from app.models.domain import WebhookEvent


def test_webhook_claim_is_idempotent_and_detects_payload_mismatch():
    db_session = SessionLocal()
    first, fresh = claim_webhook_event(
        db_session,
        provider='test-provider',
        provider_event_id='evt-145-1',
        tenant_id=None,
        event_type='payment.completed',
        payload_hash='hash-a',
        payload={'id': 'evt-145-1', 'amount': 100},
    )
    assert fresh is True
    db_session.commit()

    second, fresh = claim_webhook_event(
        db_session,
        provider='test-provider',
        provider_event_id='evt-145-1',
        tenant_id=None,
        event_type='payment.completed',
        payload_hash='hash-a',
        payload={'id': 'evt-145-1', 'amount': 100},
    )
    assert fresh is False
    assert second.id == first.id

    try:
        claim_webhook_event(
            db_session,
            provider='test-provider',
            provider_event_id='evt-145-1',
            tenant_id=None,
            event_type='payment.completed',
            payload_hash='hash-b',
            payload={'id': 'evt-145-1', 'amount': 999},
        )
    except AppError as exc:
        assert exc.code == 'WEBHOOK_PAYLOAD_MISMATCH'
    else:
        raise AssertionError('payload mismatch must be rejected')
    finally:
        db_session.rollback()
        db_session.close()


def test_webhook_claim_creates_single_row():
    db_session = SessionLocal()
    row, fresh = claim_webhook_event(
        db_session,
        provider='test-provider',
        provider_event_id='evt-145-2',
        tenant_id=None,
        event_type='payment.completed',
        payload_hash='hash-c',
        payload={'id': 'evt-145-2'},
    )
    assert fresh is True
    db_session.commit()
    assert db_session.query(WebhookEvent).filter_by(provider='test-provider', provider_event_id='evt-145-2').count() == 1
    db_session.close()
