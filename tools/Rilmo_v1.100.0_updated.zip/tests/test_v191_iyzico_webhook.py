import hashlib
import hmac as hmac_lib
from app.core.database import SessionLocal
from app.core.security import encrypt_secret
from app.models.domain import MerchantPaymentAccount, PaymentIntent, PaymentCapture, Order
from app.services.core import bind_provider_tenant


IYZICO_SECRET = 'iyzico-webhook-secret'


def _merchant_with_iyzico(client, email):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    db = SessionLocal()
    db.add(MerchantPaymentAccount(tenant_id=tid, provider='iyzico', status='ACTIVE', charges_enabled=True,
        credentials_encrypted=encrypt_secret('{"api_key":"k","secret_key":"' + IYZICO_SECRET + '"}')))
    db.commit()
    db.close()
    return tid, h


def _order_with_iyzico_intent(client, tid, h, amount=5000, currency='USD'):
    import uuid
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'iyz-item', 'title': 'Iyzico Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'IYZ-1', 'price_amount_minor': amount, 'currency': currency}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c['id']}).json()

    # iyzico's real create_intent calls out to api.iyzipay.com, which isn't
    # reachable in this environment; insert the intent row directly (exactly
    # what a successful create_intent call would have produced) so we can
    # exercise the webhook-handling logic in isolation.
    pi_id = uuid.uuid4().hex
    db = SessionLocal()
    db.add(PaymentIntent(id=pi_id, tenant_id=tid, order_id=order['id'], provider='iyzico',
        provider_payment_id=pi_id, amount_minor=order['total_minor'], currency=currency, status='REQUIRES_ACTION'))
    bind_provider_tenant(db, provider='iyzico', external_id=pi_id, tenant_id=tid)
    db.commit()
    db.close()
    return order, {'id': pi_id}


def _sign(event_type, payment_id, conversation, status, secret=IYZICO_SECRET):
    msg = secret + event_type + payment_id + conversation + status
    return hmac_lib.new(secret.encode(), msg.encode(), hashlib.sha256).hexdigest()


def _post_webhook(client, body, sig):
    return client.post('/v1/webhooks/iyzico', json=body, headers={'X-IYZ-SIGNATURE-V3': sig})


# --- unknown payment: quarantine ------------------------------------------

def test_iyzico_webhook_quarantines_unknown_payment(client):
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': 'unknown-payment-id',
        'paymentConversationId': 'unknown-conv', 'status': 'SUCCESS'}
    r = _post_webhook(client, body, 'irrelevant-since-unknown-tenant')
    assert r.status_code == 200
    assert r.json()['status'] == 'quarantined'


# --- signature verification -----------------------------------------------

def test_iyzico_webhook_rejects_bad_signature(client):
    tid, h = _merchant_with_iyzico(client, 'iyz-badsig@example.com')
    order, pi = _order_with_iyzico_intent(client, tid, h)
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': pi['id'], 'paymentConversationId': pi['id'], 'status': 'SUCCESS'}
    r = _post_webhook(client, body, 'totally-wrong-signature')
    assert r.status_code == 401
    assert r.json()['detail']['error']['code'] == 'WEBHOOK_SIGNATURE_INVALID'

def test_iyzico_webhook_rejects_missing_signature(client):
    tid, h = _merchant_with_iyzico(client, 'iyz-nosig@example.com')
    order, pi = _order_with_iyzico_intent(client, tid, h)
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': pi['id'], 'paymentConversationId': pi['id'], 'status': 'SUCCESS'}
    r = client.post('/v1/webhooks/iyzico', json=body)  # no signature header
    assert r.status_code == 401


# --- amount/currency binding ------------------------------------------------

def test_iyzico_webhook_rejects_missing_amount_on_success(client):
    tid, h = _merchant_with_iyzico(client, 'iyz-noamount@example.com')
    order, pi = _order_with_iyzico_intent(client, tid, h)
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': pi['id'], 'paymentConversationId': pi['id'], 'status': 'SUCCESS'}
    sig = _sign('PAYMENT_API', pi['id'], pi['id'], 'SUCCESS')
    r = _post_webhook(client, body, sig)
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'WEBHOOK_AMOUNT_REQUIRED'

def test_iyzico_webhook_rejects_amount_mismatch(client):
    tid, h = _merchant_with_iyzico(client, 'iyz-amountmismatch@example.com')
    order, pi = _order_with_iyzico_intent(client, tid, h, amount=5000)
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': pi['id'], 'paymentConversationId': pi['id'],
        'status': 'SUCCESS', 'paidPrice': '1.00'}  # way less than the $50 intent
    sig = _sign('PAYMENT_API', pi['id'], pi['id'], 'SUCCESS')
    r = _post_webhook(client, body, sig)
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'WEBHOOK_AMOUNT_MISMATCH'

def test_iyzico_webhook_rejects_currency_mismatch(client):
    tid, h = _merchant_with_iyzico(client, 'iyz-ccymismatch@example.com')
    order, pi = _order_with_iyzico_intent(client, tid, h, amount=5000, currency='USD')
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': pi['id'], 'paymentConversationId': pi['id'],
        'status': 'SUCCESS', 'paidPrice': '50.00', 'currency': 'EUR'}
    sig = _sign('PAYMENT_API', pi['id'], pi['id'], 'SUCCESS')
    r = _post_webhook(client, body, sig)
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'WEBHOOK_CURRENCY_MISMATCH'

def test_iyzico_webhook_rejects_invalid_amount_format(client):
    tid, h = _merchant_with_iyzico(client, 'iyz-badformat@example.com')
    order, pi = _order_with_iyzico_intent(client, tid, h)
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': pi['id'], 'paymentConversationId': pi['id'],
        'status': 'SUCCESS', 'paidPrice': 'not-a-number'}
    sig = _sign('PAYMENT_API', pi['id'], pi['id'], 'SUCCESS')
    r = _post_webhook(client, body, sig)
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'WEBHOOK_AMOUNT_INVALID'


# --- happy path: full ledger materialization -------------------------------

def test_iyzico_webhook_success_captures_and_confirms_order(client):
    tid, h = _merchant_with_iyzico(client, 'iyz-success@example.com')
    order, pi = _order_with_iyzico_intent(client, tid, h, amount=5000, currency='USD')
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': pi['id'], 'paymentConversationId': pi['id'],
        'status': 'SUCCESS', 'paidPrice': '50.00', 'currency': 'USD'}
    sig = _sign('PAYMENT_API', pi['id'], pi['id'], 'SUCCESS')
    r = _post_webhook(client, body, sig)
    assert r.status_code == 200, r.text
    assert r.json()['ok'] is True

    db = SessionLocal()
    fresh_pi = db.get(PaymentIntent, pi['id'])
    assert fresh_pi.status == 'CAPTURED'
    fresh_order = db.query(Order).filter_by(id=order['id']).first()
    assert fresh_order.payment_status == 'CAPTURED'
    assert fresh_order.status == 'CONFIRMED'
    captures = db.query(PaymentCapture).filter_by(payment_intent_id=pi['id']).all()
    assert len(captures) == 1
    assert captures[0].amount_minor == 5000
    db.close()


# --- replay protection ---------------------------------------------------

def test_iyzico_webhook_is_idempotent_on_replay(client):
    tid, h = _merchant_with_iyzico(client, 'iyz-replay@example.com')
    order, pi = _order_with_iyzico_intent(client, tid, h, amount=5000, currency='USD')
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': pi['id'], 'paymentConversationId': pi['id'],
        'status': 'SUCCESS', 'paidPrice': '50.00', 'currency': 'USD'}
    sig = _sign('PAYMENT_API', pi['id'], pi['id'], 'SUCCESS')
    first = _post_webhook(client, body, sig)
    second = _post_webhook(client, body, sig)
    assert first.status_code == 200
    assert second.status_code == 200
    assert second.json().get('duplicate') is True

    db = SessionLocal()
    captures = db.query(PaymentCapture).filter_by(payment_intent_id=pi['id']).all()
    assert len(captures) == 1  # not double-captured
    db.close()


# --- non-success statuses do not capture -----------------------------------

def test_iyzico_webhook_failure_status_does_not_capture(client):
    tid, h = _merchant_with_iyzico(client, 'iyz-failure@example.com')
    order, pi = _order_with_iyzico_intent(client, tid, h)
    body = {'iyziEventType': 'PAYMENT_API', 'paymentId': pi['id'], 'paymentConversationId': pi['id'], 'status': 'FAILURE'}
    sig = _sign('PAYMENT_API', pi['id'], pi['id'], 'FAILURE')
    r = _post_webhook(client, body, sig)
    assert r.status_code == 200

    db = SessionLocal()
    fresh_pi = db.get(PaymentIntent, pi['id'])
    assert fresh_pi.status != 'CAPTURED'
    db.close()
