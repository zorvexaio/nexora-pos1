from pathlib import Path


def test_decision_action_model_is_tenant_scoped_and_unique():
    src = Path('app/models/domain.py').read_text()
    assert "__tablename__ = 'merchant_decision_actions'" in src
    assert "UniqueConstraint('tenant_id', 'decision_key', name='uq_merchant_decision_action_key')" in src
    assert "tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)" in src


def test_decision_action_migration_enables_force_rls():
    src = Path('alembic/versions/20260909_0072_merchant_decision_actions.py').read_text()
    assert "revision = '0072'" in src
    assert "down_revision = '0071'" in src
    assert 'ALTER TABLE merchant_decision_actions ENABLE ROW LEVEL SECURITY' in src
    assert 'ALTER TABLE merchant_decision_actions FORCE ROW LEVEL SECURITY' in src
    assert 'merchant_decision_actions_tenant_isolation' in src


def test_decision_action_routes_have_idempotent_create_and_locked_update():
    src = Path('app/routes/worldclass.py').read_text()
    assert "@router.post('/merchant-decisions/actions')" in src
    assert "with db.begin_nested()" in src
    assert "filter_by(tenant_id=tenant_id, decision_key=key)" in src
    assert "@router.patch('/merchant-decisions/actions/{action_id}')" in src
    assert '.with_for_update().first()' in src
    assert 'DECISION_ACTION_TRANSITION_INVALID' in src


def test_decision_action_lifecycle_is_terminal_and_audited():
    src = Path('app/routes/worldclass.py').read_text()
    assert "'DISMISSED': set()" in src
    assert "'COMPLETED': set()" in src
    assert "merchant.decision_action.created" in src
    assert "merchant.decision_action.updated" in src
