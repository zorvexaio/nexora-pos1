from types import SimpleNamespace
from datetime import datetime, timezone
import pytest


class Q:
    def __init__(self, value=None): self.value = value
    def filter(self, *a, **k): return self
    def filter_by(self, *a, **k): return self
    def order_by(self, *a, **k): return self
    def limit(self, *a, **k): return self
    def with_for_update(self, *a, **k): return self
    def first(self): return self.value
    def all(self): return self.value if isinstance(self.value, list) else ([] if self.value is None else [self.value])


class DB:
    def __init__(self, mapping=None):
        self.mapping = mapping or {}
        self.bind = SimpleNamespace(dialect=SimpleNamespace(name='sqlite'))
        self.info = {}
        self.commits = 0
        self.rollbacks = 0
        self.added = []
    def query(self, cls): return Q(self.mapping.get(cls))
    def commit(self): self.commits += 1
    def rollback(self): self.rollbacks += 1
    def close(self): pass
    def add(self, x): self.added.append(x)
    def flush(self): pass


class Settings:
    OUTBOX_MAX_ATTEMPTS = 3
    OUTBOX_BATCH_SIZE = 10
    OUTBOX_VISIBILITY_TIMEOUT_SECONDS = 30
    APP_WEBHOOK_BATCH_SIZE = 10
    WHATSAPP_ORDER_CONFIRMED_TEMPLATE = ''
    WHATSAPP_ORDER_SHIPPED_TEMPLATE = ''
    WHATSAPP_ABANDONED_CART_TEMPLATE = ''


def setup(monkeypatch, event, mapping=None, claim_ids=None, max_attempts=None):
    import app.worker as w
    import app.services.app_webhooks as aw
    import app.services.workflow_webhooks as ww
    monkeypatch.setattr(w, 'get_settings', lambda: Settings())
    monkeypatch.setattr(w, '_tenant_ids', lambda db: ['t1'])
    monkeypatch.setattr(w, 'run_platform_monthly_report', lambda db: False)
    monkeypatch.setattr(w, 'set_tenant_context', lambda db, tid: None)
    monkeypatch.setattr(w, 'release_expired_reservations', lambda *a, **k: 0)
    monkeypatch.setattr(w, 'cleanup_guest_state', lambda *a, **k: 0)
    monkeypatch.setattr(w, '_claim_events', lambda *a, **k: list(claim_ids or ['e1']))
    monkeypatch.setattr(w, 'process_notification_deliveries', lambda *a, **k: 0)
    monkeypatch.setattr(w, 'process_whatsapp_deliveries', lambda *a, **k: 0)
    monkeypatch.setattr(aw, 'process_webhook_deliveries', lambda *a, **k: 0)
    monkeypatch.setattr(aw, 'recover_stale_webhook_deliveries', lambda *a, **k: 0)
    monkeypatch.setattr(aw, 'deliver_event', lambda *a, **k: None)
    monkeypatch.setattr(ww, 'process_workflow_webhook_deliveries', lambda *a, **k: 0)
    monkeypatch.setattr(ww, 'recover_stale_workflow_webhook_deliveries', lambda *a, **k: 0)
    monkeypatch.setattr(ww, 'materialize_workflow_webhook', lambda *a, **k: None)
    monkeypatch.setattr(w, '_execute_workflow', lambda *a, **k: None)
    monkeypatch.setattr(w, 'process_domain_registration', lambda *a, **k: 'COMPLETED')

    event_db = DB(mapping or {})
    event_db.mapping[w.OutboxEvent] = event
    sessions = [DB(), DB(), DB(), DB(), DB(), event_db, DB()]
    it = iter(sessions)
    monkeypatch.setattr(w, 'SessionLocal', lambda: next(it))
    return w, event_db


def ev(kind, payload=None):
    return SimpleNamespace(id='e1', tenant_id='t1', event_type=kind, payload=payload or {}, status='PROCESSING', attempt_count=0,
                           processed_at=None, next_attempt_at=None, last_error=None)


def test_run_once_empty_event_is_counted(monkeypatch):
    import app.worker as w
    monkeypatch.setattr(w, 'get_settings', lambda: Settings())
    monkeypatch.setattr(w, '_tenant_ids', lambda db: ['t1'])
    monkeypatch.setattr(w, 'run_platform_monthly_report', lambda db: False)
    monkeypatch.setattr(w, '_claim_events', lambda *a, **k: ['missing'])
    monkeypatch.setattr(w, 'set_tenant_context', lambda *a, **k: None)
    monkeypatch.setattr(w, 'release_expired_reservations', lambda *a, **k: 0)
    monkeypatch.setattr(w, 'cleanup_guest_state', lambda *a, **k: 0)
    dbs = [DB(), DB(), DB(), DB(), DB(), DB({w.OutboxEvent: None}), DB()]
    it=iter(dbs); monkeypatch.setattr(w,'SessionLocal',lambda:next(it))
    assert w.run_once() == 1
    assert dbs[-2].rollbacks == 1


@pytest.mark.parametrize('kind', ['order.confirmed','order.shipped'])
def test_run_once_order_notifications(monkeypatch, kind):
    import app.worker as w
    order=SimpleNamespace(order_number='A-1')
    channel=SimpleNamespace(id='ch')
    address=SimpleNamespace(phone='+90555')
    mapping={w.Order:order,w.WhatsAppChannel:channel,w.OrderAddress:address}
    w,db=setup(monkeypatch,ev(kind,{'order_id':'o1'}),mapping)
    assert w.run_once()==1
    assert db.added and db.added[0].recipient=='+90555'


def test_run_once_abandoned_cart_queues_campaign(monkeypatch):
    import app.worker as w
    from app.models.domain import AbandonedCartCampaign, Customer, MarketingPreference
    campaign=SimpleNamespace(cart_id='cart',status='PENDING',attempt_count=0,id='camp')
    cart=SimpleNamespace(customer_id='cust')
    customer=SimpleNamespace(id='cust',phone='+90555')
    pref=SimpleNamespace(whatsapp_marketing=True)
    mapping={AbandonedCartCampaign:campaign,w.Cart:cart,Customer:customer,MarketingPreference:pref,w.WhatsAppChannel:SimpleNamespace(id='ch')}
    w,db=setup(monkeypatch,ev('marketing.abandoned_cart.scheduled',{'campaign_id':'camp'}),mapping)
    assert w.run_once()==1
    assert campaign.status=='QUEUED' and campaign.attempt_count==1 and db.added


def test_run_once_notification_email_sets_schedule(monkeypatch):
    import app.worker as w
    row=SimpleNamespace(status='QUEUED',channel='email',template_id=None,scheduled_at=None)
    mapping={w.NotificationDelivery:row}
    w,db=setup(monkeypatch,ev('notification.send.queued',{'notification_delivery_id':'n1'}),mapping)
    assert w.run_once()==1
    assert row.scheduled_at is not None


def test_run_once_notification_missing_row_goes_retry(monkeypatch):
    import app.worker as w
    w,db=setup(monkeypatch,ev('notification.send.queued',{'notification_delivery_id':'n1'}),{w.NotificationDelivery:None})
    assert w.run_once(max_attempts=3)==1
    assert db.mapping[w.OutboxEvent].status=='PENDING'
    assert db.mapping[w.OutboxEvent].attempt_count==1


def test_run_once_notification_non_email_goes_dlq(monkeypatch):
    import app.worker as w
    row=SimpleNamespace(status='QUEUED',channel='sms',template_id=None,scheduled_at=None)
    w,db=setup(monkeypatch,ev('notification.send.queued',{'notification_delivery_id':'n1'}),{w.NotificationDelivery:row})
    assert w.run_once(max_attempts=1)==1
    assert db.mapping[w.OutboxEvent].status=='FAILED'
    assert db.added and db.added[-1].event_type=='notification.send.queued'


def test_run_once_workflow(monkeypatch):
    import app.worker as w
    run=SimpleNamespace(id='r')
    w,db=setup(monkeypatch,ev('workflow.run.queued',{'workflow_run_id':'r'}),{__import__('app.models.domain',fromlist=['WorkflowRun']).WorkflowRun:run})
    called=[]
    monkeypatch.setattr(w,'_execute_workflow',lambda db,run:called.append(run))
    assert w.run_once()==1 and called==[run]


def test_run_once_workflow_missing_goes_retry(monkeypatch):
    import app.worker as w
    from app.models.domain import WorkflowRun
    w,db=setup(monkeypatch,ev('workflow.run.queued',{'workflow_run_id':'r'}),{WorkflowRun:None})
    assert w.run_once(max_attempts=2)==1
    assert db.mapping[w.OutboxEvent].status=='PENDING'


def test_run_once_domain_registration(monkeypatch):
    import app.worker as w
    from app.models.domain import DomainPurchase
    purchase=SimpleNamespace(id='p')
    w,db=setup(monkeypatch,ev('domain.purchase.payment_captured',{'purchase_id':'p','amount_minor':100,'currency':'usd'}),{DomainPurchase:purchase})
    called=[]
    monkeypatch.setattr(w,'process_domain_registration',lambda db,p:called.append((db,p)) or 'COMPLETED')
    assert w.run_once()==1 and called and db.info['captured_amount_minor']==100 and db.info['captured_currency']=='USD'


def test_run_once_domain_missing_goes_retry(monkeypatch):
    import app.worker as w
    from app.models.domain import DomainPurchase
    w,db=setup(monkeypatch,ev('domain.purchase.payment_captured',{'purchase_id':'p','amount_minor':100,'currency':'usd'}),{DomainPurchase:None})
    assert w.run_once(max_attempts=2)==1
    assert db.mapping[w.OutboxEvent].status=='PENDING'


def test_run_once_workflow_webhook_materializes(monkeypatch):
    import app.worker as w
    import app.services.workflow_webhooks as ww
    w,db=setup(monkeypatch,ev('workflow.webhook.requested',{}),{})
    called=[]
    monkeypatch.setattr(ww,'materialize_workflow_webhook',lambda db,ev:called.append(ev))
    assert w.run_once()==1 and called


def test_run_once_unknown_event_dlq(monkeypatch):
    import app.worker as w
    w,db=setup(monkeypatch,ev('unknown.poison',{}),{})
    assert w.run_once(max_attempts=1)==1
    assert db.mapping[w.OutboxEvent].status=='FAILED'
    assert db.added and db.added[-1].event_type=='unknown.poison'


def test_run_once_auxiliary_event_processed(monkeypatch):
    import app.worker as w
    w,db=setup(monkeypatch,ev('return.approved',{}),{})
    assert w.run_once()==1
    assert db.mapping[w.OutboxEvent].status=='PROCESSED'
