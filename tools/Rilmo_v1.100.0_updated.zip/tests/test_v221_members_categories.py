def _merchant(client, email):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'M'}).json()
    return m['tenant']['id'], {'Authorization': 'Bearer ' + m['access_token']}


def _add_staff_member(client, tid, h, email, role='staff'):
    staff = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'}).json()
    r = client.post(f'/v1/members?tenant_id={tid}', headers=h, json={'email': email, 'role': role})
    assert r.status_code == 200, r.text
    return r.json(), staff


# --- member create validation ------------------------------------------

def test_create_member_rejects_invalid_role(client):
    tid, h = _merchant(client, 'member-badrole@example.com')
    client.post('/v1/auth/register', json={'email': 'member-badrole-target@example.com', 'password': 'VerySecurePassword123!'})
    r = client.post(f'/v1/members?tenant_id={tid}', headers=h, json={'email': 'member-badrole-target@example.com', 'role': 'superadmin'})
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'ROLE_INVALID'

def test_create_member_rejects_duplicate(client):
    tid, h = _merchant(client, 'member-dup@example.com')
    _add_staff_member(client, tid, h, 'member-dup-target@example.com')
    r2 = client.post(f'/v1/members?tenant_id={tid}', headers=h, json={'email': 'member-dup-target@example.com', 'role': 'staff'})
    assert r2.status_code == 409
    assert r2.json()['detail']['error']['code'] == 'MEMBER_EXISTS'

def test_create_member_missing_user_returns_not_found(client):
    tid, h = _merchant(client, 'member-nouser@example.com')
    r = client.post(f'/v1/members?tenant_id={tid}', headers=h, json={'email': 'no-such-user@example.com', 'role': 'staff'})
    assert r.status_code == 404


# --- member update / lockout --------------------------------------------

def test_patch_member_updates_role(client):
    tid, h = _merchant(client, 'member-patchrole@example.com')
    member, staff = _add_staff_member(client, tid, h, 'member-patchrole-target@example.com')
    r = client.patch(f"/v1/members/{member['id']}?tenant_id={tid}", headers=h, json={'role': 'admin'})
    assert r.status_code == 200
    assert r.json()['role'] == 'admin'

def test_patch_member_rejects_invalid_role(client):
    tid, h = _merchant(client, 'member-patchbadrole@example.com')
    member, staff = _add_staff_member(client, tid, h, 'member-patchbadrole-target@example.com')
    r = client.patch(f"/v1/members/{member['id']}?tenant_id={tid}", headers=h, json={'role': 'god'})
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'ROLE_INVALID'

def test_patch_member_missing_returns_not_found(client):
    tid, h = _merchant(client, 'member-patchmissing@example.com')
    r = client.patch(f'/v1/members/does-not-exist?tenant_id={tid}', headers=h, json={'role': 'admin'})
    assert r.status_code == 404

def test_patch_member_can_update_status(client):
    tid, h = _merchant(client, 'member-patchstatus@example.com')
    member, staff = _add_staff_member(client, tid, h, 'member-patchstatus-target@example.com')
    r = client.patch(f"/v1/members/{member['id']}?tenant_id={tid}", headers=h, json={'status': 'SUSPENDED'})
    assert r.status_code == 200
    assert r.json()['status'] == 'SUSPENDED'


# --- member delete --------------------------------------------------

def test_delete_member_suspends_target(client):
    tid, h = _merchant(client, 'member-delete@example.com')
    member, staff = _add_staff_member(client, tid, h, 'member-delete-target@example.com')
    r = client.delete(f"/v1/members/{member['id']}?tenant_id={tid}", headers=h)
    assert r.status_code == 200
    assert r.json()['ok'] is True

def test_delete_member_missing_returns_not_found(client):
    tid, h = _merchant(client, 'member-deletemissing@example.com')
    r = client.delete(f'/v1/members/does-not-exist?tenant_id={tid}', headers=h)
    assert r.status_code == 404

def test_delete_member_rejects_self_removal(client):
    tid, h = _merchant(client, 'member-selfremove@example.com')
    members = client.get(f'/v1/members?tenant_id={tid}', headers=h).json()
    owner_membership = members[0]
    r = client.delete(f"/v1/members/{owner_membership['id']}?tenant_id={tid}", headers=h)
    assert r.status_code == 409
    assert r.json()['detail']['error']['code'] == 'SELF_REMOVE_FORBIDDEN'


# --- categories CRUD ------------------------------------------------

def test_create_category_succeeds(client):
    tid, h = _merchant(client, 'category-create@example.com')
    r = client.post(f'/v1/categories?tenant_id={tid}', headers=h, json={'slug': 'shoes', 'name': 'Shoes'})
    assert r.status_code == 200, r.text
    assert r.json()['slug'] == 'shoes'

def test_create_category_with_valid_parent_succeeds(client):
    tid, h = _merchant(client, 'category-parent@example.com')
    parent = client.post(f'/v1/categories?tenant_id={tid}', headers=h, json={'slug': 'apparel', 'name': 'Apparel'}).json()
    r = client.post(f'/v1/categories?tenant_id={tid}', headers=h, json={'slug': 'shirts', 'name': 'Shirts', 'parent_id': parent['id']})
    assert r.status_code == 200
    assert r.json()['parent_id'] == parent['id']

def test_create_category_rejects_parent_from_other_tenant(client):
    tid1, h1 = _merchant(client, 'category-crosstenant1@example.com')
    tid2, h2 = _merchant(client, 'category-crosstenant2@example.com')
    other_parent = client.post(f'/v1/categories?tenant_id={tid2}', headers=h2, json={'slug': 'foreign', 'name': 'Foreign'}).json()
    r = client.post(f'/v1/categories?tenant_id={tid1}', headers=h1, json={'slug': 'child', 'name': 'Child', 'parent_id': other_parent['id']})
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'CATEGORY_PARENT_INVALID'

def test_patch_category_updates_fields(client):
    tid, h = _merchant(client, 'category-patch@example.com')
    c = client.post(f'/v1/categories?tenant_id={tid}', headers=h, json={'slug': 'toys', 'name': 'Toys'}).json()
    r = client.patch(f"/v1/categories/{c['id']}?tenant_id={tid}", headers={**h, 'If-Match': str(c['version'])}, json={'name': 'Toys & Games'})
    assert r.status_code == 200, r.text
    assert r.json()['name'] == 'Toys & Games'

def test_patch_category_missing_returns_not_found(client):
    tid, h = _merchant(client, 'category-patchmissing@example.com')
    r = client.patch(f'/v1/categories/does-not-exist?tenant_id={tid}', headers=h, json={'name': 'X'})
    assert r.status_code == 404

def test_patch_category_rejects_invalid_parent(client):
    tid, h = _merchant(client, 'category-patchbadparent@example.com')
    c = client.post(f'/v1/categories?tenant_id={tid}', headers=h, json={'slug': 'books', 'name': 'Books'}).json()
    r = client.patch(f"/v1/categories/{c['id']}?tenant_id={tid}", headers={**h, 'If-Match': str(c['version'])}, json={'parent_id': 'does-not-exist'})
    assert r.status_code == 400
    assert r.json()['detail']['error']['code'] == 'CATEGORY_PARENT_INVALID'

def test_delete_category_succeeds(client):
    tid, h = _merchant(client, 'category-delete@example.com')
    c = client.post(f'/v1/categories?tenant_id={tid}', headers=h, json={'slug': 'temp', 'name': 'Temp'}).json()
    r = client.delete(f"/v1/categories/{c['id']}?tenant_id={tid}", headers=h)
    assert r.status_code == 200
    assert r.json()['ok'] is True

def test_delete_category_missing_returns_not_found(client):
    tid, h = _merchant(client, 'category-deletemissing@example.com')
    r = client.delete(f'/v1/categories/does-not-exist?tenant_id={tid}', headers=h)
    assert r.status_code == 404
