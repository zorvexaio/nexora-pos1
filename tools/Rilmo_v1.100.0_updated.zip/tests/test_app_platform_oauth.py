import base64, hashlib, urllib.parse
from tests.test_p0 import register

def h(x):
    return {'Authorization': f"Bearer {x['access_token']}"}

def _pkce(verifier):
    return base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()

def test_app_oauth_authorization_code_pkce_and_api_scope(client):
    admin = register(client, 'oauth-admin@example.com')
    ah = h(admin)
    from app.core.database import SessionLocal
    from app.models.domain import AppDefinition
    from app.core.security import token_hash
    import secrets
    db = SessionLocal()
    secret = 'test-client-secret-' + secrets.token_urlsafe(12)
    app = AppDefinition(name='Test App', slug='test-app-oauth', client_id='client-test-oauth', client_secret_hash=token_hash(secret), redirect_uris=['https://example.com/cb'], scopes=['store.read'], status='APPROVED')
    db.add(app)
    db.commit()
    aid = app.id
    db.close()
    verifier = 'verifier-' + secrets.token_urlsafe(24)
    challenge = _pkce(verifier)
    state = 'state-123'
    tid = admin['tenant']['id']
    r = client.get('/v1/oauth/authorize', params={'client_id': 'client-test-oauth', 'redirect_uri': 'https://example.com/cb', 'response_type': 'code', 'scope': 'store.read', 'state': state, 'code_challenge': challenge, 'code_challenge_method': 'S256', 'tenant_id': tid}, headers=ah, follow_redirects=False)
    assert r.status_code == 302
    q = urllib.parse.parse_qs(urllib.parse.urlsplit(r.headers['location']).query)
    assert q['state'] == [state]
    code = q['code'][0]
    tok = client.post('/v1/oauth/token', data={'grant_type': 'authorization_code', 'client_id': 'client-test-oauth', 'client_secret': secret, 'code': code, 'redirect_uri': 'https://example.com/cb', 'code_verifier': verifier})
    assert tok.status_code == 200 and tok.json()['scope'] == 'store.read'
    api = client.get('/v1/apps/api/v1/tenant', headers={'Authorization': 'Bearer ' + tok.json()['access_token']})
    assert api.status_code == 200 and api.json()['id'] == tid
    replay = client.post('/v1/oauth/token', data={'grant_type': 'authorization_code', 'client_id': 'client-test-oauth', 'client_secret': secret, 'code': code, 'redirect_uri': 'https://example.com/cb', 'code_verifier': verifier})
    assert replay.status_code == 400
    refreshed = client.post('/v1/oauth/token', data={'grant_type': 'refresh_token', 'client_id': 'client-test-oauth', 'client_secret': secret, 'refresh_token': tok.json()['refresh_token']})
    assert refreshed.status_code == 200 and refreshed.json()['access_token'] != tok.json()['access_token']

def test_app_oauth_requires_pkce_and_exact_redirect(client):
    x = register(client, 'oauth-invalid@example.com')
    from app.core.database import SessionLocal
    from app.models.domain import AppDefinition
    from app.core.security import token_hash
    db = SessionLocal()
    app = AppDefinition(name='Bad App', slug='bad-app-oauth', client_id='client-bad-oauth', client_secret_hash=token_hash('secret'), redirect_uris=['https://example.com/cb'], scopes=['store.read'], status='APPROVED')
    db.add(app)
    db.commit()
    db.close()
    r = client.get('/v1/oauth/authorize', params={'client_id': 'client-bad-oauth', 'redirect_uri': 'https://evil.example/cb', 'response_type': 'code', 'scope': 'store.read', 'state': 'x', 'tenant_id': x['tenant']['id']}, headers=h(x))
    assert r.status_code == 400
