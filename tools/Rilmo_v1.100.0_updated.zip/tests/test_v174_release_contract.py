from pathlib import Path
import re


def _compose_service_block(text: str, service: str) -> str:
    lines = text.splitlines()
    start = next(i for i, line in enumerate(lines) if line == f"  {service}:")
    end = next((i for i in range(start + 1, len(lines)) if lines[i].startswith('  ') and not lines[i].startswith('    ')), len(lines))
    return '\n'.join(lines[start:end])


def test_production_compose_environment_keys_are_unique():
    text = Path('docker-compose.production.yml').read_text(encoding='utf-8')
    for service in ('api', 'worker'):
        block = _compose_service_block(text, service)
        keys = re.findall(r'^      ([A-Z][A-Z0-9_]*):', block, re.MULTILINE)
        assert len(keys) == len(set(keys)), f'duplicate environment key in {service}'


def test_production_compose_requires_global_deployment_contract():
    text = Path('docker-compose.production.yml').read_text(encoding='utf-8')
    api_block = _compose_service_block(text, 'api')
    for key in (
        'LEGAL_ENTITY_NAME', 'PRIVACY_CONTACT_EMAIL', 'PRIVACY_POLICY_VERSION',
        'TERMS_EFFECTIVE_DATE', 'PUBLIC_BASE_URL', 'COOKIE_SECURE',
        'ALLOWED_HOSTS', 'FORWARDED_ALLOW_IPS', 'S3_BUCKET',
        'S3_ACCESS_KEY_ID', 'S3_SECRET_ACCESS_KEY',
    ):
        assert f'${{{key}:?' in api_block, f'{key} is not a required compose variable for api'
    for service in ('api', 'worker'):
        block = _compose_service_block(text, service)
        for key in ('S3_BUCKET', 'S3_ACCESS_KEY_ID', 'S3_SECRET_ACCESS_KEY'):
            assert f'${{{key}:?' in block, f'{key} is not a required compose variable for {service}'


def test_current_release_documents_have_no_stale_current_status_versions():
    version = Path("VERSION").read_text(encoding="utf-8").strip()
    for name in ("README.md", "IMPLEMENTATION_STATUS.md", "docs/compliance/compliance_manifest.json", "RELEASE_MANIFEST.json"):
        text = Path(name).read_text(encoding="utf-8")
        assert version in text, f"{name} does not reference current VERSION {version}"
    status = Path("IMPLEMENTATION_STATUS.md").read_text(encoding="utf-8")
    assert "release_consistency_gate: **PASS** — VERSION " + version in status
    assert "VERSION 1.69.0" not in status


def test_release_consistency_gate_checks_current_status_documents():
    script = Path("scripts/release_consistency_gate.py").read_text(encoding="utf-8")
    assert '"IMPLEMENTATION_STATUS.md"' in script
    assert '"docs/compliance/compliance_manifest.json"' in script
