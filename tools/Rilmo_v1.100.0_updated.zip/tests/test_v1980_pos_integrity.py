from pathlib import Path

from app.core.database import SessionLocal
from app.models.domain import Customer, InventoryItem, InventoryLocation, POSLocation, Product, ProductVariant


def register(client, email):
    r = client.post('/v1/auth/register', json={
        'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'POS 1980'
    })
    assert r.status_code == 200, r.text
    return r.json()


def setup_pos(client, email='pos-v1980@example.com'):
    x = register(client, email)
    h = {'Authorization': f"Bearer {x['access_token']}"}
    tid = x['tenant']['id']
    db = SessionLocal()
    try:
        invloc = InventoryLocation(tenant_id=tid, name='POS-1980')
        db.add(invloc); db.flush()
        loc = POSLocation(tenant_id=tid, code='POS-1980', name='POS 1980', inventory_location_id=invloc.id)
        db.add(loc); db.flush()
        p = Product(tenant_id=tid, slug='pos-1980', title='POS 1980', status='PUBLISHED', product_type='PHYSICAL')
        db.add(p); db.flush()
        v = ProductVariant(tenant_id=tid, product_id=p.id, sku='POS-1980-SKU', price_amount_minor=1000, currency='USD', status='ACTIVE')
        db.add(v); db.flush()
        db.commit()
        return x, h, tid, loc.id, v.id, invloc.id
    finally:
        db.close()


def open_session(client, tid, h, loc_id):
    reg = client.post('/v1/pos/registers', params={'tenant_id': tid}, headers=h,
                      json={'location_id': loc_id, 'register_code': 'REG-1980', 'name': 'Register 1980'})
    assert reg.status_code == 200, reg.text
    op = client.post('/v1/pos/sessions/open', params={'tenant_id': tid}, headers=h,
                     json={'register_id': reg.json()['id'], 'opening_cash_minor': 0})
    assert op.status_code == 200, op.text
    return op.json()['id']


def test_pos_open_uses_register_row_lock():
    src = Path('app/routes/worldclass.py').read_text()
    assert "filter_by(id=data.get('register_id'),tenant_id=tenant_id,status='ACTIVE').with_for_update().first()" in src


def test_physical_pos_sale_requires_inventory_record(client):
    x, h, tid, loc_id, variant_id, _ = setup_pos(client)
    sid = open_session(client, tid, h, loc_id)
    r = client.post(f'/v1/pos/sessions/{sid}/sales', params={'tenant_id': tid},
                    headers={**h, 'Idempotency-Key': 'missing-inventory-1980'},
                    json={'currency': 'USD', 'items': [{'variant_id': variant_id, 'quantity': 1}]})
    assert r.status_code == 409, r.text
    assert r.json()['detail']['error']['code'] == 'POS_INVENTORY_RECORD_MISSING'


def test_pos_sale_rejects_zero_and_negative_quantities(client):
    x, h, tid, loc_id, variant_id, invloc_id = setup_pos(client, 'pos-quantity-v1980@example.com')
    db = SessionLocal()
    try:
        inv = InventoryItem(tenant_id=tid, variant_id=variant_id, location_id=invloc_id,
                            on_hand=10, available=10, reserved=0, committed=0, version=1)
        db.add(inv); db.commit()
    finally:
        db.close()
    sid = open_session(client, tid, h, loc_id)
    for idx, qty in enumerate([0, -1]):
        r = client.post(f'/v1/pos/sessions/{sid}/sales', params={'tenant_id': tid},
                        headers={**h, 'Idempotency-Key': f'bad-qty-1980-{idx}'},
                        json={'currency': 'USD', 'items': [{'variant_id': variant_id, 'quantity': qty}]})
        assert r.status_code == 422, r.text
        assert r.json()['detail']['error']['code'] == 'POS_QUANTITY_INVALID'


def test_pos_sale_rejects_currency_mismatch(client):
    x, h, tid, loc_id, variant_id, invloc_id = setup_pos(client, 'pos-currency-v1980@example.com')
    db = SessionLocal()
    try:
        db.add(InventoryItem(tenant_id=tid, variant_id=variant_id, location_id=invloc_id,
                             on_hand=10, available=10, reserved=0, committed=0, version=1))
        db.commit()
    finally:
        db.close()
    sid = open_session(client, tid, h, loc_id)
    r = client.post(f'/v1/pos/sessions/{sid}/sales', params={'tenant_id': tid},
                    headers={**h, 'Idempotency-Key': 'currency-1980'},
                    json={'currency': 'EUR', 'items': [{'variant_id': variant_id, 'quantity': 1}]})
    assert r.status_code == 409, r.text
    assert r.json()['detail']['error']['code'] == 'POS_CURRENCY_MISMATCH'


def test_pos_sale_rejects_cross_tenant_customer(client):
    a = register(client, 'pos-customer-a-v1980@example.com')
    b = register(client, 'pos-customer-b-v1980@example.com')
    ha = {'Authorization': f"Bearer {a['access_token']}"}
    hb = {'Authorization': f"Bearer {b['access_token']}"}
    ta, tb = a['tenant']['id'], b['tenant']['id']
    db = SessionLocal()
    try:
        ca = Customer(tenant_id=tb, email='customer-b@v1980.example')
        db.add(ca)
        invloc = InventoryLocation(tenant_id=ta, name='POS-CROSS')
        db.add(invloc); db.flush()
        loc = POSLocation(tenant_id=ta, code='POS-CROSS', name='POS Cross', inventory_location_id=invloc.id)
        db.add(loc); db.flush()
        p = Product(tenant_id=ta, slug='cross-customer-pos', title='Cross Customer POS', status='PUBLISHED', product_type='PHYSICAL')
        db.add(p); db.flush()
        v = ProductVariant(tenant_id=ta, product_id=p.id, sku='CROSS-CUSTOMER', price_amount_minor=1000, currency='USD', status='ACTIVE')
        db.add(v); db.flush()
        db.add(InventoryItem(tenant_id=ta, variant_id=v.id, location_id=invloc.id, on_hand=10, available=10, reserved=0, committed=0, version=1))
        db.commit(); cid=ca.id; lid=loc.id; vid=v.id
    finally:
        db.close()
    sid = open_session(client, ta, ha, lid)
    r = client.post(f'/v1/pos/sessions/{sid}/sales', params={'tenant_id': ta},
                    headers={**ha, 'Idempotency-Key': 'cross-customer-1980'},
                    json={'currency': 'USD', 'customer_id': cid, 'items': [{'variant_id': vid, 'quantity': 1}]})
    assert r.status_code == 404, r.text
    assert r.json()['detail']['error']['message'] == 'POS customer not found'
