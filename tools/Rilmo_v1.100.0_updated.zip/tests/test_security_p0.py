import uuid
import hmac, hashlib, json
from app.security.policy import validate_outbound_url, validate_upload
from app.core.security import hmac_sha256

def test_ssrf_rejects_private_and_non_http():
    for url in ['http://127.0.0.1/x', 'http://169.254.169.254/', 'file:///etc/passwd', 'gopher://127.0.0.1']:
        try:
            validate_outbound_url(url)
        except ValueError:
            pass
        else:
            raise AssertionError(url)

def test_upload_rejects_active_content_and_large_files():
    try:
        validate_upload(filename='x.svg', content_type='image/svg+xml', size_bytes=100, magic=b'<svg')
    except ValueError:
        pass
    else:
        raise AssertionError('svg accepted')
    try:
        validate_upload(filename='x.jpg', content_type='image/jpeg', size_bytes=11 * 1024 * 1024, magic=b'\xff\xd8')
    except ValueError:
        pass
    else:
        raise AssertionError('oversize accepted')

def test_webhook_signature_is_constant_time_compatible():
    body = b'{"id":"evt_1"}'
    sig = hmac_sha256(body, 'secret')
    assert hmac.compare_digest(sig, hmac_sha256(body, 'secret'))

def test_mfa_totp_enrollment_and_verification(client):
    x = client.post('/v1/auth/register', json={'email': 'mfa@example.com', 'password': 'VerySecurePassword123!'})
    assert x.status_code == 200
    h = {'Authorization': 'Bearer ' + x.json()['access_token']}
    r = client.post('/v1/mfa/factors', headers=h)
    assert r.status_code == 200
    secret = r.json()['secret']
    from app.core.security import totp_code
    v = client.post(f"/v1/mfa/factors/{r.json()['factor_id']}/verify?code={totp_code(secret)}", headers=h)
    assert v.status_code == 200

def test_ssrf_and_upload_policy(client):
    from app.security.policy import validate_outbound_url, validate_upload
    import pytest
    with pytest.raises(ValueError):
        validate_outbound_url('http://127.0.0.1:8000')
    with pytest.raises(ValueError):
        validate_upload(filename='x.svg', content_type='image/svg+xml', size_bytes=10, magic=b'<?xml')

def test_public_tracking_uses_opaque_token(client):
    x = client.post('/v1/auth/register', json={'email': 'track@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'track', 'title': 'Track', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'TRK-1', 'price_amount_minor': 100, 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=2&reason=test", headers=h)
    cart = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={cart['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': cart['id']}).json()
    tr = client.post(f"/v1/orders/{order['id']}/tracking?tenant_id={tid}", headers=h, json={'carrier': 'x', 'tracking_number': 'ABC'}).json()
    public = client.get(f"/v1/public/orders/tracking/{tr['public_token']}")
    assert public.status_code == 200
    assert public.json()['tracking_number'] == 'ABC'

def test_user_secret_not_serialized(client):
    x = client.post('/v1/auth/register', json={'email': 'secret@example.com', 'password': 'VerySecurePassword123!'}).json()
    assert 'password_hash' not in x['user']

def test_tenant_boundary_on_cart_and_wishlist(client):
    a = client.post('/v1/auth/register', json={'email': 'a-boundary@example.com', 'password': 'VerySecurePassword123!'}).json()
    b = client.post('/v1/auth/register', json={'email': 'b-boundary@example.com', 'password': 'VerySecurePassword123!'}).json()
    ha = {'Authorization': 'Bearer ' + a['access_token']}
    hb = {'Authorization': 'Bearer ' + b['access_token']}
    assert client.post(f"/v1/cart?tenant_id={b['tenant']['id']}", headers=ha).status_code in {403, 404}
    assert client.post(f"/v1/wishlist?tenant_id={b['tenant']['id']}", headers=ha).status_code in {403, 404}
    assert client.get(f"/v1/entitlements?tenant_id={b['tenant']['id']}", headers=ha).status_code in {403, 404}

def test_mock_provider_is_explicit_and_not_secret_bearing(client):
    x = client.post('/v1/auth/register', json={'email': 'pay-provider@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    r = client.post(f'/v1/payments/intents?tenant_id={tid}', headers=h, json={'amount_minor': 100, 'currency': 'USD', 'provider': 'mock'})
    assert r.status_code == 200
    assert r.json()['provider'] == 'mock'
    assert 'password_hash' not in r.text and 'secret_encrypted' not in r.text

def test_platform_admin_cannot_be_impersonated(client):
    x = client.post('/v1/auth/register', json={'email': 'not-admin@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    assert client.get('/v1/plans', headers=h).status_code in {403, 404}

def test_session_replay_after_logout_is_rejected(client):
    x = client.post('/v1/auth/register', json={'email': 'replay@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    assert client.post('/v1/auth/logout', headers=h).status_code == 200
    assert client.get('/v1/me', headers=h).status_code in {403, 404}

def test_oauth_linking_cannot_take_over_existing_identity(client):
    a = client.post('/v1/auth/register', json={'email': 'oauth-a@example.com', 'password': 'VerySecurePassword123!'}).json()
    b = client.post('/v1/auth/register', json={'email': 'oauth-b@example.com', 'password': 'VerySecurePassword123!'}).json()
    ha = {'Authorization': 'Bearer ' + a['access_token']}
    hb = {'Authorization': 'Bearer ' + b['access_token']}
    assert client.post('/v1/auth/identities/link', headers=ha, json={'provider': 'test', 'provider_subject': 'subject-1'}).status_code == 200
    assert client.post('/v1/auth/identities/link', headers=hb, json={'provider': 'test', 'provider_subject': 'subject-1'}).status_code == 409

def test_domain_verification_token_cannot_be_reused(client):
    x = client.post('/v1/auth/register', json={'email': 'domain@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    r = client.post(f'/v1/domains/provision?tenant_id={tid}', headers=h, json={'hostname': 'example-test.invalid'})
    assert r.status_code == 200
    d = r.json()['domain']
    token = r.json()['verification_token']
    assert client.post(f"/v1/domains/{d['id']}/verify?tenant_id={tid}&token={token}", headers=h).status_code == 200
    assert client.post(f"/v1/domains/{d['id']}/verify?tenant_id={tid}&token={token}", headers=h).status_code == 400

def test_audit_tampering_is_detectable(client):
    from app.core.database import SessionLocal
    from app.models.domain import AuditEvent
    from app.services.core import verify_audit_chain
    x = client.post('/v1/auth/register', json={'email': 'audit@example.com', 'password': 'VerySecurePassword123!'}).json()
    tid = x['tenant']['id']
    h = {'Authorization': 'Bearer ' + x['access_token']}
    assert client.patch(f'/v1/tenants/{tid}', headers={**h, 'If-Match': '1'}, json={'name': 'audited'}).status_code == 200
    db = SessionLocal()
    assert verify_audit_chain(db, tid) is True
    row = db.query(AuditEvent).filter_by(tenant_id=tid).first()
    row.action = 'tampered'
    db.commit()
    assert verify_audit_chain(db, tid) is False
    db.close()

def _activate_plan(client, tid, headers, code='growth'):
    from app.core.database import SessionLocal
    from app.models.domain import Plan, PlanVersion
    db = SessionLocal()
    plan = db.query(Plan).filter_by(code=code).first()
    pv = db.query(PlanVersion).filter_by(plan_id=plan.id, is_current=True).first()
    db.close()
    r = client.post(f'/v1/subscriptions?tenant_id={tid}', headers=headers, json={'plan_version_id': pv.id})
    assert r.status_code == 200, r.text

def test_coupon_usage_limit_is_enforced_inside_checkout_transaction(client):
    from app.core.database import SessionLocal
    from app.models.domain import Promotion, Coupon
    x = client.post('/v1/auth/register', json={'email': 'coupon@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    _activate_plan(client, tid, h, 'starter')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'coupon', 'title': 'Coupon', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'COUP-1', 'price_amount_minor': 1000, 'currency': 'USD', 'provider': 'mock'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=2&reason=test", headers=h)
    db = SessionLocal()
    promo = Promotion(tenant_id=tid, name='One use', discount_type='PERCENTAGE', percentage_bps=1000, usage_limit=1)
    db.add(promo)
    db.flush()
    coupon = Coupon(tenant_id=tid, promotion_id=promo.id, code='SAVE10', usage_limit=1)
    db.add(coupon)
    db.commit()
    db.close()
    c1 = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c1['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    o1 = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c1['id'], 'coupon_code': 'SAVE10'})
    assert o1.status_code == 200
    c2 = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c2['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    o2 = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c2['id'], 'coupon_code': 'SAVE10'})
    assert o2.status_code == 409

def test_cancel_subscription_revokes_entitlements(client):
    from app.core.database import SessionLocal
    from app.models.domain import Plan, PlanVersion, PlanFeature
    x = client.post('/v1/auth/register', json={'email': 'entitlement@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    db = SessionLocal()
    plan = db.query(Plan).first()
    pv = db.query(PlanVersion).filter_by(plan_id=plan.id).first()
    db.add(PlanFeature(plan_version_id=pv.id, feature_key='private_test', value_type='boolean', value_boolean=True))
    db.commit()
    db.close()
    assert client.post(f'/v1/subscriptions?tenant_id={tid}', headers=h, json={'plan_version_id': pv.id}).status_code == 200
    assert client.get(f'/v1/entitlements?tenant_id={tid}', headers=h).json()
    assert client.post(f'/v1/subscription/cancel?tenant_id={tid}', headers=h).status_code == 200
    assert client.get(f'/v1/entitlements?tenant_id={tid}', headers=h).json() == []

def test_removed_marketplace_webhooks_do_not_exist(client):
    for path in ['/v1/webhooks/stripe','/v1/webhooks/tabby','/v1/webhooks/tamara']:
        assert client.post(path, json={}).status_code == 404

def test_role_escalation_is_blocked(client):
    a = client.post('/v1/auth/register', json={'email': 'owner-role@example.com', 'password': 'VerySecurePassword123!'}).json()
    b = client.post('/v1/auth/register', json={'email': 'viewer-role@example.com', 'password': 'VerySecurePassword123!'}).json()
    ha = {'Authorization': 'Bearer ' + a['access_token']}
    hb = {'Authorization': 'Bearer ' + b['access_token']}
    tid = a['tenant']['id']
    assert client.post('/v1/members', headers=ha, params={'tenant_id': tid}, json={'email': 'viewer-role@example.com', 'role': 'viewer'}).status_code == 200
    assert client.post('/v1/products', headers=hb, params={'tenant_id': tid}, json={'slug': 'blocked', 'title': 'Blocked'}).status_code in {403, 404}

def test_recovery_code_is_single_use_and_hashed(client):
    from app.core.database import SessionLocal
    from app.models.domain import RecoveryCode
    from app.core.auth import consume_recovery_code
    x = client.post('/v1/auth/register', json={'email': 'recovery@example.com', 'password': 'VerySecurePassword123!'}).json()
    user_id = x['user']['id']
    h = {'Authorization': 'Bearer ' + x['access_token']}
    raw = client.post('/v1/mfa/factors', headers=h).json()['recovery_codes'][0]
    db = SessionLocal()
    row = db.query(RecoveryCode).filter_by(user_id=user_id).first()
    assert row and row.code_hash != raw
    assert consume_recovery_code(db, user_id, raw) is True
    db.commit()
    assert consume_recovery_code(db, user_id, raw) is False
    db.close()

def test_password_reset_existence_does_not_leak(client):
    r = client.post('/v1/auth/password-reset/request', json={'email': 'does-not-exist@example.com'})
    assert r.status_code == 200 and r.json() == {'ok': True}

def test_storage_key_is_tenant_prefixed_and_not_cross_deletable(client):
    from app.core.database import SessionLocal
    from app.models.domain import MediaAsset
    suffix = uuid.uuid4().hex
    a = client.post('/v1/auth/register', json={'email': f'storage-a-{suffix}@example.com', 'password': 'VerySecurePassword123!'}).json()
    b = client.post('/v1/auth/register', json={'email': f'storage-b-{suffix}@example.com', 'password': 'VerySecurePassword123!'}).json()
    ha = {'Authorization': 'Bearer ' + a['access_token']}
    hb = {'Authorization': 'Bearer ' + b['access_token']}
    db = SessionLocal()
    row = MediaAsset(tenant_id=a['tenant']['id'], storage_key=f"{a['tenant']['id']}/media/test.txt", mime_type='text/plain', size_bytes=1, status='READY')
    db.add(row)
    db.commit()
    rid = row.id
    db.close()
    assert client.delete(f'/v1/media/{rid}', headers=hb, params={'tenant_id': b['tenant']['id']}).status_code in {403, 404}

def test_duplicate_capture_does_not_double_charge(client):
    x = client.post('/v1/auth/register', json={'email': 'double-capture@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + x['access_token']}
    tid = x['tenant']['id']
    pi = client.post('/v1/payments/intents', headers=h, params={'tenant_id': tid}, json={'amount_minor': 100, 'currency': 'USD', 'provider': 'mock'}).json()
    first = client.post(f"/v1/payments/{pi['id']}/capture", headers=h, params={'tenant_id': tid}).json()
    second = client.post(f"/v1/payments/{pi['id']}/capture", headers=h, params={'tenant_id': tid}).json()
    assert first['status'] == 'CAPTURED' and second['status'] == 'CAPTURED'
    from app.core.database import SessionLocal
    from app.models.domain import PaymentCapture
    db = SessionLocal()
    assert db.query(PaymentCapture).filter_by(payment_intent_id=pi['id']).count() == 1
    db.close()


def test_secure_backup_roundtrip(tmp_path):
    import subprocess, sys
    src = b'rilmo-backup-integrity-check'
    backup = tmp_path / 'backup.rilmo.enc'
    enc = subprocess.run([sys.executable, 'scripts/secure_backup.py', 'encrypt', '--passphrase', 'unit-test-pass', '--output', str(backup)], input=src, capture_output=True)
    assert enc.returncode == 0
    dec = subprocess.run([sys.executable, 'scripts/secure_backup.py', 'decrypt', '--passphrase', 'unit-test-pass', '--input', str(backup)], capture_output=True)
    assert dec.returncode == 0 and dec.stdout == src
    backup.write_bytes(backup.read_bytes()[:-1] + bytes([backup.read_bytes()[-1] ^ 1]))
    bad = subprocess.run([sys.executable, 'scripts/secure_backup.py', 'decrypt', '--passphrase', 'unit-test-pass', '--input', str(backup)], capture_output=True)
    assert bad.returncode != 0
