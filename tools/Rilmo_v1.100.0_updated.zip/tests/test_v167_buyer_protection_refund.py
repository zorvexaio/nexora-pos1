import uuid

def _merchant(client):
    r=client.post('/v1/auth/register',json={'email':f"refund-{uuid.uuid4().hex}@example.com",'password':'VerySecurePassword123!'})
    return {'Authorization':'Bearer '+r.json()['access_token']}

def _paid_order(client, h):
    t=client.post('/v1/tenants',headers=h,json={'slug':f"refund-{uuid.uuid4().hex[:8]}",'name':'Refund Shop','default_currency':'USD','default_locale':'en'}).json()['id']
    p=client.post(f'/v1/products?tenant_id={t}',headers=h,json={'slug':'refund-item','title':'Refund Item','status':'ACTIVE'}).json()
    v=client.post(f'/v1/products/{p["id"]}/variants?tenant_id={t}',headers=h,json={'sku':'RF1','price_amount_minor':1000,'currency':'USD'}).json()
    client.post(f'/v1/inventory/adjustments?tenant_id={t}&variant_id={v["id"]}&delta=5&reason=test',headers=h)
    c=client.post(f'/v1/cart?tenant_id={t}',headers=h,json={'currency':'USD'}).json()
    client.post(f'/v1/cart/items?tenant_id={t}&cart_id={c["id"]}',headers=h,json={'variant_id':v['id'],'quantity':1})
    o=client.post(f'/v1/checkout?tenant_id={t}',headers=h,json={'cart_id':c['id'],'customer_email':'buyer@example.com','customer_name':'Buyer'}).json()
    pi=client.post(f'/v1/payments/intents?tenant_id={t}',headers=h,json={'order_id':o['id'],'amount_minor':o['total_minor'],'currency':'USD','provider':'mock'}).json()
    client.post(f'/v1/payments/{pi["id"]}/capture?tenant_id={t}',headers=h,json={'amount_minor':o['total_minor'],'currency':'USD'})
    return t,o

def test_merchant_resolve_refund_executes_idempotently(client):
    h=_merchant(client); tenant,order=_paid_order(client,h)
    # Seed an issue as a customer-facing record; merchant resolution must execute refund.
    from app.core.database import SessionLocal
    from app.models.domain import OrderIssue, Refund
    db=SessionLocal(); issue=OrderIssue(tenant_id=tenant,order_id=order['id'],customer_id=None,issue_type='REFUND_REQUEST',status='OPEN',customer_message='Refund',idempotency_key='ri-'+uuid.uuid4().hex); db.add(issue); db.commit(); issue_id=issue.id; db.close()
    r=client.patch(f'/v1/merchant/order-issues/{issue_id}?tenant_id={tenant}',headers=h,json={'action':'RESOLVE_REFUND','message':'Refund approved'})
    assert r.status_code==200,r.text
    r2=client.patch(f'/v1/merchant/order-issues/{issue_id}?tenant_id={tenant}',headers=h,json={'action':'RESOLVE_REFUND','message':'Refund approved'})
    assert r2.status_code in (200,409)
    db=SessionLocal(); refunds=db.query(Refund).filter_by(tenant_id=tenant,order_id=order['id']).all(); db.close()
    assert len(refunds)==1
