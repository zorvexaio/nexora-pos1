from datetime import datetime, timezone
from app.core.database import SessionLocal
from app.models.domain import MerchantProfile, MerchantPhoneVerification, Tenant, Storefront, Domain, MerchantTrustScore, TenantReview, Customer, Order

def _register(client, email='trust-merchant@example.com'):
    r=client.post('/v1/auth/register',json={'email':email,'password':'VerySecurePassword123!','display_name':'Verified Brand','phone':'+905551112233','legal_name':'Verified Brand Ltd','country_code':'TR','city':'Istanbul','address_line1':'Test Street 10'})
    assert r.status_code==200, r.text
    return r.json()['tenant']['id']

def test_merchant_profile_and_phone_verification(client):
    tid=_register(client)
    p=client.get(f'/v1/merchant/profile?tenant_id={tid}')
    assert p.status_code==200
    assert p.json()['profile']['phone']=='+905551112233'
    csrf=client.cookies.get('csrf_token'); hdr={'X-CSRF-Token':csrf} if csrf else {}; send=client.post(f'/v1/merchant/phone/send?tenant_id={tid}',headers=hdr,json={'phone':'+905551112233'})
    assert send.status_code==200, send.text
    code=send.json().get('dev_code')
    assert code
    verify=client.post(f'/v1/merchant/phone/verify?tenant_id={tid}',headers=hdr,json={'code':code})
    assert verify.status_code==200, verify.text
    readiness=client.get(f'/v1/merchant/activation-readiness?tenant_id={tid}')
    assert readiness.status_code==200
    assert readiness.json()['checks']['phone_verified'] is True

def test_subscription_cannot_become_active_before_payment(client):
    tid=_register(client,'pending-billing@example.com')
    # inject verification state only; Google is intentionally still missing, so activation remains blocked.
    r=client.get(f'/v1/merchant/activation-readiness?tenant_id={tid}')
    assert r.status_code==200
    assert r.json()['ready'] is False

def test_trust_score_is_exposed_publicly(client):
    tid=_register(client,'public-trust@example.com')
    db=SessionLocal()
    t=db.get(Tenant,tid); s=db.query(Storefront).filter_by(tenant_id=tid).first()
    d=Domain(tenant_id=tid,storefront_id=s.id,hostname='trust-store.example.test',verified_at=datetime.now(timezone.utc),verification_method='test')
    db.add(d); db.add(MerchantTrustScore(tenant_id=tid,trust_score=72,trust_level='GOOD',badge='GOOD_STANDING')); db.commit(); db.close()
    # Store isn't published yet, so the public trust endpoint must not leak tenant information.
    r=client.get('/v1/public/storefront/trust-store.example.test/trust')
    assert r.status_code in {404,503}

def test_domain_registration_requires_payment_and_is_not_immediate(client):
    tid=_register(client,'domain-pending@example.com')
    # cannot reach purchase gate without identity verification; this proves public signup is not enough to buy domains.
    csrf=client.cookies.get('csrf_token'); hdr={'X-CSRF-Token':csrf,'Idempotency-Key':'domain:brand.com'}; r=client.post(f'/v1/domains/purchase?tenant_id={tid}',headers=hdr,json={'hostname':'brand.com','years':1,'registrant_first_name':'Test','registrant_last_name':'Owner','registrant_email':'owner@example.com','registrant_phone':'+905551112233','country_code':'TR','city':'Istanbul','address_line1':'Street 1'})
    assert r.status_code==428

def test_custom_domain_root_and_product_are_real_storefront_routes(client):
    tid=_register(client,'custom-domain@example.com')
    db=SessionLocal()
    t=db.get(Tenant,tid); t.status='ACTIVE'
    s=db.query(Storefront).filter_by(tenant_id=tid).first(); s.status='PUBLISHED'
    from app.models.domain import Product, ProductTranslation
    p=Product(tenant_id=tid,storefront_id=s.id,slug='luxury-item',status='ACTIVE',title='Luxury Item',description='Premium item')
    db.add(p); db.flush()
    db.add(ProductTranslation(tenant_id=tid,product_id=p.id,locale=s.default_locale,name='Luxury Item',description='Premium item'))
    d=Domain(tenant_id=tid,storefront_id=s.id,hostname='luxury-store.example.test',verified_at=datetime.now(timezone.utc),verification_method='test',verified_hostname='luxury-store.example.test')
    db.add(d); db.commit(); db.close()
    root=client.get('/',headers={'Host':'luxury-store.example.test'})
    assert root.status_code==200 and 'store-host' in root.text
    product=client.get('/product/luxury-item',headers={'Host':'luxury-store.example.test'})
    assert product.status_code==200 and 'Luxury Item' in product.text
    robots=client.get('/robots.txt',headers={'Host':'luxury-store.example.test'})
    assert 'Sitemap: https://luxury-store.example.test/sitemap.xml' in robots.text
    sitemap=client.get('/sitemap.xml',headers={'Host':'luxury-store.example.test'})
    assert 'https://luxury-store.example.test/' in sitemap.text and '/product/luxury-item' in sitemap.text
