from app.core.config import get_settings

def test_app_store_policy_endpoint_for_physical_and_digital(client):
    r=client.get('/v1/public/app-store/payment-policy', params={'platform':'apple','market_key':'TR','sku_category':'physical_goods'})
    assert r.status_code==200
    assert r.json()['payment_method']=='merchant_processor_or_apple_pay'
    r=client.get('/v1/public/app-store/payment-policy', params={'platform':'google_play','market_key':'EU','sku_category':'digital_goods'})
    assert r.status_code==200
    assert 'google_play_billing' in r.json()['payment_method']

def test_installment_policy_is_zero_delta(client):
    r=client.get('/v1/public/payment/installation-policy', params={'currency':'TRY'})
    assert r.status_code==200
    body=r.json()
    assert body['same_price_only'] is True
    assert body['price_delta_minor']==0
    assert body['customer_price_equals_base_price'] is True

def test_production_ai_policy_is_local_only_by_default():
    s=get_settings()
    assert s.AI_EXTERNAL_PROVIDER_ALLOWED is False
    assert s.AI_SERVER_ONLY is True

