from decimal import Decimal
import xml.etree.ElementTree as ET
from app.services.tax_engine import calculate_tax
from app.services.zatca import build_zatca_invoice
from app.services.shipping import FlatRateCarrier

def test_tax_exclusive_and_inclusive_rounding():
    a = calculate_tax(amount_minor=10000, rate_bps=1500, inclusive=False)
    assert a.taxable_minor == 10000 and a.tax_minor == 1500
    b = calculate_tax(amount_minor=11500, rate_bps=1500, inclusive=True)
    assert b.taxable_minor == 10000 and b.tax_minor == 1500

def test_flat_shipping_quote_is_deterministic():
    r = FlatRateCarrier(2500, 'SAR').quote(origin={}, destination={}, parcels=[], currency='SAR')[0]
    assert r.amount_minor == 2500 and r.currency == 'SAR'

def test_zatca_ubl_invoice_is_parseable_and_hashed():
    xml, digest = build_zatca_invoice(invoice_number='INV-100', issue_date='2026-08-16', currency='SAR', seller={'vat_number': '300000000000003', 'city': 'Riyadh', 'country_code': 'SA'}, buyer={'country_code': 'SA', 'city': 'Jeddah'}, lines=[{'quantity': 2, 'title': 'Test Product', 'unit_price_minor': 5000, 'total_minor': 10000}], tax_total_minor=1500, subtotal_minor=10000, total_minor=11500)
    ET.fromstring(xml)
    assert len(digest) == 64
