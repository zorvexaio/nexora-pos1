from __future__ import annotations

import json
import subprocess
import sys
import zipfile
from pathlib import Path


SCRIPT = Path("scripts/release_artifact_audit.py")


def _make_valid_fixture(tmp_path: Path) -> Path:
    payload = b"trusted payload\n"
    manifest = {
        "release": "Unified Global Commerce",
        "version": "9.9.9",
        "generated_at": "2026-08-23",
        "file_count": 1,
        "files": [
            {
                "path": "payload.txt",
                "sha256": __import__("hashlib").sha256(payload).hexdigest(),
                "bytes": len(payload),
            }
        ],
    }
    zip_path = tmp_path / "Unified_Global_Commerce_v9.9.9_RELEASE.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("payload.txt", payload)
        zf.writestr("RELEASE_MANIFEST.json", json.dumps(manifest))
        zf.writestr("SHA256MANIFEST.txt", f"{manifest['files'][0]['sha256']}  payload.txt\n")
    return zip_path


def _run(zip_path: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(SCRIPT), "--zip", str(zip_path)],
        text=True,
        capture_output=True,
        check=False,
    )


def test_release_artifact_audit_accepts_exact_artifact(tmp_path):
    result = _run(_make_valid_fixture(tmp_path))
    assert result.returncode == 0, result.stdout + result.stderr
    assert "RELEASE_ARTIFACT_AUDIT_PASS" in result.stdout


def test_release_artifact_audit_rejects_missing_manifest_file(tmp_path):
    src = _make_valid_fixture(tmp_path)
    broken = tmp_path / "missing.zip"
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(broken, "w") as zout:
        for info in zin.infolist():
            if info.filename != "payload.txt":
                zout.writestr(info, zin.read(info.filename))
    result = _run(broken)
    assert result.returncode != 0
    assert "missing from ZIP" in result.stdout


def test_release_artifact_audit_rejects_hash_tampering(tmp_path):
    src = _make_valid_fixture(tmp_path)
    broken = tmp_path / "tampered.zip"
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(broken, "w") as zout:
        for info in zin.infolist():
            data = zin.read(info.filename)
            if info.filename == "payload.txt":
                data = b"Xrusted payload\n"
            zout.writestr(info, data)
    result = _run(broken)
    assert result.returncode != 0
    assert "SHA-256 mismatch" in result.stdout


def test_release_artifact_audit_rejects_unmanifested_file(tmp_path):
    src = _make_valid_fixture(tmp_path)
    broken = tmp_path / "extra.zip"
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(broken, "w") as zout:
        for info in zin.infolist():
            zout.writestr(info, zin.read(info.filename))
        zout.writestr("hidden.txt", b"must not ship silently")
    result = _run(broken)
    assert result.returncode != 0
    assert "absent from manifest" in result.stdout


def test_build_release_excludes_runtime_media_store(tmp_path):
    source = Path("scripts/build_release.py").read_text(encoding="utf-8")
    assert '"media_store"' in source
