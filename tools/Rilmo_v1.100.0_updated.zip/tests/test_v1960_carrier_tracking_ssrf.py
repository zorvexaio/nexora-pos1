import pytest
from app.services.shipping import ConfiguredCarrier

def _carrier(tracking_path='/shipments/{tracking_number}'):
    c = object.__new__(ConfiguredCarrier)
    c.name = 'test'
    c.base_url = 'https://carrier.example'
    c.api_token = 'x'
    c.timeout = 15
    c.tracking_path = tracking_path
    return c

def test_tracking_number_cannot_override_carrier_authority(monkeypatch):
    carrier = _carrier()
    seen = {}
    def fake_request(method, path, **kwargs):
        seen['path'] = path
        return {}
    monkeypatch.setattr(carrier, '_request', fake_request)
    carrier.track('//evil.example/x')
    assert seen['path'] == '/shipments/%2F%2Fevil.example%2Fx'

def test_tracking_path_must_be_origin_relative(monkeypatch):
    carrier = _carrier('//{tracking_number}')
    with pytest.raises(Exception):
        carrier.track('abc')
