from app.core.database import SessionLocal
from app.models.domain import ShippingMethod


def _merchant_with_order(client, email, amount=1000):
    m = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    p = client.post(f'/v1/products?tenant_id={tid}', headers=h, json={'slug': 'ship-quote-item', 'title': 'Item', 'status': 'ACTIVE'}).json()
    v = client.post(f"/v1/products/{p['id']}/variants?tenant_id={tid}", headers=h, json={'sku': 'SQ-1', 'price_amount_minor': amount, 'currency': 'USD'}).json()
    client.post(f"/v1/inventory/adjustments?tenant_id={tid}&variant_id={v['id']}&delta=5&reason=test", headers=h)
    c = client.post(f'/v1/cart?tenant_id={tid}', headers=h).json()
    client.post(f"/v1/cart/items?tenant_id={tid}&cart_id={c['id']}", headers=h, json={'variant_id': v['id'], 'quantity': 1})
    order = client.post(f'/v1/checkout?tenant_id={tid}', headers=h, json={'cart_id': c['id']}).json()
    return tid, h, order


# --- shipping quote --------------------------------------------------

def test_shipping_quote_returns_no_rates_when_none_configured(client):
    tid, h, order = _merchant_with_order(client, 'shipquote-none@example.com')
    r = client.post(f'/v1/shipping/quote?tenant_id={tid}', headers=h, json={
        'subtotal_minor': 1000, 'currency': 'USD',
        'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    assert r.status_code == 404
    assert r.json()['detail']['error']['code'] == 'NO_SHIPPING_RATES'

def test_shipping_quote_returns_configured_flat_rate(client):
    tid, h, order = _merchant_with_order(client, 'shipquote-flat@example.com')
    db = SessionLocal()
    db.add(ShippingMethod(tenant_id=tid, name='Standard', carrier_code='platform', mode='FLAT',
        amount_minor=500, currency='USD'))
    db.commit()
    db.close()
    r = client.post(f'/v1/shipping/quote?tenant_id={tid}', headers=h, json={
        'subtotal_minor': 1000, 'currency': 'USD',
        'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    assert r.status_code == 200, r.text
    assert any(rate['amount_minor'] == 500 for rate in r.json())

def test_shipping_quote_applies_free_shipping_over_threshold(client):
    tid, h, order = _merchant_with_order(client, 'shipquote-free@example.com')
    db = SessionLocal()
    db.add(ShippingMethod(tenant_id=tid, name='Free over 50', carrier_code='platform', mode='FLAT',
        amount_minor=800, currency='USD', free_shipping=True, free_shipping_threshold_minor=5000))
    db.commit()
    db.close()
    r = client.post(f'/v1/shipping/quote?tenant_id={tid}', headers=h, json={
        'subtotal_minor': 6000, 'currency': 'USD',
        'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    assert r.status_code == 200, r.text
    assert any(rate['amount_minor'] == 0 for rate in r.json())

def test_shipping_quote_filters_by_currency(client):
    tid, h, order = _merchant_with_order(client, 'shipquote-currency@example.com')
    db = SessionLocal()
    db.add(ShippingMethod(tenant_id=tid, name='EUR Rate', carrier_code='platform', mode='FLAT',
        amount_minor=500, currency='EUR'))
    db.commit()
    db.close()
    r = client.post(f'/v1/shipping/quote?tenant_id={tid}', headers=h, json={
        'subtotal_minor': 1000, 'currency': 'USD',
        'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    assert r.status_code == 404


# --- shipment creation: platform carrier + idempotency edges ------------

def test_create_shipment_missing_order_returns_not_found(client):
    m = client.post('/v1/auth/register', json={'email': 'shipment-missing@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    r = client.post(f'/v1/orders/does-not-exist/shipments?tenant_id={tid}', headers=h, json={
        'carrier_code': 'platform', 'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    assert r.status_code == 404

def test_create_shipment_rejects_unconfigured_carrier(client):
    tid, h, order = _merchant_with_order(client, 'shipment-unconfigured@example.com')
    r = client.post(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=h, json={
        'carrier_code': 'dhl', 'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    assert r.status_code == 503
    assert r.json()['detail']['error']['code'] == 'CARRIER_NOT_CONFIGURED'

def test_create_shipment_platform_carrier_is_quote_only_not_label_creation(client):
    tid, h, order = _merchant_with_order(client, 'shipment-platform@example.com')
    r = client.post(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=h, json={
        'carrier_code': 'platform', 'service_code': 'standard',
        'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    # FlatRateCarrier is a rate-quote-only implementation and intentionally
    # cannot create a real shipment/label — this is expected behavior.
    assert r.status_code == 503
    assert r.json()['detail']['error']['code'] == 'CARRIER_NOT_CONFIGURED'

def _configure_carrier(tid):
    from app.core.security import encrypt_secret
    db = SessionLocal()
    from app.models.domain import CarrierAccount
    db.add(CarrierAccount(tenant_id=tid, carrier_code='fastship', status='ACTIVE',
        api_base_url='https://carrier.example.com', api_token_encrypted=encrypt_secret('fake-token')))
    db.commit()
    db.close()

def test_create_shipment_with_configured_carrier_succeeds(client, monkeypatch):
    from app.services import shipping as shipping_module
    tid, h, order = _merchant_with_order(client, 'shipment-configured@example.com')
    _configure_carrier(tid)
    monkeypatch.setattr(shipping_module, 'validate_outbound_url', lambda url, **kw: url)
    monkeypatch.setattr(shipping_module.ConfiguredCarrier, 'create_shipment',
        lambda self, **kw: {'shipment_id': 'X-1', 'tracking_number': 'TRACK-1', 'label_url': 'https://labels.example.com/1', 'status': 'CREATED'})
    r = client.post(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=h, json={
        'carrier_code': 'fastship', 'service_code': 'standard',
        'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    assert r.status_code == 200, r.text
    assert r.json()['tracking_number'] == 'TRACK-1'

def test_create_shipment_idempotency_returns_cached_response(client, monkeypatch):
    from app.services import shipping as shipping_module
    tid, h, order = _merchant_with_order(client, 'shipment-idem@example.com')
    _configure_carrier(tid)
    monkeypatch.setattr(shipping_module, 'validate_outbound_url', lambda url, **kw: url)
    monkeypatch.setattr(shipping_module.ConfiguredCarrier, 'create_shipment',
        lambda self, **kw: {'shipment_id': 'X-2', 'tracking_number': 'TRACK-2', 'label_url': 'https://labels.example.com/2', 'status': 'CREATED'})
    payload = {'carrier_code': 'fastship', 'service_code': 'standard',
        'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}]}
    headers = {**h, 'Idempotency-Key': 'ship-once'}
    first = client.post(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=headers, json=payload)
    second = client.post(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=headers, json=payload)
    assert first.status_code == 200
    assert second.status_code == 200
    assert first.json()['id'] == second.json()['id']

def test_create_shipment_idempotency_key_reuse_with_different_body_conflicts(client, monkeypatch):
    from app.services import shipping as shipping_module
    tid, h, order = _merchant_with_order(client, 'shipment-idemconflict@example.com')
    _configure_carrier(tid)
    monkeypatch.setattr(shipping_module, 'validate_outbound_url', lambda url, **kw: url)
    monkeypatch.setattr(shipping_module.ConfiguredCarrier, 'create_shipment',
        lambda self, **kw: {'shipment_id': 'X-3', 'tracking_number': 'TRACK-3', 'label_url': 'https://labels.example.com/3', 'status': 'CREATED'})
    headers = {**h, 'Idempotency-Key': 'ship-conflict'}
    first = client.post(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=headers, json={
        'carrier_code': 'fastship', 'service_code': 'standard',
        'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    assert first.status_code == 200
    second = client.post(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=headers, json={
        'carrier_code': 'fastship', 'service_code': 'express',
        'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 2}],
    })
    assert second.status_code == 409
    assert second.json()['detail']['error']['code'] == 'IDEMPOTENCY_MISMATCH'


# --- list shipments ----------------------------------------------------

def test_list_order_shipments_missing_order_returns_not_found(client):
    m = client.post('/v1/auth/register', json={'email': 'shipmentlist-missing@example.com', 'password': 'VerySecurePassword123!'}).json()
    h = {'Authorization': 'Bearer ' + m['access_token']}
    tid = m['tenant']['id']
    r = client.get(f'/v1/orders/does-not-exist/shipments?tenant_id={tid}', headers=h)
    assert r.status_code == 404

def test_list_order_shipments_returns_created_shipment(client, monkeypatch):
    from app.services import shipping as shipping_module
    tid, h, order = _merchant_with_order(client, 'shipmentlist-ok@example.com')
    _configure_carrier(tid)
    monkeypatch.setattr(shipping_module, 'validate_outbound_url', lambda url, **kw: url)
    monkeypatch.setattr(shipping_module.ConfiguredCarrier, 'create_shipment',
        lambda self, **kw: {'shipment_id': 'X-4', 'tracking_number': 'TRACK-4', 'label_url': 'https://labels.example.com/4', 'status': 'CREATED'})
    client.post(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=h, json={
        'carrier_code': 'fastship', 'origin': {'country': 'US'}, 'destination': {'country': 'US'}, 'parcels': [{'weight_kg': 1}],
    })
    r = client.get(f"/v1/orders/{order['id']}/shipments?tenant_id={tid}", headers=h)
    assert r.status_code == 200
    assert len(r.json()['items']) == 1
