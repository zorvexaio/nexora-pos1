from datetime import datetime, timezone
from app.models.domain import Storefront, Domain, Product, ProductVariant, Tenant

def _register(client, email):
    r=client.post('/v1/auth/register',json={'email':email,'password':'VerySecurePassword123!','display_name':'Agent Policy'})
    assert r.status_code==200, r.text
    return r.json()

def test_agent_transaction_policy_fields_and_migration(client):
    from pathlib import Path
    text=(Path(__file__).resolve().parents[1]/'app/models/domain.py').read_text()
    assert 'max_checkout_total_minor' in text and 'allowed_currencies' in text
    mig=(Path(__file__).resolve().parents[1]/'alembic/versions/20260819_0049_agent_transaction_limits.py').read_text()
    assert 'agent_profiles' in mig and 'max_checkout_total_minor' in mig and 'allowed_currencies' in mig

def test_agent_spend_currency_and_country_limits_are_enforced(client):
    x=_register(client,'agent-policy-v154@example.com'); h={'Authorization':'Bearer '+x['access_token']}; tid=x['tenant']['id']
    created=client.post('/v1/agents',params={'tenant_id':tid},headers=h,json={
        'client_id':'limited-agent','slug':'limited-agent','name':'Limited Agent','scopes':['checkout:complete'],
        'allowed_countries':['TR'],'allowed_currencies':['TRY'],'max_checkout_total_minor':1000})
    assert created.status_code==200, created.text
    # Directly exercise the policy helper with a persisted profile; UCP route tests below rely on its checks.
    from app.core.database import SessionLocal
    from app.services.global_control_plane import authorize_agent_action
    db=SessionLocal()
    try:
        profile,_=authorize_agent_action(db,tid,'limited-agent',created.json()['client_secret'],'checkout.complete','ucp_checkout_session','r1','h1','id1')
        assert profile.allowed_countries==['TR'] and profile.allowed_currencies==['TRY'] and profile.max_checkout_total_minor==1000
        db.commit()
    finally: db.close()

def test_agent_policy_is_returned_without_secrets(client):
    x=_register(client,'agent-policy-public-v154@example.com'); h={'Authorization':'Bearer '+x['access_token']}; tid=x['tenant']['id']; host=f"{x['tenant']['slug']}.example.com"
    created=client.post('/v1/agents',params={'tenant_id':tid},headers=h,json={'client_id':'policy-public','slug':'policy-public','name':'Policy Public','scopes':['checkout:complete'],'allowed_countries':['TR'],'allowed_currencies':['TRY'],'max_checkout_total_minor':5000})
    assert created.status_code==200
    from app.core.database import SessionLocal
    db=SessionLocal()
    try:
        sf=db.query(Storefront).filter_by(tenant_id=tid).first()
        db.query(Tenant).filter_by(id=tid).update({'status':'ACTIVE'})
        db.add(Domain(tenant_id=tid, storefront_id=sf.id, hostname=host, verified_at=datetime.now(timezone.utc), is_primary=True))
        db.commit()
    finally: db.close()
    r=client.get('/v1/public/storefront/'+host+'/agent-policy',params={'client_id':'policy-public'})
    assert r.status_code==200, r.text
    b=r.json(); assert b['allowed_currencies']==['TRY'] and b['max_checkout_total_minor']==5000
    assert 'access_token' not in b and 'client_secret' not in b

def test_ucp_agent_transaction_limits_block_overspend(client):
    x=_register(client,'agent-ucp-limit-v154@example.com'); h={'Authorization':'Bearer '+x['access_token']}; tid=x['tenant']['id']; host='agent-limit-v154.example.test'
    db=__import__('app.core.database', fromlist=['SessionLocal']).SessionLocal()
    try:
        sf=db.query(Storefront).filter_by(tenant_id=tid).first(); db.query(Tenant).filter_by(id=tid).update({'status':'ACTIVE'})
        db.add(Domain(tenant_id=tid, storefront_id=sf.id, hostname=host, verified_at=datetime.now(timezone.utc), is_primary=True))
        product=Product(tenant_id=tid,slug='agent-limit-product',title='Agent Limit Product',status='PUBLISHED'); db.add(product); db.flush()
        variant=ProductVariant(tenant_id=tid,product_id=product.id,sku='AL-1',price_amount_minor=1500,currency='TRY',status='ACTIVE'); db.add(variant); db.commit(); vid=variant.id
    finally: db.close()
    created=client.post('/v1/agents',params={'tenant_id':tid},headers=h,json={'client_id':'limited-ucp','slug':'limited-ucp','name':'Limited UCP','scopes':['checkout:complete'],'allowed_countries':['TR'],'allowed_currencies':['TRY'],'max_checkout_total_minor':1000})
    assert created.status_code==200
    checkout=client.post('/v1/public/storefront/'+host+'/ucp/checkouts',json={'external_session_id':'limit-1','currency':'TRY','line_items':[{'variant_id':vid,'quantity':1}],'buyer':{'country_code':'TR'}})
    assert checkout.status_code==200
    agent_secret=created.json()['client_secret']
    headers={'Idempotency-Key':'limit-id-1','Authorization':'Bearer '+agent_secret,'UCP-Agent':f'profile="https://{host}/.well-known/agent/limited-ucp.json"'}
    blocked=client.post('/v1/public/storefront/'+host+'/ucp/checkouts/limit-1/complete',params={'agent_client_id':'limited-ucp'},headers=headers)
    assert blocked.status_code==403 and blocked.json()['detail']['error']['code']=='AGENT_SPEND_LIMIT_EXCEEDED'
