from types import SimpleNamespace
from decimal import Decimal
import pytest
import httpx
from app.core.errors import AppError
from app.services.fx import FXProvider, get_fx_provider
from app.services.tax_engine import calculate_tax, calculate_lines
from app.services import domain_registrar as dr


# --- fx.py -----------------------------------------------------------

def test_fx_quote_returns_one_for_identical_currencies():
    p = FXProvider()
    assert p.quote(base='usd', quote='USD') == Decimal('1')

def test_fx_quote_raises_not_configured_for_different_currencies():
    p = FXProvider()
    with pytest.raises(AppError) as exc:
        p.quote(base='USD', quote='EUR')
    assert exc.value.code == 'FX_NOT_CONFIGURED'

def test_fx_convert_minor_same_currency_returns_same_amount():
    p = FXProvider()
    assert p.convert_minor(amount_minor=1500, base='USD', quote='usd') == 1500

def test_fx_convert_minor_rejects_negative_amount():
    p = FXProvider()
    with pytest.raises(AppError) as exc:
        p.convert_minor(amount_minor=-1, base='USD', quote='USD')
    assert exc.value.code == 'FX_AMOUNT_INVALID'

def test_get_fx_provider_returns_fx_provider_instance():
    assert isinstance(get_fx_provider(), FXProvider)


# --- tax_engine.py -----------------------------------------------------

def test_calculate_tax_exclusive_basic():
    result = calculate_tax(amount_minor=10000, rate_bps=2000)  # 20%
    assert result.taxable_minor == 10000
    assert result.tax_minor == 2000
    assert result.inclusive is False

def test_calculate_tax_inclusive_basic():
    result = calculate_tax(amount_minor=12000, rate_bps=2000, inclusive=True)  # 20% inclusive
    assert result.taxable_minor + result.tax_minor == 12000
    assert result.tax_minor == 2000

def test_calculate_tax_zero_rate_inclusive_has_no_tax():
    result = calculate_tax(amount_minor=10000, rate_bps=0, inclusive=True)
    assert result.tax_minor == 0
    assert result.taxable_minor == 10000

def test_calculate_tax_rejects_negative_amount():
    with pytest.raises(AppError) as exc:
        calculate_tax(amount_minor=-1, rate_bps=1000)
    assert exc.value.code == 'TAX_INPUT_INVALID'

def test_calculate_tax_rejects_negative_rate():
    with pytest.raises(AppError):
        calculate_tax(amount_minor=1000, rate_bps=-1)

def test_calculate_tax_rejects_rate_above_100_percent():
    with pytest.raises(AppError):
        calculate_tax(amount_minor=1000, rate_bps=10001)

def test_calculate_tax_accepts_rate_at_upper_bound():
    result = calculate_tax(amount_minor=1000, rate_bps=10000)  # 100%
    assert result.tax_minor == 1000

def test_calculate_lines_sums_tax_across_multiple_lines():
    lines = [1000, 2000, 3000]
    results, total = calculate_lines(lines, rate_bps=1000)  # 10%
    assert len(results) == 3
    assert total == sum(r.tax_minor for r in results)
    assert total == 100 + 200 + 300

def test_calculate_lines_empty_list_returns_zero_total():
    results, total = calculate_lines([], rate_bps=1000)
    assert results == []
    assert total == 0


# --- domain_registrar.py: normalize_domain --------------------------------

def test_normalize_domain_accepts_valid_hostname():
    assert dr.normalize_domain('Example.COM.') == 'example.com'

def test_normalize_domain_rejects_www_prefix():
    with pytest.raises(AppError) as exc:
        dr.normalize_domain('www.example.com')
    assert exc.value.code == 'DOMAIN_INVALID'

def test_normalize_domain_rejects_invalid_format():
    with pytest.raises(AppError):
        dr.normalize_domain('not a domain!!')

def test_normalize_domain_rejects_missing_tld():
    with pytest.raises(AppError):
        dr.normalize_domain('localhost')


# --- domain_registrar.py: check_domain / register_domain ------------------

def _settings(**overrides):
    base = dict(DOMAIN_PROVIDER='cloudflare', DOMAIN_PROVIDER_ACCOUNT_ID='acc123', DOMAIN_PROVIDER_API_TOKEN='tok456')
    base.update(overrides)
    return SimpleNamespace(**base)

def test_check_domain_raises_when_provider_unsupported(monkeypatch):
    monkeypatch.setattr(dr, 'get_settings', lambda: _settings(DOMAIN_PROVIDER='godaddy'))
    with pytest.raises(AppError) as exc:
        dr.check_domain('example.com')
    assert exc.value.code == 'DOMAIN_PROVIDER_NOT_CONFIGURED'

def test_check_domain_raises_when_credentials_missing(monkeypatch):
    monkeypatch.setattr(dr, 'get_settings', lambda: _settings(DOMAIN_PROVIDER_ACCOUNT_ID=''))
    with pytest.raises(AppError) as exc:
        dr.check_domain('example.com')
    assert exc.value.code == 'DOMAIN_PROVIDER_NOT_CONFIGURED'

def test_check_domain_returns_registrable_result(monkeypatch):
    monkeypatch.setattr(dr, 'get_settings', lambda: _settings())
    class _Resp:
        status_code = 200
        def json(self):
            return {'result': {'domains': [{'name': 'example.com', 'registrable': True, 'tier': 'standard', 'pricing': {'registration_cost': 12.5, 'renewal_cost': 15.0}}]}}
    monkeypatch.setattr(dr.httpx, 'post', lambda *a, **k: _Resp())
    result = dr.check_domain('example.com')
    assert result['registrable'] is True
    assert result['registration_cost_minor'] == 1250
    assert result['renewal_cost_minor'] == 1500

def test_check_domain_raises_on_provider_error_status(monkeypatch):
    monkeypatch.setattr(dr, 'get_settings', lambda: _settings())
    class _Resp:
        status_code = 500
        def json(self): return {}
    monkeypatch.setattr(dr.httpx, 'post', lambda *a, **k: _Resp())
    with pytest.raises(AppError) as exc:
        dr.check_domain('example.com')
    assert exc.value.code == 'DOMAIN_PROVIDER_ERROR'

def test_check_domain_raises_unavailable_on_network_error(monkeypatch):
    monkeypatch.setattr(dr, 'get_settings', lambda: _settings())
    def _raise(*a, **k):
        raise httpx.ConnectError('down')
    monkeypatch.setattr(dr.httpx, 'post', _raise)
    with pytest.raises(AppError) as exc:
        dr.check_domain('example.com')
    assert exc.value.code == 'DOMAIN_PROVIDER_UNAVAILABLE'

def _registrant():
    return {
        'registrant_first_name': 'Jane', 'registrant_last_name': 'Doe',
        'registrant_email': 'jane@example.com', 'registrant_phone': '+15551234567',
        'country_code': 'us', 'city': 'Austin', 'address_line1': '123 Main St', 'postal_code': '78701',
    }

def test_register_domain_raises_when_provider_unsupported(monkeypatch):
    monkeypatch.setattr(dr, 'get_settings', lambda: _settings(DOMAIN_PROVIDER='other'))
    with pytest.raises(AppError) as exc:
        dr.register_domain('example.com', _registrant(), 1)
    assert exc.value.code == 'DOMAIN_PROVIDER_NOT_CONFIGURED'

def test_register_domain_returns_registered_status_on_success(monkeypatch):
    monkeypatch.setattr(dr, 'get_settings', lambda: _settings())
    class _Resp:
        status_code = 200
        def json(self):
            return {'result': {'id': 'reg-123', 'domain_name': 'example.com'}}
    monkeypatch.setattr(dr.httpx, 'post', lambda *a, **k: _Resp())
    result = dr.register_domain('example.com', _registrant(), 1)
    assert result['status'] == 'REGISTERED'
    assert result['reference'] == 'reg-123'

def test_register_domain_raises_on_registration_failure(monkeypatch):
    monkeypatch.setattr(dr, 'get_settings', lambda: _settings())
    class _Resp:
        status_code = 422
        def json(self): return {}
    monkeypatch.setattr(dr.httpx, 'post', lambda *a, **k: _Resp())
    with pytest.raises(AppError) as exc:
        dr.register_domain('example.com', _registrant(), 1)
    assert exc.value.code == 'DOMAIN_REGISTRATION_FAILED'

def test_register_domain_raises_unavailable_on_network_error(monkeypatch):
    monkeypatch.setattr(dr, 'get_settings', lambda: _settings())
    def _raise(*a, **k):
        raise httpx.ConnectError('down')
    monkeypatch.setattr(dr.httpx, 'post', _raise)
    with pytest.raises(AppError) as exc:
        dr.register_domain('example.com', _registrant(), 1)
    assert exc.value.code == 'DOMAIN_PROVIDER_UNAVAILABLE'
