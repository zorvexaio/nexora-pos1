import hashlib, hmac, json, time

def _signed(body: bytes, secret: str, ts: int | None=None):
    ts = ts or int(time.time())
    digest=hmac.new(secret.encode(), f'{ts}:'.encode()+body, hashlib.sha256).hexdigest()
    return f'ts={ts};h1={digest}'

def test_removed_installment_webhooks_are_gone(client):
    for path in ['/v1/webhooks/tabby','/v1/webhooks/tamara']:
        assert client.post(path,json={}).status_code==404

def test_paddle_webhook_replay_is_idempotent(client, monkeypatch):
    secret='pdl_test_secret_1234567890'; monkeypatch.setenv('PADDLE_WEBHOOK_SECRET',secret)
    from app.core.config import get_settings; get_settings.cache_clear()
    payload={'event_id':'evt_01testpaddle1234567890123456','event_type':'customer.created','data':{'id':'ctm_test','custom_data':{}}}
    body=json.dumps(payload,separators=(',',':')).encode(); headers={'Paddle-Signature':_signed(body,secret)}
    r=client.post('/v1/webhooks/paddle',content=body,headers=headers); assert r.status_code==200
    r2=client.post('/v1/webhooks/paddle',content=body,headers=headers); assert r2.status_code==200 and r2.json()['duplicate'] is True

def test_paddle_webhook_rejects_bad_signature(client, monkeypatch):
    secret='pdl_test_secret_1234567890'; monkeypatch.setenv('PADDLE_WEBHOOK_SECRET',secret)
    from app.core.config import get_settings; get_settings.cache_clear()
    body=b'{"event_id":"evt_bad","event_type":"customer.created","data":{}}'
    r=client.post('/v1/webhooks/paddle',content=body,headers={'Paddle-Signature':'ts=1;h1=bad'})
    assert r.status_code==400

def test_paddle_signature_rejects_stale_timestamp(client, monkeypatch):
    secret='pdl_test_secret_1234567890'; monkeypatch.setenv('PADDLE_WEBHOOK_SECRET',secret)
    from app.core.config import get_settings; get_settings.cache_clear()
    body=b'{"event_id":"evt_stale","event_type":"customer.created","data":{}}'
    headers={'Paddle-Signature':_signed(body,secret,int(time.time())-301)}
    r=client.post('/v1/webhooks/paddle',content=body,headers=headers)
    assert r.status_code==400
