from datetime import datetime, timezone
from app.models.domain import Product, ProductPassport, ProductPassportRevision, Storefront, Domain


def _register(client, email):
    r = client.post('/v1/auth/register', json={'email': email, 'password': 'VerySecurePassword123!', 'display_name': 'DPP'})
    assert r.status_code == 200, r.text
    x = r.json()
    return x['tenant']['id'], {'Authorization': 'Bearer ' + x['access_token']}

def test_product_passport_create_publish_and_public_endpoint(client):
    tid, headers = _register(client, 'dpp-owner@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=headers,
                    json={'slug': 'passport-item', 'title': 'Passport Item', 'status': 'PUBLISHED'}).json()
    from app.core.database import SessionLocal
    db = SessionLocal()
    sf = Storefront(tenant_id=tid, slug='main', name='Passport Store', status='PUBLISHED')
    from app.models.domain import Tenant
    tenant = db.get(Tenant, tid); tenant.status = 'ACTIVE'
    db.add(sf); db.flush()
    db.add(Domain(tenant_id=tid, storefront_id=sf.id, hostname='passport-store.example.test',
                  verified_at=datetime.now(timezone.utc), is_primary=True))
    db.commit(); db.close()
    r = client.put(f'/v1/products/{p["id"]}/digital-passport?tenant_id={tid}', headers=headers, json={
        'status': 'PUBLISHED', 'origin_country': 'TR', 'manufacturer_name': 'Rilmo Labs',
        'conformance_profile': 'ESPR-DPP-2026', 'identifier_scheme': 'GTIN',
        'manufacturer_address': 'Industrial Zone 1, Istanbul, TR', 'manufacturer_contact': 'safety@rilmo.example',
        'responsible_person_name': 'EU Responsible Operator', 'responsible_person_address': 'EU Business Address',
        'responsible_person_contact': 'eu-responsible@rilmo.example', 'economic_operator_role': 'MANUFACTURER',
        'product_identifier': '09506000134352', 'safety_warnings': ['Keep away from heat'],
        'recall_information': {'policy': 'contact-support'},
        'unique_product_identifier': '09506000134352', 'data_carrier': 'QR',
        'registry_status': 'TESTING', 'registry_reference': 'registry-test-001',
        'materials': [{'name': 'Aluminium', 'percentage': 80}],
        'certifications': [{'scheme': 'ISO', 'reference': 'SAFE-1'}],
        'compliance_claims': ['RECYCLABLE'],
        'circularity': {'recycled_content_pct': 80},
        'sustainability': {'repairability_score': 8},
        'public_data': {'care': 'Keep dry'},
        'change_reason': 'initial publication',
    })
    assert r.status_code == 200
    assert 'public_token' not in r.json()['passport']
    template = r.json()['passport']['public_url_template']
    token = template.rsplit('/', 1)[-1]
    assert len(token) >= 32
    pub = client.get(f'/v1/public/storefront/passport-store.example.test/products/passport-item/digital-passport/{token}')
    assert pub.status_code == 200, pub.text
    body = pub.json()
    assert body['scheme'] == 'Rilmo-DPP-1'
    assert body['conformance_profile'] == 'ESPR-DPP-2026'
    assert body['identifier_scheme'] == 'GTIN'
    assert body['unique_product_identifier'] == '09506000134352'
    assert body['data_carrier'] == 'QR'
    assert body['registry_status'] == 'TESTING'
    assert body['registry_reference'] == 'registry-test-001'
    assert body['origin_country'] == 'TR'
    assert body['manufacturer_name'] == 'Rilmo Labs'
    assert body['manufacturer_address'] == 'Industrial Zone 1, Istanbul, TR'
    assert body['responsible_person_name'] == 'EU Responsible Operator'
    assert body['product_identifier'] == '09506000134352'
    assert body['safety_warnings'] == ['Keep away from heat']
    assert 'public_data' in body
    assert 'tenant_id' not in body
    assert 'secret' not in body


def test_product_passport_revision_increments(client):
    tid, headers = _register(client, 'dpp-revision@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=headers,
                    json={'slug': 'passport-revision', 'title': 'Passport Revision', 'status': 'PUBLISHED'}).json()
    a = client.put(f'/v1/products/{p["id"]}/digital-passport?tenant_id={tid}', headers=headers,
                   json={'status': 'DRAFT', 'origin_country': 'DE', 'public_data': {'v': 1}})
    b = client.put(f'/v1/products/{p["id"]}/digital-passport?tenant_id={tid}', headers=headers,
                   json={'status': 'PUBLISHED', 'origin_country': 'DE', 'unique_product_identifier': '09506000134352', 'manufacturer_name': 'Rilmo Labs', 'public_data': {'v': 2}, 'change_reason': 'publish'})
    assert a.status_code == 200 and b.status_code == 200
    assert b.json()['passport']['version'] == 2


def test_product_passport_rejects_oversized_payload(client):
    tid, headers = _register(client, 'dpp-size@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=headers, json={'slug': 'passport-size', 'title': 'Passport Size', 'status': 'PUBLISHED'}).json()
    huge = 'x' * 70000
    r = client.put(f'/v1/products/{p["id"]}/digital-passport?tenant_id={tid}', headers=headers, json={'public_data': {'huge': huge}})
    assert r.status_code == 413


def test_product_passport_public_endpoint_rate_limits(monkeypatch, client):
    tid, headers = _register(client, 'dpp-rate@example.com')
    from app.core.database import SessionLocal
    db = SessionLocal()
    from app.models.domain import Tenant, Product, Storefront, Domain
    tenant = db.get(Tenant, tid); tenant.status = 'ACTIVE'
    product = Product(tenant_id=tid, slug='passport-rate', title='Passport Rate', status='PUBLISHED')
    db.add(product); db.flush()
    sf = Storefront(tenant_id=tid, slug='main-rate', name='Rate Store', status='PUBLISHED')
    db.add(sf); db.flush()
    db.add(Domain(tenant_id=tid, storefront_id=sf.id, hostname='passport-rate.example.test', verified_at=datetime.now(timezone.utc)))
    db.add(ProductPassport(tenant_id=tid, product_id=product.id, public_token='a'*64, status='PUBLISHED'))
    db.commit(); db.close()
    monkeypatch.setattr('app.routes.worldclass.enforce_rate_limit', lambda db, *args, **kwargs: (_ for _ in ()).throw(__import__('app.core.errors', fromlist=['AppError']).AppError(429, 'RATE_LIMITED', 'Too many requests')))
    r = client.get('/v1/public/storefront/passport-rate.example.test/products/passport-rate/digital-passport/' + 'a'*64)
    assert r.status_code == 429


def test_published_product_passport_requires_unique_identifier(client):
    tid, headers = _register(client, 'dpp-identifier-required@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=headers,
                    json={'slug': 'passport-id-required', 'title': 'Passport ID Required', 'status': 'PUBLISHED'}).json()
    r = client.put(f"/v1/products/{p['id']}/digital-passport?tenant_id={tid}", headers=headers,
                   json={'status': 'PUBLISHED', 'origin_country': 'TR'})
    assert r.status_code == 422
    assert r.json()['detail']['error']['code'] == 'DPP_IDENTIFIER_REQUIRED'


def test_product_passport_rejects_invalid_registry_status(client):
    tid, headers = _register(client, 'dpp-registry-status@example.com')
    p = client.post(f'/v1/products?tenant_id={tid}', headers=headers,
                    json={'slug': 'passport-registry-status', 'title': 'Passport Registry Status', 'status': 'PUBLISHED'}).json()
    r = client.put(f"/v1/products/{p['id']}/digital-passport?tenant_id={tid}", headers=headers,
                   json={'status': 'DRAFT', 'registry_status': 'HACKED'})
    assert r.status_code == 422
    assert r.json()['detail']['error']['code'] == 'DPP_REGISTRY_STATUS_INVALID'
