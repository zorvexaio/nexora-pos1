from pathlib import Path


def test_ucp_completion_locks_checkout_row_for_concurrent_completion():
    src = Path('app/routes/worldclass.py').read_text(encoding='utf-8')
    needle = "db.query(UCPCheckoutSession)\n        .filter_by(tenant_id=tenant.id, external_session_id=external_session_id)\n        .with_for_update()"
    assert needle in src
