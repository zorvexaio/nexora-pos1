from app.core.database import SessionLocal
from app.models.domain import MFAFactor, PlatformAdmin, User
from app.core.security import hash_password


def test_generic_platform_admin_dependency_rejects_specialist_roles_without_dedicated_grant():
    from app.core.auth import current_platform_admin
    from fastapi import HTTPException
    db = SessionLocal()
    try:
        u = User(email='compliance-generic-admin-v1968@example.com', password_hash=hash_password('x'), status='ACTIVE')
        db.add(u); db.flush()
        db.add(MFAFactor(user_id=u.id, factor_type='TOTP', secret_encrypted='x', enabled=True))
        db.add(PlatformAdmin(user_id=u.id, platform_role='compliance_officer'))
        db.commit()
        try:
            current_platform_admin.__wrapped__
        except AttributeError:
            pass
        try:
            current_platform_admin.__call__
        except AttributeError:
            pass
        # Dependency functions are ordinary callables; inject explicit args directly.
        try:
            current_platform_admin(user=u, db=db)
        except HTTPException as exc:
            assert exc.status_code == 403
        else:
            raise AssertionError('specialist role must not satisfy generic platform admin dependency')
    finally:
        db.close()
