from alembic import op
import sqlalchemy as sa

revision = "20260822_0063"
down_revision = "20260821_0062"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("loyalty_transactions", sa.Column("request_hash", sa.String(length=128), nullable=True))
    op.create_index("ix_loyalty_transactions_request_hash", "loyalty_transactions", ["request_hash"])

def downgrade():
    op.drop_index("ix_loyalty_transactions_request_hash", table_name="loyalty_transactions")
    op.drop_column("loyalty_transactions", "request_hash")
