from alembic import op
import sqlalchemy as sa

revision = '20260819_0051'
down_revision = '20260819_0050'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('global_market_profiles',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('market_key', sa.String(80), nullable=False),
        sa.Column('country_code', sa.String(2), nullable=False),
        sa.Column('region_code', sa.String(40)),
        sa.Column('status', sa.String(24), nullable=False, server_default='PLANNED'),
        sa.Column('legal_review_status', sa.String(24), nullable=False, server_default='REQUIRED'),
        sa.Column('tax_invoicing_status', sa.String(24), nullable=False, server_default='REQUIRED'),
        sa.Column('payments_status', sa.String(24), nullable=False, server_default='REQUIRED'),
        sa.Column('data_transfer_status', sa.String(24), nullable=False, server_default='REQUIRED'),
        sa.Column('app_store_status', sa.String(24), nullable=False, server_default='REQUIRED'),
        sa.Column('requirements', sa.JSON(), nullable=False, server_default='{}'),
        sa.Column('last_reviewed_at', sa.DateTime(timezone=True)),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('market_key'))
    op.create_index('ix_global_market_profiles_country','global_market_profiles',['country_code'])
    op.create_index('ix_global_market_profiles_market_key','global_market_profiles',['market_key'],unique=True)

    op.create_table('global_launch_evidence',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('market_key', sa.String(80), nullable=False),
        sa.Column('requirement_code', sa.String(100), nullable=False),
        sa.Column('status', sa.String(24), nullable=False, server_default='MISSING'),
        sa.Column('evidence_ref', sa.String(500)),
        sa.Column('source_url', sa.String(2000)),
        sa.Column('verified_at', sa.DateTime(timezone=True)),
        sa.Column('expires_at', sa.DateTime(timezone=True)),
        sa.Column('reviewer_user_id', sa.String(36)),
        sa.Column('notes', sa.Text()),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('market_key','requirement_code'))
    op.create_index('ix_global_launch_evidence_market','global_launch_evidence',['market_key'])
    op.create_index('ix_global_launch_evidence_status','global_launch_evidence',['market_key','status'])

    op.create_table('app_store_distribution_policies',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('platform', sa.String(30), nullable=False),
        sa.Column('market_key', sa.String(80), nullable=False),
        sa.Column('sku_category', sa.String(40), nullable=False),
        sa.Column('payment_method', sa.String(80), nullable=False),
        sa.Column('allowed', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('policy_reference', sa.String(255), nullable=False),
        sa.Column('notes', sa.Text()),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('platform','market_key','sku_category'))
    op.create_index('ix_app_store_policies_market','app_store_distribution_policies',['market_key'])

    op.create_table('merchant_marketplace_traceability',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), nullable=False),
        sa.Column('trade_register_name', sa.String(255)),
        sa.Column('trade_register_number', sa.String(120)),
        sa.Column('payout_account_reference', sa.String(255)),
        sa.Column('seller_self_certification', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('verified_at', sa.DateTime(timezone=True)),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id'))
    op.create_index('ix_merchant_marketplace_traceability_tenant','merchant_marketplace_traceability',['tenant_id'],unique=True)
    conn=op.get_bind()
    # Global market/evidence/app-store policy tables are platform-control-plane data and are
    # protected by platform-admin authorization at the API layer. Merchant traceability is
    # tenant-owned and therefore receives PostgreSQL RLS.
    if conn.dialect.name == 'postgresql':
        op.execute(sa.text('ALTER TABLE merchant_marketplace_traceability ENABLE ROW LEVEL SECURITY'))
        op.execute(sa.text('ALTER TABLE merchant_marketplace_traceability FORCE ROW LEVEL SECURITY'))
        op.execute(sa.text("CREATE POLICY merchant_traceability_tenant_iso ON merchant_marketplace_traceability USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))"))

def downgrade():
    conn=op.get_bind()
    if conn.dialect.name == 'postgresql':
        op.execute(sa.text('DROP POLICY IF EXISTS merchant_traceability_tenant_iso ON merchant_marketplace_traceability'))
        op.execute(sa.text('ALTER TABLE merchant_marketplace_traceability DISABLE ROW LEVEL SECURITY'))
    op.drop_index('ix_merchant_marketplace_traceability_tenant', table_name='merchant_marketplace_traceability')
    op.drop_table('merchant_marketplace_traceability')
    op.drop_index('ix_app_store_policies_market', table_name='app_store_distribution_policies')
    op.drop_table('app_store_distribution_policies')
    op.drop_index('ix_global_launch_evidence_status', table_name='global_launch_evidence')
    op.drop_index('ix_global_launch_evidence_market', table_name='global_launch_evidence')
    op.drop_table('global_launch_evidence')
    op.drop_index('ix_global_market_profiles_market_key', table_name='global_market_profiles')
    op.drop_index('ix_global_market_profiles_country', table_name='global_market_profiles')
    op.drop_table('global_market_profiles')
