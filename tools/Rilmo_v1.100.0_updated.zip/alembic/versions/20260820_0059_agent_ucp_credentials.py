from alembic import op
import sqlalchemy as sa
revision = "20260820_0059"
down_revision = "20260820_0058"
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table("agent_profiles", recreate="always") as batch:
        batch.add_column(sa.Column("client_secret_hash", sa.String(128), nullable=False, server_default=""))

def downgrade():
    with op.batch_alter_table("agent_profiles", recreate="always") as batch:
        batch.drop_column("client_secret_hash")
