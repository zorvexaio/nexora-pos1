"""Add optimistic concurrency versions to mutable commerce resources."""
from alembic import op
import sqlalchemy as sa

revision = '20260816_0015'
down_revision = '20260816_0014'
branch_labels = None
depends_on = None

TABLES = ('tenants','domains','product_variants','categories','shipping_methods','tax_rates')

def upgrade():
    for table in TABLES:
        op.add_column(table, sa.Column('version', sa.Integer(), nullable=False, server_default='1'))

def downgrade():
    for table in reversed(TABLES):
        op.drop_column(table, 'version')
