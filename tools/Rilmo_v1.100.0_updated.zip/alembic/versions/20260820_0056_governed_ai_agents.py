"""Governed AI policy, quota accounting and agent role boundary.

Revision ID: 20260820_0056
Revises: 20260820_0055
"""
from alembic import op
import sqlalchemy as sa

revision = '20260820_0056'
down_revision = '20260820_0055'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('tenant_ai_policies',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False, unique=True),
        sa.Column('enabled', sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column('customer_agent_enabled', sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column('merchant_agent_enabled', sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column('daily_request_limit', sa.Integer(), nullable=False, server_default='1000'),
        sa.Column('allow_external_data', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_tenant_ai_policies_tenant_id', 'tenant_ai_policies', ['tenant_id'])
    op.create_index('ix_tenant_ai_policies_enabled', 'tenant_ai_policies', ['enabled'])
    op.create_table('ai_daily_usage',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('agent_role', sa.String(24), nullable=False),
        sa.Column('usage_date', sa.String(10), nullable=False),
        sa.Column('requests_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('fallback_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('blocked_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('last_provider', sa.String(40), nullable=True),
        sa.Column('last_used_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id', 'agent_role', 'usage_date'),
    )
    op.create_index('ix_ai_daily_usage_tenant_id', 'ai_daily_usage', ['tenant_id'])
    op.create_index('ix_ai_daily_usage_tenant_date', 'ai_daily_usage', ['tenant_id', 'usage_date'])
    if op.get_bind().dialect.name == 'postgresql':
        op.execute('ALTER TABLE tenant_ai_policies ENABLE ROW LEVEL SECURITY')
        op.execute('ALTER TABLE tenant_ai_policies FORCE ROW LEVEL SECURITY')
        op.execute("CREATE POLICY tenant_ai_policies_tenant_isolation ON tenant_ai_policies USING (tenant_id = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id = current_setting('app.current_tenant', true))")
        op.execute('ALTER TABLE ai_daily_usage ENABLE ROW LEVEL SECURITY')
        op.execute('ALTER TABLE ai_daily_usage FORCE ROW LEVEL SECURITY')
        op.execute('CREATE POLICY ai_daily_usage_tenant_isolation ON ai_daily_usage USING (tenant_id = current_setting(\'app.current_tenant\', true)) WITH CHECK (tenant_id = current_setting(\'app.current_tenant\', true))')

def downgrade():
    if op.get_bind().dialect.name == 'postgresql':
        op.execute('DROP POLICY IF EXISTS ai_daily_usage_tenant_isolation ON ai_daily_usage')
        op.execute('DROP POLICY IF EXISTS tenant_ai_policies_tenant_isolation ON tenant_ai_policies')
    op.drop_index('ix_ai_daily_usage_tenant_date', table_name='ai_daily_usage')
    op.drop_index('ix_ai_daily_usage_tenant_id', table_name='ai_daily_usage')
    op.drop_table('ai_daily_usage')
    op.drop_index('ix_tenant_ai_policies_enabled', table_name='tenant_ai_policies')
    op.drop_index('ix_tenant_ai_policies_tenant_id', table_name='tenant_ai_policies')
    op.drop_table('tenant_ai_policies')
