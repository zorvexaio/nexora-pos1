from alembic import op
import sqlalchemy as sa
revision='20260819_0047'
down_revision='20260819_0046'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('workflow_webhook_deliveries',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('workflow_run_id',sa.String(36),sa.ForeignKey('workflow_runs.id'),nullable=False),
        sa.Column('step_position',sa.Integer(),nullable=False),
        sa.Column('endpoint_url',sa.Text(),nullable=False),
        sa.Column('payload',sa.JSON(),nullable=False),
        sa.Column('status',sa.String(20),nullable=False,server_default='PENDING'),
        sa.Column('attempt_count',sa.Integer(),nullable=False,server_default='0'),
        sa.Column('next_attempt_at',sa.DateTime(timezone=True)),
        sa.Column('last_error',sa.Text()),
        sa.Column('delivered_at',sa.DateTime(timezone=True)),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
        sa.UniqueConstraint('workflow_run_id','step_position'))
    op.create_index('ix_workflow_webhook_deliveries_tenant_id','workflow_webhook_deliveries',['tenant_id'])
    op.create_index('ix_workflow_webhook_deliveries_workflow_run_id','workflow_webhook_deliveries',['workflow_run_id'])
    op.create_index('ix_workflow_webhook_deliveries_next_attempt_at','workflow_webhook_deliveries',['next_attempt_at'])
    op.create_index('ix_workflow_webhook_tenant_status','workflow_webhook_deliveries',['tenant_id','status'])
    conn=op.get_bind()
    if conn.dialect.name=='postgresql':
        op.execute(sa.text('ALTER TABLE workflow_webhook_deliveries ENABLE ROW LEVEL SECURITY'))
        op.execute(sa.text('ALTER TABLE workflow_webhook_deliveries FORCE ROW LEVEL SECURITY'))
        op.execute(sa.text("CREATE POLICY workflow_webhook_deliveries_tenant_isolation ON workflow_webhook_deliveries USING (tenant_id = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id = current_setting('app.current_tenant', true))"))

def downgrade():
    conn=op.get_bind()
    if conn.dialect.name=='postgresql':
        op.execute(sa.text('DROP POLICY IF EXISTS workflow_webhook_deliveries_tenant_isolation ON workflow_webhook_deliveries'))
        op.execute(sa.text('ALTER TABLE workflow_webhook_deliveries NO FORCE ROW LEVEL SECURITY'))
        op.execute(sa.text('ALTER TABLE workflow_webhook_deliveries DISABLE ROW LEVEL SECURITY'))
    op.drop_table('workflow_webhook_deliveries')
