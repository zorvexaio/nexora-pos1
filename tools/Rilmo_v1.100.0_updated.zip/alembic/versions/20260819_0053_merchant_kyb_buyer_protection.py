from alembic import op
import sqlalchemy as sa

revision = '20260819_0053'
down_revision = '20260819_0052'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('order_issues',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('order_id', sa.String(36), sa.ForeignKey('orders.id'), nullable=False),
        sa.Column('customer_id', sa.String(36), sa.ForeignKey('customers.id'), nullable=True),
        sa.Column('issue_type', sa.String(40), nullable=False),
        sa.Column('status', sa.String(24), nullable=False, server_default='OPEN'),
        sa.Column('customer_message', sa.Text(), nullable=False),
        sa.Column('merchant_message', sa.Text(), nullable=True),
        sa.Column('resolution', sa.String(40), nullable=True),
        sa.Column('idempotency_key', sa.String(200), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','idempotency_key'))
    op.create_index('ix_order_issues_tenant','order_issues',['tenant_id'])
    op.create_index('ix_order_issues_order','order_issues',['order_id'])
    op.create_index('ix_order_issues_customer','order_issues',['customer_id'])
    op.create_index('ix_order_issues_status','order_issues',['tenant_id','status'])


def downgrade():
    op.drop_index('ix_order_issues_status', table_name='order_issues')
    op.drop_index('ix_order_issues_customer', table_name='order_issues')
    op.drop_index('ix_order_issues_order', table_name='order_issues')
    op.drop_index('ix_order_issues_tenant', table_name='order_issues')
    op.drop_table('order_issues')
