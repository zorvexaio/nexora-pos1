from alembic import op
import sqlalchemy as sa

revision = "20260819_0048"
down_revision = "20260819_0047"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "product_passports",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("tenant_id", sa.String(36), sa.ForeignKey("tenants.id"), nullable=False),
        sa.Column("product_id", sa.String(36), sa.ForeignKey("products.id"), nullable=False),
        sa.Column("public_token", sa.String(96), nullable=False),
        sa.Column("scheme", sa.String(80), nullable=False, server_default="Rilmo-DPP-1"),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("status", sa.String(20), nullable=False, server_default="DRAFT"),
        sa.Column("origin_country", sa.String(2)),
        sa.Column("manufacturer_name", sa.String(255)),
        sa.Column("materials", sa.JSON(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("certifications", sa.JSON(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("compliance_claims", sa.JSON(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("circularity", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("sustainability", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("public_data", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("effective_at", sa.DateTime(timezone=True)),
        sa.Column("expires_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("public_token"),
        sa.UniqueConstraint("tenant_id", "product_id"),
    )
    op.create_index("ix_product_passports_tenant_status", "product_passports", ["tenant_id", "status"])
    op.create_index("ix_product_passports_public_token", "product_passports", ["public_token"])
    op.create_index("ix_product_passports_product_id", "product_passports", ["product_id"])

    op.create_table(
        "product_passport_revisions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("tenant_id", sa.String(36), sa.ForeignKey("tenants.id"), nullable=False),
        sa.Column("product_passport_id", sa.String(36), sa.ForeignKey("product_passports.id"), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("snapshot", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("change_reason", sa.String(255), nullable=False, server_default="update"),
        sa.Column("actor_id", sa.String(36)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("product_passport_id", "version"),
    )
    op.create_index("ix_product_passport_revisions_tenant_passport", "product_passport_revisions", ["tenant_id", "product_passport_id"])
    op.create_index("ix_product_passport_revisions_product_passport_id", "product_passport_revisions", ["product_passport_id"])

    conn = op.get_bind()
    if conn.dialect.name == "postgresql":
        for table in ("product_passports", "product_passport_revisions"):
            op.execute(sa.text(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY"))
            op.execute(sa.text(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY"))
            policy = f"{table}_tenant_isolation"
            op.execute(sa.text(f"CREATE POLICY {policy} ON {table} USING (tenant_id = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id = current_setting('app.current_tenant', true))"))

def downgrade():
    conn = op.get_bind()
    if conn.dialect.name == "postgresql":
        for table in ("product_passport_revisions", "product_passports"):
            op.execute(sa.text(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}"))
            op.execute(sa.text(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY"))
            op.execute(sa.text(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY"))
    op.drop_table("product_passport_revisions")
    op.drop_table("product_passports")
