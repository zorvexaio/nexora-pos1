"""Close remaining v1.8 canonical tables and relationships."""
from alembic import op
import sqlalchemy as sa

revision='20260816_0009'
down_revision='20260816_0008'
branch_labels=None
depends_on=None


def upgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql':
        # SQLite development schema is created from ORM metadata.
        return
    uuid=sa.String(36); ts=sa.DateTime(timezone=True); js=sa.JSON()
    op.create_table('roles',
        sa.Column('id',uuid,primary_key=True), sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id')), sa.Column('name',sa.String(100),nullable=False), sa.Column('system_role',sa.Boolean(),nullable=False,server_default=sa.false()),
        sa.UniqueConstraint('tenant_id','name',name='uq_roles_tenant_name'))
    op.create_table('permissions',sa.Column('id',uuid,primary_key=True),sa.Column('code',sa.String(120),nullable=False,unique=True))
    # Preserve the legacy role/permission string columns while adding canonical references.
    op.add_column('role_permissions',sa.Column('role_id',uuid,nullable=True))
    op.add_column('role_permissions',sa.Column('permission_id',uuid,nullable=True))
    op.create_foreign_key('fk_role_permissions_role','role_permissions','roles',['role_id'],['id'])
    op.create_foreign_key('fk_role_permissions_permission','role_permissions','permissions',['permission_id'],['id'])
    op.create_table('product_categories',
        sa.Column('product_id',uuid,sa.ForeignKey('products.id'),primary_key=True),sa.Column('category_id',uuid,sa.ForeignKey('categories.id'),primary_key=True))
    op.create_table('product_media',
        sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),primary_key=True),sa.Column('product_id',uuid,sa.ForeignKey('products.id'),primary_key=True),sa.Column('media_asset_id',uuid,sa.ForeignKey('media_assets.id'),primary_key=True),sa.Column('position',sa.Integer(),nullable=False,server_default='0'),sa.Column('alt_text',sa.Text()))
    op.create_table('customer_addresses',
        sa.Column('id',uuid,primary_key=True),sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),nullable=False),sa.Column('customer_id',uuid,sa.ForeignKey('customers.id'),nullable=False),sa.Column('country_code',sa.String(2),nullable=False),sa.Column('region',sa.String(120)),sa.Column('city',sa.String(120)),sa.Column('postal_code',sa.String(32)),sa.Column('address_line1',sa.Text(),nullable=False),sa.Column('address_line2',sa.Text()),sa.Column('type',sa.String(20),nullable=False,server_default='SHIPPING'))
    op.create_check_constraint('ck_customer_address_type','customer_addresses',"type IN ('BILLING','SHIPPING')")
    op.create_table('tax_jurisdictions',sa.Column('id',uuid,primary_key=True),sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),nullable=False),sa.Column('country_code',sa.String(2),nullable=False),sa.Column('region_code',sa.String(80)),sa.Column('city',sa.String(120)),sa.Column('name',sa.String(255),nullable=False),sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'),sa.UniqueConstraint('tenant_id','country_code','region_code','city',name='uq_tax_jurisdiction_scope'))
    op.create_table('tax_classes',sa.Column('id',uuid,primary_key=True),sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),nullable=False),sa.Column('code',sa.String(80),nullable=False),sa.Column('name',sa.String(255),nullable=False),sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'),sa.UniqueConstraint('tenant_id','code',name='uq_tax_class_code'))
    op.create_table('tax_calculations',sa.Column('id',uuid,primary_key=True),sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),nullable=False),sa.Column('order_id',uuid,sa.ForeignKey('orders.id')),sa.Column('currency',sa.String(3),nullable=False),sa.Column('provider',sa.String(80)),sa.Column('provider_reference',sa.String(255)),sa.Column('subtotal_minor',sa.BigInteger(),nullable=False),sa.Column('tax_total_minor',sa.BigInteger(),nullable=False),sa.Column('created_at',ts,nullable=False,server_default=sa.func.now()))
    op.create_table('tax_lines',sa.Column('id',uuid,primary_key=True),sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),nullable=False),sa.Column('tax_calculation_id',uuid,sa.ForeignKey('tax_calculations.id'),nullable=False),sa.Column('jurisdiction_id',uuid,sa.ForeignKey('tax_jurisdictions.id')),sa.Column('tax_class_id',uuid,sa.ForeignKey('tax_classes.id')),sa.Column('taxable_amount_minor',sa.BigInteger(),nullable=False),sa.Column('tax_amount_minor',sa.BigInteger(),nullable=False),sa.Column('rate_bps',sa.Integer()),sa.Column('currency',sa.String(3),nullable=False))
    op.create_check_constraint('ck_tax_line_nonnegative','tax_lines','taxable_amount_minor >= 0 AND tax_amount_minor >= 0 AND (rate_bps IS NULL OR (rate_bps >= 0 AND rate_bps <= 10000))')
    op.create_table('plan_prices',sa.Column('id',uuid,primary_key=True),sa.Column('plan_version_id',uuid,sa.ForeignKey('plan_versions.id'),nullable=False),sa.Column('billing_interval',sa.String(20),nullable=False),sa.Column('amount_minor_units',sa.BigInteger(),nullable=False),sa.Column('currency',sa.String(3),nullable=False),sa.Column('stripe_price_id',sa.String(255)),sa.Column('created_at',ts,nullable=False,server_default=sa.func.now()),sa.UniqueConstraint('plan_version_id','billing_interval','currency',name='uq_plan_price_variant'))
    op.create_table('subscription_items',sa.Column('id',uuid,primary_key=True),sa.Column('subscription_id',uuid,sa.ForeignKey('subscriptions.id'),nullable=False),sa.Column('plan_price_id',uuid,sa.ForeignKey('plan_prices.id'),nullable=False),sa.Column('quantity',sa.Integer(),nullable=False,server_default='1'))
    op.create_check_constraint('ck_subscription_item_quantity','subscription_items','quantity > 0')
    op.create_table('billing_events',sa.Column('id',uuid,primary_key=True),sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),nullable=False),sa.Column('subscription_id',uuid,sa.ForeignKey('subscriptions.id')),sa.Column('event_type',sa.String(120),nullable=False),sa.Column('provider_event_id',sa.String(255),nullable=False,unique=True),sa.Column('payload',js,nullable=False),sa.Column('status',sa.String(20),nullable=False,server_default='RECEIVED'),sa.Column('received_at',ts,nullable=False,server_default=sa.func.now()),sa.Column('processed_at',ts),sa.Column('created_at',ts,nullable=False,server_default=sa.func.now()))
    op.create_check_constraint('ck_billing_event_status','billing_events',"status IN ('RECEIVED','PROCESSING','PROCESSED','FAILED')")
    op.create_table('tenant_entitlements',sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),primary_key=True),sa.Column('feature_key',sa.String(100),primary_key=True),sa.Column('value_type',sa.String(20),nullable=False),sa.Column('value_boolean',sa.Boolean()),sa.Column('value_integer',sa.Integer()),sa.Column('source_subscription_id',uuid,sa.ForeignKey('subscriptions.id')),sa.Column('resolved_at',ts,nullable=False,server_default=sa.func.now()))
    op.create_table('review_questions',sa.Column('id',uuid,primary_key=True),sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),nullable=False),sa.Column('product_id',uuid,sa.ForeignKey('products.id'),nullable=False),sa.Column('customer_id',uuid,sa.ForeignKey('customers.id'),nullable=False),sa.Column('body',sa.Text(),nullable=False),sa.Column('status',sa.String(20),nullable=False,server_default='unanswered'),sa.Column('created_at',ts,nullable=False,server_default=sa.func.now()))
    op.create_table('review_answers',sa.Column('id',uuid,primary_key=True),sa.Column('question_id',uuid,sa.ForeignKey('review_questions.id'),nullable=False),sa.Column('tenant_id',uuid,sa.ForeignKey('tenants.id'),nullable=False),sa.Column('answered_by_user_id',uuid,sa.ForeignKey('users.id'),nullable=False),sa.Column('body',sa.Text(),nullable=False),sa.Column('created_at',ts,nullable=False,server_default=sa.func.now()))
    for table in ['roles','product_media','customer_addresses','tax_jurisdictions','tax_classes','tax_calculations','tax_lines','billing_events','tenant_entitlements','review_questions','review_answers']:
        op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
        op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (current_setting('app.worker', true)='on' OR tenant_id::text=current_setting('app.current_tenant', true)) WITH CHECK (current_setting('app.worker', true)='on' OR tenant_id::text=current_setting('app.current_tenant', true))")

def downgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql': return
    for table in ['review_answers','review_questions','tenant_entitlements','billing_events','subscription_items','plan_prices','tax_lines','tax_calculations','tax_classes','tax_jurisdictions','customer_addresses','product_media','product_categories','permissions','roles']:
        op.execute(f'DROP TABLE IF EXISTS {table} CASCADE')
    op.drop_constraint('fk_role_permissions_permission','role_permissions',type_='foreignkey')
    op.drop_constraint('fk_role_permissions_role','role_permissions',type_='foreignkey')
    op.drop_column('role_permissions','permission_id'); op.drop_column('role_permissions','role_id')
