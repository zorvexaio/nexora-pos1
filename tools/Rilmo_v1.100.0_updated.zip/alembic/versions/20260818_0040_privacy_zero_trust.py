from alembic import op
import sqlalchemy as sa

revision = '20260818_0040'
down_revision = '20260818_0039'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('privacy_access_grants',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('verification_id', sa.String(length=36), sa.ForeignKey('merchant_identity_verifications.id'), nullable=False),
        sa.Column('case_id', sa.String(length=36), sa.ForeignKey('merchant_review_cases.id'), nullable=False),
        sa.Column('requester_user_id', sa.String(length=36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('purpose', sa.String(length=255), nullable=False),
        sa.Column('ticket_ref', sa.String(length=120), nullable=False),
        sa.Column('status', sa.String(length=24), nullable=False, server_default='GRANTED'),
        sa.Column('provider_access_reference', sa.String(length=255)),
        sa.Column('granted_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('revoked_at', sa.DateTime(timezone=True)),
        sa.Column('ip_hash', sa.String(length=128)),
    )
    op.create_index('ix_privacy_access_grants_tenant_status','privacy_access_grants',['tenant_id','status'])
    op.create_index('ix_privacy_access_grants_expires_at','privacy_access_grants',['expires_at'])
    op.create_table('privacy_incidents',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('jurisdiction', sa.String(length=40), nullable=False),
        sa.Column('status', sa.String(length=24), nullable=False, server_default='DETECTED'),
        sa.Column('severity', sa.String(length=16), nullable=False, server_default='MEDIUM'),
        sa.Column('detected_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('assessed_at', sa.DateTime(timezone=True)),
        sa.Column('authority_due_at', sa.DateTime(timezone=True)),
        sa.Column('affected_subjects_estimate', sa.Integer()),
        sa.Column('data_categories', sa.JSON()),
        sa.Column('containment_notes', sa.Text()),
        sa.Column('notification_decision', sa.String(length=32)),
        sa.Column('notification_at', sa.DateTime(timezone=True)),
        sa.Column('owner_user_id', sa.String(length=36), sa.ForeignKey('users.id')),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_privacy_incidents_status_created','privacy_incidents',['status','detected_at'])
    op.create_table('privacy_transfer_register',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('processor_name', sa.String(length=160), nullable=False),
        sa.Column('role', sa.String(length=32), nullable=False, server_default='PROCESSOR'),
        sa.Column('destination_country', sa.String(length=2), nullable=False),
        sa.Column('mechanism', sa.String(length=80), nullable=False),
        sa.Column('data_categories', sa.JSON(), nullable=False),
        sa.Column('purpose', sa.Text(), nullable=False),
        sa.Column('contract_reference', sa.String(length=160)),
        sa.Column('policy_version', sa.String(length=50), nullable=False, server_default='privacy-v1'),
        sa.Column('active', sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column('reviewed_at', sa.DateTime(timezone=True)),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('processor_name','destination_country','mechanism',name='uq_privacy_transfer_register_route'),
    )
    op.add_column('app_installations', sa.Column('last_used_at', sa.DateTime(timezone=True)))

def downgrade():
    op.drop_column('app_installations','last_used_at')
    op.drop_table('privacy_transfer_register')
    op.drop_index('ix_privacy_incidents_status_created',table_name='privacy_incidents')
    op.drop_table('privacy_incidents')
    op.drop_index('ix_privacy_access_grants_expires_at',table_name='privacy_access_grants')
    op.drop_index('ix_privacy_access_grants_tenant_status',table_name='privacy_access_grants')
    op.drop_table('privacy_access_grants')
