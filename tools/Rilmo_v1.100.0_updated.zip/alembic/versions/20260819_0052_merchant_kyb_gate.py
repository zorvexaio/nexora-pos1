from alembic import op
import sqlalchemy as sa

revision = '20260819_0052'
down_revision = '20260819_0051'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('merchant_profiles', sa.Column('registration_number', sa.String(160), nullable=True))
    op.add_column('merchant_profiles', sa.Column('business_registry_country', sa.String(2), nullable=True))
    op.add_column('merchant_profiles', sa.Column('beneficial_owner_name', sa.String(255), nullable=True))
    op.add_column('merchant_profiles', sa.Column('beneficial_owner_country', sa.String(2), nullable=True))
    op.add_column('merchant_profiles', sa.Column('kyb_status', sa.String(32), nullable=False, server_default='NOT_STARTED'))
    op.add_column('merchant_profiles', sa.Column('kyb_verified_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('merchant_profiles', sa.Column('kyb_verification_method', sa.String(40), nullable=True))
    op.add_column('merchant_profiles', sa.Column('kyb_evidence_hash', sa.String(128), nullable=True))


def downgrade():
    op.drop_column('merchant_profiles', 'kyb_evidence_hash')
    op.drop_column('merchant_profiles', 'kyb_verification_method')
    op.drop_column('merchant_profiles', 'kyb_verified_at')
    op.drop_column('merchant_profiles', 'kyb_status')
    op.drop_column('merchant_profiles', 'beneficial_owner_country')
    op.drop_column('merchant_profiles', 'beneficial_owner_name')
    op.drop_column('merchant_profiles', 'business_registry_country')
    op.drop_column('merchant_profiles', 'registration_number')
