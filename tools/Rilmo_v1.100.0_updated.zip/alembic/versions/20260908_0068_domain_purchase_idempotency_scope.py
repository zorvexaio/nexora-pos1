"""Scope domain purchase idempotency keys to their owning tenant."""
from alembic import op
revision = "20260908_0068"
down_revision = "20260825_0067"
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    if bind.dialect.name != 'postgresql':
        return
    op.drop_constraint('domain_purchases_idempotency_key_key', 'domain_purchases', type_='unique')
    op.create_unique_constraint('uq_domain_purchases_tenant_idempotency', 'domain_purchases', ['tenant_id', 'idempotency_key'])

def downgrade():
    bind = op.get_bind()
    if bind.dialect.name != 'postgresql':
        return
    op.drop_constraint('uq_domain_purchases_tenant_idempotency', 'domain_purchases', type_='unique')
    op.create_unique_constraint('domain_purchases_idempotency_key_key', 'domain_purchases', ['idempotency_key'])
