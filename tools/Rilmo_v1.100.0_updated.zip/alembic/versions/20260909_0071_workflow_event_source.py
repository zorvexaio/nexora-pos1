"""Add durable workflow source-event idempotency."""
from alembic import op
import sqlalchemy as sa

revision = '0071'
down_revision = '20260909_0070'
branch_labels = None
depends_on = None


def upgrade():
    # batch mode keeps the migration executable on SQLite test/CI databases
    # while emitting normal ALTER/constraint DDL on PostgreSQL.
    with op.batch_alter_table('workflow_runs', recreate='auto') as batch:
        batch.add_column(sa.Column('source_event_id', sa.String(length=36), nullable=True))
        batch.create_index('ix_workflow_runs_source_event_id', ['source_event_id'])
        batch.create_foreign_key('fk_workflow_runs_source_event', 'outbox_events', ['source_event_id'], ['id'])
        batch.create_unique_constraint('uq_workflow_run_source_event', ['tenant_id', 'workflow_id', 'source_event_id'])


def downgrade():
    with op.batch_alter_table('workflow_runs', recreate='auto') as batch:
        batch.drop_constraint('uq_workflow_run_source_event', type_='unique')
        batch.drop_constraint('fk_workflow_runs_source_event', type_='foreignkey')
        batch.drop_index('ix_workflow_runs_source_event_id')
        batch.drop_column('source_event_id')
