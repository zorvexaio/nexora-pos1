"""merchant trust, identity verification and domain commerce

Revision ID: 20260818_0035
Revises: 20260818_0034
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision='20260818_0035'
down_revision='20260818_0034'
branch_labels=None
depends_on=None
JSON = postgresql.JSONB().with_variant(sa.JSON(), 'sqlite')


def upgrade():
    op.create_table('merchant_profiles',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),nullable=False),
        sa.Column('legal_name',sa.String(255),nullable=False),sa.Column('phone',sa.String(32),nullable=False),
        sa.Column('country_code',sa.String(2),nullable=False),sa.Column('city',sa.String(120),nullable=False),
        sa.Column('address_line1',sa.String(255),nullable=False),sa.Column('postal_code',sa.String(30)),
        sa.Column('tax_id',sa.String(120)),sa.Column('business_type',sa.String(40),nullable=False,server_default='individual'),
        sa.Column('identity_status',sa.String(24),nullable=False,server_default='PENDING'),
        sa.Column('phone_verified_at',sa.DateTime(timezone=True)),sa.Column('google_verified_at',sa.DateTime(timezone=True)),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False),
        sa.ForeignKeyConstraint(['tenant_id'],['tenants.id']),sa.UniqueConstraint('tenant_id'))
    op.create_index('ix_merchant_profiles_tenant_id','merchant_profiles',['tenant_id'])
    op.create_table('merchant_phone_verifications',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),nullable=False),
        sa.Column('phone',sa.String(32),nullable=False),sa.Column('code_hash',sa.String(128),nullable=False),
        sa.Column('expires_at',sa.DateTime(timezone=True),nullable=False),sa.Column('attempts',sa.Integer(),nullable=False,server_default='0'),
        sa.Column('used_at',sa.DateTime(timezone=True)),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
        sa.ForeignKeyConstraint(['tenant_id'],['tenants.id']),sa.UniqueConstraint('tenant_id','phone'))
    op.create_index('ix_merchant_phone_verifications_tenant_id','merchant_phone_verifications',['tenant_id'])
    op.create_index('ix_merchant_phone_verifications_code_hash','merchant_phone_verifications',['code_hash'])
    op.create_index('ix_merchant_phone_verifications_expires_at','merchant_phone_verifications',['expires_at'])
    op.create_table('tenant_reviews',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),nullable=False),sa.Column('customer_id',sa.String(36),nullable=False),
        sa.Column('order_id',sa.String(36)),sa.Column('rating',sa.Integer(),nullable=False),sa.Column('body',sa.Text()),
        sa.Column('status',sa.String(20),nullable=False,server_default='PENDING'),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False),
        sa.ForeignKeyConstraint(['tenant_id'],['tenants.id']),sa.ForeignKeyConstraint(['customer_id'],['customers.id']),sa.ForeignKeyConstraint(['order_id'],['orders.id']),sa.UniqueConstraint('tenant_id','customer_id'))
    op.create_index('ix_tenant_reviews_tenant_id','tenant_reviews',['tenant_id'])
    op.create_index('ix_tenant_reviews_customer_id','tenant_reviews',['customer_id'])
    op.create_index('ix_tenant_reviews_order_id','tenant_reviews',['order_id'])
    op.create_table('trust_reports',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),nullable=False),sa.Column('reporter_customer_id',sa.String(36)),sa.Column('reporter_user_id',sa.String(36)),
        sa.Column('reason',sa.String(80),nullable=False),sa.Column('details',sa.Text(),nullable=False),sa.Column('evidence_url',sa.String(1000)),sa.Column('status',sa.String(24),nullable=False,server_default='OPEN'),
        sa.Column('risk_score',sa.Integer(),nullable=False,server_default='0'),sa.Column('reviewer_note',sa.Text()),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),sa.Column('resolved_at',sa.DateTime(timezone=True)),
        sa.ForeignKeyConstraint(['tenant_id'],['tenants.id']),sa.ForeignKeyConstraint(['reporter_customer_id'],['customers.id']),sa.ForeignKeyConstraint(['reporter_user_id'],['users.id']))
    op.create_index('ix_trust_reports_tenant_id','trust_reports',['tenant_id'])
    op.create_index('ix_trust_reports_tenant_status','trust_reports',['tenant_id','status'])
    op.create_table('merchant_trust_scores',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),nullable=False),sa.Column('rating_average',sa.Numeric(4,2),nullable=False,server_default='0'),
        sa.Column('rating_count',sa.Integer(),nullable=False,server_default='0'),sa.Column('report_count',sa.Integer(),nullable=False,server_default='0'),sa.Column('resolved_report_count',sa.Integer(),nullable=False,server_default='0'),
        sa.Column('trust_score',sa.Integer(),nullable=False,server_default='50'),sa.Column('trust_level',sa.String(20),nullable=False,server_default='NEW'),sa.Column('badge',sa.String(40),nullable=False,server_default='NEW_STORE'),sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False),
        sa.ForeignKeyConstraint(['tenant_id'],['tenants.id']),sa.UniqueConstraint('tenant_id'))
    op.create_index('ix_merchant_trust_scores_tenant_id','merchant_trust_scores',['tenant_id'])
    op.create_table('domain_purchases',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),nullable=False),sa.Column('domain_id',sa.String(36)),sa.Column('hostname',sa.String(255),nullable=False),sa.Column('years',sa.Integer(),nullable=False,server_default='1'),
        sa.Column('provider',sa.String(40),nullable=False,server_default='cloudflare'),sa.Column('provider_reference',sa.String(255)),sa.Column('provider_cost_minor',sa.BigInteger()),sa.Column('customer_price_minor',sa.BigInteger(),nullable=False,server_default='1000'),sa.Column('currency',sa.String(3),nullable=False,server_default='USD'),
        sa.Column('status',sa.String(30),nullable=False,server_default='PENDING_PAYMENT'),sa.Column('idempotency_key',sa.String(200),nullable=False),sa.Column('registrant_snapshot',JSON,nullable=False),sa.Column('failure_reason',sa.Text()),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),sa.Column('completed_at',sa.DateTime(timezone=True)),
        sa.ForeignKeyConstraint(['tenant_id'],['tenants.id']),sa.ForeignKeyConstraint(['domain_id'],['domains.id']),sa.UniqueConstraint('idempotency_key'))
    op.create_index('ix_domain_purchases_tenant_id','domain_purchases',['tenant_id'])
    op.create_index('ix_domain_purchases_domain_id','domain_purchases',['domain_id'])
    op.create_index('ix_domain_purchases_hostname','domain_purchases',['hostname'])
    op.create_index('ix_domain_purchases_tenant_status','domain_purchases',['tenant_id','status'])

def downgrade():
    for name in ['domain_purchases','merchant_trust_scores','trust_reports','tenant_reviews','merchant_phone_verifications','merchant_profiles']:
        op.drop_table(name)
