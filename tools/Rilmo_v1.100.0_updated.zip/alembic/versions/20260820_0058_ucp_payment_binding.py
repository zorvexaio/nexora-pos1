"""Bind payment intents to UCP checkout sessions for payment-safe completion.

Revision ID: 20260820_0058
Revises: 20260820_0057
"""
from alembic import op
import sqlalchemy as sa

revision = "20260820_0058"
down_revision = "20260820_0057"
branch_labels = None
depends_on = None


def upgrade():
    # SQLite cannot ALTER a table to add/drop foreign-key constraints directly.
    # Batch mode keeps the migration portable across SQLite dev/runtime smoke and PostgreSQL.
    with op.batch_alter_table("payment_intents", recreate="always") as batch:
        batch.add_column(sa.Column("ucp_checkout_session_id", sa.String(36), nullable=True))
        batch.create_foreign_key(
            "fk_payment_intents_ucp_checkout_session",
            "ucp_checkout_sessions",
            ["ucp_checkout_session_id"],
            ["id"],
        )
        batch.create_index("ix_payment_intents_ucp_checkout_session_id", ["ucp_checkout_session_id"])


def downgrade():
    with op.batch_alter_table("payment_intents", recreate="always") as batch:
        batch.drop_index("ix_payment_intents_ucp_checkout_session_id")
        batch.drop_constraint("fk_payment_intents_ucp_checkout_session", type_="foreignkey")
        batch.drop_column("ucp_checkout_session_id")
