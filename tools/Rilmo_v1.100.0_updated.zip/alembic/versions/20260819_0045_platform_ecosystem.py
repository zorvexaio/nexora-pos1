from alembic import op
import sqlalchemy as sa

revision = '20260819_0045'
down_revision = '20260819_0044'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        'app_listings',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('app_id', sa.String(length=36), sa.ForeignKey('app_definitions.id'), nullable=False),
        sa.Column('category', sa.String(length=80), nullable=False, server_default='GENERAL'),
        sa.Column('description', sa.Text(), nullable=False, server_default=''),
        sa.Column('icon_url', sa.String(length=1000)),
        sa.Column('pricing_model', sa.String(length=32), nullable=False, server_default='FREE'),
        sa.Column('monthly_price_minor', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('currency', sa.String(length=3), nullable=False, server_default='USD'),
        sa.Column('supported_locales', sa.JSON(), nullable=False),
        sa.Column('supported_countries', sa.JSON(), nullable=False),
        sa.Column('featured', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('status', sa.String(length=24), nullable=False, server_default='DRAFT'),
        sa.Column('published_at', sa.DateTime(timezone=True)),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('app_id'),
    )
    op.create_index('ix_app_listings_app_id', 'app_listings', ['app_id'])

    op.create_table(
        'app_reviews',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('app_id', sa.String(length=36), sa.ForeignKey('app_definitions.id'), nullable=False),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('rating', sa.Integer(), nullable=False),
        sa.Column('title', sa.String(length=160)),
        sa.Column('body', sa.Text()),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='PUBLISHED'),
        sa.Column('verified_installation', sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('app_id', 'tenant_id'),
    )
    op.create_index('ix_app_reviews_app_id', 'app_reviews', ['app_id'])
    op.create_index('ix_app_reviews_tenant_id', 'app_reviews', ['tenant_id'])
    op.create_index('ix_app_reviews_app_status', 'app_reviews', ['app_id', 'status'])

    op.create_table(
        'workflow_step_runs',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('workflow_run_id', sa.String(length=36), sa.ForeignKey('workflow_runs.id'), nullable=False),
        sa.Column('position', sa.Integer(), nullable=False),
        sa.Column('step_type', sa.String(length=60), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='QUEUED'),
        sa.Column('input_payload', sa.JSON(), nullable=False),
        sa.Column('output_payload', sa.JSON(), nullable=False),
        sa.Column('error_message', sa.Text()),
        sa.Column('started_at', sa.DateTime(timezone=True)),
        sa.Column('completed_at', sa.DateTime(timezone=True)),
        sa.UniqueConstraint('workflow_run_id', 'position'),
    )
    op.create_index('ix_workflow_step_runs_tenant_id', 'workflow_step_runs', ['tenant_id'])
    op.create_index('ix_workflow_step_runs_workflow_run_id', 'workflow_step_runs', ['workflow_run_id'])
    op.create_index('ix_workflow_step_runs_tenant_status', 'workflow_step_runs', ['tenant_id', 'status'])

    op.create_table(
        'commerce_event_schemas',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('event_type', sa.String(length=120), nullable=False),
        sa.Column('schema_version', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('schema_json', sa.JSON(), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('event_type', 'schema_version'),
    )

    op.create_table(
        'commerce_event_subscriptions',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('event_type', sa.String(length=120), nullable=False),
        sa.Column('endpoint_url', sa.Text(), nullable=False),
        sa.Column('secret_hash', sa.String(length=128), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id', 'event_type', 'endpoint_url'),
    )
    op.create_index('ix_commerce_event_subscriptions_tenant_id', 'commerce_event_subscriptions', ['tenant_id'])

    bind = op.get_bind()
    if bind.dialect.name == 'postgresql':
        for table in ['app_reviews', 'workflow_step_runs', 'commerce_event_subscriptions']:
            op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
            op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
            op.execute(
                f"""CREATE POLICY {table}_tenant_isolation ON {table}
                USING (tenant_id::text = current_setting('app.current_tenant', true))
                WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))"""
            )

def downgrade():
    bind = op.get_bind()
    if bind.dialect.name == 'postgresql':
        for table in ['commerce_event_subscriptions', 'workflow_step_runs', 'app_reviews']:
            op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
            op.execute(f'ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY')
            op.execute(f'ALTER TABLE {table} DISABLE ROW LEVEL SECURITY')
    for table in ['commerce_event_subscriptions', 'commerce_event_schemas', 'workflow_step_runs', 'app_reviews', 'app_listings']:
        op.drop_table(table)
