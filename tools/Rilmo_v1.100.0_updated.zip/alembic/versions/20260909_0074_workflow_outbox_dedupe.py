"""Add durable workflow queue-event deduplication."""
from alembic import op
import sqlalchemy as sa

revision = '20260909_0074'
down_revision = '0073'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('outbox_events', sa.Column('dedupe_key', sa.String(length=255), nullable=True))
    op.create_index('ix_outbox_events_dedupe_key', 'outbox_events', ['dedupe_key'], unique=True)


def downgrade():
    op.drop_index('ix_outbox_events_dedupe_key', table_name='outbox_events')
    op.drop_column('outbox_events', 'dedupe_key')
