"""P0 PostgreSQL RLS, immutability, and financial guards."""
from alembic import op

revision='20260816_0002'
down_revision='20260816_0001'
branch_labels=None
depends_on=None

TENANT_TABLES=['storefronts','domains','products','product_translations','product_variants','categories','product_seo','media_assets','prices','promotions','coupons','coupon_redemptions','customers','carts','cart_items','orders','order_items','order_status_history','inventory_locations','inventory_items','inventory_reservations','inventory_adjustments','payment_intents','payment_captures','refunds','ledger_accounts','journal_entries','journal_lines','outbox_events','dead_letter_events','idempotency_keys','webhook_events','provider_events','reconciliation_records','settlements','payouts','financial_transactions','price_lists','market_prices','discount_applications','product_options','product_option_values','product_variant_option_values','shipping_methods','tax_rates','merchant_payment_accounts','billing_customers','subscriptions','entitlements','wishlists','wishlist_items','reviews','questions','answers','order_tracking_references','consent_records']

def upgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql': return
    for table in TENANT_TABLES:
        op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
        op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")
    for table in ['journal_entries','journal_lines','audit_events']:
        op.execute(f"REVOKE UPDATE, DELETE ON {table} FROM PUBLIC")
    op.execute("ALTER TABLE journal_entries ADD CONSTRAINT journal_entries_currency_nonempty CHECK (length(currency)=3)")
    op.execute("ALTER TABLE journal_lines ADD CONSTRAINT journal_lines_balanced_side CHECK ((debit_minor > 0 AND credit_minor = 0) OR (credit_minor > 0 AND debit_minor = 0))")

def downgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql': return
    for table in reversed(TENANT_TABLES):
        op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
        op.execute(f'ALTER TABLE {table} DISABLE ROW LEVEL SECURITY')
