from alembic import op
import sqlalchemy as sa

revision = "20260820_0061"
down_revision = "20260820_0060"
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table("product_passports", recreate="always") as batch:
        batch.add_column(sa.Column("manufacturer_address", sa.Text(), nullable=True))
        batch.add_column(sa.Column("manufacturer_contact", sa.String(length=320), nullable=True))
        batch.add_column(sa.Column("responsible_person_name", sa.String(length=255), nullable=True))
        batch.add_column(sa.Column("responsible_person_address", sa.Text(), nullable=True))
        batch.add_column(sa.Column("responsible_person_contact", sa.String(length=320), nullable=True))
        batch.add_column(sa.Column("economic_operator_role", sa.String(length=80), nullable=True))
        batch.add_column(sa.Column("product_identifier", sa.String(length=255), nullable=True))
        batch.add_column(sa.Column("safety_warnings", sa.JSON(), nullable=True))
        batch.add_column(sa.Column("recall_information", sa.JSON(), nullable=True))

def downgrade():
    with op.batch_alter_table("product_passports", recreate="always") as batch:
        for name in ["recall_information","safety_warnings","product_identifier","economic_operator_role","responsible_person_contact","responsible_person_address","responsible_person_name","manufacturer_contact","manufacturer_address"]:
            batch.drop_column(name)
