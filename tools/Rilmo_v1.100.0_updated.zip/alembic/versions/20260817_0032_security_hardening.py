"""security hardening for public flows and webhook idempotency

Revision ID: 20260817_0032
Revises: 20260817_0031
"""
from alembic import op

revision = '20260817_0032'
down_revision = '20260817_0031'
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table('whatsapp_messages', recreate='auto') as batch:
        batch.create_unique_constraint('uq_whatsapp_message_tenant_provider', ['tenant_id', 'provider_message_id'])

def downgrade():
    with op.batch_alter_table('whatsapp_messages', recreate='auto') as batch:
        batch.drop_constraint('uq_whatsapp_message_tenant_provider', type_='unique')
