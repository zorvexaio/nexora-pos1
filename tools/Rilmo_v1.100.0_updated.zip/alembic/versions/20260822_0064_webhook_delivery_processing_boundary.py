from alembic import op
import sqlalchemy as sa

revision = "20260822_0064"
down_revision = "20260822_0063"
branch_labels = None
depends_on = None

def upgrade():
    for table in ("app_webhook_deliveries", "workflow_webhook_deliveries"):
        op.add_column(table, sa.Column("processing_started_at", sa.DateTime(timezone=True), nullable=True))
        op.create_index(f"ix_{table}_processing_started_at", table, ["processing_started_at"])

def downgrade():
    for table in ("workflow_webhook_deliveries", "app_webhook_deliveries"):
        op.drop_index(f"ix_{table}_processing_started_at", table_name=table)
        op.drop_column(table, "processing_started_at")
