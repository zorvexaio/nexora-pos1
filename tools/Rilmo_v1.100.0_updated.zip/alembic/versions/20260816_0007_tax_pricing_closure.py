"""Tax display mode and authoritative storefront pricing closure."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0007'
down_revision='20260816_0006'
branch_labels=None
depends_on=None

def upgrade():
    op.add_column('storefronts', sa.Column('price_display_mode', sa.String(length=20), nullable=False, server_default='tax_exclusive'))

def downgrade():
    op.drop_column('storefronts','price_display_mode')
