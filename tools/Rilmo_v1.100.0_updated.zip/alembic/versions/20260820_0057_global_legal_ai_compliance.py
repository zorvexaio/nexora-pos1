"""2026 global legal/privacy/DSA/AI compliance control plane.

Revision ID: 20260820_0057
Revises: 20260820_0056
"""
from alembic import op
import sqlalchemy as sa

revision = '20260820_0057'
down_revision = '20260820_0056'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('jurisdiction_compliance_policies',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('jurisdiction', sa.String(80), nullable=False),
        sa.Column('country_code', sa.String(2)),
        sa.Column('policy_version', sa.String(50), nullable=False),
        sa.Column('effective_date', sa.String(10), nullable=False),
        sa.Column('rights', sa.JSON(), nullable=False, server_default='[]'),
        sa.Column('consent_categories', sa.JSON(), nullable=False, server_default='[]'),
        sa.Column('transfer_mechanisms', sa.JSON(), nullable=False, server_default='[]'),
        sa.Column('breach_authority_hours', sa.Integer()),
        sa.Column('dsr_due_days', sa.Integer(), nullable=False, server_default='45'),
        sa.Column('cookie_opt_in_required', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('gpc_signal_respected', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('ai_interaction_disclosure_required', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('ai_generated_marking_required', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('admt_risk_assessment_required', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('dsa_marketplace_controls', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('requirements', sa.JSON(), nullable=False, server_default='{}'),
        sa.Column('status', sa.String(24), nullable=False, server_default='ENGINEERING_BASELINE'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('jurisdiction','policy_version'),
    )
    op.create_index('ix_jurisdiction_compliance_policies_jurisdiction','jurisdiction_compliance_policies',['jurisdiction'])
    op.create_index('ix_jurisdiction_compliance_policies_country','jurisdiction_compliance_policies',['country_code'])

    op.create_table('privacy_processing_activities',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('activity_key', sa.String(120), nullable=False),
        sa.Column('purpose', sa.Text(), nullable=False),
        sa.Column('legal_bases', sa.JSON(), nullable=False, server_default='{}'),
        sa.Column('data_categories', sa.JSON(), nullable=False, server_default='[]'),
        sa.Column('data_subject_categories', sa.JSON(), nullable=False, server_default='[]'),
        sa.Column('recipients', sa.JSON(), nullable=False, server_default='[]'),
        sa.Column('transfer_mechanisms', sa.JSON(), nullable=False, server_default='[]'),
        sa.Column('retention_rule', sa.String(255), nullable=False),
        sa.Column('dpia_required', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('automated_decisioning', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('ai_system', sa.String(120)),
        sa.Column('owner_role', sa.String(80), nullable=False),
        sa.Column('status', sa.String(24), nullable=False, server_default='ACTIVE'),
        sa.Column('reviewed_at', sa.DateTime(timezone=True)),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('activity_key'),
    )
    op.create_index('ix_privacy_processing_activities_status','privacy_processing_activities',['status'])

    op.create_table('dsa_compliance_cases',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id')),
        sa.Column('reporter_user_id', sa.String(36), sa.ForeignKey('users.id')),
        sa.Column('reporter_email', sa.String(320)),
        sa.Column('content_type', sa.String(40), nullable=False),
        sa.Column('content_id', sa.String(120), nullable=False),
        sa.Column('jurisdiction', sa.String(80), nullable=False, server_default='GLOBAL'),
        sa.Column('reason_code', sa.String(80), nullable=False),
        sa.Column('description', sa.Text(), nullable=False),
        sa.Column('status', sa.String(32), nullable=False, server_default='SUBMITTED'),
        sa.Column('decision', sa.String(32)),
        sa.Column('decision_reason', sa.Text()),
        sa.Column('appeal_status', sa.String(32), nullable=False, server_default='NOT_REQUESTED'),
        sa.Column('appeal_decision', sa.String(32)),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_dsa_cases_status_created','dsa_compliance_cases',['status','created_at'])
    op.create_index('ix_dsa_cases_tenant_status','dsa_compliance_cases',['tenant_id','status'])
    conn=op.get_bind()
    if conn.dialect.name == 'postgresql':
        op.execute(sa.text('ALTER TABLE privacy_processing_activities ENABLE ROW LEVEL SECURITY'))
        op.execute(sa.text('ALTER TABLE privacy_processing_activities FORCE ROW LEVEL SECURITY'))
        # ROPA is platform-level governance data; only platform-compliance APIs access it.
        op.execute(sa.text("CREATE POLICY privacy_processing_activities_platform_only ON privacy_processing_activities USING (current_setting('app.platform_role', true) IN ('privacy_officer','compliance_officer','super_admin'))"))
        op.execute(sa.text('ALTER TABLE dsa_compliance_cases ENABLE ROW LEVEL SECURITY'))
        op.execute(sa.text('ALTER TABLE dsa_compliance_cases FORCE ROW LEVEL SECURITY'))
        op.execute(sa.text("CREATE POLICY dsa_cases_tenant_iso ON dsa_compliance_cases USING (tenant_id::text = current_setting('app.current_tenant', true) OR current_setting('app.platform_role', true) IN ('privacy_officer','compliance_officer','super_admin')) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true) OR current_setting('app.platform_role', true) IN ('privacy_officer','compliance_officer','super_admin'))"))

def downgrade():
    conn=op.get_bind()
    if conn.dialect.name == 'postgresql':
        op.execute(sa.text('DROP POLICY IF EXISTS dsa_cases_tenant_iso ON dsa_compliance_cases'))
        op.execute(sa.text('DROP POLICY IF EXISTS privacy_processing_activities_platform_only ON privacy_processing_activities'))
    op.drop_index('ix_dsa_cases_tenant_status', table_name='dsa_compliance_cases')
    op.drop_index('ix_dsa_cases_status_created', table_name='dsa_compliance_cases')
    op.drop_table('dsa_compliance_cases')
    op.drop_index('ix_privacy_processing_activities_status', table_name='privacy_processing_activities')
    op.drop_table('privacy_processing_activities')
    op.drop_index('ix_jurisdiction_compliance_policies_country', table_name='jurisdiction_compliance_policies')
    op.drop_index('ix_jurisdiction_compliance_policies_jurisdiction', table_name='jurisdiction_compliance_policies')
    op.drop_table('jurisdiction_compliance_policies')
