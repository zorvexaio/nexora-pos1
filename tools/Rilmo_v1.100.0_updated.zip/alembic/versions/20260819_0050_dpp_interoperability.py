from alembic import op
import sqlalchemy as sa

revision = '20260819_0050'
down_revision = '20260819_0049'
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('product_passports', sa.Column('conformance_profile', sa.String(120), nullable=False, server_default='ESPR-DPP-2026'))
    op.add_column('product_passports', sa.Column('identifier_scheme', sa.String(80)))
    op.add_column('product_passports', sa.Column('unique_product_identifier', sa.String(255)))
    op.add_column('product_passports', sa.Column('data_carrier', sa.String(80)))
    op.add_column('product_passports', sa.Column('registry_status', sa.String(30), nullable=False, server_default='NOT_REGISTERED'))
    op.add_column('product_passports', sa.Column('registry_reference', sa.String(255)))
    op.create_index('ix_product_passports_unique_product_identifier', 'product_passports', ['unique_product_identifier'])

def downgrade():
    op.drop_index('ix_product_passports_unique_product_identifier', table_name='product_passports')
    for col in ('registry_reference','registry_status','data_carrier','unique_product_identifier','identifier_scheme','conformance_profile'):
        op.drop_column('product_passports', col)
