"""Add durable experiment outcome observations."""
from alembic import op
import sqlalchemy as sa

revision = '0073'
down_revision = '0072'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        'commerce_experiment_observations',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('experiment_id', sa.String(36), sa.ForeignKey('commerce_experiments.id'), nullable=False),
        sa.Column('assignment_id', sa.String(36), sa.ForeignKey('commerce_experiment_assignments.id'), nullable=False),
        sa.Column('subject_key', sa.String(160), nullable=False),
        sa.Column('variant_key', sa.String(100), nullable=False),
        sa.Column('metric_key', sa.String(80), nullable=False),
        sa.Column('value_numeric', sa.Numeric(20, 6), nullable=False, server_default='1'),
        sa.Column('value_minor', sa.BigInteger(), nullable=True),
        sa.Column('currency', sa.String(3), nullable=True),
        sa.Column('occurred_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('metadata_json', sa.JSON(), nullable=False),
        sa.UniqueConstraint('tenant_id','experiment_id','subject_key','metric_key', name='uq_commerce_experiment_observation_once'),
    )
    op.create_index('ix_commerce_experiment_observations_tenant_id','commerce_experiment_observations',['tenant_id'])
    op.create_index('ix_commerce_experiment_observations_experiment_id','commerce_experiment_observations',['experiment_id'])
    op.create_index('ix_commerce_experiment_observations_assignment_id','commerce_experiment_observations',['assignment_id'])
    op.create_index('ix_commerce_experiment_observations_tenant_experiment','commerce_experiment_observations',['tenant_id','experiment_id'])
    op.create_index('ix_commerce_experiment_observations_metric','commerce_experiment_observations',['tenant_id','experiment_id','metric_key'])
    op.create_index('ix_commerce_experiment_observations_occurred_at','commerce_experiment_observations',['occurred_at'])
    if op.get_bind().dialect.name == 'postgresql':
        op.execute('ALTER TABLE commerce_experiment_observations ENABLE ROW LEVEL SECURITY')
        op.execute('ALTER TABLE commerce_experiment_observations FORCE ROW LEVEL SECURITY')
        op.execute("CREATE POLICY commerce_experiment_observations_tenant_isolation ON commerce_experiment_observations USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")

def downgrade():
    if op.get_bind().dialect.name == 'postgresql':
        op.execute('DROP POLICY IF EXISTS commerce_experiment_observations_tenant_isolation ON commerce_experiment_observations')
    for idx in ['ix_commerce_experiment_observations_occurred_at','ix_commerce_experiment_observations_metric','ix_commerce_experiment_observations_tenant_experiment','ix_commerce_experiment_observations_assignment_id','ix_commerce_experiment_observations_experiment_id','ix_commerce_experiment_observations_tenant_id']:
        op.drop_index(idx, table_name='commerce_experiment_observations')
    op.drop_table('commerce_experiment_observations')
