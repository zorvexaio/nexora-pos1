"""Eliminate client-settable RLS bypass GUCs and quarantine unresolved provider webhooks.

The previous runtime-context migration allowed `app.worker=on` and
`app.allow_unscoped_ingest=on` to bypass tenant policies. PostgreSQL custom
GUCs are not an authorization primitive: a normal database role can set them.
This migration removes those bypasses. Workers now iterate tenants and set a
normal tenant context; unresolved verified provider events are persisted in a
platform-scoped quarantine table until their tenant can be resolved.
"""
from alembic import op
import sqlalchemy as sa

revision='20260816_0013'
down_revision='20260816_0012'
branch_labels=None
depends_on=None

TENANT_TABLES=[
    'storefronts','domains','products','product_translations','product_variants','categories','product_seo','media_assets','prices','promotions','coupons','coupon_redemptions','customers','carts','cart_items','orders','order_items','order_status_history','inventory_locations','inventory_items','inventory_reservations','inventory_adjustments','payment_intents','payment_attempts','payment_captures','refunds','ledger_accounts','journal_entries','journal_lines','outbox_events','dead_letter_events','idempotency_keys','provider_events','reconciliation_records','settlements','payouts','financial_transactions','price_lists','market_prices','discount_applications','product_options','product_option_values','product_variant_option_values','shipping_methods','tax_rates','merchant_payment_accounts','billing_customers','subscriptions','entitlements','wishlists','wishlist_items','reviews','questions','answers','order_tracking_references','consent_records','tenant_entitlements','plan_prices','subscription_items','billing_events','review_questions','review_answers'
]

def upgrade():
    bind=op.get_bind()
    op.create_table(
        'provider_ingest_events',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('provider', sa.String(50), nullable=False),
        sa.Column('provider_event_id', sa.String(255), nullable=False),
        sa.Column('event_type', sa.String(120), nullable=False),
        sa.Column('payload_hash', sa.String(128), nullable=False),
        sa.Column('payload', sa.JSON(), nullable=False),
        sa.Column('status', sa.String(30), nullable=False, server_default='QUARANTINED'),
        sa.Column('received_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('resolved_tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=True),
        sa.Column('resolved_at', sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint('provider','provider_event_id',name='uq_provider_ingest_event'),
    )
    op.create_index('ix_provider_ingest_events_resolved_tenant_id','provider_ingest_events',['resolved_tenant_id'])
    if bind.dialect.name!='postgresql':
        return
    for table in TENANT_TABLES:
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
        op.execute(f"""CREATE POLICY {table}_tenant_isolation ON {table}
        USING (tenant_id::text = current_setting('app.current_tenant', true))
        WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))""")
    # The quarantine table is intentionally platform-scoped and contains only
    # verified provider payloads. It is not a tenant data plane table.
    op.execute("REVOKE UPDATE, DELETE ON provider_ingest_events FROM PUBLIC")

def downgrade():
    bind=op.get_bind()
    op.drop_index('ix_provider_ingest_events_resolved_tenant_id', table_name='provider_ingest_events')
    op.drop_table('provider_ingest_events')
    if bind.dialect.name!='postgresql':
        return
    for table in TENANT_TABLES:
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
        op.execute(f"""CREATE POLICY {table}_tenant_isolation ON {table}
        USING (current_setting('app.worker', true) = 'on' OR tenant_id::text = current_setting('app.current_tenant', true))
        WITH CHECK (current_setting('app.worker', true) = 'on' OR tenant_id::text = current_setting('app.current_tenant', true))""")
