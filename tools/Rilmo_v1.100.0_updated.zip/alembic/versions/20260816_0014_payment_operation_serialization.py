"""Serialize capture/refund effects and close inventory mutation races."""
from alembic import op
import sqlalchemy as sa

revision = "20260816_0014"
down_revision = "20260816_0013"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "payment_operations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("tenant_id", sa.String(36), sa.ForeignKey("tenants.id"), nullable=False),
        sa.Column("payment_intent_id", sa.String(36), sa.ForeignKey("payment_intents.id"), nullable=False),
        sa.Column("operation_type", sa.String(32), nullable=False),
        sa.Column("idempotency_key", sa.String(255), nullable=False),
        sa.Column("requested_amount_minor", sa.BigInteger(), nullable=True),
        sa.Column("currency", sa.String(3), nullable=True),
        sa.Column("status", sa.String(32), nullable=False, server_default="PENDING"),
        sa.Column("provider_reference", sa.String(255), nullable=True),
        sa.Column("error_code", sa.String(100), nullable=True),
        sa.Column("response_body", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("tenant_id","payment_intent_id","operation_type",name="uq_payment_operation_scope"),
        sa.UniqueConstraint("tenant_id","idempotency_key",name="uq_payment_operation_key"),
    )
    op.create_index("ix_payment_operations_tenant","payment_operations",["tenant_id"])
    op.create_index("ix_payment_operations_payment","payment_operations",["payment_intent_id"])

def downgrade():
    op.drop_index("ix_payment_operations_payment",table_name="payment_operations")
    op.drop_index("ix_payment_operations_tenant",table_name="payment_operations")
    op.drop_table("payment_operations")
