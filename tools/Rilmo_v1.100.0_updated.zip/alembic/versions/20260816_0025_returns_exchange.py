"""Returns/refunds workflow with tenant isolation and immutable request history."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0025'; down_revision='20260816_0024'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('return_requests',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('order_id',sa.String(36),sa.ForeignKey('orders.id'),nullable=False),
        sa.Column('customer_id',sa.String(36),sa.ForeignKey('customers.id')),
        sa.Column('type',sa.String(20),nullable=False,server_default='REFUND'),
        sa.Column('status',sa.String(24),nullable=False,server_default='REQUESTED'),
        sa.Column('reason_code',sa.String(80),nullable=False),
        sa.Column('reason_note',sa.Text()),
        sa.Column('requested_amount_minor',sa.BigInteger(),nullable=False),
        sa.Column('approved_amount_minor',sa.BigInteger()),
        sa.Column('currency',sa.String(3),nullable=False),
        sa.Column('idempotency_key',sa.String(200),nullable=False),
        sa.Column('provider_refund_id',sa.String(255)),
        sa.Column('created_at',sa.DateTime(timezone=True)),
        sa.Column('updated_at',sa.DateTime(timezone=True)),
        sa.UniqueConstraint('tenant_id','idempotency_key',name='uq_return_requests_tenant_idem'),
        sa.UniqueConstraint('tenant_id','order_id','id',name='uq_return_requests_order_id'),
    )
    op.create_index('ix_return_requests_tenant_id','return_requests',['tenant_id'])
    op.create_index('ix_return_requests_order_id','return_requests',['order_id'])
    op.create_index('ix_return_requests_status','return_requests',['status'])
    op.create_table('return_items',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('return_request_id',sa.String(36),sa.ForeignKey('return_requests.id'),nullable=False),
        sa.Column('order_item_id',sa.String(36),sa.ForeignKey('order_items.id'),nullable=False),
        sa.Column('quantity',sa.BigInteger(),nullable=False),
        sa.Column('amount_minor',sa.BigInteger(),nullable=False),
    )
    op.create_index('ix_return_items_tenant_id','return_items',['tenant_id'])
    op.create_index('ix_return_items_request_id','return_items',['return_request_id'])
    if op.get_bind().dialect.name=='postgresql':
        for table in ['return_requests','return_items']:
            op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
            op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
            op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
            op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")

def downgrade():
    if op.get_bind().dialect.name=='postgresql':
        for table in ['return_items','return_requests']:
            op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
            op.execute(f'ALTER TABLE {table} DISABLE ROW LEVEL SECURITY')
    op.drop_table('return_items'); op.drop_table('return_requests')
