from alembic import op
import sqlalchemy as sa
revision="20260816_0011"
down_revision="20260816_0010"
branch_labels=None
depends_on=None
def upgrade():
    op.add_column("payment_intents", sa.Column("application_fee_minor", sa.BigInteger(), nullable=False, server_default="0"))
def downgrade():
    op.drop_column("payment_intents","application_fee_minor")
