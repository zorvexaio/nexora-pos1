"""App OAuth authorization-code/PKCE flow and encrypted webhook secrets."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0023'; down_revision='20260816_0022'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('app_oauth_authorization_codes',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('app_id',sa.String(36),sa.ForeignKey('app_definitions.id'),nullable=False),
        sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('user_id',sa.String(36),sa.ForeignKey('users.id'),nullable=False),
        sa.Column('code_hash',sa.String(128),nullable=False,unique=True),
        sa.Column('redirect_uri',sa.Text(),nullable=False),
        sa.Column('scopes',sa.JSON(),nullable=False),
        sa.Column('code_challenge',sa.String(128)),
        sa.Column('code_challenge_method',sa.String(20)),
        sa.Column('expires_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('used_at',sa.DateTime(timezone=True)),
        sa.Column('created_at',sa.DateTime(timezone=True)),
    )
    op.create_index('ix_app_oauth_codes_app_id','app_oauth_authorization_codes',['app_id'])
    op.create_index('ix_app_oauth_codes_tenant_id','app_oauth_authorization_codes',['tenant_id'])
    op.create_index('ix_app_oauth_codes_user_id','app_oauth_authorization_codes',['user_id'])
    op.create_table('app_refresh_tokens',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('installation_id',sa.String(36),sa.ForeignKey('app_installations.id'),nullable=False),
        sa.Column('token_hash',sa.String(128),nullable=False,unique=True),
        sa.Column('expires_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('revoked_at',sa.DateTime(timezone=True)),
        sa.Column('created_at',sa.DateTime(timezone=True)),
    )
    op.create_index('ix_app_refresh_tokens_installation_id','app_refresh_tokens',['installation_id'])
    op.create_index('ix_app_refresh_tokens_tenant_id','app_refresh_tokens',['tenant_id'])
    op.add_column('app_webhook_subscriptions',sa.Column('secret_encrypted',sa.Text()))
    if op.get_bind().dialect.name=='postgresql':
        for table in ['app_oauth_authorization_codes','app_refresh_tokens']:
            op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY'); op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
            op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
            op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")

def downgrade():
    if op.get_bind().dialect.name=='postgresql':
        for table in ['app_refresh_tokens','app_oauth_authorization_codes']:
            op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}'); op.execute(f'ALTER TABLE {table} DISABLE ROW LEVEL SECURITY')
    op.drop_column('app_webhook_subscriptions','secret_encrypted')
    op.drop_table('app_refresh_tokens'); op.drop_table('app_oauth_authorization_codes')
