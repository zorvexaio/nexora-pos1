"""Reconcile ORM columns that were missing from the executable migration contract."""
from alembic import op
import sqlalchemy as sa

revision = "20260816_0016"
down_revision = "20260816_0015"
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table("role_permissions", schema=None) as b:
        b.add_column(sa.Column("role_id", sa.String(36), nullable=True))
        b.add_column(sa.Column("permission_id", sa.String(36), nullable=True))
        b.create_foreign_key("fk_role_permissions_role_id", "roles", ["role_id"], ["id"])
        b.create_foreign_key("fk_role_permissions_permission_id", "permissions", ["permission_id"], ["id"])
    with op.batch_alter_table("coupon_redemptions", schema=None) as b:
        b.add_column(sa.Column("customer_id", sa.String(36), nullable=True))
        b.add_column(sa.Column("idempotency_key", sa.String(200), nullable=True))
        b.create_foreign_key("fk_coupon_redemptions_customer_id", "customers", ["customer_id"], ["id"])
        b.create_unique_constraint("uq_coupon_redemption_idempotency", ["tenant_id", "idempotency_key"])
    with op.batch_alter_table("reviews", schema=None) as b:
        b.add_column(sa.Column("order_id", sa.String(36), nullable=True))
        b.create_foreign_key("fk_reviews_order_id", "orders", ["order_id"], ["id"])
        b.create_unique_constraint("uq_review_order_product_customer", ["tenant_id", "order_id", "product_id", "customer_id"])

def downgrade():
    with op.batch_alter_table("reviews", schema=None) as b:
        b.drop_constraint("uq_review_order_product_customer", type_="unique")
        b.drop_constraint("fk_reviews_order_id", type_="foreignkey")
        b.drop_column("order_id")
    with op.batch_alter_table("coupon_redemptions", schema=None) as b:
        b.drop_constraint("uq_coupon_redemption_idempotency", type_="unique")
        b.drop_constraint("fk_coupon_redemptions_customer_id", type_="foreignkey")
        b.drop_column("idempotency_key")
        b.drop_column("customer_id")
    with op.batch_alter_table("role_permissions", schema=None) as b:
        b.drop_constraint("fk_role_permissions_permission_id", type_="foreignkey")
        b.drop_constraint("fk_role_permissions_role_id", type_="foreignkey")
        b.drop_column("permission_id")
        b.drop_column("role_id")
