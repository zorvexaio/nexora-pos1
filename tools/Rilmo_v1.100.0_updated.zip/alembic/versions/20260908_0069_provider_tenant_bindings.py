"""Verified provider-reference routing table for FORCE-RLS webhook ingress."""
from alembic import op
import sqlalchemy as sa

revision='20260908_0069'
down_revision='20260908_0068'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table(
        'provider_tenant_bindings',
        sa.Column('id', sa.String(length=36), nullable=False),
        sa.Column('provider', sa.String(length=50), nullable=False),
        sa.Column('external_id', sa.String(length=255), nullable=False),
        sa.Column('tenant_id', sa.String(length=36), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id']),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('provider', 'external_id', name='uq_provider_tenant_binding'),
    )
    op.create_index('ix_provider_tenant_bindings_external_id', 'provider_tenant_bindings', ['external_id'], unique=False)
    op.create_index('ix_provider_tenant_bindings_tenant_id', 'provider_tenant_bindings', ['tenant_id'], unique=False)

def downgrade():
    op.drop_index('ix_provider_tenant_bindings_tenant_id', table_name='provider_tenant_bindings')
    op.drop_index('ix_provider_tenant_bindings_external_id', table_name='provider_tenant_bindings')
    op.drop_table('provider_tenant_bindings')
