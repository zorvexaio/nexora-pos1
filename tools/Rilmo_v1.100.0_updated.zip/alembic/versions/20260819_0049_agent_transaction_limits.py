"""Agent transaction policy limits.

Revision ID: 20260819_0049
Revises: 20260819_0048
"""
from alembic import op
import sqlalchemy as sa

revision = "20260819_0049"
down_revision = "20260819_0048"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("agent_profiles", sa.Column("max_checkout_total_minor", sa.BigInteger(), nullable=True))
    op.add_column("agent_profiles", sa.Column("allowed_currencies", sa.JSON(), nullable=False, server_default="[]"))

def downgrade():
    op.drop_column("agent_profiles", "allowed_currencies")
    op.drop_column("agent_profiles", "max_checkout_total_minor")
