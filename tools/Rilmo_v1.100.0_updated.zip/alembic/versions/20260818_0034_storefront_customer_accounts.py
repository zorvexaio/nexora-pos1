"""Add first-class storefront customer accounts and Google/email sign-in."""
from alembic import op
import sqlalchemy as sa

revision = '20260818_0034'
down_revision = '20260818_0033'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('customer_identities',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('customer_id', sa.String(36), sa.ForeignKey('customers.id'), nullable=False),
        sa.Column('provider', sa.String(40), nullable=False),
        sa.Column('provider_subject', sa.String(255), nullable=False),
        sa.Column('provider_email', sa.String(320)),
        sa.Column('email_verified_at', sa.DateTime(timezone=True)),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','provider','provider_subject'),
    )
    op.create_index('ix_customer_identities_tenant_id','customer_identities',['tenant_id'])
    op.create_index('ix_customer_identities_customer_id','customer_identities',['customer_id'])
    op.create_index('ix_customer_identities_provider','customer_identities',['provider'])
    op.create_index('ix_customer_identities_provider_subject','customer_identities',['provider_subject'])

    op.create_table('customer_sessions',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('customer_id', sa.String(36), sa.ForeignKey('customers.id'), nullable=False),
        sa.Column('token_hash', sa.String(128), nullable=False, unique=True),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('last_seen_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_customer_sessions_tenant_id','customer_sessions',['tenant_id'])
    op.create_index('ix_customer_sessions_customer_id','customer_sessions',['customer_id'])
    op.create_index('ix_customer_sessions_token_hash','customer_sessions',['token_hash'])
    op.create_index('ix_customer_sessions_expires_at','customer_sessions',['expires_at'])

    op.create_table('customer_login_codes',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('customer_id', sa.String(36), sa.ForeignKey('customers.id')),
        sa.Column('email', sa.String(320), nullable=False),
        sa.Column('code_hash', sa.String(128), nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('used_at', sa.DateTime(timezone=True)),
        sa.Column('attempts', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_customer_login_codes_tenant_id','customer_login_codes',['tenant_id'])
    op.create_index('ix_customer_login_codes_customer_id','customer_login_codes',['customer_id'])
    op.create_index('ix_customer_login_codes_email','customer_login_codes',['email'])
    op.create_index('ix_customer_login_codes_code_hash','customer_login_codes',['code_hash'])
    op.create_index('ix_customer_login_codes_expires_at','customer_login_codes',['expires_at'])

    op.create_table('storefront_oauth_states',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('hostname', sa.String(255), nullable=False),
        sa.Column('provider', sa.String(40), nullable=False, server_default='google'),
        sa.Column('state_hash', sa.String(128), nullable=False, unique=True),
        sa.Column('nonce_hash', sa.String(128), nullable=False),
        sa.Column('redirect_uri', sa.String(1000), nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('used_at', sa.DateTime(timezone=True)),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_storefront_oauth_states_tenant_id','storefront_oauth_states',['tenant_id'])
    op.create_index('ix_storefront_oauth_states_hostname','storefront_oauth_states',['hostname'])
    op.create_index('ix_storefront_oauth_states_state_hash','storefront_oauth_states',['state_hash'])
    op.create_index('ix_storefront_oauth_states_nonce_hash','storefront_oauth_states',['nonce_hash'])
    op.create_index('ix_storefront_oauth_states_expires_at','storefront_oauth_states',['expires_at'])

def downgrade():
    for idx, table in [
        ('ix_storefront_oauth_states_expires_at','storefront_oauth_states'),('ix_storefront_oauth_states_nonce_hash','storefront_oauth_states'),('ix_storefront_oauth_states_state_hash','storefront_oauth_states'),('ix_storefront_oauth_states_hostname','storefront_oauth_states'),('ix_storefront_oauth_states_tenant_id','storefront_oauth_states'),
        ('ix_customer_login_codes_expires_at','customer_login_codes'),('ix_customer_login_codes_code_hash','customer_login_codes'),('ix_customer_login_codes_email','customer_login_codes'),('ix_customer_login_codes_customer_id','customer_login_codes'),('ix_customer_login_codes_tenant_id','customer_login_codes'),
        ('ix_customer_sessions_expires_at','customer_sessions'),('ix_customer_sessions_token_hash','customer_sessions'),('ix_customer_sessions_customer_id','customer_sessions'),('ix_customer_sessions_tenant_id','customer_sessions'),
        ('ix_customer_identities_provider_subject','customer_identities'),('ix_customer_identities_provider','customer_identities'),('ix_customer_identities_customer_id','customer_identities'),('ix_customer_identities_tenant_id','customer_identities')]:
        op.drop_index(idx, table_name=table)
    for table in ['storefront_oauth_states','customer_login_codes','customer_sessions','customer_identities']:
        op.drop_table(table)
