"""Provider/Billing closure: Stripe identifiers and Connect onboarding state."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0006'
down_revision='20260816_0005'
branch_labels=None
depends_on=None

def upgrade():
    op.add_column('plan_versions', sa.Column('provider_price_id', sa.String(length=255), nullable=True))
    op.add_column('billing_customers', sa.Column('email', sa.String(length=320), nullable=True))
    op.add_column('billing_customers', sa.Column('created_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('subscriptions', sa.Column('provider_subscription_id', sa.String(length=255), nullable=True))
    op.add_column('subscriptions', sa.Column('current_period_end', sa.DateTime(timezone=True), nullable=True))
    with op.batch_alter_table('subscriptions') as batch:
        batch.create_unique_constraint('uq_subscriptions_provider_subscription_id',['provider_subscription_id'])
    op.add_column('merchant_payment_accounts', sa.Column('onboarding_url', sa.Text(), nullable=True))
    op.add_column('merchant_payment_accounts', sa.Column('charges_enabled', sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column('merchant_payment_accounts', sa.Column('payouts_enabled', sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column('merchant_payment_accounts', sa.Column('requirements_due', sa.JSON(), nullable=True))

def downgrade():
    op.drop_column('merchant_payment_accounts','requirements_due')
    op.drop_column('merchant_payment_accounts','payouts_enabled')
    op.drop_column('merchant_payment_accounts','charges_enabled')
    op.drop_column('merchant_payment_accounts','onboarding_url')
    with op.batch_alter_table('subscriptions') as batch:
        batch.drop_constraint('uq_subscriptions_provider_subscription_id',type_='unique')
    op.drop_column('subscriptions','current_period_end')
    op.drop_column('subscriptions','provider_subscription_id')
    op.drop_column('billing_customers','created_at')
    op.drop_column('billing_customers','email')
    op.drop_column('plan_versions','provider_price_id')
