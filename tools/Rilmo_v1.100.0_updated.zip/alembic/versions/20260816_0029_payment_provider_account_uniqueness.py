"""Allow one merchant to configure multiple payment providers."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0029'
down_revision='20260816_0028'
branch_labels=None
depends_on=None

def upgrade():
    bind=op.get_bind()
    if bind.dialect.name == 'sqlite':
        insp=sa.inspect(bind); uniques=insp.get_unique_constraints('merchant_payment_accounts'); old=next((u['name'] for u in uniques if u.get('column_names')==['tenant_id']),None)
        with op.batch_alter_table('merchant_payment_accounts', recreate='always') as batch:
            if old: batch.drop_constraint(old, type_='unique')
            batch.create_unique_constraint('uq_merchant_payment_account_tenant_provider',['tenant_id','provider'])
    else:
        insp=sa.inspect(bind)
        uniques=insp.get_unique_constraints('merchant_payment_accounts')
        old=next((u['name'] for u in uniques if u.get('column_names')==['tenant_id']),None)
        if old: op.drop_constraint(old,'merchant_payment_accounts',type_='unique')
        op.create_unique_constraint('uq_merchant_payment_account_tenant_provider','merchant_payment_accounts',['tenant_id','provider'])

def downgrade():
    bind=op.get_bind()
    if bind.dialect.name == 'sqlite':
        with op.batch_alter_table('merchant_payment_accounts', recreate='always') as batch:
            batch.drop_constraint('uq_merchant_payment_account_tenant_provider',type_='unique')
            batch.create_unique_constraint('uq_merchant_payment_account_tenant',['tenant_id'])
    else:
        op.drop_constraint('uq_merchant_payment_account_tenant_provider','merchant_payment_accounts',type_='unique')
        op.create_unique_constraint('uq_merchant_payment_account_tenant','merchant_payment_accounts',['tenant_id'])
