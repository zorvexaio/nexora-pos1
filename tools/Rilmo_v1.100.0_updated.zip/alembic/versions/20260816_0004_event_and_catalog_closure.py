"""P0 final event envelope and catalog schema closure."""
from alembic import op
import sqlalchemy as sa

revision='20260816_0004'
down_revision='20260816_0003'
branch_labels=None
depends_on=None

def upgrade():
    bind=op.get_bind(); inspector=sa.inspect(bind)
    for table, column, typ, nullable in [
        ('outbox_events','causation_id',sa.String(36),True),
        ('outbox_events','producer',sa.String(100),False),
        ('outbox_events','occurred_at',sa.DateTime(timezone=True),True),
        ('prices','price_list_id',sa.String(36),True),
        ('price_lists','is_default',sa.Boolean(),False),
        ('product_seo','meta_title',sa.String(255),True),
        ('product_seo','meta_description',sa.Text(),True),
        ('product_seo','og_title',sa.String(255),True),
        ('product_seo','og_description',sa.Text(),True),
        ('product_seo','robots',sa.String(100),True),
    ]:
        if table in inspector.get_table_names() and column not in {c['name'] for c in inspector.get_columns(table)}:
            op.add_column(table,sa.Column(column,typ,nullable=nullable,server_default=(sa.text("'commerce-api'") if column=='producer' else None)))
    if bind.dialect.name=='postgresql':
        op.execute("UPDATE outbox_events SET producer='commerce-api' WHERE producer IS NULL")
        op.execute("UPDATE outbox_events SET occurred_at=created_at WHERE occurred_at IS NULL")
        op.execute("ALTER TABLE outbox_events ALTER COLUMN producer SET NOT NULL")
        op.execute("ALTER TABLE outbox_events ALTER COLUMN occurred_at SET NOT NULL")
        op.execute("ALTER TABLE prices ADD CONSTRAINT fk_prices_price_list FOREIGN KEY(price_list_id) REFERENCES price_lists(id)")
        op.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_default_price_list ON price_lists(tenant_id) WHERE is_default=true")
        op.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_price_list_variant_currency ON prices(tenant_id,price_list_id,variant_id,currency) WHERE price_list_id IS NOT NULL")

def downgrade():
    pass
