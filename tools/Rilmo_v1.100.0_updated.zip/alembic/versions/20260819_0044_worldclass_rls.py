from alembic import op

revision = '20260819_0044'
down_revision = '20260819_0043'
branch_labels = None
depends_on = None

TABLES = [
    'b2b_companies','b2b_company_contacts','b2b_catalogs','b2b_catalog_assignments','b2b_catalog_items',
    'pos_locations','pos_registers','pos_sessions','pos_order_links',
    'commerce_experiments','commerce_experiment_assignments','product_feeds','ucp_checkout_sessions','ucp_events',
]

def upgrade():
    bind = op.get_bind()
    if bind.dialect.name != 'postgresql':
        return
    for table in TABLES:
        op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
        op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
        op.execute(f'''CREATE POLICY {table}_tenant_isolation ON {table}
            USING (tenant_id::text = current_setting('app.current_tenant', true))
            WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))''')

def downgrade():
    bind = op.get_bind()
    if bind.dialect.name != 'postgresql':
        return
    for table in reversed(TABLES):
        op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
        op.execute(f'ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE {table} DISABLE ROW LEVEL SECURITY')
