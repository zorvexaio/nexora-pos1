"""P0 deep closure: tenant columns, missing commercial/financial entities, invariants."""
from alembic import op
import sqlalchemy as sa

revision='20260816_0003'
down_revision='20260816_0002'
branch_labels=None
depends_on=None

TENANT_CHILD_TABLES = ['product_translations','cart_items','wishlist_items']

def upgrade():
    bind=op.get_bind()
    # Existing child tables lacked tenant_id, which made the RLS matrix invalid.
    for table in TENANT_CHILD_TABLES:
        cols={c['name'] for c in sa.inspect(bind).get_columns(table)}
        if 'tenant_id' not in cols:
            op.add_column(table, sa.Column('tenant_id', sa.String(36), nullable=True))
            if table=='product_translations':
                op.execute("UPDATE product_translations pt SET tenant_id=p.tenant_id FROM products p WHERE p.id=pt.product_id")
            elif table=='cart_items':
                op.execute("UPDATE cart_items ci SET tenant_id=c.tenant_id FROM carts c WHERE c.id=ci.cart_id")
            elif table=='wishlist_items':
                op.execute("UPDATE wishlist_items wi SET tenant_id=w.tenant_id FROM wishlists w WHERE w.id=wi.wishlist_id")
            if bind.dialect.name == 'postgresql':
                op.alter_column(table,'tenant_id',nullable=False)
    # Frozen DDL for closure tables that were absent from the 0001/0002 baseline.
    # This migration intentionally does not call Base.metadata.create_all(): later model changes must not mutate historical migrations.
    ddl = {
        'permissions': "CREATE TABLE permissions (id VARCHAR(36) NOT NULL PRIMARY KEY, code VARCHAR(120) NOT NULL UNIQUE)",
        'roles': "CREATE TABLE roles (id VARCHAR(36) NOT NULL PRIMARY KEY, tenant_id VARCHAR(36), name VARCHAR(100) NOT NULL, system_role BOOLEAN NOT NULL, CONSTRAINT uq_roles_tenant_name UNIQUE (tenant_id,name), FOREIGN KEY(tenant_id) REFERENCES tenants(id))",
        'tax_classes': "CREATE TABLE tax_classes (id VARCHAR(36) NOT NULL PRIMARY KEY, tenant_id VARCHAR(36) NOT NULL, code VARCHAR(80) NOT NULL, name VARCHAR(255) NOT NULL, status VARCHAR(20) NOT NULL, CONSTRAINT uq_tax_classes_tenant_code UNIQUE (tenant_id,code), FOREIGN KEY(tenant_id) REFERENCES tenants(id))",
        'tax_jurisdictions': "CREATE TABLE tax_jurisdictions (id VARCHAR(36) NOT NULL PRIMARY KEY, tenant_id VARCHAR(36) NOT NULL, country_code VARCHAR(2) NOT NULL, region_code VARCHAR(80), city VARCHAR(120), name VARCHAR(255) NOT NULL, status VARCHAR(20) NOT NULL, CONSTRAINT uq_tax_jurisdictions UNIQUE (tenant_id,country_code,region_code,city), FOREIGN KEY(tenant_id) REFERENCES tenants(id))",
        'customer_addresses': "CREATE TABLE customer_addresses (id VARCHAR(36) NOT NULL PRIMARY KEY, tenant_id VARCHAR(36) NOT NULL, customer_id VARCHAR(36) NOT NULL, country_code VARCHAR(2) NOT NULL, region VARCHAR(120), city VARCHAR(120), postal_code VARCHAR(32), address_line1 TEXT NOT NULL, address_line2 TEXT, type VARCHAR(20) NOT NULL, FOREIGN KEY(tenant_id) REFERENCES tenants(id), FOREIGN KEY(customer_id) REFERENCES customers(id))",
        'plan_prices': "CREATE TABLE plan_prices (id VARCHAR(36) NOT NULL PRIMARY KEY, plan_version_id VARCHAR(36) NOT NULL, billing_interval VARCHAR(20) NOT NULL, amount_minor_units BIGINT NOT NULL, currency VARCHAR(3) NOT NULL, stripe_price_id VARCHAR(255), created_at TIMESTAMP WITH TIME ZONE NOT NULL, CONSTRAINT uq_plan_prices UNIQUE (plan_version_id,billing_interval,currency), FOREIGN KEY(plan_version_id) REFERENCES plan_versions(id))",
        'billing_events': "CREATE TABLE billing_events (id VARCHAR(36) NOT NULL PRIMARY KEY, tenant_id VARCHAR(36) NOT NULL, subscription_id VARCHAR(36), event_type VARCHAR(120) NOT NULL, provider_event_id VARCHAR(255) NOT NULL UNIQUE, payload JSON NOT NULL, status VARCHAR(20) NOT NULL, received_at TIMESTAMP WITH TIME ZONE NOT NULL, processed_at TIMESTAMP WITH TIME ZONE, created_at TIMESTAMP WITH TIME ZONE NOT NULL, FOREIGN KEY(tenant_id) REFERENCES tenants(id), FOREIGN KEY(subscription_id) REFERENCES subscriptions(id))",
        'product_categories': "CREATE TABLE product_categories (product_id VARCHAR(36) NOT NULL, category_id VARCHAR(36) NOT NULL, PRIMARY KEY(product_id,category_id), FOREIGN KEY(product_id) REFERENCES products(id), FOREIGN KEY(category_id) REFERENCES categories(id))",
        'product_media': "CREATE TABLE product_media (tenant_id VARCHAR(36) NOT NULL, product_id VARCHAR(36) NOT NULL, media_asset_id VARCHAR(36) NOT NULL, position INTEGER NOT NULL, alt_text TEXT, PRIMARY KEY(tenant_id,product_id,media_asset_id), FOREIGN KEY(tenant_id) REFERENCES tenants(id), FOREIGN KEY(product_id) REFERENCES products(id), FOREIGN KEY(media_asset_id) REFERENCES media_assets(id))",
        'review_questions': "CREATE TABLE review_questions (id VARCHAR(36) NOT NULL PRIMARY KEY, tenant_id VARCHAR(36) NOT NULL, product_id VARCHAR(36) NOT NULL, customer_id VARCHAR(36) NOT NULL, body TEXT NOT NULL, status VARCHAR(20) NOT NULL, created_at TIMESTAMP WITH TIME ZONE NOT NULL, FOREIGN KEY(tenant_id) REFERENCES tenants(id), FOREIGN KEY(product_id) REFERENCES products(id), FOREIGN KEY(customer_id) REFERENCES customers(id))",
        'subscription_items': "CREATE TABLE subscription_items (id VARCHAR(36) NOT NULL PRIMARY KEY, subscription_id VARCHAR(36) NOT NULL, plan_price_id VARCHAR(36) NOT NULL, quantity INTEGER NOT NULL, FOREIGN KEY(subscription_id) REFERENCES subscriptions(id), FOREIGN KEY(plan_price_id) REFERENCES plan_prices(id))",
        'tax_calculations': "CREATE TABLE tax_calculations (id VARCHAR(36) NOT NULL PRIMARY KEY, tenant_id VARCHAR(36) NOT NULL, order_id VARCHAR(36), currency VARCHAR(3) NOT NULL, provider VARCHAR(80), provider_reference VARCHAR(255), subtotal_minor BIGINT NOT NULL, tax_total_minor BIGINT NOT NULL, created_at TIMESTAMP WITH TIME ZONE NOT NULL, FOREIGN KEY(tenant_id) REFERENCES tenants(id), FOREIGN KEY(order_id) REFERENCES orders(id))",
        'tenant_entitlements': "CREATE TABLE tenant_entitlements (tenant_id VARCHAR(36) NOT NULL, feature_key VARCHAR(100) NOT NULL, value_type VARCHAR(20) NOT NULL, value_boolean BOOLEAN, value_integer INTEGER, source_subscription_id VARCHAR(36), resolved_at TIMESTAMP WITH TIME ZONE NOT NULL, PRIMARY KEY(tenant_id,feature_key), FOREIGN KEY(tenant_id) REFERENCES tenants(id), FOREIGN KEY(source_subscription_id) REFERENCES subscriptions(id))",
        'review_answers': "CREATE TABLE review_answers (id VARCHAR(36) NOT NULL PRIMARY KEY, question_id VARCHAR(36) NOT NULL, tenant_id VARCHAR(36) NOT NULL, answered_by_user_id VARCHAR(36) NOT NULL, body TEXT NOT NULL, created_at TIMESTAMP WITH TIME ZONE NOT NULL, FOREIGN KEY(question_id) REFERENCES review_questions(id), FOREIGN KEY(tenant_id) REFERENCES tenants(id), FOREIGN KEY(answered_by_user_id) REFERENCES users(id))",
        'tax_lines': "CREATE TABLE tax_lines (id VARCHAR(36) NOT NULL PRIMARY KEY, tenant_id VARCHAR(36) NOT NULL, tax_calculation_id VARCHAR(36) NOT NULL, jurisdiction_id VARCHAR(36), tax_class_id VARCHAR(36), taxable_amount_minor BIGINT NOT NULL, tax_amount_minor BIGINT NOT NULL, rate_bps INTEGER, currency VARCHAR(3) NOT NULL, FOREIGN KEY(tenant_id) REFERENCES tenants(id), FOREIGN KEY(tax_calculation_id) REFERENCES tax_calculations(id), FOREIGN KEY(jurisdiction_id) REFERENCES tax_jurisdictions(id), FOREIGN KEY(tax_class_id) REFERENCES tax_classes(id))",
    }
    # SQLite accepts the portable subset above; PostgreSQL accepts it as well.
    for name, statement in ddl.items():
        if name not in sa.inspect(bind).get_table_names():
            op.execute(statement)
    # Webhooks were missing from the RLS matrix; keep tenant nullable for platform-level events.
    if bind.dialect.name=='postgresql':
        # Enforce application-facing financial invariants at DB level where possible.
        for table, checks in {
            'payment_intents': ["CHECK (amount_minor > 0)"],
            'payment_captures': ["CHECK (amount_minor > 0)"],
            'refunds': ["CHECK (amount_minor > 0)"],
            'inventory_reservations': ["CHECK (quantity > 0)"],
            'journal_lines': ["CHECK ((debit_minor > 0 AND credit_minor = 0) OR (credit_minor > 0 AND debit_minor = 0))"],
        }.items():
            for i,expr in enumerate(checks):
                op.execute(f"ALTER TABLE {table} ADD CONSTRAINT {table}_p0_check_{i} {expr}")
        for table in ['product_translations','cart_items','wishlist_items','webhook_events','provider_events']:
            if table in sa.inspect(bind).get_table_names():
                op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
                op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
                colnames={c['name'] for c in sa.inspect(bind).get_columns(table)}
                if 'tenant_id' in colnames:
                    op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
                    op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")

def downgrade():
    pass
