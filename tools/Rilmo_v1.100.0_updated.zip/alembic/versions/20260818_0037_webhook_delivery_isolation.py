"""Isolate app webhook delivery state from outbox event processing.

Revision ID: 20260818_0037
Revises: 20260818_0036
"""
from alembic import op
import sqlalchemy as sa

revision = '20260818_0037'
down_revision = '20260818_0036'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'app_webhook_deliveries',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('subscription_id', sa.String(length=36), sa.ForeignKey('app_webhook_subscriptions.id'), nullable=False),
        sa.Column('event_id', sa.String(length=36), sa.ForeignKey('outbox_events.id'), nullable=False),
        sa.Column('endpoint_url', sa.Text(), nullable=False),
        sa.Column('event_type', sa.String(length=120), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='PENDING'),
        sa.Column('attempt_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('next_attempt_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_error', sa.Text(), nullable=True),
        sa.Column('delivered_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('subscription_id', 'event_id', name='uq_app_webhook_delivery_subscription_event'),
    )
    op.create_index('ix_app_webhook_deliveries_tenant_id', 'app_webhook_deliveries', ['tenant_id'])
    op.create_index('ix_app_webhook_deliveries_subscription_id', 'app_webhook_deliveries', ['subscription_id'])
    op.create_index('ix_app_webhook_deliveries_event_id', 'app_webhook_deliveries', ['event_id'])
    op.create_index('ix_app_webhook_deliveries_next_attempt_at', 'app_webhook_deliveries', ['next_attempt_at'])


def downgrade():
    op.drop_index('ix_app_webhook_deliveries_next_attempt_at', table_name='app_webhook_deliveries')
    op.drop_index('ix_app_webhook_deliveries_event_id', table_name='app_webhook_deliveries')
    op.drop_index('ix_app_webhook_deliveries_subscription_id', table_name='app_webhook_deliveries')
    op.drop_index('ix_app_webhook_deliveries_tenant_id', table_name='app_webhook_deliveries')
    op.drop_table('app_webhook_deliveries')
