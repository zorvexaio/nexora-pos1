"""Production runtime-context policies for tenant bootstrap, webhooks, and workers."""
from alembic import op

revision='20260816_0008'
down_revision='20260816_0007'
branch_labels=None
depends_on=None

TENANT_TABLES=['storefronts','domains','products','product_translations','product_variants','categories','product_seo','media_assets','prices','promotions','coupons','coupon_redemptions','customers','carts','cart_items','orders','order_items','order_status_history','inventory_locations','inventory_items','inventory_reservations','inventory_adjustments','payment_intents','payment_attempts','payment_captures','refunds','ledger_accounts','journal_entries','journal_lines','outbox_events','dead_letter_events','idempotency_keys','provider_events','reconciliation_records','settlements','payouts','financial_transactions','price_lists','market_prices','discount_applications','product_options','product_option_values','product_variant_option_values','shipping_methods','tax_rates','merchant_payment_accounts','billing_customers','subscriptions','entitlements','wishlists','wishlist_items','reviews','questions','answers','order_tracking_references','consent_records']

def upgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql': return
    for table in TENANT_TABLES:
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
        op.execute(f"""CREATE POLICY {table}_tenant_isolation ON {table}
        USING (
          current_setting('app.worker', true) = 'on'
          OR tenant_id::text = current_setting('app.current_tenant', true)
        )
        WITH CHECK (
          current_setting('app.worker', true) = 'on'
          OR tenant_id::text = current_setting('app.current_tenant', true)
        )""")
    op.execute("DROP POLICY IF EXISTS webhook_events_tenant_isolation ON webhook_events")
    op.execute("""CREATE POLICY webhook_events_tenant_isolation ON webhook_events
      USING (
        current_setting('app.worker', true) = 'on'
        OR current_setting('app.allow_unscoped_ingest', true) = 'on'
        OR tenant_id::text = current_setting('app.current_tenant', true)
      )
      WITH CHECK (
        current_setting('app.worker', true) = 'on'
        OR current_setting('app.allow_unscoped_ingest', true) = 'on'
        OR tenant_id::text = current_setting('app.current_tenant', true)
      )""")
    op.execute("""COMMENT ON POLICY webhook_events_tenant_isolation ON webhook_events IS
      'Allows only the verified webhook ingestion transaction to persist unresolved provider events; normal API traffic requires tenant context.'""")

def downgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql': return
    for table in TENANT_TABLES:
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
        op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")
