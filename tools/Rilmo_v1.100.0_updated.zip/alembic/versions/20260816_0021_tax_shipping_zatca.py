"""Tax invoices, carrier abstraction and shipment lifecycle."""
from alembic import op
import sqlalchemy as sa

revision='20260816_0021'
down_revision='20260816_0020'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('carrier_accounts',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('carrier_code',sa.String(40),nullable=False),sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'),
        sa.Column('api_base_url',sa.Text()),sa.Column('api_token_encrypted',sa.Text()),sa.Column('metadata_json',sa.JSON()),
        sa.UniqueConstraint('tenant_id','carrier_code',name='uq_carrier_account_tenant_code'))
    op.create_index('ix_carrier_accounts_tenant_id','carrier_accounts',['tenant_id'])
    op.create_table('shipments',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('order_id',sa.String(36),sa.ForeignKey('orders.id'),nullable=False),sa.Column('carrier_code',sa.String(40),nullable=False),
        sa.Column('service_code',sa.String(80)),sa.Column('provider_shipment_id',sa.String(255)),sa.Column('tracking_number',sa.String(255)),
        sa.Column('label_url',sa.Text()),sa.Column('status',sa.String(30),nullable=False,server_default='PENDING'),
        sa.Column('created_at',sa.DateTime(timezone=True)),sa.Column('updated_at',sa.DateTime(timezone=True)),
        sa.UniqueConstraint('tenant_id','provider_shipment_id',name='uq_shipment_tenant_provider'))
    op.create_index('ix_shipments_tenant_id','shipments',['tenant_id']); op.create_index('ix_shipments_order_id','shipments',['order_id'])
    op.create_table('shipment_events',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('shipment_id',sa.String(36),sa.ForeignKey('shipments.id'),nullable=False),sa.Column('provider_event_id',sa.String(255),nullable=False),
        sa.Column('status',sa.String(40),nullable=False),sa.Column('payload',sa.JSON(),nullable=False),sa.Column('occurred_at',sa.DateTime(timezone=True)),
        sa.UniqueConstraint('tenant_id','provider_event_id',name='uq_shipment_event_tenant_provider'))
    op.create_index('ix_shipment_events_tenant_id','shipment_events',['tenant_id']); op.create_index('ix_shipment_events_shipment_id','shipment_events',['shipment_id'])
    op.create_table('tax_invoices',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('order_id',sa.String(36),sa.ForeignKey('orders.id'),nullable=False),sa.Column('invoice_number',sa.String(80),nullable=False),
        sa.Column('invoice_type',sa.String(30),nullable=False,server_default='STANDARD'),sa.Column('status',sa.String(30),nullable=False,server_default='DRAFT'),
        sa.Column('currency',sa.String(3),nullable=False),sa.Column('subtotal_minor',sa.BigInteger(),nullable=False),sa.Column('tax_minor',sa.BigInteger(),nullable=False),
        sa.Column('total_minor',sa.BigInteger(),nullable=False),sa.Column('xml_sha256',sa.String(64)),sa.Column('xml_content',sa.Text()),sa.Column('zatca_uuid',sa.String(64)),
        sa.Column('reported_at',sa.DateTime(timezone=True)),sa.Column('created_at',sa.DateTime(timezone=True)),
        sa.UniqueConstraint('tenant_id','invoice_number',name='uq_tax_invoice_tenant_number'),sa.UniqueConstraint('order_id',name='uq_tax_invoice_order'))
    op.create_index('ix_tax_invoices_tenant_id','tax_invoices',['tenant_id'])
    if op.get_bind().dialect.name == 'postgresql':
        for table in ['carrier_accounts','shipments','shipment_events','tax_invoices']:
            op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
            op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
            op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
            op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting(\'app.current_tenant\', true)) WITH CHECK (tenant_id::text = current_setting(\'app.current_tenant\', true))")

def downgrade():
    if op.get_bind().dialect.name == 'postgresql':
        for table in ['tax_invoices','shipment_events','shipments','carrier_accounts']:
            op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
            op.execute(f'ALTER TABLE {table} DISABLE ROW LEVEL SECURITY')
    op.drop_table('tax_invoices'); op.drop_table('shipment_events'); op.drop_table('shipments'); op.drop_table('carrier_accounts')
