"""buyer protection issue conversations and merchant refund execution"""
from alembic import op
import sqlalchemy as sa

revision = '20260820_0055'
down_revision = '20260820_0054'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        'order_issue_messages',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('issue_id', sa.String(length=36), sa.ForeignKey('order_issues.id'), nullable=False),
        sa.Column('author_type', sa.String(length=20), nullable=False),
        sa.Column('author_id', sa.String(length=36), nullable=True),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_order_issue_messages_tenant_id', 'order_issue_messages', ['tenant_id'])
    op.create_index('ix_order_issue_messages_issue_id', 'order_issue_messages', ['issue_id'])
    op.create_index('ix_order_issue_messages_author_id', 'order_issue_messages', ['author_id'])
    op.create_index('ix_order_issue_messages_created_at', 'order_issue_messages', ['created_at'])
    try:
        op.execute('ALTER TABLE order_issue_messages ENABLE ROW LEVEL SECURITY')
        op.execute('ALTER TABLE order_issue_messages FORCE ROW LEVEL SECURITY')
        op.execute("CREATE POLICY order_issue_messages_tenant_isolation ON order_issue_messages USING (tenant_id = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id = current_setting('app.current_tenant', true))")
    except Exception:
        pass

def downgrade():
    try:
        op.execute('DROP POLICY IF EXISTS order_issue_messages_tenant_isolation ON order_issue_messages')
    except Exception:
        pass
    op.drop_index('ix_order_issue_messages_created_at', table_name='order_issue_messages')
    op.drop_index('ix_order_issue_messages_author_id', table_name='order_issue_messages')
    op.drop_index('ix_order_issue_messages_issue_id', table_name='order_issue_messages')
    op.drop_index('ix_order_issue_messages_tenant_id', table_name='order_issue_messages')
    op.drop_table('order_issue_messages')
