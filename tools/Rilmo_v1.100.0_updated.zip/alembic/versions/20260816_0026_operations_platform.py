"""Operations platform: onboarding, support, workflow automation."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0026'; down_revision='20260816_0025'; branch_labels=None; depends_on=None

def _rls(table):
    b=op.get_bind()
    if b.dialect.name=='postgresql':
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")

def upgrade():
    op.create_table('merchant_onboarding_steps',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('step_key',sa.String(80),nullable=False),sa.Column('status',sa.String(24),nullable=False,server_default='PENDING'),sa.Column('completed_at',sa.DateTime(timezone=True)),sa.Column('metadata',sa.JSON(),nullable=False),sa.Column('created_at',sa.DateTime(timezone=True)),sa.UniqueConstraint('tenant_id','step_key',name='uq_onboarding_step'))
    op.create_index('ix_onboarding_steps_tenant','merchant_onboarding_steps',['tenant_id'])
    op.create_table('support_tickets',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('ticket_number',sa.String(40),nullable=False),sa.Column('subject',sa.String(200),nullable=False),sa.Column('body',sa.Text(),nullable=False),sa.Column('priority',sa.String(20),nullable=False,server_default='NORMAL'),sa.Column('status',sa.String(20),nullable=False,server_default='OPEN'),sa.Column('category',sa.String(50),nullable=False,server_default='GENERAL'),sa.Column('requester_user_id',sa.String(36),sa.ForeignKey('users.id'),nullable=False),sa.Column('assigned_user_id',sa.String(36),sa.ForeignKey('users.id')),sa.Column('sla_due_at',sa.DateTime(timezone=True)),sa.Column('created_at',sa.DateTime(timezone=True)),sa.Column('updated_at',sa.DateTime(timezone=True)),sa.UniqueConstraint('tenant_id','ticket_number',name='uq_support_ticket_number'))
    op.create_index('ix_support_tickets_tenant','support_tickets',['tenant_id'])
    op.create_table('workflow_definitions',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('slug',sa.String(120),nullable=False),sa.Column('name',sa.String(200),nullable=False),sa.Column('trigger_event',sa.String(120),nullable=False),sa.Column('enabled',sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column('steps',sa.JSON(),nullable=False),sa.Column('version',sa.Integer(),nullable=False,server_default='1'),sa.Column('created_at',sa.DateTime(timezone=True)),sa.UniqueConstraint('tenant_id','slug',name='uq_workflow_definition'))
    op.create_index('ix_workflow_definitions_tenant','workflow_definitions',['tenant_id'])
    op.create_table('workflow_runs',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('workflow_id',sa.String(36),sa.ForeignKey('workflow_definitions.id'),nullable=False),sa.Column('trigger_event',sa.String(120),nullable=False),sa.Column('status',sa.String(20),nullable=False,server_default='QUEUED'),sa.Column('input_payload',sa.JSON(),nullable=False),sa.Column('output_payload',sa.JSON(),nullable=False),sa.Column('error_message',sa.Text()),sa.Column('started_at',sa.DateTime(timezone=True)),sa.Column('completed_at',sa.DateTime(timezone=True)),sa.Column('created_at',sa.DateTime(timezone=True)))
    op.create_index('ix_workflow_runs_tenant','workflow_runs',['tenant_id'])
    op.create_index('ix_workflow_runs_workflow','workflow_runs',['workflow_id'])
    for t in ['merchant_onboarding_steps','support_tickets','workflow_definitions','workflow_runs']: _rls(t)

def downgrade():
    b=op.get_bind()
    if b.dialect.name=='postgresql':
        for t in ['workflow_runs','workflow_definitions','support_tickets','merchant_onboarding_steps']:
            op.execute(f'DROP POLICY IF EXISTS {t}_tenant_isolation ON {t}')
            op.execute(f'ALTER TABLE {t} DISABLE ROW LEVEL SECURITY')
    for t in ['workflow_runs','workflow_definitions','support_tickets','merchant_onboarding_steps']: op.drop_table(t)
