"""Close tenant RLS coverage gaps introduced by post-baseline commerce features.

This migration intentionally re-asserts RLS on tables that contain tenant-scoped
buyer-protection, merchant-trust, domain-commerce, and customer-account data.
It does not silently swallow PostgreSQL failures.
"""
from alembic import op

revision = "20260822_0065"
down_revision = "20260822_0064"
branch_labels = None
depends_on = None

TABLES = [
    # Storefront customer authentication/state.
    "customer_identities",
    "customer_sessions",
    "customer_login_codes",
    "storefront_oauth_states",
    # Merchant trust / onboarding / domain commerce.
    "merchant_profiles",
    "merchant_phone_verifications",
    "tenant_reviews",
    "trust_reports",
    "merchant_trust_scores",
    "domain_purchases",
    # Buyer protection and support conversations.
    "order_issues",
    "order_issue_messages",
]


def _set_rls(table: str) -> None:
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
    op.execute(
        f"""CREATE POLICY {table}_tenant_isolation ON {table}
            USING (tenant_id::text = current_setting('app.current_tenant', true))
            WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))"""
    )


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    for table in TABLES:
        _set_rls(table)


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    for table in reversed(TABLES):
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY")
