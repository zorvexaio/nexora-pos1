"""Capture immutable unit cost on order items for historical profitability."""
from alembic import op
import sqlalchemy as sa

revision = '20260909_0070'
down_revision = '20260908_0069'
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('order_items', sa.Column('cost_amount_minor', sa.BigInteger(), nullable=True))

def downgrade():
    op.drop_column('order_items', 'cost_amount_minor')
