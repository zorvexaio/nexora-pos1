from alembic import op
import sqlalchemy as sa

revision = '20260820_0054'
down_revision = '20260819_0053'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('shipping_methods', sa.Column('carrier_code', sa.String(40), nullable=False, server_default='platform'))
    op.add_column('shipping_methods', sa.Column('service_code', sa.String(80), nullable=True))
    op.add_column('shipping_methods', sa.Column('free_shipping', sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column('shipping_methods', sa.Column('free_shipping_threshold_minor', sa.BigInteger(), nullable=True))
    op.add_column('shipping_methods', sa.Column('offer_label', sa.String(255), nullable=True))
    op.add_column('shipping_methods', sa.Column('estimated_days_min', sa.Integer(), nullable=True))
    op.add_column('shipping_methods', sa.Column('estimated_days_max', sa.Integer(), nullable=True))

    op.add_column('orders', sa.Column('shipping_list_minor', sa.BigInteger(), nullable=False, server_default='0'))
    op.add_column('orders', sa.Column('shipping_discount_minor', sa.BigInteger(), nullable=False, server_default='0'))
    op.add_column('orders', sa.Column('shipping_method_id', sa.String(36), nullable=True))
    op.add_column('orders', sa.Column('shipping_carrier_code', sa.String(40), nullable=True))
    op.add_column('orders', sa.Column('shipping_service_code', sa.String(80), nullable=True))
    op.create_index('ix_orders_shipping_method_id', 'orders', ['shipping_method_id'])
    bind = op.get_bind()
    if bind.dialect.name == 'sqlite':
        with op.batch_alter_table('orders') as batch:
            batch.create_foreign_key('fk_orders_shipping_method', 'shipping_methods', ['shipping_method_id'], ['id'])
    else:
        op.create_foreign_key('fk_orders_shipping_method', 'orders', 'shipping_methods', ['shipping_method_id'], ['id'])

    bind = op.get_bind()
    if bind.dialect.name == 'postgresql':
        op.execute('ALTER TABLE shipping_methods ENABLE ROW LEVEL SECURITY')
        op.execute('ALTER TABLE shipping_methods FORCE ROW LEVEL SECURITY')


def downgrade():
    bind = op.get_bind()
    if bind.dialect.name == 'sqlite':
        with op.batch_alter_table('orders') as batch:
            batch.drop_constraint('fk_orders_shipping_method', type_='foreignkey')
    else:
        op.drop_constraint('fk_orders_shipping_method', 'orders', type_='foreignkey')
    op.drop_index('ix_orders_shipping_method_id', table_name='orders')
    for col in ('shipping_service_code', 'shipping_carrier_code', 'shipping_method_id', 'shipping_discount_minor', 'shipping_list_minor'):
        op.drop_column('orders', col)
    for col in ('estimated_days_max', 'estimated_days_min', 'offer_label', 'free_shipping_threshold_minor', 'free_shipping', 'service_code', 'carrier_code'):
        op.drop_column('shipping_methods', col)
