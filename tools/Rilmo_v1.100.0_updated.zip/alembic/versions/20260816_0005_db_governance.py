"""P0 database governance: immutable finance/audit roles and RLS guardrails."""
from alembic import op
import sqlalchemy as sa

revision='20260816_0005'
down_revision='20260816_0004'
branch_labels=None
depends_on=None

TENANT_TABLES=['storefronts','domains','products','product_translations','product_variants','categories','product_seo','media_assets','prices','promotions','coupons','coupon_redemptions','customers','carts','cart_items','orders','order_items','order_status_history','inventory_locations','inventory_items','inventory_reservations','inventory_adjustments','payment_intents','payment_attempts','payment_captures','refunds','ledger_accounts','journal_entries','journal_lines','outbox_events','dead_letter_events','idempotency_keys','provider_events','reconciliation_records','settlements','payouts','financial_transactions','price_lists','market_prices','discount_applications','product_options','product_option_values','product_variant_option_values','shipping_methods','tax_rates','merchant_payment_accounts','billing_customers','subscriptions','entitlements','wishlists','wishlist_items','reviews','questions','answers','order_tracking_references','consent_records']

def upgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql': return
    inspector=sa.inspect(bind)
    # Runtime application role must never be allowed to mutate immutable evidence tables.
    for table in ('journal_entries','journal_lines','audit_events'):
        if table in inspector.get_table_names():
            op.execute(f'REVOKE UPDATE, DELETE ON {table} FROM PUBLIC')
    # RLS should remain forced for all tenant-scoped tables.
    for table in TENANT_TABLES:
        if table not in inspector.get_table_names():
            continue
        cols={c['name'] for c in inspector.get_columns(table)}
        if 'tenant_id' not in cols:
            continue
        op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
        op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
        op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")
    # Refuse empty/current-tenant bypass attempts for application role; a missing setting yields no match.
    op.execute("CREATE INDEX IF NOT EXISTS idx_outbox_claim ON outbox_events(status, next_attempt_at, created_at)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_idempotency_lookup ON idempotency_keys(tenant_id, endpoint, key, expires_at)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_provider_events_replay ON provider_events(provider, provider_event_id, received_at)")

def downgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql': return
    for table in reversed(TENANT_TABLES):
        op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
