"""payment operation retry semantics + media variants"""
from alembic import op
import sqlalchemy as sa

revision = "20260816_0019"
down_revision = "20260816_0018_global_i18n_oauth_link"
branch_labels = None
depends_on = None

def upgrade():
    bind=op.get_bind()
    # A payment intent may have multiple sequential refunds/retries, but only one
    # active operation of each type at a time. Replace the overly restrictive
    # permanent uniqueness constraint with an active-operation partial index.
    try: op.drop_constraint('uq_payment_operation_scope', 'payment_operations', type_='unique')
    except Exception: pass
    op.create_index('uq_payment_operation_active', 'payment_operations', ['tenant_id','payment_intent_id','operation_type'], unique=True, postgresql_where=sa.text("status IN ('PENDING','PROVIDER_PENDING')"), sqlite_where=sa.text("status IN ('PENDING','PROVIDER_PENDING')"))
    op.create_table(
        'media_variants',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('media_asset_id', sa.String(length=36), sa.ForeignKey('media_assets.id'), nullable=False),
        sa.Column('variant', sa.String(length=30), nullable=False),
        sa.Column('storage_key', sa.String(length=500), nullable=False, unique=True),
        sa.Column('mime_type', sa.String(length=100), nullable=False),
        sa.Column('width', sa.Integer()),
        sa.Column('height', sa.Integer()),
        sa.Column('size_bytes', sa.BigInteger(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','media_asset_id','variant',name='uq_media_variant'),
    )
    op.create_index('ix_media_variants_tenant_id','media_variants',['tenant_id'])
    op.create_index('ix_media_variants_media_asset_id','media_variants',['media_asset_id'])

def downgrade():
    op.drop_index('ix_media_variants_media_asset_id',table_name='media_variants')
    op.drop_index('ix_media_variants_tenant_id',table_name='media_variants')
    op.drop_table('media_variants')
    op.drop_index('uq_payment_operation_active',table_name='payment_operations')
    with op.batch_alter_table('payment_operations', recreate='always') as batch:
        batch.create_unique_constraint('uq_payment_operation_scope',['tenant_id','payment_intent_id','operation_type'])
