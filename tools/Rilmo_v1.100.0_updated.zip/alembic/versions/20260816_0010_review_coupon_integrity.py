"""Close verified-review and coupon-redemption invariants."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0010'
down_revision='20260816_0009'
branch_labels=None
depends_on=None

def upgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql': return
    op.add_column('reviews',sa.Column('order_id',sa.String(36),nullable=True))
    op.create_foreign_key('fk_reviews_order','reviews','orders',['order_id'],['id'])
    op.create_unique_constraint('uq_review_purchase','reviews',['tenant_id','order_id','product_id','customer_id'])
    # Existing rows are legacy; keep nullable for migration safety. New application writes always require order_id.
    op.add_column('coupon_redemptions',sa.Column('customer_id',sa.String(36),nullable=True))
    op.add_column('coupon_redemptions',sa.Column('idempotency_key',sa.String(200),nullable=True))
    op.create_foreign_key('fk_coupon_redemptions_customer','coupon_redemptions','customers',['customer_id'],['id'])
    # Backfill deterministic keys for existing rows, then enforce uniqueness for new writes.
    op.execute("UPDATE coupon_redemptions SET idempotency_key='legacy:'||id WHERE idempotency_key IS NULL")
    op.alter_column('coupon_redemptions','idempotency_key',nullable=False)
    op.create_unique_constraint('uq_coupon_redemption_idempotency','coupon_redemptions',['tenant_id','idempotency_key'])

def downgrade():
    bind=op.get_bind()
    if bind.dialect.name!='postgresql': return
    op.drop_constraint('uq_coupon_redemption_idempotency','coupon_redemptions',type_='unique')
    op.drop_constraint('fk_coupon_redemptions_customer','coupon_redemptions',type_='foreignkey')
    op.drop_column('coupon_redemptions','idempotency_key'); op.drop_column('coupon_redemptions','customer_id')
    op.drop_constraint('uq_review_purchase','reviews',type_='unique'); op.drop_constraint('fk_reviews_order','reviews',type_='foreignkey'); op.drop_column('reviews','order_id')
