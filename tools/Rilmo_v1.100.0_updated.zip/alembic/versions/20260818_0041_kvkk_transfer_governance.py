from alembic import op
import sqlalchemy as sa

revision = '20260818_0041'
down_revision = '20260818_0040'
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('privacy_transfer_register', sa.Column('contract_type', sa.String(length=80)))
    op.add_column('privacy_transfer_register', sa.Column('signed_at', sa.DateTime(timezone=True)))
    op.add_column('privacy_transfer_register', sa.Column('signatory_authority_reference', sa.String(length=255)))
    op.add_column('privacy_transfer_register', sa.Column('regulatory_notification_reference', sa.String(length=255)))
    op.add_column('privacy_transfer_register', sa.Column('regulatory_notified_at', sa.DateTime(timezone=True)))
    op.add_column('privacy_transfer_register', sa.Column('approval_status', sa.String(length=32), nullable=False, server_default='PENDING_REVIEW'))
    op.create_index('ix_privacy_transfer_register_approval_status', 'privacy_transfer_register', ['approval_status'])

def downgrade():
    op.drop_index('ix_privacy_transfer_register_approval_status', table_name='privacy_transfer_register')
    op.drop_column('privacy_transfer_register', 'approval_status')
    op.drop_column('privacy_transfer_register', 'regulatory_notified_at')
    op.drop_column('privacy_transfer_register', 'regulatory_notification_reference')
    op.drop_column('privacy_transfer_register', 'signatory_authority_reference')
    op.drop_column('privacy_transfer_register', 'signed_at')
    op.drop_column('privacy_transfer_register', 'contract_type')
