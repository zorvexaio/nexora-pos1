from alembic import op
import sqlalchemy as sa

revision = '20260819_0042'
down_revision = '20260818_0041'
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('impersonation_sessions', sa.Column('ticket_id', sa.String(length=120), nullable=True))
    op.create_index('ix_impersonation_sessions_ticket_id', 'impersonation_sessions', ['ticket_id'])

def downgrade():
    op.drop_index('ix_impersonation_sessions_ticket_id', table_name='impersonation_sessions')
    op.drop_column('impersonation_sessions', 'ticket_id')
