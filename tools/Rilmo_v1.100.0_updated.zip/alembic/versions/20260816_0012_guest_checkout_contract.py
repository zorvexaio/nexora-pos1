"""guest checkout + immutable order/cart lifecycle fields"""
from alembic import op
import sqlalchemy as sa

revision='20260816_0012'
down_revision='20260816_0011'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('guest_sessions',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('tenant_id',sa.String(36),nullable=False),
        sa.Column('token_hash',sa.String(128),nullable=False,unique=True),
        sa.Column('expires_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('last_seen_at',sa.DateTime(timezone=True),nullable=False),
        sa.ForeignKeyConstraint(['tenant_id'],['tenants.id']),
        sa.UniqueConstraint('tenant_id','token_hash'))
    op.create_index('ix_guest_sessions_tenant_id','guest_sessions',['tenant_id'])
    op.create_index('ix_guest_sessions_token_hash','guest_sessions',['token_hash'])
    op.create_index('ix_guest_sessions_expires_at','guest_sessions',['expires_at'])
    if op.get_bind().dialect.name == 'postgresql':
        op.execute('ALTER TABLE guest_sessions ENABLE ROW LEVEL SECURITY')
        op.execute('ALTER TABLE guest_sessions FORCE ROW LEVEL SECURITY')
        op.execute("CREATE POLICY guest_sessions_tenant_isolation ON guest_sessions USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")
    op.add_column('carts',sa.Column('guest_session_id',sa.String(36),nullable=True))
    if op.get_bind().dialect.name == 'sqlite':
        with op.batch_alter_table('carts', recreate='always') as batch:
            batch.create_foreign_key('fk_carts_guest_session','guest_sessions',['guest_session_id'],['id'])
    else:
        op.create_foreign_key('fk_carts_guest_session','carts','guest_sessions',['guest_session_id'],['id'])
    op.create_index('ix_carts_guest_session_id','carts',['guest_session_id'])
    op.add_column('carts',sa.Column('expires_at',sa.DateTime(timezone=True),nullable=True))
    op.add_column('carts',sa.Column('created_at',sa.DateTime(timezone=True),nullable=True))
    op.add_column('carts',sa.Column('updated_at',sa.DateTime(timezone=True),nullable=True))
    op.execute("UPDATE carts SET created_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE created_at IS NULL")
    if op.get_bind().dialect.name == 'sqlite':
        with op.batch_alter_table('carts', recreate='always') as batch:
            batch.alter_column('created_at',nullable=False)
            batch.alter_column('updated_at',nullable=False)
    else:
        op.alter_column('carts','created_at',nullable=False)
        op.alter_column('carts','updated_at',nullable=False)
    op.add_column('orders',sa.Column('customer_email_snapshot',sa.String(320),nullable=True))
    op.add_column('orders',sa.Column('guest_session_id',sa.String(36),nullable=True))
    if op.get_bind().dialect.name == 'sqlite':
        with op.batch_alter_table('orders', recreate='always') as batch:
            batch.create_foreign_key('fk_orders_guest_session','guest_sessions',['guest_session_id'],['id'])
    else:
        op.create_foreign_key('fk_orders_guest_session','orders','guest_sessions',['guest_session_id'],['id'])
    op.create_index('ix_orders_guest_session_id','orders',['guest_session_id'])
    op.add_column('orders',sa.Column('updated_at',sa.DateTime(timezone=True),nullable=True))
    op.execute("UPDATE orders SET updated_at=created_at WHERE updated_at IS NULL")
    if op.get_bind().dialect.name == 'sqlite':
        with op.batch_alter_table('orders', recreate='always') as batch:
            batch.alter_column('updated_at',nullable=False)
    else:
        op.alter_column('orders','updated_at',nullable=False)
    op.create_index('ix_orders_customer_email_snapshot','orders',['tenant_id','customer_email_snapshot'])

def downgrade():
    op.drop_index('ix_orders_customer_email_snapshot',table_name='orders')
    op.drop_column('orders','updated_at')
    op.drop_column('orders','customer_email_snapshot')
    op.drop_index('ix_orders_guest_session_id',table_name='orders')
    if op.get_bind().dialect.name == 'sqlite':
        with op.batch_alter_table('orders', recreate='always') as batch:
            batch.drop_constraint('fk_orders_guest_session',type_='foreignkey')
    else:
        op.drop_constraint('fk_orders_guest_session','orders',type_='foreignkey')
    op.drop_column('orders','guest_session_id')
    op.drop_column('carts','updated_at')
    op.drop_column('carts','created_at')
    op.drop_column('carts','expires_at')
    op.drop_index('ix_carts_guest_session_id',table_name='carts')
    if op.get_bind().dialect.name == 'sqlite':
        with op.batch_alter_table('carts', recreate='always') as batch:
            batch.drop_constraint('fk_carts_guest_session',type_='foreignkey')
    else:
        op.drop_constraint('fk_carts_guest_session','carts',type_='foreignkey')
    op.drop_column('carts','guest_session_id')
    op.drop_index('ix_guest_sessions_expires_at',table_name='guest_sessions')
    op.drop_index('ix_guest_sessions_token_hash',table_name='guest_sessions')
    op.drop_index('ix_guest_sessions_tenant_id',table_name='guest_sessions')
    if op.get_bind().dialect.name == 'postgresql':
        op.execute('DROP POLICY IF EXISTS guest_sessions_tenant_isolation ON guest_sessions')
        op.execute('ALTER TABLE guest_sessions NO FORCE ROW LEVEL SECURITY')
        op.execute('ALTER TABLE guest_sessions DISABLE ROW LEVEL SECURITY')
    op.drop_table('guest_sessions')
