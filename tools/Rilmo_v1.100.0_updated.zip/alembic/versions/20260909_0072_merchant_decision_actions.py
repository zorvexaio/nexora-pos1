"""Persist merchant decisions for action/outcome tracking."""
from alembic import op
import sqlalchemy as sa

revision = '0072'
down_revision = '0071'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'merchant_decision_actions',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('decision_key', sa.String(240), nullable=False),
        sa.Column('decision_code', sa.String(100), nullable=False),
        sa.Column('priority', sa.String(20), nullable=False, server_default='MEDIUM'),
        sa.Column('status', sa.String(20), nullable=False, server_default='OPEN'),
        sa.Column('currency', sa.String(3), nullable=True),
        sa.Column('expected_impact_minor', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('actual_impact_minor', sa.BigInteger(), nullable=True),
        sa.Column('confidence', sa.String(20), nullable=False, server_default='HIGH'),
        sa.Column('evidence', sa.JSON(), nullable=False),
        sa.Column('recommended_action', sa.Text(), nullable=True),
        sa.Column('outcome_note', sa.Text(), nullable=True),
        sa.Column('created_by_user_id', sa.String(36), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('completed_by_user_id', sa.String(36), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('accepted_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id', 'decision_key', name='uq_merchant_decision_action_key'),
    )
    op.create_index('ix_merchant_decision_actions_tenant_id', 'merchant_decision_actions', ['tenant_id'])
    op.create_index('ix_merchant_decision_actions_decision_code', 'merchant_decision_actions', ['decision_code'])
    op.create_index('ix_merchant_decision_actions_status', 'merchant_decision_actions', ['status'])
    op.create_index('ix_merchant_decision_actions_tenant_status', 'merchant_decision_actions', ['tenant_id', 'status'])
    op.create_index('ix_merchant_decision_actions_tenant_created', 'merchant_decision_actions', ['tenant_id', 'created_at'])
    if op.get_bind().dialect.name == 'postgresql':
        op.execute('ALTER TABLE merchant_decision_actions ENABLE ROW LEVEL SECURITY')
        op.execute('ALTER TABLE merchant_decision_actions FORCE ROW LEVEL SECURITY')
        op.execute("CREATE POLICY merchant_decision_actions_tenant_isolation ON merchant_decision_actions USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")


def downgrade():
    if op.get_bind().dialect.name == 'postgresql':
        op.execute('DROP POLICY IF EXISTS merchant_decision_actions_tenant_isolation ON merchant_decision_actions')
    op.drop_index('ix_merchant_decision_actions_tenant_created', table_name='merchant_decision_actions')
    op.drop_index('ix_merchant_decision_actions_tenant_status', table_name='merchant_decision_actions')
    op.drop_index('ix_merchant_decision_actions_status', table_name='merchant_decision_actions')
    op.drop_index('ix_merchant_decision_actions_decision_code', table_name='merchant_decision_actions')
    op.drop_index('ix_merchant_decision_actions_tenant_id', table_name='merchant_decision_actions')
    op.drop_table('merchant_decision_actions')
