"""Enforce the inventory available quantity invariant at the database layer.

A negative available quantity can otherwise consume stock already reserved for
another order. The application also enforces this rule, but PostgreSQL must
enforce the invariant independently.
"""
from alembic import op
import sqlalchemy as sa

revision = "20260825_0067"
down_revision = "20260823_0066"
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        op.create_check_constraint(
            "ck_inventory_items_available_nonnegative",
            "inventory_items",
            "available >= 0",
        )

def downgrade():
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        op.drop_constraint(
            "ck_inventory_items_available_nonnegative",
            "inventory_items",
            type_="check",
        )
