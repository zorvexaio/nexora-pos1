"""Global i18n and secure OAuth account-linking state."""
from alembic import op
import sqlalchemy as sa

revision='20260816_0018_global_i18n_oauth_link'
down_revision='20260816_0017'
branch_labels=None
depends_on=None

def upgrade():
    with op.batch_alter_table('oauth_states', recreate='auto') as batch:
        batch.add_column(sa.Column('user_id', sa.String(length=36), nullable=True))
        batch.create_index('ix_oauth_states_user_id', ['user_id'], unique=False)
        batch.create_foreign_key('fk_oauth_states_user_id', 'users', ['user_id'], ['id'])

def downgrade():
    with op.batch_alter_table('oauth_states', recreate='auto') as batch:
        batch.drop_constraint('fk_oauth_states_user_id', type_='foreignkey')
        batch.drop_index('ix_oauth_states_user_id')
        batch.drop_column('user_id')
