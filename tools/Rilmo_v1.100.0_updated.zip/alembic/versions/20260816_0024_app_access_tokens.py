"""Dedicated multi-token storage for installed app OAuth access tokens."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0024'; down_revision='20260816_0023'; branch_labels=None; depends_on=None
def upgrade():
    op.create_table('app_access_tokens',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('installation_id',sa.String(36),sa.ForeignKey('app_installations.id'),nullable=False),
        sa.Column('token_hash',sa.String(128),nullable=False,unique=True),
        sa.Column('scopes',sa.JSON(),nullable=False),
        sa.Column('expires_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('revoked_at',sa.DateTime(timezone=True)),
        sa.Column('created_at',sa.DateTime(timezone=True)),
    )
    op.create_index('ix_app_access_tokens_tenant_id','app_access_tokens',['tenant_id'])
    op.create_index('ix_app_access_tokens_installation_id','app_access_tokens',['installation_id'])
    if op.get_bind().dialect.name=='postgresql':
        op.execute('ALTER TABLE app_access_tokens ENABLE ROW LEVEL SECURITY'); op.execute('ALTER TABLE app_access_tokens FORCE ROW LEVEL SECURITY')
        op.execute('DROP POLICY IF EXISTS app_access_tokens_tenant_isolation ON app_access_tokens')
        op.execute("CREATE POLICY app_access_tokens_tenant_isolation ON app_access_tokens USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")
def downgrade():
    if op.get_bind().dialect.name=='postgresql':
        op.execute('DROP POLICY IF EXISTS app_access_tokens_tenant_isolation ON app_access_tokens'); op.execute('ALTER TABLE app_access_tokens DISABLE ROW LEVEL SECURITY')
    op.drop_table('app_access_tokens')
