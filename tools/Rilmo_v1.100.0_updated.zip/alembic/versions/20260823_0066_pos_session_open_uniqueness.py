from alembic import op
import sqlalchemy as sa

revision = "20260823_0066"
down_revision = "20260822_0065"
branch_labels = None
depends_on = None

def upgrade():
    op.create_index(
        "uq_pos_session_open_register",
        "pos_sessions",
        ["tenant_id", "register_id"],
        unique=True,
        postgresql_where=sa.text("status = 'OPEN'"),
        sqlite_where=sa.text("status = 'OPEN'"),
    )

def downgrade():
    op.drop_index("uq_pos_session_open_register", table_name="pos_sessions")
