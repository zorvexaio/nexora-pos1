"""OAuth state and DNS domain verification hardening."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0017'; down_revision='20260816_0016'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('oauth_states',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('provider',sa.String(50),nullable=False),
        sa.Column('state_hash',sa.String(128),nullable=False),
        sa.Column('nonce_hash',sa.String(128),nullable=False),
        sa.Column('redirect_uri',sa.String(1000),nullable=False),
        sa.Column('expires_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('used_at',sa.DateTime(timezone=True)),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
        sa.UniqueConstraint('state_hash','provider',name='uq_oauth_state_provider_state'))
    op.create_index('ix_oauth_states_state_hash','oauth_states',['state_hash'])
    op.create_index('ix_oauth_states_nonce_hash','oauth_states',['nonce_hash'])
    op.create_index('ix_oauth_states_expires_at','oauth_states',['expires_at'])
    with op.batch_alter_table('domains') as b:
        b.add_column(sa.Column('verification_method',sa.String(20)))
        b.add_column(sa.Column('verified_hostname',sa.String(255)))
        b.add_column(sa.Column('verification_version',sa.Integer(),nullable=False,server_default='1'))

def downgrade():
    with op.batch_alter_table('domains') as b:
        b.drop_column('verification_version'); b.drop_column('verified_hostname'); b.drop_column('verification_method')
    op.drop_index('ix_oauth_states_expires_at',table_name='oauth_states')
    op.drop_index('ix_oauth_states_nonce_hash',table_name='oauth_states')
    op.drop_index('ix_oauth_states_state_hash',table_name='oauth_states')
    op.drop_table('oauth_states')
