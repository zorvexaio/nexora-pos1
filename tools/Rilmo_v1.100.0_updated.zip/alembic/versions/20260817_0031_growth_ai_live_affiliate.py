"""Add advanced commerce growth, AI, WhatsApp, live analytics, landing pages and affiliates."""
from alembic import op
import sqlalchemy as sa

revision = '20260817_0031'
down_revision = '20260817_0030'
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table('sessions') as batch:
        batch.add_column(sa.Column('impersonator_user_id', sa.String(36), sa.ForeignKey('users.id', name='fk_sessions_impersonator_user_id'), nullable=True))
        batch.add_column(sa.Column('read_only_impersonation', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    with op.batch_alter_table('marketing_preferences') as batch:
        batch.add_column(sa.Column('whatsapp_marketing', sa.Boolean(), nullable=False, server_default=sa.text('false')))

    op.create_table('live_storefront_events',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('storefront_id', sa.String(36), sa.ForeignKey('storefronts.id'), nullable=False),
        sa.Column('visitor_key_hash', sa.String(128), nullable=False),
        sa.Column('event_type', sa.String(60), nullable=False),
        sa.Column('path', sa.Text(), nullable=True),
        sa.Column('product_id', sa.String(36), sa.ForeignKey('products.id'), nullable=True),
        sa.Column('metadata', sa.JSON(), nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_live_storefront_events_tenant_created', 'live_storefront_events', ['tenant_id', 'created_at'])
    op.create_index('ix_live_storefront_events_visitor_created', 'live_storefront_events', ['visitor_key_hash', 'created_at'])

    op.create_table('ai_content_generations',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('user_id', sa.String(36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('product_id', sa.String(36), sa.ForeignKey('products.id'), nullable=True),
        sa.Column('kind', sa.String(40), nullable=False),
        sa.Column('locale', sa.String(20), nullable=False),
        sa.Column('provider', sa.String(40), nullable=False, server_default='local'),
        sa.Column('model', sa.String(120), nullable=True),
        sa.Column('prompt', sa.Text(), nullable=False),
        sa.Column('result', sa.JSON(), nullable=False, server_default='{}'),
        sa.Column('status', sa.String(24), nullable=False, server_default='COMPLETED'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_ai_content_generations_tenant_created', 'ai_content_generations', ['tenant_id', 'created_at'])

    op.create_table('whatsapp_channels',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('phone_number_id', sa.String(120), nullable=False),
        sa.Column('business_account_id', sa.String(120), nullable=True),
        sa.Column('access_token_encrypted', sa.Text(), nullable=False),
        sa.Column('app_secret_encrypted', sa.Text(), nullable=True),
        sa.Column('verify_token_hash', sa.String(128), nullable=False),
        sa.Column('api_version', sa.String(30), nullable=False, server_default='v23.0'),
        sa.Column('status', sa.String(24), nullable=False, server_default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id', name='uq_whatsapp_channel_tenant'))

    op.create_table('whatsapp_messages',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('channel_id', sa.String(36), sa.ForeignKey('whatsapp_channels.id'), nullable=False),
        sa.Column('direction', sa.String(12), nullable=False, server_default='OUTBOUND'),
        sa.Column('recipient', sa.String(40), nullable=False),
        sa.Column('message_type', sa.String(30), nullable=False, server_default='text'),
        sa.Column('body', sa.Text(), nullable=False),
        sa.Column('provider_message_id', sa.String(255), nullable=True),
        sa.Column('status', sa.String(24), nullable=False, server_default='QUEUED'),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('metadata', sa.JSON(), nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('sent_at', sa.DateTime(timezone=True), nullable=True))
    op.create_index('ix_whatsapp_messages_tenant_created', 'whatsapp_messages', ['tenant_id', 'created_at'])

    op.create_table('landing_pages',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('slug', sa.String(120), nullable=False),
        sa.Column('title', sa.String(200), nullable=False),
        sa.Column('status', sa.String(20), nullable=False, server_default='DRAFT'),
        sa.Column('locale', sa.String(20), nullable=False, server_default='ar'),
        sa.Column('seo_title', sa.String(255), nullable=True),
        sa.Column('seo_description', sa.Text(), nullable=True),
        sa.Column('content', sa.JSON(), nullable=False, server_default='{}'),
        sa.Column('published_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id', 'slug', name='uq_landing_page_tenant_slug'))

    op.create_table('affiliate_programs',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('name', sa.String(160), nullable=False, server_default='Affiliate Program'),
        sa.Column('status', sa.String(20), nullable=False, server_default='ACTIVE'),
        sa.Column('commission_bps', sa.Integer(), nullable=False, server_default='1000'),
        sa.Column('cookie_days', sa.Integer(), nullable=False, server_default='30'),
        sa.Column('min_payout_minor', sa.BigInteger(), nullable=False, server_default='5000'),
        sa.Column('currency', sa.String(3), nullable=False, server_default='USD'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id', name='uq_affiliate_program_tenant'))

    op.create_table('affiliate_partners',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('program_id', sa.String(36), sa.ForeignKey('affiliate_programs.id'), nullable=False),
        sa.Column('code', sa.String(80), nullable=False),
        sa.Column('name', sa.String(160), nullable=False),
        sa.Column('email', sa.String(320), nullable=False),
        sa.Column('status', sa.String(20), nullable=False, server_default='ACTIVE'),
        sa.Column('payout_minor', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id', 'code', name='uq_affiliate_partner_code'),
        sa.UniqueConstraint('tenant_id', 'email', name='uq_affiliate_partner_email'))

    op.create_table('affiliate_referrals',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('partner_id', sa.String(36), sa.ForeignKey('affiliate_partners.id'), nullable=False),
        sa.Column('visitor_key_hash', sa.String(128), nullable=False),
        sa.Column('order_id', sa.String(36), sa.ForeignKey('orders.id'), nullable=True, unique=True),
        sa.Column('status', sa.String(20), nullable=False, server_default='CLICKED'),
        sa.Column('landing_path', sa.Text(), nullable=True),
        sa.Column('revenue_minor', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('commission_minor', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('converted_at', sa.DateTime(timezone=True), nullable=True))
    op.create_index('ix_affiliate_referrals_tenant_visitor', 'affiliate_referrals', ['tenant_id', 'visitor_key_hash', 'created_at'])

    op.create_table('affiliate_commissions',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('partner_id', sa.String(36), sa.ForeignKey('affiliate_partners.id'), nullable=False),
        sa.Column('referral_id', sa.String(36), sa.ForeignKey('affiliate_referrals.id'), nullable=False),
        sa.Column('order_id', sa.String(36), sa.ForeignKey('orders.id'), nullable=False),
        sa.Column('amount_minor', sa.BigInteger(), nullable=False),
        sa.Column('currency', sa.String(3), nullable=False),
        sa.Column('status', sa.String(20), nullable=False, server_default='PENDING'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint('referral_id', name='uq_affiliate_commission_referral'))

    op.create_table('platform_monthly_reports',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('period_key', sa.String(7), nullable=False),
        sa.Column('generated_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('recipients', sa.JSON(), nullable=False, server_default='[]'),
        sa.Column('metrics', sa.JSON(), nullable=False, server_default='{}'),
        sa.Column('delivery_status', sa.String(20), nullable=False, server_default='NOT_SENT'),
        sa.UniqueConstraint('period_key', name='uq_platform_monthly_report_period'))

    op.create_table('impersonation_sessions',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('admin_user_id', sa.String(36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('target_user_id', sa.String(36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('tenant_id', sa.String(36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('session_id', sa.String(36), sa.ForeignKey('sessions.id'), nullable=True),
        sa.Column('reason', sa.String(500), nullable=False),
        sa.Column('read_only', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('ended_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False))
    op.create_index('ix_impersonation_sessions_admin_created', 'impersonation_sessions', ['admin_user_id', 'created_at'])


def downgrade():
    with op.batch_alter_table('marketing_preferences') as batch:
        batch.drop_column('whatsapp_marketing')
    with op.batch_alter_table('sessions') as batch:
        batch.drop_column('read_only_impersonation')
        batch.drop_column('impersonator_user_id')
    for name in ['impersonation_sessions', 'platform_monthly_reports', 'affiliate_commissions', 'affiliate_referrals', 'affiliate_partners', 'affiliate_programs', 'landing_pages', 'whatsapp_messages', 'whatsapp_channels', 'ai_content_generations', 'live_storefront_events']:
        op.drop_table(name)
