from alembic import op
import sqlalchemy as sa

revision = '20260819_0043'
down_revision = '20260819_0042'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('b2b_companies',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('external_code', sa.String(length=120), nullable=False),
        sa.Column('status', sa.String(length=24), nullable=False),
        sa.Column('currency', sa.String(length=3), nullable=False),
        sa.Column('payment_terms_days', sa.Integer(), nullable=False),
        sa.Column('credit_limit_minor', sa.BigInteger(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','external_code'))
    op.create_index('ix_b2b_companies_tenant_id','b2b_companies',['tenant_id'])
    op.create_table('b2b_company_contacts',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('company_id', sa.String(length=36), sa.ForeignKey('b2b_companies.id'), nullable=False),
        sa.Column('email', sa.String(length=320), nullable=False),
        sa.Column('name', sa.String(length=255)),
        sa.Column('role', sa.String(length=40), nullable=False),
        sa.Column('status', sa.String(length=24), nullable=False),
        sa.UniqueConstraint('tenant_id','company_id','email'))
    op.create_index('ix_b2b_company_contacts_tenant_id','b2b_company_contacts',['tenant_id'])
    op.create_index('ix_b2b_company_contacts_company_id','b2b_company_contacts',['company_id'])
    op.create_table('b2b_catalogs',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('code', sa.String(length=80), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('status', sa.String(length=24), nullable=False),
        sa.Column('currency', sa.String(length=3), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','code'))
    op.create_index('ix_b2b_catalogs_tenant_id','b2b_catalogs',['tenant_id'])
    op.create_table('b2b_catalog_assignments',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('company_id', sa.String(length=36), sa.ForeignKey('b2b_companies.id'), nullable=False),
        sa.Column('catalog_id', sa.String(length=36), sa.ForeignKey('b2b_catalogs.id'), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','company_id','catalog_id'))
    op.create_index('ix_b2b_catalog_assignments_tenant_id','b2b_catalog_assignments',['tenant_id'])
    op.create_index('ix_b2b_catalog_assignments_company_id','b2b_catalog_assignments',['company_id'])
    op.create_index('ix_b2b_catalog_assignments_catalog_id','b2b_catalog_assignments',['catalog_id'])
    op.create_table('b2b_catalog_items',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('catalog_id', sa.String(length=36), sa.ForeignKey('b2b_catalogs.id'), nullable=False),
        sa.Column('variant_id', sa.String(length=36), sa.ForeignKey('product_variants.id'), nullable=False),
        sa.Column('price_minor', sa.BigInteger()),
        sa.Column('min_quantity', sa.BigInteger(), nullable=False),
        sa.Column('max_quantity', sa.BigInteger()),
        sa.Column('discount_bps', sa.Integer(), nullable=False),
        sa.UniqueConstraint('tenant_id','catalog_id','variant_id'))
    op.create_index('ix_b2b_catalog_items_tenant_id','b2b_catalog_items',['tenant_id'])
    op.create_index('ix_b2b_catalog_items_catalog_id','b2b_catalog_items',['catalog_id'])
    op.create_index('ix_b2b_catalog_items_variant_id','b2b_catalog_items',['variant_id'])

    op.create_table('pos_locations',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('code', sa.String(length=80), nullable=False),
        sa.Column('name', sa.String(length=160), nullable=False),
        sa.Column('address', sa.JSON()),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('inventory_location_id', sa.String(length=36), sa.ForeignKey('inventory_locations.id')),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','code'))
    op.create_index('ix_pos_locations_tenant_id','pos_locations',['tenant_id'])
    op.create_table('pos_registers',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('location_id', sa.String(length=36), sa.ForeignKey('pos_locations.id'), nullable=False),
        sa.Column('register_code', sa.String(length=80), nullable=False),
        sa.Column('name', sa.String(length=160), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('device_public_key', sa.Text()),
        sa.UniqueConstraint('tenant_id','register_code'))
    op.create_index('ix_pos_registers_tenant_id','pos_registers',['tenant_id'])
    op.create_index('ix_pos_registers_location_id','pos_registers',['location_id'])
    op.create_table('pos_sessions',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('register_id', sa.String(length=36), sa.ForeignKey('pos_registers.id'), nullable=False),
        sa.Column('opened_by_user_id', sa.String(length=36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('opening_cash_minor', sa.BigInteger(), nullable=False),
        sa.Column('closing_cash_minor', sa.BigInteger()),
        sa.Column('expected_cash_minor', sa.BigInteger(), nullable=False),
        sa.Column('opened_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('closed_at', sa.DateTime(timezone=True)))
    op.create_index('ix_pos_sessions_tenant_id','pos_sessions',['tenant_id'])
    op.create_index('ix_pos_sessions_register_id','pos_sessions',['register_id'])
    op.create_index('ix_pos_sessions_tenant_status','pos_sessions',['tenant_id','status'])
    op.create_table('pos_order_links',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('order_id', sa.String(length=36), sa.ForeignKey('orders.id'), nullable=False),
        sa.Column('pos_session_id', sa.String(length=36), sa.ForeignKey('pos_sessions.id'), nullable=False),
        sa.Column('channel', sa.String(length=20), nullable=False),
        sa.UniqueConstraint('tenant_id','order_id'))
    op.create_index('ix_pos_order_links_tenant_id','pos_order_links',['tenant_id'])
    op.create_index('ix_pos_order_links_order_id','pos_order_links',['order_id'])
    op.create_index('ix_pos_order_links_pos_session_id','pos_order_links',['pos_session_id'])

    op.create_table('commerce_experiments',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('key', sa.String(length=100), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('traffic_bps', sa.Integer(), nullable=False),
        sa.Column('variants', sa.JSON(), nullable=False),
        sa.Column('target_metric', sa.String(length=80), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','key'))
    op.create_index('ix_commerce_experiments_tenant_id','commerce_experiments',['tenant_id'])
    op.create_table('commerce_experiment_assignments',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('experiment_id', sa.String(length=36), sa.ForeignKey('commerce_experiments.id'), nullable=False),
        sa.Column('subject_key', sa.String(length=160), nullable=False),
        sa.Column('variant_key', sa.String(length=100), nullable=False),
        sa.Column('assigned_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','experiment_id','subject_key'))
    op.create_index('ix_commerce_experiment_assignments_tenant_id','commerce_experiment_assignments',['tenant_id'])
    op.create_index('ix_commerce_experiment_assignments_experiment_id','commerce_experiment_assignments',['experiment_id'])

    op.create_table('product_feeds',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('channel', sa.String(length=40), nullable=False),
        sa.Column('locale', sa.String(length=20), nullable=False),
        sa.Column('country_code', sa.String(length=2), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('last_generated_at', sa.DateTime(timezone=True)),
        sa.Column('last_item_count', sa.Integer(), nullable=False),
        sa.Column('config', sa.JSON(), nullable=False),
        sa.UniqueConstraint('tenant_id','channel','locale','country_code'))
    op.create_index('ix_product_feeds_tenant_id','product_feeds',['tenant_id'])

    op.create_table('ucp_checkout_sessions',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('external_session_id', sa.String(length=160), nullable=False),
        sa.Column('status', sa.String(length=24), nullable=False),
        sa.Column('currency', sa.String(length=3), nullable=False),
        sa.Column('line_items', sa.JSON(), nullable=False),
        sa.Column('subtotal_minor', sa.BigInteger(), nullable=False),
        sa.Column('total_minor', sa.BigInteger(), nullable=False),
        sa.Column('buyer', sa.JSON()),
        sa.Column('metadata_json', sa.JSON(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','external_session_id'))
    op.create_index('ix_ucp_checkout_sessions_tenant_id','ucp_checkout_sessions',['tenant_id'])
    op.create_table('ucp_events',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('event_id', sa.String(length=160), nullable=False),
        sa.Column('event_type', sa.String(length=120), nullable=False),
        sa.Column('payload_hash', sa.String(length=128), nullable=False),
        sa.Column('payload', sa.JSON(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id','event_id'))
    op.create_index('ix_ucp_events_tenant_id','ucp_events',['tenant_id'])

def downgrade():
    for name, table in [
        ('ix_ucp_events_tenant_id','ucp_events'),('ucp_events',None),
        ('ix_ucp_checkout_sessions_tenant_id','ucp_checkout_sessions'),('ucp_checkout_sessions',None),
        ('ix_product_feeds_tenant_id','product_feeds'),('product_feeds',None),
        ('ix_commerce_experiment_assignments_experiment_id','commerce_experiment_assignments'),('ix_commerce_experiment_assignments_tenant_id','commerce_experiment_assignments'),('commerce_experiment_assignments',None),
        ('ix_commerce_experiments_tenant_id','commerce_experiments'),('commerce_experiments',None),
        ('ix_pos_order_links_pos_session_id','pos_order_links'),('ix_pos_order_links_order_id','pos_order_links'),('ix_pos_order_links_tenant_id','pos_order_links'),('pos_order_links',None),
        ('ix_pos_sessions_tenant_status','pos_sessions'),('ix_pos_sessions_register_id','pos_sessions'),('ix_pos_sessions_tenant_id','pos_sessions'),('pos_sessions',None),
        ('ix_pos_registers_location_id','pos_registers'),('ix_pos_registers_tenant_id','pos_registers'),('pos_registers',None),
        ('ix_pos_locations_tenant_id','pos_locations'),('pos_locations',None),
        ('ix_b2b_catalog_items_variant_id','b2b_catalog_items'),('ix_b2b_catalog_items_catalog_id','b2b_catalog_items'),('ix_b2b_catalog_items_tenant_id','b2b_catalog_items'),('b2b_catalog_items',None),
        ('ix_b2b_catalog_assignments_catalog_id','b2b_catalog_assignments'),('ix_b2b_catalog_assignments_company_id','b2b_catalog_assignments'),('ix_b2b_catalog_assignments_tenant_id','b2b_catalog_assignments'),('b2b_catalog_assignments',None),
        ('ix_b2b_catalogs_tenant_id','b2b_catalogs'),('b2b_catalogs',None),
        ('ix_b2b_company_contacts_company_id','b2b_company_contacts'),('ix_b2b_company_contacts_tenant_id','b2b_company_contacts'),('b2b_company_contacts',None),
        ('ix_b2b_companies_tenant_id','b2b_companies'),('b2b_companies',None)]:
        if table is None: op.drop_table(name)
        else: op.drop_index(name, table_name=table)
