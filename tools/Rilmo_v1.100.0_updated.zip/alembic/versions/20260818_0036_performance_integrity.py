"""v1.36 performance/integrity indexes.

Revision ID: 20260818_0036
Revises: 20260818_0035
"""
from alembic import op

revision = '20260818_0036'
down_revision = '20260818_0035'
branch_labels = None
depends_on = None


def upgrade():
    op.create_index('ix_sessions_user_revoked_last_seen', 'sessions', ['user_id', 'revoked_at', 'last_seen_at'])
    op.create_index('ix_customer_login_codes_tenant_email_used_created', 'customer_login_codes', ['tenant_id', 'email', 'used_at', 'created_at'])
    op.create_index('ix_password_reset_tokens_user_used_expires', 'password_reset_tokens', ['user_id', 'used_at', 'expires_at'])


def downgrade():
    op.drop_index('ix_password_reset_tokens_user_used_expires', table_name='password_reset_tokens')
    op.drop_index('ix_customer_login_codes_tenant_email_used_created', table_name='customer_login_codes')
    op.drop_index('ix_sessions_user_revoked_last_seen', table_name='sessions')
