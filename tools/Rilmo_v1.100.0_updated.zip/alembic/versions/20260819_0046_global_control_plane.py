from alembic import op
import sqlalchemy as sa
revision='20260819_0046'
down_revision='20260819_0045'
branch_labels=None
depends_on=None

TENANT_TABLES=['agent_profiles','agent_action_audits','tenant_region_policies','financial_reconciliation_runs','financial_reconciliation_mismatches']

def upgrade():
    op.create_table('agent_profiles',
        sa.Column('id',sa.String(36),primary_key=True), sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('client_id',sa.String(160),nullable=False), sa.Column('slug',sa.String(100),nullable=False), sa.Column('name',sa.String(160),nullable=False),
        sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'), sa.Column('scopes',sa.JSON(),nullable=False), sa.Column('allowed_countries',sa.JSON(),nullable=False),
        sa.Column('require_confirmation',sa.Boolean(),nullable=False,server_default=sa.false()), sa.Column('rate_limit_per_minute',sa.Integer(),nullable=False,server_default='120'),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False), sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False),
        sa.UniqueConstraint('tenant_id','client_id'), sa.UniqueConstraint('tenant_id','slug'))
    op.create_index('ix_agent_profiles_tenant_id','agent_profiles',['tenant_id'])
    op.create_table('agent_action_audits',
        sa.Column('id',sa.String(36),primary_key=True), sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('agent_profile_id',sa.String(36),sa.ForeignKey('agent_profiles.id'),nullable=False), sa.Column('action',sa.String(120),nullable=False),
        sa.Column('resource_type',sa.String(80),nullable=False), sa.Column('resource_id',sa.String(36)), sa.Column('decision',sa.String(20),nullable=False),
        sa.Column('reason',sa.String(255),nullable=False), sa.Column('idempotency_key',sa.String(200),nullable=False), sa.Column('request_hash',sa.String(128),nullable=False),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False), sa.UniqueConstraint('tenant_id','agent_profile_id','idempotency_key'))
    op.create_index('ix_agent_action_audits_tenant_id','agent_action_audits',['tenant_id'])
    op.create_index('ix_agent_action_audits_agent_profile_id','agent_action_audits',['agent_profile_id'])
    op.create_index('ix_agent_action_audits_tenant_created','agent_action_audits',['tenant_id','created_at'])
    op.create_table('tenant_region_policies',
        sa.Column('id',sa.String(36),primary_key=True), sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('home_region',sa.String(40),nullable=False,server_default='eu-west-1'), sa.Column('allowed_regions',sa.JSON(),nullable=False),
        sa.Column('residency_mode',sa.String(32),nullable=False,server_default='HOME_REGION_ONLY'), sa.Column('cross_border_transfer_allowed',sa.Boolean(),nullable=False,server_default=sa.false()),
        sa.Column('transfer_basis',sa.String(80)), sa.Column('approved_at',sa.DateTime(timezone=True)), sa.Column('approved_by',sa.String(36)),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False), sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False), sa.UniqueConstraint('tenant_id'))
    op.create_index('ix_tenant_region_policies_tenant_id','tenant_region_policies',['tenant_id'])
    op.create_table('financial_reconciliation_runs',
        sa.Column('id',sa.String(36),primary_key=True), sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('period_start',sa.DateTime(timezone=True),nullable=False), sa.Column('period_end',sa.DateTime(timezone=True),nullable=False), sa.Column('currency',sa.String(3),nullable=False),
        sa.Column('status',sa.String(20),nullable=False,server_default='RUNNING'), sa.Column('payment_captured_minor',sa.BigInteger(),nullable=False,server_default='0'),
        sa.Column('ledger_debit_minor',sa.BigInteger(),nullable=False,server_default='0'), sa.Column('ledger_credit_minor',sa.BigInteger(),nullable=False,server_default='0'),
        sa.Column('delta_minor',sa.BigInteger(),nullable=False,server_default='0'), sa.Column('mismatch_count',sa.Integer(),nullable=False,server_default='0'), sa.Column('details',sa.JSON(),nullable=False),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False), sa.Column('completed_at',sa.DateTime(timezone=True)),
        sa.UniqueConstraint('tenant_id','period_start','period_end','currency'))
    op.create_index('ix_financial_reconciliation_runs_tenant_id','financial_reconciliation_runs',['tenant_id'])
    op.create_index('ix_fin_recon_tenant_status','financial_reconciliation_runs',['tenant_id','status'])
    op.create_table('financial_reconciliation_mismatches',
        sa.Column('id',sa.String(36),primary_key=True), sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('reconciliation_run_id',sa.String(36),sa.ForeignKey('financial_reconciliation_runs.id'),nullable=False), sa.Column('category',sa.String(80),nullable=False),
        sa.Column('reference_type',sa.String(80),nullable=False), sa.Column('reference_id',sa.String(36),nullable=False), sa.Column('expected_minor',sa.BigInteger(),nullable=False,server_default='0'),
        sa.Column('observed_minor',sa.BigInteger(),nullable=False,server_default='0'), sa.Column('delta_minor',sa.BigInteger(),nullable=False,server_default='0'), sa.Column('currency',sa.String(3),nullable=False),
        sa.Column('details',sa.JSON(),nullable=False), sa.Column('created_at',sa.DateTime(timezone=True),nullable=False))
    op.create_index('ix_financial_reconciliation_mismatches_tenant_id','financial_reconciliation_mismatches',['tenant_id'])
    op.create_index('ix_fin_recon_mismatch_run','financial_reconciliation_mismatches',['reconciliation_run_id'])
    conn=op.get_bind()
    if conn.dialect.name=='postgresql':
        for table in TENANT_TABLES:
            op.execute(sa.text(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY'))
            op.execute(sa.text(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY'))
            op.execute(sa.text(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id = current_setting('app.current_tenant', true))"))

def downgrade():
    conn=op.get_bind()
    if conn.dialect.name=='postgresql':
        for table in reversed(TENANT_TABLES):
            op.execute(sa.text(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}'))
            op.execute(sa.text(f'ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY'))
            op.execute(sa.text(f'ALTER TABLE {table} DISABLE ROW LEVEL SECURITY'))
    for table in reversed(TENANT_TABLES):
        op.drop_table(table)
