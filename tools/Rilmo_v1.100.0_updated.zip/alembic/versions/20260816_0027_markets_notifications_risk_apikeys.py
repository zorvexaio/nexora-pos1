from alembic import op
import sqlalchemy as sa
revision="20260816_0027"
down_revision="20260816_0026"
branch_labels=None
depends_on=None

def _rls(table):
    b=op.get_bind()
    if b.dialect.name=="postgresql":
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")

def upgrade():
    op.create_table("markets", sa.Column("id",sa.String(36),primary_key=True),sa.Column("tenant_id",sa.String(36),sa.ForeignKey("tenants.id"),nullable=False),sa.Column("code",sa.String(32),nullable=False),sa.Column("name",sa.String(120),nullable=False),sa.Column("country_code",sa.String(2),nullable=False),sa.Column("currency",sa.String(3),nullable=False),sa.Column("locale",sa.String(16),nullable=False,server_default="en"),sa.Column("status",sa.String(20),nullable=False,server_default="ACTIVE"),sa.Column("is_default",sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column("created_at",sa.DateTime(timezone=True)),sa.Column("updated_at",sa.DateTime(timezone=True)),sa.UniqueConstraint("tenant_id","code",name="uq_market_tenant_code"))
    op.create_index("ix_markets_tenant","markets",["tenant_id"])
    op.create_table("notification_templates",sa.Column("id",sa.String(36),primary_key=True),sa.Column("tenant_id",sa.String(36),sa.ForeignKey("tenants.id"),nullable=False),sa.Column("code",sa.String(100),nullable=False),sa.Column("channel",sa.String(20),nullable=False),sa.Column("locale",sa.String(16),nullable=False),sa.Column("subject",sa.String(255),nullable=False,server_default=""),sa.Column("body",sa.Text(),nullable=False),sa.Column("active",sa.Boolean(),nullable=False,server_default=sa.true()),sa.Column("version",sa.Integer(),nullable=False,server_default="1"),sa.Column("created_at",sa.DateTime(timezone=True)),sa.Column("updated_at",sa.DateTime(timezone=True)),sa.UniqueConstraint("tenant_id","code","channel","locale",name="uq_notification_template"))
    op.create_index("ix_notification_templates_tenant","notification_templates",["tenant_id"])
    op.create_table("notification_deliveries",sa.Column("id",sa.String(36),primary_key=True),sa.Column("tenant_id",sa.String(36),sa.ForeignKey("tenants.id"),nullable=False),sa.Column("template_id",sa.String(36),sa.ForeignKey("notification_templates.id")),sa.Column("channel",sa.String(20),nullable=False),sa.Column("recipient",sa.String(320),nullable=False),sa.Column("status",sa.String(20),nullable=False,server_default="QUEUED"),sa.Column("idempotency_key",sa.String(200),nullable=False),sa.Column("payload",sa.JSON(),nullable=False),sa.Column("provider_message_id",sa.String(255)),sa.Column("scheduled_at",sa.DateTime(timezone=True)),sa.Column("sent_at",sa.DateTime(timezone=True)),sa.Column("error_message",sa.Text()),sa.Column("created_at",sa.DateTime(timezone=True)),sa.UniqueConstraint("tenant_id","idempotency_key",name="uq_notification_delivery_idem"))
    op.create_index("ix_notification_deliveries_tenant","notification_deliveries",["tenant_id"])
    op.create_table("risk_assessments",sa.Column("id",sa.String(36),primary_key=True),sa.Column("tenant_id",sa.String(36),sa.ForeignKey("tenants.id"),nullable=False),sa.Column("order_id",sa.String(36),sa.ForeignKey("orders.id"),nullable=False),sa.Column("score",sa.Integer(),nullable=False),sa.Column("decision",sa.String(20),nullable=False),sa.Column("reasons",sa.JSON(),nullable=False),sa.Column("engine_version",sa.String(40),nullable=False,server_default="rules-v1"),sa.Column("created_at",sa.DateTime(timezone=True)),sa.UniqueConstraint("tenant_id","order_id",name="uq_risk_order"))
    op.create_index("ix_risk_assessments_tenant","risk_assessments",["tenant_id"])
    op.create_table("api_keys",sa.Column("id",sa.String(36),primary_key=True),sa.Column("tenant_id",sa.String(36),sa.ForeignKey("tenants.id"),nullable=False),sa.Column("name",sa.String(100),nullable=False),sa.Column("key_prefix",sa.String(16),nullable=False),sa.Column("key_hash",sa.String(128),nullable=False,unique=True),sa.Column("scopes",sa.JSON(),nullable=False),sa.Column("expires_at",sa.DateTime(timezone=True)),sa.Column("revoked_at",sa.DateTime(timezone=True)),sa.Column("last_used_at",sa.DateTime(timezone=True)),sa.Column("created_at",sa.DateTime(timezone=True)),sa.UniqueConstraint("tenant_id","name",name="uq_api_key_tenant_name"))
    op.create_index("ix_api_keys_tenant","api_keys",["tenant_id"])
    for t in ["markets","notification_templates","notification_deliveries","risk_assessments","api_keys"]: _rls(t)

def downgrade():
    b=op.get_bind()
    tables=["api_keys","risk_assessments","notification_deliveries","notification_templates","markets"]
    if b.dialect.name=="postgresql":
        for t in tables:
            op.execute(f"DROP POLICY IF EXISTS {t}_tenant_isolation ON {t}")
            op.execute(f"ALTER TABLE {t} DISABLE ROW LEVEL SECURITY")
    for t in tables: op.drop_table(t)
