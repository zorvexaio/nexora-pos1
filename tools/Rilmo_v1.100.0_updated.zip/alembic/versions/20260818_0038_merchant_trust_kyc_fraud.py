"""merchant trust KYC risk and review controls

Revision ID: 20260818_0038".
Revises: 20260818_0037_webhook_delivery_isolation
"""
from alembic import op
import sqlalchemy as sa

revision = '20260818_0038'
down_revision = '20260818_0037'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('merchant_profiles', sa.Column('kyc_provider', sa.String(length=40), nullable=True))
    op.add_column('merchant_profiles', sa.Column('kyc_status', sa.String(length=32), nullable=False, server_default='NOT_STARTED'))
    op.add_column('merchant_profiles', sa.Column('kyc_verified_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('merchant_profiles', sa.Column('kyc_external_id', sa.String(length=255), nullable=True))
    op.add_column('merchant_profiles', sa.Column('risk_level', sa.String(length=24), nullable=False, server_default='UNKNOWN'))
    op.add_column('merchant_profiles', sa.Column('risk_score', sa.Integer(), nullable=False, server_default='0'))
    op.add_column('merchant_profiles', sa.Column('review_required', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('merchant_profiles', sa.Column('payout_hold', sa.Boolean(), nullable=False, server_default=sa.text('true')))
    op.add_column('merchant_profiles', sa.Column('trust_lock_reason', sa.String(length=255), nullable=True))

    op.create_table(
        'merchant_identity_verifications',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('user_id', sa.String(length=36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('provider', sa.String(length=40), nullable=False),
        sa.Column('external_id', sa.String(length=255), nullable=False),
        sa.Column('status', sa.String(length=32), nullable=False, server_default='CREATED'),
        sa.Column('decision', sa.String(length=32), nullable=True),
        sa.Column('risk_level', sa.String(length=24), nullable=True),
        sa.Column('country_code', sa.String(length=2), nullable=True),
        sa.Column('verification_url', sa.String(length=2000), nullable=True),
        sa.Column('vendor_data_hash', sa.String(length=128), nullable=True),
        sa.Column('provider_event_id', sa.String(length=255), nullable=True),
        sa.Column('provider_metadata', sa.JSON(), nullable=True),
        sa.Column('failure_code', sa.String(length=120), nullable=True),
        sa.Column('failure_reason', sa.Text(), nullable=True),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('tenant_id', 'provider', 'external_id', name='uq_merchant_identity_provider_external'),
    )
    op.create_index('ix_merchant_identity_tenant_status', 'merchant_identity_verifications', ['tenant_id','status'])

    op.create_table(
        'merchant_risk_events',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('event_type', sa.String(length=80), nullable=False),
        sa.Column('severity', sa.String(length=16), nullable=False, server_default='INFO'),
        sa.Column('score_delta', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('source', sa.String(length=40), nullable=False, server_default='system'),
        sa.Column('dedupe_key', sa.String(length=255), nullable=True),
        sa.Column('metadata_json', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('dedupe_key', name='uq_merchant_risk_events_dedupe_key'),
    )
    op.create_index('ix_merchant_risk_events_tenant_created', 'merchant_risk_events', ['tenant_id','created_at'])

    op.create_table(
        'merchant_review_cases',
        sa.Column('id', sa.String(length=36), primary_key=True),
        sa.Column('tenant_id', sa.String(length=36), sa.ForeignKey('tenants.id'), nullable=False),
        sa.Column('verification_id', sa.String(length=36), sa.ForeignKey('merchant_identity_verifications.id'), nullable=True),
        sa.Column('open_reason', sa.String(length=100), nullable=False),
        sa.Column('status', sa.String(length=24), nullable=False, server_default='OPEN'),
        sa.Column('priority', sa.String(length=16), nullable=False, server_default='NORMAL'),
        sa.Column('assigned_user_id', sa.String(length=36), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('reviewer_note', sa.Text(), nullable=True),
        sa.Column('resolution', sa.String(length=40), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('resolved_at', sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint('tenant_id', 'open_reason', name='uq_merchant_review_open_reason'),
    )


def downgrade():
    op.drop_table('merchant_review_cases')
    op.drop_index('ix_merchant_risk_events_tenant_created', table_name='merchant_risk_events')
    op.drop_table('merchant_risk_events')
    op.drop_index('ix_merchant_identity_tenant_status', table_name='merchant_identity_verifications')
    op.drop_table('merchant_identity_verifications')
    for col in ['trust_lock_reason','payout_hold','review_required','risk_score','risk_level','kyc_external_id','kyc_verified_at','kyc_status','kyc_provider']:
        op.drop_column('merchant_profiles', col)
