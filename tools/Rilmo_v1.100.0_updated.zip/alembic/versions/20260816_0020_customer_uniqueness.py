"""Enforce tenant-scoped customer email uniqueness."""
from alembic import op

revision = "20260816_0020"
down_revision = "20260816_0019"
branch_labels = None
depends_on = None

def upgrade():
    # Batch mode keeps the migration executable on SQLite test environments while
    # emitting a normal ALTER TABLE/constraint path on PostgreSQL.
    with op.batch_alter_table("customers", recreate="auto") as batch:
        batch.create_unique_constraint("uq_customer_tenant_email", ["tenant_id", "email"])

def downgrade():
    with op.batch_alter_table("customers", recreate="auto") as batch:
        batch.drop_constraint("uq_customer_tenant_email", type_="unique")
