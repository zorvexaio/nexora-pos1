"""privacy control plane: DSRs, consent events, jurisdiction routing"""
from alembic import op
import sqlalchemy as sa

revision='20260818_0039'
down_revision='20260818_0038'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('privacy_requests',
        sa.Column('id',sa.String(length=36),primary_key=True),
        sa.Column('tenant_id',sa.String(length=36),sa.ForeignKey('tenants.id'),nullable=True),
        sa.Column('user_id',sa.String(length=36),sa.ForeignKey('users.id'),nullable=True),
        sa.Column('customer_id',sa.String(length=36),sa.ForeignKey('customers.id'),nullable=True),
        sa.Column('request_type',sa.String(length=32),nullable=False),
        sa.Column('status',sa.String(length=24),nullable=False,server_default='SUBMITTED'),
        sa.Column('jurisdiction',sa.String(length=40),nullable=True),
        sa.Column('identity_verification',sa.String(length=24),nullable=False,server_default='ACCOUNT_AUTHENTICATED'),
        sa.Column('requested_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('due_at',sa.DateTime(timezone=True),nullable=True),
        sa.Column('resolved_at',sa.DateTime(timezone=True),nullable=True),
        sa.Column('data_export_ready_at',sa.DateTime(timezone=True),nullable=True),
        sa.Column('resolution_note',sa.Text(),nullable=True),
        sa.Column('metadata_json',sa.JSON(),nullable=True),
    )
    op.create_index('ix_privacy_requests_user_status','privacy_requests',['user_id','status'])
    op.create_index('ix_privacy_requests_tenant_status','privacy_requests',['tenant_id','status'])
    op.create_table('privacy_consent_events',
        sa.Column('id',sa.String(length=36),primary_key=True),
        sa.Column('tenant_id',sa.String(length=36),sa.ForeignKey('tenants.id'),nullable=True),
        sa.Column('user_id',sa.String(length=36),sa.ForeignKey('users.id'),nullable=True),
        sa.Column('customer_id',sa.String(length=36),sa.ForeignKey('customers.id'),nullable=True),
        sa.Column('subject_type',sa.String(length=24),nullable=False,server_default='USER'),
        sa.Column('subject_id',sa.String(length=120),nullable=False),
        sa.Column('jurisdiction',sa.String(length=40),nullable=True),
        sa.Column('policy_version',sa.String(length=50),nullable=False),
        sa.Column('action',sa.String(length=16),nullable=False),
        sa.Column('categories',sa.JSON(),nullable=False),
        sa.Column('lawful_basis',sa.JSON(),nullable=True),
        sa.Column('source',sa.String(length=40),nullable=False,server_default='privacy_center'),
        sa.Column('ip_hash',sa.String(length=128),nullable=True),
        sa.Column('user_agent_hash',sa.String(length=128),nullable=True),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
    )
    op.create_index('ix_privacy_consent_subject_created','privacy_consent_events',['subject_type','subject_id','created_at'])

def downgrade():
    op.drop_index('ix_privacy_consent_subject_created',table_name='privacy_consent_events')
    op.drop_table('privacy_consent_events')
    op.drop_index('ix_privacy_requests_tenant_status',table_name='privacy_requests')
    op.drop_index('ix_privacy_requests_user_status',table_name='privacy_requests')
    op.drop_table('privacy_requests')
