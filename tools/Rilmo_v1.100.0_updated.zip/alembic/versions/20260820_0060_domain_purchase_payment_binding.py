from alembic import op
import sqlalchemy as sa

revision = "20260820_0060"
down_revision = "20260820_0059"
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table("payment_intents", recreate="always") as batch:
        batch.add_column(sa.Column("domain_purchase_id", sa.String(length=36), nullable=True))
        batch.create_index("ix_payment_intents_domain_purchase_id", ["domain_purchase_id"], unique=False)
        batch.create_foreign_key("fk_payment_intents_domain_purchase_id", "domain_purchases", ["domain_purchase_id"], ["id"])

def downgrade():
    with op.batch_alter_table("payment_intents", recreate="always") as batch:
        batch.drop_constraint("fk_payment_intents_domain_purchase_id", type_="foreignkey")
        batch.drop_index("ix_payment_intents_domain_purchase_id")
        batch.drop_column("domain_purchase_id")
