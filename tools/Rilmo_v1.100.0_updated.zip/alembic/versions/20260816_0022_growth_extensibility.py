"""Theme engine, loyalty, marketing preferences and app extensibility foundation."""
from alembic import op
import sqlalchemy as sa
revision='20260816_0022'
down_revision='20260816_0021'
branch_labels=None
depends_on=None

def tenant_table(name, cols, uniques=()):
    op.create_table(name, *cols, *[sa.UniqueConstraint(*u, name=f"uq_{name}_{'_'.join(u)}") for u in uniques])
    op.create_index(f'ix_{name}_tenant_id', name, ['tenant_id'])

def upgrade():
    tenant_table('themes', [sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('slug',sa.String(100),nullable=False),sa.Column('name',sa.String(160),nullable=False),sa.Column('version',sa.String(30),nullable=False,server_default='1.0.0'),sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'),sa.Column('template_key',sa.String(80),nullable=False,server_default='catalog'),sa.Column('settings',sa.JSON(),nullable=False),sa.Column('created_at',sa.DateTime(timezone=True))],[('tenant_id','slug')])
    op.create_table('theme_assignments',sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('theme_id',sa.String(36),sa.ForeignKey('themes.id'),nullable=False),sa.Column('published_at',sa.DateTime(timezone=True)),sa.UniqueConstraint('tenant_id',name='uq_theme_assignment_tenant'))
    op.create_index('ix_theme_assignments_tenant_id','theme_assignments',['tenant_id'])
    tenant_table('loyalty_accounts',[sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('customer_id',sa.String(36),sa.ForeignKey('customers.id'),nullable=False),sa.Column('points_balance',sa.BigInteger(),nullable=False,server_default='0'),sa.Column('lifetime_earned',sa.BigInteger(),nullable=False,server_default='0'),sa.Column('lifetime_redeemed',sa.BigInteger(),nullable=False,server_default='0'),sa.Column('created_at',sa.DateTime(timezone=True))],[('tenant_id','customer_id')])
    tenant_table('loyalty_transactions',[sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('loyalty_account_id',sa.String(36),sa.ForeignKey('loyalty_accounts.id'),nullable=False),sa.Column('order_id',sa.String(36),sa.ForeignKey('orders.id')),sa.Column('points_delta',sa.BigInteger(),nullable=False),sa.Column('reason',sa.String(120),nullable=False),sa.Column('idempotency_key',sa.String(200),nullable=False),sa.Column('created_at',sa.DateTime(timezone=True))],[('tenant_id','idempotency_key')])
    tenant_table('abandoned_cart_campaigns',[sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('cart_id',sa.String(36),sa.ForeignKey('carts.id'),nullable=False),sa.Column('status',sa.String(30),nullable=False,server_default='PENDING'),sa.Column('scheduled_at',sa.DateTime(timezone=True),nullable=False),sa.Column('sent_at',sa.DateTime(timezone=True)),sa.Column('attempt_count',sa.Integer(),nullable=False,server_default='0'),sa.Column('last_error',sa.Text())],[('tenant_id','cart_id')])
    tenant_table('marketing_preferences',[sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('customer_id',sa.String(36),sa.ForeignKey('customers.id'),nullable=False),sa.Column('email_marketing',sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column('sms_marketing',sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column('updated_at',sa.DateTime(timezone=True))],[('tenant_id','customer_id')])
    op.create_table('app_definitions',sa.Column('id',sa.String(36),primary_key=True),sa.Column('name',sa.String(160),nullable=False),sa.Column('slug',sa.String(100),nullable=False),sa.Column('client_id',sa.String(160),nullable=False),sa.Column('client_secret_hash',sa.String(128),nullable=False),sa.Column('redirect_uris',sa.JSON(),nullable=False),sa.Column('scopes',sa.JSON(),nullable=False),sa.Column('status',sa.String(20),nullable=False,server_default='PENDING_REVIEW'),sa.Column('publisher_name',sa.String(160)),sa.Column('created_at',sa.DateTime(timezone=True)),sa.UniqueConstraint('client_id'),sa.UniqueConstraint('slug'))
    op.create_table('app_installations',sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('app_id',sa.String(36),sa.ForeignKey('app_definitions.id'),nullable=False),sa.Column('granted_scopes',sa.JSON(),nullable=False),sa.Column('access_token_hash',sa.String(128),nullable=False),sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'),sa.Column('installed_at',sa.DateTime(timezone=True)),sa.Column('revoked_at',sa.DateTime(timezone=True)),sa.UniqueConstraint('tenant_id','app_id'),sa.UniqueConstraint('access_token_hash'))
    op.create_index('ix_app_installations_tenant_id','app_installations',['tenant_id'])
    op.create_table('app_webhook_subscriptions',sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('installation_id',sa.String(36),sa.ForeignKey('app_installations.id'),nullable=False),sa.Column('event_type',sa.String(120),nullable=False),sa.Column('endpoint_url',sa.Text(),nullable=False),sa.Column('secret_hash',sa.String(128),nullable=False),sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'),sa.Column('created_at',sa.DateTime(timezone=True)),sa.UniqueConstraint('installation_id','event_type','endpoint_url'))
    op.create_index('ix_app_webhook_subscriptions_tenant_id','app_webhook_subscriptions',['tenant_id'])
    if op.get_bind().dialect.name=='postgresql':
        for table in ['themes','theme_assignments','loyalty_accounts','loyalty_transactions','abandoned_cart_campaigns','marketing_preferences','app_installations','app_webhook_subscriptions']:
            op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY'); op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
            op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}')
            op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true))")

def downgrade():
    if op.get_bind().dialect.name=='postgresql':
        for table in ['app_webhook_subscriptions','app_installations','marketing_preferences','abandoned_cart_campaigns','loyalty_transactions','loyalty_accounts','theme_assignments','themes']:
            op.execute(f'DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}'); op.execute(f'ALTER TABLE {table} DISABLE ROW LEVEL SECURITY')
    for table in ['app_webhook_subscriptions','app_installations','app_definitions','marketing_preferences','abandoned_cart_campaigns','loyalty_transactions','loyalty_accounts','theme_assignments','themes']:
        op.drop_table(table)
