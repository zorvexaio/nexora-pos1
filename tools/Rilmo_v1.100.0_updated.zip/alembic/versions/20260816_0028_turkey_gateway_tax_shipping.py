"""Turkey payment gateways, KDV profiles, e-invoice records and carrier configs."""
from alembic import op
import sqlalchemy as sa

revision='20260816_0028'
down_revision='20260816_0027'
branch_labels=None
depends_on=None
TENANT_TABLES=['turkey_tax_profiles','turkey_einvoices','turkey_einvoice_submissions','turkey_carrier_configs']

def _rls(t):
    bind=op.get_bind()
    if bind.dialect.name != 'postgresql':
        return
    op.execute(f'ALTER TABLE {t} ENABLE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE {t} FORCE ROW LEVEL SECURITY')
    op.execute(f'''CREATE POLICY {t}_tenant_isolation ON {t} USING (tenant_id = current_setting('app.current_tenant', true)) WITH CHECK (tenant_id = current_setting('app.current_tenant', true))''')

def upgrade():
    op.add_column('merchant_payment_accounts', sa.Column('credentials_encrypted', sa.Text(), nullable=True))
    op.create_table('turkey_tax_profiles',
        sa.Column('id',sa.String(36),primary_key=True), sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('code',sa.String(50),nullable=False), sa.Column('name',sa.String(120),nullable=False), sa.Column('kdv_bps',sa.Integer(),nullable=False),
        sa.Column('inclusive',sa.Boolean(),nullable=False,server_default=sa.false()), sa.Column('active',sa.Boolean(),nullable=False,server_default=sa.true()),
        sa.Column('created_at',sa.DateTime(timezone=True)),sa.Column('updated_at',sa.DateTime(timezone=True)), sa.UniqueConstraint('tenant_id','code'))
    op.create_index('ix_turkey_tax_profiles_tenant','turkey_tax_profiles',['tenant_id'])
    op.create_table('turkey_einvoices',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('order_id',sa.String(36),sa.ForeignKey('orders.id'),nullable=False),
        sa.Column('invoice_number',sa.String(80),nullable=False),sa.Column('invoice_type',sa.String(30),nullable=False,server_default='E_ARCHIVE'),sa.Column('status',sa.String(30),nullable=False,server_default='DRAFT'),
        sa.Column('currency',sa.String(3),nullable=False),sa.Column('subtotal_minor',sa.BigInteger(),nullable=False),sa.Column('kdv_minor',sa.BigInteger(),nullable=False),sa.Column('total_minor',sa.BigInteger(),nullable=False),
        sa.Column('xml_sha256',sa.String(64)),sa.Column('xml_content',sa.Text()),sa.Column('provider_reference',sa.String(255)),sa.Column('reported_at',sa.DateTime(timezone=True)),sa.Column('created_at',sa.DateTime(timezone=True)),
        sa.UniqueConstraint('tenant_id','invoice_number'),sa.UniqueConstraint('tenant_id','order_id'))
    op.create_index('ix_turkey_einvoices_tenant','turkey_einvoices',['tenant_id'])
    op.create_table('turkey_einvoice_submissions',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('invoice_id',sa.String(36),sa.ForeignKey('turkey_einvoices.id'),nullable=False),
        sa.Column('provider',sa.String(40),nullable=False),sa.Column('idempotency_key',sa.String(200),nullable=False),sa.Column('status',sa.String(30),nullable=False,server_default='PENDING'),sa.Column('response',sa.JSON()),sa.Column('created_at',sa.DateTime(timezone=True)),
        sa.UniqueConstraint('tenant_id','idempotency_key'))
    op.create_index('ix_turkey_einvoice_submissions_tenant','turkey_einvoice_submissions',['tenant_id'])
    op.create_table('turkey_carrier_configs',
        sa.Column('id',sa.String(36),primary_key=True),sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),sa.Column('carrier_code',sa.String(40),nullable=False),
        sa.Column('api_base_url',sa.Text()),sa.Column('api_token_encrypted',sa.Text()),sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'),sa.Column('metadata_json',sa.JSON()),
        sa.UniqueConstraint('tenant_id','carrier_code'))
    op.create_index('ix_turkey_carrier_configs_tenant','turkey_carrier_configs',['tenant_id'])
    for t in TENANT_TABLES: _rls(t)

def downgrade():
    bind=op.get_bind()
    for t in reversed(TENANT_TABLES):
        if bind.dialect.name == 'postgresql':
            op.execute(f'DROP POLICY IF EXISTS {t}_tenant_isolation ON {t}')
            op.execute(f'ALTER TABLE {t} DISABLE ROW LEVEL SECURITY')
    op.drop_index('ix_turkey_carrier_configs_tenant',table_name='turkey_carrier_configs'); op.drop_table('turkey_carrier_configs')
    op.drop_index('ix_turkey_einvoice_submissions_tenant',table_name='turkey_einvoice_submissions'); op.drop_table('turkey_einvoice_submissions')
    op.drop_index('ix_turkey_einvoices_tenant',table_name='turkey_einvoices'); op.drop_table('turkey_einvoices')
    op.drop_index('ix_turkey_tax_profiles_tenant',table_name='turkey_tax_profiles'); op.drop_table('turkey_tax_profiles')
    op.drop_column('merchant_payment_accounts','credentials_encrypted')
