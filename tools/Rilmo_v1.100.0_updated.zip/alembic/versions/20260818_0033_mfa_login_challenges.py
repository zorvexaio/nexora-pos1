"""Require MFA verification before issuing authenticated sessions."""
from alembic import op
import sqlalchemy as sa

revision = '20260818_0033'
down_revision = '20260817_0032'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'mfa_login_challenges',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('user_id', sa.String(36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('token_hash', sa.String(128), nullable=False, unique=True),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('used_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_mfa_login_challenges_user_id', 'mfa_login_challenges', ['user_id'])
    op.create_index('ix_mfa_login_challenges_token_hash', 'mfa_login_challenges', ['token_hash'])
    op.create_index('ix_mfa_login_challenges_expires_at', 'mfa_login_challenges', ['expires_at'])


def downgrade():
    op.drop_index('ix_mfa_login_challenges_expires_at', table_name='mfa_login_challenges')
    op.drop_index('ix_mfa_login_challenges_token_hash', table_name='mfa_login_challenges')
    op.drop_index('ix_mfa_login_challenges_user_id', table_name='mfa_login_challenges')
    op.drop_table('mfa_login_challenges')
