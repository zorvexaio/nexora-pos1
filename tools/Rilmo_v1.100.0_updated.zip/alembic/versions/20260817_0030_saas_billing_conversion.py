"""Convert billing architecture from marketplace commission to SaaS + merchant-owned checkout."""
from alembic import op
import sqlalchemy as sa

revision='20260817_0030'
down_revision='20260816_0029'
branch_labels=None
depends_on=None

def upgrade():
    op.add_column('subscriptions', sa.Column('billing_provider', sa.String(length=40), nullable=False, server_default='paddle'))
    op.add_column('subscriptions', sa.Column('provider_customer_id', sa.String(length=255), nullable=True))
    op.add_column('plan_prices', sa.Column('billing_provider', sa.String(length=40), nullable=False, server_default='paddle'))
    op.add_column('plan_prices', sa.Column('provider_price_id', sa.String(length=255), nullable=True))
    # Legacy marketplace columns remain physically present for safe rollback/data preservation but are no longer mapped or written by application code.
    # Legacy marketplace columns remain physically present for rollback/data preservation but are no longer mapped or written by application code.
    op.create_table('platform_billing_discounts',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('code',sa.String(100),nullable=False),
        sa.Column('plan_id',sa.String(36),sa.ForeignKey('plans.id'),nullable=True),
        sa.Column('discount_type',sa.String(20),nullable=False),
        sa.Column('value_minor',sa.BigInteger,nullable=True),
        sa.Column('percentage_bps',sa.Integer,nullable=True),
        sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'),
        sa.Column('usage_limit',sa.BigInteger,nullable=True),
        sa.Column('usage_count',sa.BigInteger,nullable=False,server_default='0'),
        sa.Column('starts_at',sa.DateTime(timezone=True),nullable=True),
        sa.Column('ends_at',sa.DateTime(timezone=True),nullable=True),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
        sa.UniqueConstraint('code',name='uq_platform_billing_discount_code'))
    op.create_table('product_discounts',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('tenant_id',sa.String(36),sa.ForeignKey('tenants.id'),nullable=False),
        sa.Column('variant_id',sa.String(36),sa.ForeignKey('product_variants.id'),nullable=False),
        sa.Column('percentage_bps',sa.Integer,nullable=False),
        sa.Column('status',sa.String(20),nullable=False,server_default='ACTIVE'),
        sa.Column('starts_at',sa.DateTime(timezone=True),nullable=True),
        sa.Column('ends_at',sa.DateTime(timezone=True),nullable=True),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
        sa.UniqueConstraint('tenant_id','variant_id',name='uq_product_discount_tenant_variant'),
        sa.CheckConstraint('percentage_bps >= 0 AND percentage_bps <= 10000',name='ck_product_discount_bps'))
    # The new model has no commission/application fee semantics. Existing rows remain inert and can be archived later.

def downgrade():
    op.drop_table('product_discounts')
    op.drop_table('platform_billing_discounts')
    op.drop_column('plan_prices','provider_price_id')
    op.drop_column('plan_prices','billing_provider')
    op.drop_column('subscriptions','provider_customer_id')
    op.drop_column('subscriptions','billing_provider')
