from alembic import op
import sqlalchemy as sa

revision = "20260821_0062"
down_revision = "20260820_0061"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("payment_operations", sa.Column("request_hash", sa.String(length=128), nullable=True))
    op.create_index("ix_payment_operations_request_hash", "payment_operations", ["request_hash"])

def downgrade():
    op.drop_index("ix_payment_operations_request_hash", table_name="payment_operations")
    op.drop_column("payment_operations", "request_hash")
