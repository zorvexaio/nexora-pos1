from pathlib import Path
import os, hashlib
from app.core.config import get_settings
from app.core.errors import AppError
from abc import ABC, abstractmethod

class ObjectStore(ABC):

    @abstractmethod
    def put(self, key: str, content: bytes, content_type: str):
        ...

    @abstractmethod
    def delete(self, key: str):
        ...

    @abstractmethod
    def get(self, key: str):
        ...

class LocalObjectStore(ObjectStore):

    def __init__(self):
        self.root = Path(os.getenv('LOCAL_MEDIA_ROOT', 'media_store'))

    def _safe_path(self, key: str) -> Path:
        if not key or len(key) > 1024:
            raise AppError(400, 'STORAGE_KEY_INVALID', 'Storage key is invalid')
        candidate = Path(key)
        if candidate.is_absolute() or '..' in candidate.parts:
            raise AppError(400, 'STORAGE_KEY_INVALID', 'Storage key is invalid')
        path = (self.root / candidate).resolve()
        root = self.root.resolve()
        if path != root and root not in path.parents:
            raise AppError(400, 'STORAGE_KEY_INVALID', 'Storage key escapes storage root')
        return path

    def put(self, key, content, content_type):
        path = self._safe_path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return key

    def delete(self, key):
        path = self._safe_path(key)
        try:
            path.unlink()
        except FileNotFoundError:
            pass

    def get(self, key):
        return self._safe_path(key).read_bytes()

class S3ObjectStore(ObjectStore):

    def __init__(self):
        s = get_settings()
        if not all([s.S3_BUCKET, s.S3_ACCESS_KEY_ID, s.S3_SECRET_ACCESS_KEY]):
            raise AppError(503, 'OBJECT_STORAGE_NOT_CONFIGURED', 'Object storage is not configured')
        import boto3
        self.bucket = s.S3_BUCKET
        self.client = boto3.client('s3', endpoint_url=s.S3_ENDPOINT_URL or None,
         aws_access_key_id=s.S3_ACCESS_KEY_ID,
            aws_secret_access_key=s.S3_SECRET_ACCESS_KEY, region_name=s.S3_REGION)

    def put(self, key, content, content_type):
        self.client.put_object(Bucket=self.bucket, Key=key, Body=content, ContentType=content_type, ServerSideEncryption='AES256', ChecksumSHA256=__import__('base64').b64encode(hashlib.sha256(content).digest()).decode())
        return key

    def delete(self, key):
        self.client.delete_object(Bucket=self.bucket, Key=key)

    def get(self, key):
        obj = self.client.get_object(Bucket=self.bucket, Key=key)
        return obj['Body'].read()

def get_object_store():
    s = get_settings()
    return S3ObjectStore() if s.ENVIRONMENT == 'production' else LocalObjectStore()
