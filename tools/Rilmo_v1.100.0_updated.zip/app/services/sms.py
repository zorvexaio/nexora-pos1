from __future__ import annotations

from app.services.notifications import get_sms_provider


class SMSConfigurationError(RuntimeError):
    pass


def send_verification_sms(phone: str, code: str, expires_minutes: int) -> None:
    if not phone or not code:
        raise SMSConfigurationError("Recipient and verification code are required")
    try:
        get_sms_provider().send(
            to=phone,
            message=f"Your Unified Global Commerce verification code is {code}. It expires in {expires_minutes} minutes.",
        )
    except Exception as exc:
        if isinstance(exc, SMSConfigurationError):
            raise
        raise SMSConfigurationError("SMS delivery failed") from exc
