from __future__ import annotations
from datetime import date
from app.core.errors import AppError

# Engineering defaults reflect current 2026 requirements and are intentionally conservative.
# They are not a substitute for jurisdiction-specific counsel.
JURISDICTION_DEFAULTS = {
    'EU-GDPR': {
        'country_codes': ['AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR','DE','GR','HU','IE','IT','LV','LT','LU','MT','NL','PL','PT','RO','SK','SI','ES','SE','IS','LI','NO'],
        'rights': ['ACCESS','RECTIFICATION','ERASURE','RESTRICTION','OBJECTION','PORTABILITY','AUTOMATED_DECISION_REVIEW'],
        'consent_required_categories': ['analytics','marketing','whatsapp_marketing','sms_marketing','preferences','personalization'],
        'breach_authority_hours': 72,
        'cookie_opt_in_required': True,
        'ai_interaction_disclosure_required': True,
        'ai_generated_marking_required': True,
        'dsr_due_days': 30,
        'transfer_default': 'ADEQUACY_OR_SCC',
        'dsa_marketplace_controls': True,
    },
    'TR-KVKK': {
        'country_codes': ['TR'],
        'rights': ['ACCESS','RECTIFICATION','ERASURE','RESTRICTION','OBJECTION','PORTABILITY'],
        'consent_required_categories': ['marketing','whatsapp_marketing','sms_marketing','analytics'],
        'breach_authority_hours': 72,
        'cookie_opt_in_required': True,
        'ai_interaction_disclosure_required': False,
        'ai_generated_marking_required': False,
        'dsr_due_days': 30,
        'transfer_default': 'ADEQUACY_OR_STANDARD_CONTRACT',
        'dsr_due_days_authority_note': 'Internal response target; verify current Board practice for each request.',
        'dsa_marketplace_controls': False,
    },
    'UK-GDPR': {
        'country_codes': ['GB'],
        'rights': ['ACCESS','RECTIFICATION','ERASURE','RESTRICTION','OBJECTION','PORTABILITY','AUTOMATED_DECISION_REVIEW'],
        'consent_required_categories': ['analytics','marketing','whatsapp_marketing','sms_marketing','preferences'],
        'breach_authority_hours': 72,
        'cookie_opt_in_required': True,
        'ai_interaction_disclosure_required': False,
        'ai_generated_marking_required': False,
        'dsr_due_days': 30,
        'transfer_default': 'UK_IDTA_OR_ADDENDUM',
        'dsa_marketplace_controls': False,
    },
    'BR-LGPD': {
        'country_codes': ['BR'],
        'rights': ['ACCESS','RECTIFICATION','ERASURE','PORTABILITY','OBJECTION','REVIEW_AUTOMATED_DECISION'],
        'consent_required_categories': ['marketing','whatsapp_marketing','sms_marketing'],
        'breach_authority_hours': None,
        'cookie_opt_in_required': False,
        'ai_interaction_disclosure_required': False,
        'ai_generated_marking_required': False,
        'dsr_due_days': 15,
        'transfer_default': 'ANPD_APPROVED_MECHANISM',
        'dsa_marketplace_controls': False,
    },
    'US-STATE-PRIVACY': {
        'country_codes': ['US'],
        'rights': ['ACCESS','RECTIFICATION','DELETION','PORTABILITY','OPT_OUT_SALE_SHARE','OPT_OUT_TARGETED_ADVERTISING','OPT_OUT_PROFILING'],
        'consent_required_categories': ['marketing'],
        'breach_authority_hours': None,
        'cookie_opt_in_required': False,
        'ai_interaction_disclosure_required': False,
        'ai_generated_marking_required': False,
        'dsr_due_days': 45,
        'transfer_default': 'CONTRACT_AND_STATE_REQUIREMENTS',
        'gpc_signal_respected': True,
        'admt_risk_assessment_required': True,
        'dsa_marketplace_controls': False,
    },
    'IN-DPDP': {
        'country_codes': ['IN'],
        'rights': ['ACCESS','CORRECTION','ERASURE','GRIEVANCE'],
        'consent_required_categories': ['marketing'],
        'breach_authority_hours': None,
        'cookie_opt_in_required': False,
        'ai_interaction_disclosure_required': False,
        'ai_generated_marking_required': False,
        'dsr_due_days': 30,
        'transfer_default': 'GOVERNMENT_RESTRICTIONS_AS_APPLICABLE',
        'dsa_marketplace_controls': False,
    },
    'SA-PDPL': {
        'country_codes': ['SA'],
        'rights': ['ACCESS','CORRECTION','DELETION','OBJECTION'],
        'consent_required_categories': ['marketing','personalization'],
        'breach_authority_hours': None,
        'cookie_opt_in_required': False,
        'ai_interaction_disclosure_required': False,
        'ai_generated_marking_required': False,
        'dsr_due_days': 30,
        'transfer_default': 'ADEQUACY_OR_APPROVED_SAFEGUARD',
        'dsa_marketplace_controls': False,
    },
    'AE-PDPL': {
        'country_codes': ['AE'],
        'rights': ['ACCESS','CORRECTION','DELETION','PORTABILITY','OBJECTION'],
        'consent_required_categories': ['marketing','personalization'],
        'breach_authority_hours': None,
        'cookie_opt_in_required': False,
        'ai_interaction_disclosure_required': False,
        'ai_generated_marking_required': False,
        'dsr_due_days': 30,
        'transfer_default': 'CONTRACT_OR_APPROVED_TRANSFER',
        'dsa_marketplace_controls': False,
    },
}


def policy_for(jurisdiction: str | None) -> dict:
    key = str(jurisdiction or 'GLOBAL-BASELINE').upper()
    base = dict(JURISDICTION_DEFAULTS.get(key, {
        # Unknown jurisdictions are fail-closed: do not silently assume that
        # a generic privacy/transfer rule is legally sufficient.
        'rights': ['ACCESS','RECTIFICATION','ERASURE'],
        'consent_required_categories': ['analytics','marketing','personalization'],
        'breach_authority_hours': None,
        'cookie_opt_in_required': True,
        'ai_interaction_disclosure_required': True,
        'ai_generated_marking_required': True,
        'gpc_signal_respected': True,
        'dsr_due_days': 45,
        'transfer_default': 'BLOCK_UNTIL_JURISDICTION_APPROVAL',
        'dsa_marketplace_controls': False,
        'unknown_jurisdiction': True,
    }))
    base['jurisdiction'] = key
    base['effective_engineering_baseline'] = '2026-08-20'
    return base


def validate_dsr_type(jurisdiction: str | None, request_type: str) -> None:
    policy = policy_for(jurisdiction)
    normalized = str(request_type or '').upper()
    allowed = set(policy['rights'])
    aliases = {
        'AUTOMATED_DECISION_REVIEW': {'AUTOMATED_DECISION_REVIEW','REVIEW_AUTOMATED_DECISION'},
        'REVIEW_AUTOMATED_DECISION': {'AUTOMATED_DECISION_REVIEW','REVIEW_AUTOMATED_DECISION'},
        'ERASURE': {'ERASURE','DELETION'},
        'DELETION': {'ERASURE','DELETION'},
        'CORRECTION': {'RECTIFICATION','CORRECTION'},
        'RECTIFICATION': {'RECTIFICATION','CORRECTION'},
    }
    accepted = aliases.get(normalized, {normalized})
    if not (accepted & allowed):
        raise AppError(400, 'PRIVACY_RIGHT_NOT_ENABLED', 'Requested privacy right is not enabled by the applicable jurisdiction policy')


def build_ai_disclosure(*, locale: str = 'en', provider: str = 'rules', model: str = 'rules', content_modality: str = 'text', human_review: bool = False, public_interest_context: bool = False) -> dict:
    # Engineering metadata for EU AI Act Article 50 workflows and general transparency.
    # This is not a legal certification and provider-specific provenance/watermark APIs remain external.
    Arabic = locale.lower().startswith('ar')
    ai_generated = provider != 'rules'
    return {
        'is_ai_generated': ai_generated,
        'interaction_type': 'AI_ASSISTANT',
        'human_review': bool(human_review),
        'public_interest_context': bool(public_interest_context),
        'provider': provider,
        'model': model,
        'content_modality': content_modality,
        'machine_readable_marker': 'rilmo:ai-generated:v2' if ai_generated else None,
        'content_provenance_required': ai_generated and content_modality in {'image','audio','video','text'},
        'public_interest_human_review_required': bool(public_interest_context and content_modality == 'text' and not human_review),
        'deepfake_disclosure_required': bool(content_modality in {'image','audio','video'} and ai_generated),
        'notice': ('هذا الرد مولّد بواسطة الذكاء الاصطناعي، وليس موظف دعم بشرياً.' if Arabic else 'This response is generated by an AI system, not a human support agent.'),
    }
