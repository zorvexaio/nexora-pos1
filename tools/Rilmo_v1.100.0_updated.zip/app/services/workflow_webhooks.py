import json
import ipaddress
import socket
from datetime import datetime, timezone, timedelta
from urllib.parse import urlsplit

from sqlalchemy import or_

from app.core.errors import AppError
from app.models.domain import WorkflowWebhookDelivery, WorkflowStepRun
from app.services.app_webhooks import _post_pinned
from app.core.config import get_settings


def validate_endpoint(url: str, *, resolve: bool = True) -> str:
    raw = str(url or '')
    if not raw or len(raw) > 2048 or any(ch in raw for ch in '\r\n\x00'):
        raise AppError(400, 'WORKFLOW_WEBHOOK_INVALID', 'Webhook endpoint is invalid')
    raw = raw.strip()
    p = urlsplit(raw)
    if p.scheme.lower() != 'https' or not p.hostname or p.username or p.password or p.fragment:
        raise AppError(400, 'WORKFLOW_WEBHOOK_INVALID', 'Workflow webhooks must use HTTPS without credentials or fragments')
    host = p.hostname.rstrip('.').lower()
    try:
        port = p.port or 443
    except ValueError as exc:
        raise AppError(400, 'WORKFLOW_WEBHOOK_INVALID', 'Webhook endpoint has an invalid port') from exc
    allowed = {x.strip().lower().rstrip('.') for x in get_settings().APP_WEBHOOK_ALLOWED_HOSTS.split(',') if x.strip()}
    if allowed and host not in allowed:
        raise AppError(400, 'WEBHOOK_ENDPOINT_BLOCKED', 'Webhook endpoint is not allowlisted')
    if not resolve:
        return raw
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise AppError(400, 'WEBHOOK_ENDPOINT_BLOCKED', 'Webhook endpoint cannot be resolved') from exc
    public = False
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError as exc:
            raise AppError(400, 'WEBHOOK_ENDPOINT_BLOCKED', 'Webhook endpoint resolved to an invalid address') from exc
        if not ip.is_global:
            raise AppError(400, 'WEBHOOK_ENDPOINT_BLOCKED', 'Webhook endpoint is not publicly routable')
        public = True
    if not public:
        raise AppError(400, 'WEBHOOK_ENDPOINT_BLOCKED', 'Webhook endpoint has no public address')
    return raw


def materialize_workflow_webhook(db, event):
    payload = event.payload or {}
    # DNS is deliberately deferred until delivery time: materialization is durable state,
    # while final routing must be revalidated immediately before network I/O to resist DNS rebinding.
    url = validate_endpoint(payload.get('url'), resolve=False)
    run_id = payload.get('workflow_run_id')
    position = int(payload.get('step_position'))
    existing = db.query(WorkflowWebhookDelivery).filter_by(workflow_run_id=run_id, step_position=position).first()
    if existing:
        return existing
    delivery = WorkflowWebhookDelivery(
        tenant_id=event.tenant_id, workflow_run_id=run_id, step_position=position,
        endpoint_url=url, payload=payload.get('payload') or {}, status='PENDING',
        attempt_count=0, next_attempt_at=datetime.now(timezone.utc))
    db.add(delivery)
    db.flush()
    return delivery


def recover_stale_workflow_webhook_deliveries(db, stale_seconds: int = 3600, tenant_id: str | None = None):
    from app.core.database import set_tenant_context
    cutoff = datetime.now(timezone.utc) - timedelta(seconds=max(60, stale_seconds))
    q = db.query(WorkflowWebhookDelivery).filter(
        WorkflowWebhookDelivery.status == 'PROCESSING',
        WorkflowWebhookDelivery.processing_started_at.isnot(None),
        WorkflowWebhookDelivery.processing_started_at <= cutoff,
    )
    if tenant_id:
        q=q.filter(WorkflowWebhookDelivery.tenant_id == tenant_id)
        set_tenant_context(db, tenant_id)
    rows=q.all()
    for delivery in rows:
        delivery.status='RECONCILIATION_REQUIRED'
        delivery.last_error='Delivery was interrupted during external I/O; manual/provider reconciliation required'
        delivery.processing_started_at=None
    db.commit()
    return len(rows)


def process_workflow_webhook_deliveries(db, batch_size=25, tenant_id=None):
    now=datetime.now(timezone.utc)
    if tenant_id:
        from app.core.database import set_tenant_context
        set_tenant_context(db, tenant_id)
    q=db.query(WorkflowWebhookDelivery).filter(
        WorkflowWebhookDelivery.status.in_(['PENDING','RETRY']),
        or_(WorkflowWebhookDelivery.next_attempt_at.is_(None), WorkflowWebhookDelivery.next_attempt_at <= now)
    )
    if tenant_id:
        q=q.filter(WorkflowWebhookDelivery.tenant_id == tenant_id)
    q=q.order_by(WorkflowWebhookDelivery.created_at).limit(max(1,min(batch_size,100)))
    if db.bind.dialect.name == 'postgresql':
        q=q.with_for_update(skip_locked=True)
    rows=q.all(); sent=0
    for delivery in rows:
        delivery.status='PROCESSING'; delivery.attempt_count += 1; delivery.processing_started_at=datetime.now(timezone.utc); db.commit()
        try:
            validate_endpoint(delivery.endpoint_url)
            body=json.dumps({'workflow_run_id':delivery.workflow_run_id,'step_position':delivery.step_position,'data':delivery.payload},separators=(',',':'),sort_keys=True).encode()
            headers={'Content-Type':'application/json','User-Agent':'Rilmo-Workflow-Webhooks/1.0','X-Rilmo-Workflow-Run':delivery.workflow_run_id,'X-Rilmo-Workflow-Step':str(delivery.step_position)}
            status,_,_= _post_pinned(delivery.endpoint_url,body,headers,timeout=10.0)
            if not 200 <= status < 300: raise RuntimeError(f'HTTP {status}')
            delivery.status='SUCCEEDED'; delivery.delivered_at=datetime.now(timezone.utc); delivery.next_attempt_at=None; delivery.last_error=None; delivery.processing_started_at=None; sent+=1
            step=db.query(WorkflowStepRun).filter_by(workflow_run_id=delivery.workflow_run_id,position=delivery.step_position,tenant_id=delivery.tenant_id).first()
            if step:
                step.status='COMPLETED'; step.output_payload={'delivered':True,'endpoint_host':urlsplit(delivery.endpoint_url).hostname}; step.completed_at=datetime.now(timezone.utc)
        except Exception as exc:
            delivery.last_error=str(exc)[:2000]
            delivery.processing_started_at=None
            if delivery.attempt_count >= get_settings().APP_WEBHOOK_MAX_ATTEMPTS:
                delivery.status='FAILED'; delivery.next_attempt_at=None
                step=db.query(WorkflowStepRun).filter_by(workflow_run_id=delivery.workflow_run_id,position=delivery.step_position,tenant_id=delivery.tenant_id).first()
                if step:
                    step.status='FAILED'; step.error_message=str(exc)[:500]; step.completed_at=datetime.now(timezone.utc)
            else:
                delivery.status='RETRY'; delivery.next_attempt_at=datetime.now(timezone.utc)+timedelta(seconds=min(3600,2**min(delivery.attempt_count,10)))
    db.flush(); return sent
