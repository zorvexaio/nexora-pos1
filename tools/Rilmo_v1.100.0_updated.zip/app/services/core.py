from datetime import datetime, timezone, timedelta
import hashlib, json, uuid
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import select, text, or_, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.dialects.postgresql import insert as pg_insert
from app.models.domain import *
from app.core.security import random_token, token_hash, hash_password
from app.core.errors import AppError

def _json_safe(value):
    if value is None:
        return None
    return json.loads(json.dumps(value, default=lambda x: x.isoformat() if hasattr(x,
        'isoformat') else str(x), sort_keys=True))

def audit(db, tenant_id, actor_id, action, resource_type=None, resource_id=None, before=None,
    after=None, request_id=None, correlation_id=None, ip_hash=None, user_agent_hash=None):
    safe_before = _json_safe(before)
    safe_after = _json_safe(after)
    request_id = request_id or str(uuid.uuid4())
    correlation_id = correlation_id or str(uuid.uuid4())
    if db.bind and db.bind.dialect.name == 'postgresql':
        lock_key = tenant_id or 'platform-global'
        db.execute(text('SELECT pg_advisory_xact_lock(hashtext(:lock_key))'), {'lock_key': lock_key})
    q = db.query(AuditEvent)
    if tenant_id is not None:
        q = q.filter(AuditEvent.tenant_id == tenant_id)
    previous = q.order_by(AuditEvent.created_at.desc(), AuditEvent.id.desc()).first()
    prev_hash = previous.event_hash if previous else None
    material = {'tenant_id': tenant_id, 'actor_id': actor_id, 'action': action,
     'resource_type': resource_type,
     'resource_id': resource_id,
     'request_id': request_id,
     'correlation_id': correlation_id,
     'before': safe_before,
     'after': safe_after,
        'prev_hash': prev_hash, 'ip_hash': ip_hash, 'user_agent_hash': user_agent_hash}
    event_hash = hashlib.sha256(json.dumps(material, sort_keys=True, separators=(',',
        ':')).encode()).hexdigest()
    db.add(AuditEvent(tenant_id=tenant_id, actor_id=actor_id, action=action,
     resource_type=resource_type,
     resource_id=resource_id,
     before_data=safe_before,
     after_data=safe_after,
     request_id=request_id,
     correlation_id=correlation_id,
        ip_hash=ip_hash, user_agent_hash=user_agent_hash, prev_hash=prev_hash, event_hash=event_hash))
CANONICAL_EVENT_ALIASES = {'payment_intent.created': 'payment.intent.created',
    'payment_intent.captured': 'payment.captured', 'payment_intent.failed': 'payment.failed'}

def canonical_event_name(name: str) -> str:
    return CANONICAL_EVENT_ALIASES.get(name, name)

def outbox(db, tenant_id, aggregate_type, aggregate_id, event_type, payload, *, schema_version=1,
    causation_id=None, correlation_id=None, dedupe_key=None):
    et = canonical_event_name(event_type)
    body = _json_safe(payload or {})
    body.setdefault('tenant_id', tenant_id)
    db.add(OutboxEvent(tenant_id=tenant_id, aggregate_type=aggregate_type,
     aggregate_id=aggregate_id,
     event_type=et,
     schema_version=schema_version,
     payload=body,
     correlation_id=correlation_id or str(uuid.uuid4()),
     causation_id=causation_id,
     producer='commerce-api',
        occurred_at=datetime.now(timezone.utc), status='PENDING', attempt_count=0,
        dedupe_key=dedupe_key))

def idem(db, tenant_id, actor_id, endpoint, key, request_hash):
    if not key:
        return (None, True)
    existing = db.query(IdempotencyKey).filter_by(tenant_id=tenant_id, endpoint=endpoint,
        key=key).first()
    if existing:
        existing._idempotency_fresh = False
        if existing.request_hash != request_hash:
            return (existing, False)
        return (existing, True)
    rec = IdempotencyKey(tenant_id=tenant_id, actor_id=actor_id, endpoint=endpoint, key=key,
     request_hash=request_hash,
        status='IN_PROGRESS', expires_at=datetime.now(timezone.utc) + timedelta(days=2))
    try:
        with db.begin_nested():
            db.add(rec)
            db.flush()
    except IntegrityError:
        existing = db.query(IdempotencyKey).filter_by(tenant_id=tenant_id, endpoint=endpoint,
            key=key).first()
        if not existing:
            raise
        existing._idempotency_fresh = False
        if existing.request_hash != request_hash:
            return (existing, False)
        return (existing, True)
    rec._idempotency_fresh = True
    return (rec, True)

def finalize_idem(rec, body, status):
    if not rec:
        return
    rec.status = 'COMPLETED'
    rec.response_status = status
    rec.response_body = _json_safe(body)



def bind_provider_tenant(db, *, provider: str, external_id: str | None, tenant_id: str):
    if not external_id:
        return
    from app.models.domain import ProviderTenantBinding
    from sqlalchemy.exc import IntegrityError
    existing = db.query(ProviderTenantBinding).filter_by(
        provider=str(provider).lower(), external_id=str(external_id)).first()
    if existing:
        if existing.tenant_id != tenant_id:
            raise AppError(409, 'PROVIDER_REFERENCE_TENANT_CONFLICT',
                'Provider reference is already bound to another tenant')
        existing.updated_at = datetime.now(timezone.utc)
        return existing
    row = ProviderTenantBinding(provider=str(provider).lower(), external_id=str(external_id), tenant_id=tenant_id)
    db.add(row)
    try:
        with db.begin_nested():
            db.flush()
    except IntegrityError:
        existing = db.query(ProviderTenantBinding).filter_by(
            provider=str(provider).lower(), external_id=str(external_id)).first()
        if existing and existing.tenant_id == tenant_id:
            return existing
        raise AppError(409, 'PROVIDER_REFERENCE_TENANT_CONFLICT',
            'Provider reference is already bound to another tenant')
    return row

def resolve_provider_tenant(db, *, provider: str, external_id: str | None):
    if not external_id:
        return None
    from app.models.domain import ProviderTenantBinding
    row = db.query(ProviderTenantBinding).filter_by(
        provider=str(provider).lower(), external_id=str(external_id)).first()
    return row.tenant_id if row else None


def quarantine_provider_ingest_event(db, *, provider, provider_event_id, event_type, payload_hash, payload):
    """Idempotently persist a verified but not-yet-routable provider event."""
    from app.models.domain import ProviderIngestEvent
    from sqlalchemy.exc import IntegrityError
    existing = db.query(ProviderIngestEvent).filter_by(
        provider=str(provider).lower(), provider_event_id=str(provider_event_id)).first()
    if existing:
        if existing.payload_hash != payload_hash:
            raise AppError(409, 'WEBHOOK_PAYLOAD_MISMATCH',
                'Provider event id was previously quarantined with a different payload')
        return existing, False
    row = ProviderIngestEvent(provider=str(provider).lower(), provider_event_id=str(provider_event_id),
        event_type=str(event_type), payload_hash=payload_hash, payload=payload, status='QUARANTINED')
    try:
        with db.begin_nested():
            db.add(row); db.flush()
    except IntegrityError:
        existing = db.query(ProviderIngestEvent).filter_by(
            provider=str(provider).lower(), provider_event_id=str(provider_event_id)).first()
        if existing:
            if existing.payload_hash != payload_hash:
                raise AppError(409, 'WEBHOOK_PAYLOAD_MISMATCH',
                    'Provider event id was previously quarantined with a different payload')
            return existing, False
        raise
    return row, True


def claim_webhook_event(db, *, provider, provider_event_id, tenant_id, event_type, payload_hash, payload):
    """Atomically claim a provider webhook event.

    Returns (event, True) for the request that won the insert, or (existing, False)
    for a concurrent/replayed duplicate. A reused provider event id with a
    different payload hash is rejected as a provider-integrity violation.
    """
    from sqlalchemy.exc import IntegrityError
    now = datetime.now(timezone.utc)
    existing = db.query(WebhookEvent).filter_by(provider=provider, provider_event_id=provider_event_id).first()
    if existing:
        if existing.payload_hash != payload_hash:
            raise AppError(409, 'WEBHOOK_PAYLOAD_MISMATCH',
                'Provider event id was previously seen with a different payload')
        return existing, False
    row = WebhookEvent(tenant_id=tenant_id, provider=provider, provider_event_id=provider_event_id,
        event_type=event_type, payload_hash=payload_hash, payload=payload, status='RECEIVED',
        received_at=now)
    try:
        with db.begin_nested():
            db.add(row)
            db.flush()
    except IntegrityError:
        existing = db.query(WebhookEvent).filter_by(provider=provider, provider_event_id=provider_event_id).first()
        if existing:
            if existing.payload_hash != payload_hash:
                raise AppError(409, 'WEBHOOK_PAYLOAD_MISMATCH',
                    'Provider event id was previously seen with a different payload')
            return existing, False
        raise
    return row, True

def body_hash(payload):
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',',
        ':')).encode()).hexdigest()

def ensure_seed(db):
    permissions = ['products.read', 'products.write', 'orders.read', 'orders.manage',
     'orders.cancel',
     'orders.refund',
     'inventory.read',
     'inventory.write',
     'finance.read',
     'finance.manage',
     'customers.read',
     'customers.write',
     'customers.export',
     'storefront.read',
        'storefront.write', 'apps.manage', 'settings.manage', 'billing.manage', 'staff.manage']
    if db.query(RolePermission).count() == 0:
        rows = []
        for r in ['owner', 'admin', 'staff', 'viewer']:
            for p in permissions:
                if r in ('owner', 'admin') or p in ({'products.read', 'orders.read',
                 'inventory.read',
                 'finance.read'} if r == 'viewer' else {'products.read',
                 'products.write',
                 'orders.read',
                 'orders.manage',
                 'inventory.read',
                 'inventory.write',
                 'finance.read',
                 'customers.read',
                 'customers.write',
                 'storefront.read',
                 'storefront.write',
                    'apps.manage', 'settings.manage', 'billing.manage', 'staff.manage'}):
                    rows.append(RolePermission(role=r, permission=p))
        db.add_all(rows)
    for code in permissions:
        if not db.query(Permission).filter_by(code=code).first():
            db.add(Permission(code=code))
    for role_name in ('owner', 'admin', 'staff', 'viewer'):
        if not db.query(Role).filter_by(tenant_id=None, name=role_name).first():
            db.add(Role(name=role_name, system_role=True))
    db.flush()
    if db.query(Plan).count() == 0:
        plans=[
            ('starter','Starter',12,[('max_products','integer',50,False),('max_languages','integer',1,False),('coupons','boolean',None,True),('abandoned_cart','boolean',None,False),('sms_monthly','integer',0,False),('advanced_analytics','boolean',None,False),('priority_support','boolean',None,False),('api_access','boolean',None,False)]),
            ('growth','Growth',30,[('max_products','integer',500,False),('max_languages','integer',5,False),('coupons','boolean',None,True),('abandoned_cart','boolean',None,True),('sms_monthly','integer',100,False),('advanced_analytics','boolean',None,True),('priority_support','boolean',None,True),('api_access','boolean',None,False)]),
            ('scale','Scale',100,[('max_products','integer',-1,False),('max_languages','integer',13,False),('coupons','boolean',None,True),('abandoned_cart','boolean',None,True),('sms_monthly','integer',2000,False),('advanced_analytics','boolean',None,True),('priority_support','boolean',None,True),('api_access','boolean',None,True)]),
        ]
        for code,name,usd,features in plans:
            pl=Plan(code=code,name=name); db.add(pl); db.flush()
            v=PlanVersion(plan_id=pl.id,version=1,is_current=True); db.add(v); db.flush()
            db.add(PlanPrice(plan_version_id=v.id,billing_interval='month',amount_minor_units=usd*100,currency='USD',billing_provider='paddle'))
            for key,typ,ival,bval in features:
                db.add(PlanFeature(plan_version_id=v.id,feature_key=key,value_type=typ,value_integer=ival,value_boolean=bval))
    db.commit()

def get_entitlement(db, tenant_id: str, feature_key: str):
    return db.query(Entitlement).filter_by(tenant_id=tenant_id, feature_key=feature_key).first()

def require_entitlement(db, tenant_id: str, feature_key: str, *, minimum: int | None=None):
    row=get_entitlement(db,tenant_id,feature_key)
    if not row:
        raise AppError(402,'PLAN_FEATURE_REQUIRED',f'Your plan does not include {feature_key}')
    if row.value_type=='boolean' and row.value_boolean is not True:
        raise AppError(402,'PLAN_FEATURE_REQUIRED',f'Your plan does not include {feature_key}')
    if row.value_type=='integer' and minimum is not None and int(row.value_integer or 0) < minimum and int(row.value_integer or 0) != -1:
        raise AppError(402,'PLAN_LIMIT_REACHED',f'Your plan limit for {feature_key} has been reached')
    return row

    db.commit()

def _redis_rate_limit(scope_key: str, limit: int, window_seconds: int):
    from app.core.config import get_settings
    url = get_settings().REDIS_URL
    if not url:
        return None
    import redis
    key = get_settings().REDIS_KEY_PREFIX + hashlib.sha256(scope_key.encode()).hexdigest()
    client = redis.Redis.from_url(url, socket_timeout=get_settings().REDIS_SOCKET_TIMEOUT_SECONDS, decode_responses=True)
    script = (
        "local c=redis.call('INCR',KEYS[1]); if c==1 then redis.call('EXPIRE',KEYS[1],ARGV[1]); end; return c"
    )
    count = int(client.eval(script, 1, key, int(window_seconds)))
    return count

def enforce_rate_limit(db, scope_key: str, limit: int, window_seconds: int=60):
    from app.core.config import get_settings
    try:
        redis_count = _redis_rate_limit(scope_key, limit, window_seconds)
    except Exception as exc:
        if get_settings().ENVIRONMENT == 'production':
            raise AppError(503, 'RATE_LIMIT_BACKEND_UNAVAILABLE', 'Rate limiting backend unavailable') from exc
        redis_count = None
    if redis_count is not None:
        if redis_count > limit:
            raise AppError(429, 'RATE_LIMITED', 'Too many requests',
                headers={'Retry-After': str(window_seconds), 'X-RateLimit-Limit': str(limit),
                         'X-RateLimit-Remaining': '0'})
        return
    now = datetime.now(timezone.utc)
    epoch = int(now.timestamp())
    bucket = epoch - epoch % window_seconds
    window = datetime.fromtimestamp(bucket, tz=timezone.utc)
    if db.bind.dialect.name == 'postgresql':
        stmt = text('INSERT INTO rate_limit_counters(id,scope_key,window_start,count,created_at) VALUES (:id,:scope_key,:window_start,1,:created_at) ON CONFLICT (scope_key,window_start) DO UPDATE SET count=rate_limit_counters.count+1 RETURNING count')
        count = int(db.execute(stmt, {'id': str(uuid.uuid4()), 'scope_key': scope_key,
            'window_start': window, 'created_at': now}).scalar_one())
    else:
        row = db.query(RateLimitCounter).filter_by(scope_key=scope_key, window_start=window).first()
        if not row:
            row = RateLimitCounter(scope_key=scope_key, window_start=window, count=1)
            db.add(row)
            db.flush()
            count = 1
        else:
            row.count += 1
            count = row.count
    if count > limit:
        raise AppError(429, 'RATE_LIMITED', 'Too many requests',
            headers={'Retry-After': str(window_seconds), 'X-RateLimit-Limit': str(limit),
                     'X-RateLimit-Remaining': '0'})

def begin_payment_operation(db, tenant_id, payment_intent_id, operation_type, idempotency_key, *,
    amount_minor=None, currency=None, request_hash=None):
    from sqlalchemy.exc import IntegrityError
    if not idempotency_key:
        raise AppError(400, 'IDEMPOTENCY_KEY_REQUIRED',
            'Idempotency-Key is required for payment mutations')
    if request_hash is None:
        request_hash = body_hash({'payment_intent_id': payment_intent_id,
            'operation_type': operation_type, 'amount_minor': amount_minor,
            'currency': (currency or '').upper()})
    existing_key = db.query(PaymentOperation).filter_by(tenant_id=tenant_id,
        idempotency_key=idempotency_key).first()
    if existing_key:
        if existing_key.payment_intent_id != payment_intent_id or existing_key.operation_type != operation_type:
            raise AppError(409, 'IDEMPOTENCY_KEY_REUSED',
                'Idempotency-Key is already bound to another payment operation')
        if existing_key.request_hash and existing_key.request_hash != request_hash:
            raise AppError(409, 'IDEMPOTENCY_REQUEST_MISMATCH',
                'Idempotency-Key was reused with different payment parameters')
        if not existing_key.request_hash:
            existing_key.request_hash = request_hash
        if existing_key.status == 'COMPLETED':
            return (existing_key, 'COMPLETED')
        if existing_key.status in {'PENDING', 'PROVIDER_PENDING'}:
            return (existing_key, 'IN_PROGRESS')
        existing_key.status = 'PENDING'
        existing_key.error_code = None
        existing_key.response_body = None
        existing_key.completed_at = None
        db.flush()
        return (existing_key, 'RETRY')
    active = db.query(PaymentOperation).filter_by(tenant_id=tenant_id,
     payment_intent_id=payment_intent_id,
     operation_type=operation_type).filter(PaymentOperation.status.in_(['PENDING',
        'PROVIDER_PENDING'])).first()
    if active:
        raise AppError(409, 'PAYMENT_OPERATION_IN_PROGRESS',
            'Another payment operation is already in progress')
    op = PaymentOperation(tenant_id=tenant_id, payment_intent_id=payment_intent_id,
     operation_type=operation_type,
     idempotency_key=idempotency_key,
     request_hash=request_hash,
     requested_amount_minor=amount_minor,
        currency=(currency or '').upper() or None, status='PENDING')
    db.add(op)
    try:
        with db.begin_nested():
            db.flush()
    except IntegrityError:
        existing_key = db.query(PaymentOperation).filter_by(tenant_id=tenant_id,
            idempotency_key=idempotency_key).first()
        if existing_key:
            if existing_key.payment_intent_id != payment_intent_id or existing_key.operation_type != operation_type:
                raise AppError(409, 'IDEMPOTENCY_KEY_REUSED',
                    'Idempotency-Key is already bound to another payment operation')
            if existing_key.request_hash and existing_key.request_hash != request_hash:
                raise AppError(409, 'IDEMPOTENCY_REQUEST_MISMATCH',
                    'Idempotency-Key was reused with different payment parameters')
            if not existing_key.request_hash:
                existing_key.request_hash = request_hash
            if existing_key.status == 'COMPLETED':
                return (existing_key, 'COMPLETED')
            return (existing_key, 'IN_PROGRESS')
        active = db.query(PaymentOperation).filter_by(tenant_id=tenant_id,
         payment_intent_id=payment_intent_id,
         operation_type=operation_type).filter(PaymentOperation.status.in_(['PENDING',
            'PROVIDER_PENDING'])).first()
        if active:
            raise AppError(409, 'PAYMENT_OPERATION_IN_PROGRESS',
                'Another payment operation is already in progress')
        raise
    return (op, 'CREATED')

def complete_payment_operation(op, body, provider_reference=None):
    op.status = 'COMPLETED'
    op.provider_reference = provider_reference
    op.response_body = _json_safe(body)
    op.completed_at = datetime.now(timezone.utc)

def fail_payment_operation(op, code):
    op.status = 'FAILED'
    op.error_code = code
    op.completed_at = datetime.now(timezone.utc)

def post_ledger_entry(db, tenant_id, currency, reference_type, reference_id, debit_account,
    credit_account, amount_minor):
    if amount_minor <= 0:
        raise AppError(400, 'LEDGER_AMOUNT_INVALID', 'Ledger amount must be positive')
    cur = currency.upper()
    for account in (debit_account, credit_account):
        if account.tenant_id != tenant_id:
            raise AppError(409, 'LEDGER_TENANT_MISMATCH', 'Ledger account tenant mismatch')
        if account.currency and account.currency != cur:
            raise AppError(409, 'LEDGER_CURRENCY_MISMATCH', 'Ledger account currency mismatch')
    if debit_account.id == credit_account.id:
        raise AppError(409, 'LEDGER_SELF_TRANSFER', 'Debit and credit account cannot be identical')
    je = JournalEntry(tenant_id=tenant_id, currency=cur, reference_type=reference_type,
        reference_id=reference_id)
    db.add(je)
    db.flush()
    db.add_all([JournalLine(tenant_id=tenant_id, journal_entry_id=je.id,
     account_id=debit_account.id,
     debit_minor=amount_minor,
     credit_minor=0,
     currency=cur),
     JournalLine(tenant_id=tenant_id,
     journal_entry_id=je.id,
        account_id=credit_account.id, debit_minor=0, credit_minor=amount_minor, currency=cur)])
    return je

def post_split_ledger_entry(db, tenant_id, currency, reference_type, reference_id, debit_account,
    credit_lines):
    """Post one balanced journal with one debit and multiple credits. credit_lines=[(account, amount)]."""
    cur = currency.upper()
    total = 0
    for account, amount in credit_lines:
        if amount <= 0:
            continue
        if account.tenant_id != tenant_id or (account.currency and account.currency != cur):
            raise AppError(409, 'LEDGER_ACCOUNT_MISMATCH', 'Ledger account mismatch')
        total += int(amount)
    if total <= 0:
        raise AppError(400, 'LEDGER_AMOUNT_INVALID', 'Ledger amount must be positive')
    if debit_account.tenant_id != tenant_id or (debit_account.currency and debit_account.currency != cur):
        raise AppError(409, 'LEDGER_ACCOUNT_MISMATCH', 'Ledger account mismatch')
    je = JournalEntry(tenant_id=tenant_id, currency=cur, reference_type=reference_type,
        reference_id=reference_id)
    db.add(je)
    db.flush()
    db.add(JournalLine(tenant_id=tenant_id, journal_entry_id=je.id, account_id=debit_account.id,
        debit_minor=total, credit_minor=0, currency=cur))
    for account, amount in credit_lines:
        if amount > 0:
            db.add(JournalLine(tenant_id=tenant_id, journal_entry_id=je.id, account_id=account.id,
                debit_minor=0, credit_minor=int(amount), currency=cur))
    return je

def assert_journal_balanced(db, journal_entry_id: str):
    totals = db.query(func.coalesce(func.sum(JournalLine.debit_minor), 0),
     func.coalesce(func.sum(JournalLine.credit_minor),
        0)).filter(JournalLine.journal_entry_id == journal_entry_id).first()
    if not totals or int(totals[0]) != int(totals[1]) or int(totals[0]) <= 0:
        raise AppError(500, 'LEDGER_UNBALANCED', 'Ledger entry is not balanced')
    return True

def resolve_variant_price_details(db, tenant_id: str, variant):
    """Resolve list price and active merchant product-sale price from tenant-owned data."""
    list_price=resolve_variant_price(db,tenant_id,variant)
    now_dt=datetime.now(timezone.utc)
    sale=db.query(ProductDiscount).filter_by(tenant_id=tenant_id,variant_id=variant.id,status='ACTIVE').first()
    if sale and (sale.starts_at is None or sale.starts_at<=now_dt) and (sale.ends_at is None or sale.ends_at>now_dt):
        discount=list_price*int(sale.percentage_bps)//10000
        return {'list_price_minor':list_price,'discount_minor':max(0,min(list_price,discount)),'selling_price_minor':max(0,list_price-discount),'discount_bps':int(sale.percentage_bps)}
    return {'list_price_minor':list_price,'discount_minor':0,'selling_price_minor':list_price,'discount_bps':0}

def resolve_variant_price(db, tenant_id: str, variant):
    pl = db.query(PriceList).filter_by(tenant_id=tenant_id, is_default=True, status='ACTIVE').first()
    if pl:
        row = db.query(Price).filter_by(tenant_id=tenant_id, price_list_id=pl.id, variant_id=variant.id, currency=variant.currency).first()
        if row and (row.valid_from is None or row.valid_from <= datetime.now(timezone.utc)) and (row.valid_to is None or row.valid_to > datetime.now(timezone.utc)):
            return int(row.amount_minor)
    return int(variant.price_amount_minor)

def calculate_coupon_discount(db, tenant_id: str, code: str, subtotal_minor: int, currency: str):
    """Lock and validate coupon/promotion usage inside the checkout transaction."""
    coupon = db.query(Coupon).filter_by(tenant_id=tenant_id, code=code.strip().upper(),
        status='ACTIVE').with_for_update().first()
    if not coupon:
        raise AppError(400, 'COUPON_INVALID', 'Coupon is invalid or inactive')
    if coupon.usage_limit is not None and coupon.usage_count >= coupon.usage_limit:
        raise AppError(409, 'COUPON_EXHAUSTED', 'Coupon usage limit reached')
    promotion = db.query(Promotion).filter_by(id=coupon.promotion_id, tenant_id=tenant_id,
        status='ACTIVE').with_for_update().first()
    if not promotion:
        raise AppError(400, 'PROMOTION_INVALID', 'Promotion is invalid or inactive')
    if promotion.usage_limit is not None and promotion.usage_count >= promotion.usage_limit:
        raise AppError(409, 'PROMOTION_EXHAUSTED', 'Promotion usage limit reached')
    if promotion.discount_type == 'PERCENTAGE':
        discount = subtotal_minor * int(promotion.percentage_bps or 0) // 10000
    elif promotion.discount_type == 'FIXED':
        discount = int(promotion.value_minor or 0)
    else:
        raise AppError(400, 'PROMOTION_TYPE_INVALID', 'Unsupported promotion type')
    return (coupon, promotion, max(0, min(subtotal_minor, discount)))

def verify_audit_chain(db, tenant_id: str | None=None):
    q = db.query(AuditEvent)
    if tenant_id is not None:
        q = q.filter(AuditEvent.tenant_id == tenant_id)
    rows = q.order_by(AuditEvent.created_at.asc(), AuditEvent.id.asc()).all()
    prev = None
    for row in rows:
        material = {'tenant_id': row.tenant_id, 'actor_id': row.actor_id, 'action': row.action,
         'resource_type': row.resource_type,
         'resource_id': row.resource_id,
         'request_id': row.request_id,
         'correlation_id': row.correlation_id,
         'before': row.before_data,
         'after': row.after_data,
            'prev_hash': prev, 'ip_hash': row.ip_hash, 'user_agent_hash': row.user_agent_hash}
        expected = hashlib.sha256(json.dumps(material, sort_keys=True, separators=(',',
            ':')).encode()).hexdigest()
        if row.prev_hash != prev or row.event_hash != expected:
            return False
        prev = row.event_hash
    return True
