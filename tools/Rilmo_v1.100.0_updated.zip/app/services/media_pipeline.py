from io import BytesIO
from PIL import Image, ImageOps, UnidentifiedImageError
from app.core.errors import AppError
MAX_PIXELS = 25000000
SIZES = {'thumbnail': 320, 'small': 640, 'medium': 1280, 'large': 1920, 'original': 4096}

def process_image(content: bytes):
    Image.MAX_IMAGE_PIXELS = MAX_PIXELS
    try:
        with Image.open(BytesIO(content)) as source:
            source.verify()
        with Image.open(BytesIO(content)) as image:
            image.load()
            if image.width * image.height > MAX_PIXELS:
                raise AppError(422, 'IMAGE_TOO_LARGE',
                    'Image pixel dimensions exceed the safety limit')
            image = ImageOps.exif_transpose(image).convert('RGB')
            outputs = {}
            for name, max_edge in SIZES.items():
                current = image.copy()
                if max(current.size) > max_edge:
                    current.thumbnail((max_edge, max_edge), Image.Resampling.LANCZOS)
                buf = BytesIO()
                current.save(buf, format='WEBP', quality=88, method=6)
                outputs[name] = (buf.getvalue(), current.width, current.height)
            return outputs
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise AppError(422, 'INVALID_IMAGE', 'Image could not be safely decoded') from exc
