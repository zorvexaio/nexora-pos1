from dataclasses import dataclass
from typing import Any, Protocol
from urllib.parse import quote
from app.core.errors import AppError
from app.core.network import validate_outbound_url


def _safe_relative_path(path: str) -> str:
    raw = str(path or '')
    if not raw or len(raw) > 2048 or any(ch in raw for ch in ('\r', '\n', '\x00', '\\')):
        raise AppError(400, 'CARRIER_PATH_INVALID', 'Carrier request path is invalid')
    if not raw.startswith('/') or raw.startswith('//'):
        raise AppError(400, 'CARRIER_PATH_INVALID', 'Carrier request path must remain on the configured host')
    from urllib.parse import urlsplit
    parsed = urlsplit(raw)
    if parsed.scheme or parsed.netloc:
        raise AppError(400, 'CARRIER_PATH_INVALID', 'Carrier request path cannot override the configured host')
    # Reject dot-segments before the URL is handed to httpx. A path such as
    # /safe/../admin is syntactically relative but can still escape the
    # configured endpoint namespace after URL normalization.
    segments = [seg for seg in parsed.path.split('/') if seg]
    if any(seg in {'.', '..'} for seg in segments):
        raise AppError(400, 'CARRIER_PATH_INVALID', 'Carrier request path cannot contain dot-segments')
    if parsed.query or parsed.fragment:
        raise AppError(400, 'CARRIER_PATH_INVALID', 'Carrier request path cannot contain query or fragment data')
    return raw

@dataclass(frozen=True)
class ShippingRate:
    carrier: str
    service: str
    amount_minor: int
    currency: str
    estimated_days: int | None = None
    metadata: dict[str, Any] | None = None

class CarrierProvider(Protocol):
    name: str

    def quote(self, *, origin: dict, destination: dict, parcels: list[dict],
        currency: str) -> list[ShippingRate]:
        ...

    def create_shipment(self, *, order_id: str, origin: dict, destination: dict,
        parcels: list[dict], service: str) -> dict:
        ...

    def track(self, tracking_number: str) -> dict:
        ...

class FlatRateCarrier(CarrierProvider):
    name = 'flat'

    def __init__(self, amount_minor: int, currency: str, service='standard'):
        if amount_minor < 0:
            raise AppError(400, 'SHIPPING_RATE_INVALID', 'Shipping rate cannot be negative')
        self.amount_minor = amount_minor
        self.currency = currency.upper()
        self.service = service

    def quote(self, **kwargs):
        return [ShippingRate(self.name, self.service, self.amount_minor, self.currency, 3, {})]

    def create_shipment(self, **kwargs):
        raise AppError(503, 'CARRIER_NOT_CONFIGURED',
            'Flat-rate shipping does not create carrier labels')

    def track(self, tracking_number):
        return {'carrier': self.name, 'tracking_number': tracking_number, 'status': 'UNKNOWN'}

class GenericHttpCarrier(CarrierProvider):
    """Production adapter contract. Provider-specific payload mapping belongs in subclasses."""

    def __init__(self, *, name: str, base_url: str, api_token: str, timeout: float=15):
        if not base_url or not api_token:
            raise AppError(503, 'CARRIER_NOT_CONFIGURED', f'{name} carrier is not configured')
        self.name = name
        self.base_url = validate_outbound_url(base_url).rstrip('/')
        self.api_token = api_token
        self.timeout = timeout

    def _request(self, *args, **kwargs):
        import httpx
        safe_args = list(args)
        if len(safe_args) >= 2 and isinstance(safe_args[1], str):
            safe_args[1] = _safe_relative_path(safe_args[1])
        try:
            with httpx.Client(base_url=self.base_url, timeout=self.timeout, trust_env=False,
             headers={'Authorization': f'Bearer {self.api_token}',
                'Content-Type': 'application/json'}) as c:
                r = c.request(*safe_args, **kwargs)
                data = r.json() if r.content else {}
        except Exception as exc:
            raise AppError(503, 'CARRIER_UNAVAILABLE', f'{self.name} carrier unavailable') from exc
        if r.status_code >= 400:
            raise AppError(502, 'CARRIER_ERROR', f'{self.name} carrier rejected the request')
        return data

    def quote(self, **kwargs):
        return self._request('POST', '/rates', json=kwargs).get('rates', [])

    def create_shipment(self, **kwargs):
        return self._request('POST', '/shipments', json=kwargs)

    def track(self, tracking_number):
        return self._request('GET', f'/shipments/{tracking_number}')

class ConfiguredCarrier(GenericHttpCarrier):
    """Provider adapter with deployment-supplied endpoint map. No provider-specific assumptions are baked in."""

    def __init__(self, *, name: str, base_url: str, api_token: str, rate_path: str='/rates',
     shipment_path: str='/shipments',
        tracking_path: str='/shipments/{tracking_number}', timeout: float=15):
        super().__init__(name=name, base_url=base_url, api_token=api_token, timeout=timeout)
        self.rate_path = _safe_relative_path(rate_path)
        self.shipment_path = _safe_relative_path(shipment_path)
        self.tracking_path = _safe_relative_path(tracking_path)

    def quote(self, *, origin, destination, parcels, currency):
        data = self._request('POST', self.rate_path, json={'origin': origin,
            'destination': destination, 'parcels': parcels, 'currency': currency})
        return [ShippingRate(self.name, x.get('service', 'standard'), int(x.get('amount_minor', 0)),
         str(x.get('currency',
            currency)).upper(), x.get('estimated_days'), x) for x in data.get('rates', [])]

    def create_shipment(self, *, order_id, origin, destination, parcels, service):
        return self._request('POST', self.shipment_path, json={'order_id': order_id,
            'origin': origin, 'destination': destination, 'parcels': parcels, 'service': service})

    def track(self, tracking_number):
        safe_tracking_number = quote(str(tracking_number), safe='')
        path = self.tracking_path.format(tracking_number=safe_tracking_number)
        return self._request('GET', path)

def build_carrier(code: str, config: dict):
    code = code.lower()
    if code == 'flat':
        return FlatRateCarrier(int(config.get('amount_minor', 0)), str(config.get('currency',
            'USD')), str(config.get('service', 'standard')))
    aliases = {'aramex': 'Aramex', 'dhl': 'DHL', 'smsa': 'SMSA', 'naqel': 'Naqel',
        'yurtici': 'Yurtici Kargo', 'aras': 'Aras Kargo', 'mng': 'MNG Kargo', 'ptt': 'PTT Kargo'}
    if code in aliases:
        return ConfiguredCarrier(name=aliases[code], base_url=config.get('base_url', ''),
         api_token=config.get('api_token',
         ''),
         rate_path=config.get('rate_path',
         '/rates'),
         shipment_path=config.get('shipment_path',
         '/shipments'),
         tracking_path=config.get('tracking_path',
            '/shipments/{tracking_number}'), timeout=float(config.get('timeout', 15)))
    raise AppError(400, 'CARRIER_UNSUPPORTED', 'Unsupported carrier')
