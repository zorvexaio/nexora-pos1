from __future__ import annotations
from datetime import datetime, timezone, timedelta
import hashlib, hmac, json, secrets
from dataclasses import dataclass
import httpx
from sqlalchemy.orm import Session
from app.core.config import get_settings
from app.core.errors import AppError
from app.core.security import encrypt_secret
from app.models.domain import MerchantIdentityVerification, MerchantRiskEvent, MerchantReviewCase, MerchantProfile
from app.services.core import audit, outbox, enforce_rate_limit


def sha256_hex(value: str | bytes) -> str:
    return hashlib.sha256(value.encode() if isinstance(value, str) else value).hexdigest()


def verify_hmac_sha256(raw_body: bytes, signature: str, secret: str) -> bool:
    if not signature or not secret:
        return False
    expected = hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature.strip().lower())


def _provider():
    s = get_settings()
    if s.MERCHANT_KYC_PROVIDER == 'veriff':
        return VeriffProvider(s)
    if s.MERCHANT_KYC_PROVIDER == 'mock':
        return MockIdentityProvider(s)
    raise AppError(503, 'KYC_PROVIDER_NOT_CONFIGURED', 'Merchant identity verification provider is not configured')


@dataclass
class IdentitySession:
    external_id: str
    verification_url: str | None
    expires_at: datetime | None
    provider: str


class MockIdentityProvider:
    name = 'mock'
    def __init__(self, settings): self.settings = settings
    def create_session(self, *, tenant_id: str, user_id: str, vendor_data: str, country_code: str, full_name: str):
        external_id = 'mock_' + secrets.token_urlsafe(18)
        return IdentitySession(external_id, f'{self.settings.PUBLIC_BASE_URL}/v1/merchant/identity/mock/{external_id}', datetime.now(timezone.utc)+timedelta(hours=24), self.name)


class VeriffProvider:
    name = 'veriff'
    def __init__(self, settings):
        self.settings = settings
        if not all([settings.VERIFF_API_BASE_URL, settings.VERIFF_API_KEY, settings.VERIFF_SHARED_SECRET]):
            raise AppError(503, 'VERIFF_NOT_CONFIGURED', 'Veriff credentials are not configured')
    def _headers(self, body: bytes) -> dict[str, str]:
        sig = hmac.new(self.settings.VERIFF_SHARED_SECRET.encode(), body, hashlib.sha256).hexdigest()
        return {'X-AUTH-CLIENT': self.settings.VERIFF_API_KEY, 'X-HMAC-SIGNATURE': sig, 'Content-Type': 'application/json'}
    def create_session(self, *, tenant_id: str, user_id: str, vendor_data: str, country_code: str, full_name: str):
        payload = {'verification': {'vendorData': vendor_data, 'endUserId': user_id, 'person': {'firstName': full_name.split(' ',1)[0], 'lastName': full_name.split(' ',1)[1] if ' ' in full_name else full_name, 'country': country_code}}}
        raw = json.dumps(payload, separators=(',', ':'), ensure_ascii=False).encode()
        try:
            with httpx.Client(timeout=self.settings.VERIFF_TIMEOUT_SECONDS, follow_redirects=False, trust_env=False) as client:
                r = client.post(self.settings.VERIFF_API_BASE_URL.rstrip('/') + '/v1/sessions', content=raw, headers=self._headers(raw))
                r.raise_for_status()
                data = r.json()
        except httpx.HTTPError as exc:
            raise AppError(503, 'KYC_PROVIDER_UNAVAILABLE', 'Identity verification provider is unavailable') from exc
        verification = data.get('verification') or {}
        external_id = str(verification.get('id') or '')
        if not external_id:
            raise AppError(502, 'KYC_PROVIDER_INVALID_RESPONSE', 'Identity provider returned no session identifier')
        url = verification.get('url') or verification.get('verification', {}).get('url')
        return IdentitySession(external_id, url, datetime.now(timezone.utc)+timedelta(hours=24), self.name)


def recalc_merchant_risk(db: Session, tenant_id: str) -> MerchantProfile:
    profile = db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    if not profile:
        raise AppError(404, 'MERCHANT_PROFILE_REQUIRED', 'Merchant profile not found')
    risk = 0
    if not profile.phone_verified_at: risk += 15
    if profile.kyc_status != 'VERIFIED': risk += 50
    if profile.review_required: risk += 25
    if profile.payout_hold: risk += 5
    open_cases = db.query(MerchantReviewCase).filter_by(tenant_id=tenant_id, status='OPEN').count()
    risk += min(20, open_cases * 10)
    recent = db.query(MerchantRiskEvent).filter(MerchantRiskEvent.tenant_id==tenant_id).order_by(MerchantRiskEvent.created_at.desc()).limit(50).all()
    risk += max(0, sum(max(0, e.score_delta) for e in recent))
    profile.risk_score = max(0, min(100, risk))
    profile.risk_level = 'HIGH' if profile.risk_score >= 70 else 'MEDIUM' if profile.risk_score >= 40 else 'LOW'
    profile.payout_hold = profile.kyc_status != 'VERIFIED' or profile.review_required or profile.risk_score >= 70
    return profile


def add_risk_event(db: Session, tenant_id: str, event_type: str, *, severity='INFO', score_delta=0, source='system', metadata=None, dedupe_key=None, actor_id=None):
    if dedupe_key and db.query(MerchantRiskEvent).filter_by(dedupe_key=dedupe_key).first():
        return None
    row = MerchantRiskEvent(tenant_id=tenant_id, event_type=event_type, severity=severity, score_delta=score_delta, source=source, dedupe_key=dedupe_key, metadata_json=metadata or {})
    db.add(row); db.flush()
    audit(db, tenant_id, actor_id, f'merchant.risk.{event_type.lower()}', 'MerchantRiskEvent', row.id, after={'severity':severity,'score_delta':score_delta,'source':source})
    return row


def open_review_case(db: Session, tenant_id: str, reason: str, *, verification_id=None, priority='NORMAL', actor_id=None):
    existing = db.query(MerchantReviewCase).filter_by(tenant_id=tenant_id, open_reason=reason).first()
    if existing:
        if existing.status != 'OPEN':
            existing.status='OPEN'; existing.resolution=None; existing.reviewer_note=None; existing.resolved_at=None
            existing.priority=priority
        if verification_id:
            existing.verification_id=verification_id
        return existing
    case = MerchantReviewCase(tenant_id=tenant_id, verification_id=verification_id, open_reason=reason, priority=priority)
    db.add(case); db.flush()
    profile = db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    if profile:
        profile.review_required = True
        profile.payout_hold = True
        profile.trust_lock_reason = reason
    outbox(db, tenant_id, 'merchant_review_case', case.id, 'merchant.review.required', {'reason':reason,'priority':priority})
    audit(db, tenant_id, actor_id, 'merchant.review.opened', 'MerchantReviewCase', case.id, after={'reason':reason,'priority':priority})
    return case


def start_identity_verification(db: Session, tenant_id: str, user_id: str, *, country_code: str, full_name: str, request_host: str | None = None):
    existing = db.query(MerchantIdentityVerification).filter_by(tenant_id=tenant_id).filter(MerchantIdentityVerification.status.in_(['CREATED','STARTED','SUBMITTED','IN_REVIEW'])).order_by(MerchantIdentityVerification.created_at.desc()).first()
    if existing and existing.verification_url:
        return existing
    vendor_data = f'{tenant_id}:{user_id}:{secrets.token_hex(8)}'
    session = _provider().create_session(tenant_id=tenant_id, user_id=user_id, vendor_data=vendor_data, country_code=country_code, full_name=full_name)
    row = MerchantIdentityVerification(tenant_id=tenant_id, user_id=user_id, provider=session.provider, external_id=session.external_id, status='STARTED', country_code=country_code.upper(), verification_url=session.verification_url, vendor_data_hash=sha256_hex(vendor_data), expires_at=session.expires_at, started_at=datetime.now(timezone.utc), created_at=datetime.now(timezone.utc), updated_at=datetime.now(timezone.utc))
    db.add(row); db.flush()
    profile = db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    profile.kyc_provider = session.provider; profile.kyc_status='IN_PROGRESS'; profile.kyc_external_id=session.external_id; profile.identity_status='PENDING'; profile.payout_hold=True; profile.updated_at=datetime.now(timezone.utc)
    add_risk_event(db, tenant_id, 'KYC_STARTED', score_delta=5, source=session.provider, dedupe_key=f'kyc-start:{row.id}', actor_id=user_id)
    db.commit()
    return row


def apply_identity_decision(db: Session, *, provider: str, external_id: str, event_id: str | None, decision: str, status: str | None = None, risk_level: str | None = None, metadata=None):
    row = db.query(MerchantIdentityVerification).filter_by(provider=provider, external_id=external_id).first()
    if not row:
        return False
    if event_id and row.provider_event_id == event_id:
        return True
    if event_id:
        row.provider_event_id = event_id
    now = datetime.now(timezone.utc)
    normalized = decision.upper().replace(' ', '_')
    terminal = {'APPROVED','DECLINED','FAILED','RESUBMISSION_REQUESTED','ABANDONED','EXPIRED','REVIEW'}
    # Provider webhooks are at-least-once and may arrive out of order. Once a session
    # has a terminal decision, never let a later delivery regress that decision.
    if row.completed_at is not None and row.decision in terminal:
        return True
    row.decision = normalized
    row.status = (status or normalized).upper().replace(' ', '_')
    row.risk_level = (risk_level or '').upper() or None
    row.provider_metadata = metadata or {}
    row.updated_at = now
    row.completed_at = now if normalized in {'APPROVED','DECLINED','RESUBMISSION_REQUESTED','ABANDONED','EXPIRED','REVIEW'} else row.completed_at
    profile = db.query(MerchantProfile).filter_by(tenant_id=row.tenant_id).first()
    if normalized == 'APPROVED':
        profile.kyc_status='VERIFIED'; profile.identity_status='VERIFIED'; profile.kyc_verified_at=now; profile.review_required=False
        profile.trust_lock_reason=None
        add_risk_event(db, row.tenant_id, 'KYC_APPROVED', score_delta=-50, source=provider, dedupe_key=f'kyc-approved:{row.id}', metadata={'external_id':row.external_id})
    elif normalized in {'DECLINED','FAILED'}:
        profile.kyc_status='DECLINED'; profile.identity_status='REJECTED'; profile.review_required=False; profile.payout_hold=True
        row.failure_reason = 'Identity verification was declined by provider'
        add_risk_event(db, row.tenant_id, 'KYC_DECLINED', severity='HIGH', score_delta=50, source=provider, dedupe_key=f'kyc-declined:{row.id}', metadata={'external_id':row.external_id})
        open_review_case(db, row.tenant_id, 'KYC_DECLINED', verification_id=row.id, priority='HIGH')
    elif normalized in {'REVIEW','NEEDS_REVIEW'}:
        profile.kyc_status='IN_REVIEW'; profile.identity_status='PENDING'; profile.review_required=True; profile.payout_hold=True
        add_risk_event(db, row.tenant_id, 'KYC_REVIEW', severity='WARN', score_delta=20, source=provider, dedupe_key=f'kyc-review:{row.id}', metadata={'external_id':row.external_id})
        open_review_case(db, row.tenant_id, 'KYC_REVIEW', verification_id=row.id, priority='HIGH')
    else:
        profile.kyc_status='IN_PROGRESS'; profile.payout_hold=True
    recalc_merchant_risk(db, row.tenant_id)
    audit(db, row.tenant_id, None, 'merchant.kyc.decision', 'MerchantIdentityVerification', row.id, after={'provider':provider,'decision':normalized,'status':row.status})
    db.commit()
    return True
