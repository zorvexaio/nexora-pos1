from datetime import datetime, timezone
import hashlib, json, hmac
from sqlalchemy import func
from app.core.errors import AppError, forbidden
from app.core.security import token_hash
from app.models.domain import AgentProfile, AgentActionAudit, TenantRegionPolicy, FinancialReconciliationRun, FinancialReconciliationMismatch, PaymentCapture, JournalLine, JournalEntry

AGENT_SCOPES = {'catalog:read', 'cart:create', 'checkout:read', 'checkout:complete', 'order:read'}
REGIONS = {'eu-west-1', 'eu-central-1', 'me-south-1', 'ap-southeast-1', 'us-east-1'}

def validate_agent_scopes(scopes):
    scopes = [str(x).strip() for x in (scopes or []) if str(x).strip()]
    unknown = sorted(set(scopes) - AGENT_SCOPES)
    if unknown:
        raise AppError(400, 'AGENT_SCOPE_INVALID', f'Unsupported agent scope: {unknown[0]}')
    return sorted(set(scopes))

def authorize_agent_action(db, tenant_id, agent_client_id, agent_secret, action, resource_type, resource_id=None, request_hash='', idempotency_key=''):
    if not agent_client_id or not agent_secret or not idempotency_key:
        raise AppError(428, 'AGENT_CREDENTIALS_REQUIRED', 'agent_client_id, agent credential and Idempotency-Key are required')
    profile = (db.query(AgentProfile)
        .filter_by(tenant_id=tenant_id, client_id=agent_client_id, status='ACTIVE')
        .with_for_update()
        .first())
    if not profile or not profile.client_secret_hash or not hmac.compare_digest(profile.client_secret_hash, token_hash(agent_secret)):
        raise forbidden('Agent credential invalid')
    scope = {'catalog.read':'catalog:read', 'checkout.create':'cart:create', 'checkout.complete':'checkout:complete'}.get(action, action)
    if scope not in set(profile.scopes or []):
        reason = f'Missing scope: {scope}'
        db.add(AgentActionAudit(tenant_id=tenant_id, agent_profile_id=profile.id, action=action, resource_type=resource_type, resource_id=resource_id, decision='DENIED', reason=reason, idempotency_key=idempotency_key, request_hash=request_hash))
        db.flush()
        raise forbidden('Agent scope denied')
    existing = db.query(AgentActionAudit).filter_by(tenant_id=tenant_id, agent_profile_id=profile.id, idempotency_key=idempotency_key).first()
    if existing:
        if existing.request_hash != request_hash or existing.action != action:
            raise AppError(409, 'AGENT_IDEMPOTENCY_MISMATCH', 'Agent idempotency key reused with different request')
        return profile, existing
    minute_floor = datetime.now(timezone.utc).replace(second=0, microsecond=0)
    recent_count = db.query(func.count(AgentActionAudit.id)).filter(AgentActionAudit.tenant_id == tenant_id, AgentActionAudit.agent_profile_id == profile.id, AgentActionAudit.created_at >= minute_floor, AgentActionAudit.decision == 'ALLOWED').scalar() or 0
    if int(recent_count) >= int(profile.rate_limit_per_minute):
        reason = 'Agent rate limit exceeded'
        db.add(AgentActionAudit(tenant_id=tenant_id, agent_profile_id=profile.id, action=action, resource_type=resource_type, resource_id=resource_id, decision='DENIED', reason=reason, idempotency_key=idempotency_key, request_hash=request_hash))
        db.flush()
        raise AppError(429, 'AGENT_RATE_LIMITED', 'Agent action rate limit exceeded')
    audit = AgentActionAudit(tenant_id=tenant_id, agent_profile_id=profile.id, action=action, resource_type=resource_type, resource_id=resource_id, decision='ALLOWED', reason='Scope granted', idempotency_key=idempotency_key, request_hash=request_hash)
    db.add(audit)
    db.flush()
    return profile, audit

def ensure_region_policy(db, tenant_id):
    row = db.query(TenantRegionPolicy).filter_by(tenant_id=tenant_id).first()
    if not row:
        row = TenantRegionPolicy(tenant_id=tenant_id, home_region='eu-west-1', allowed_regions=['eu-west-1'], residency_mode='HOME_REGION_ONLY', cross_border_transfer_allowed=False)
        db.add(row); db.flush()
    return row

def validate_region_policy(home_region, allowed_regions, residency_mode, cross_border_transfer_allowed, transfer_basis=None):
    home = str(home_region or '').strip()
    allowed = [str(x).strip() for x in (allowed_regions or []) if str(x).strip()]
    if home not in REGIONS or any(x not in REGIONS for x in allowed):
        raise AppError(400, 'REGION_INVALID', 'Unsupported deployment region')
    if home not in allowed:
        allowed.append(home)
    mode = str(residency_mode or 'HOME_REGION_ONLY').upper()
    if mode not in {'HOME_REGION_ONLY', 'APPROVED_REGIONS'}:
        raise AppError(400, 'RESIDENCY_MODE_INVALID', 'Unsupported residency mode')
    if mode == 'HOME_REGION_ONLY' and len(set(allowed)) > 1:
        raise AppError(409, 'RESIDENCY_POLICY_CONFLICT', 'HOME_REGION_ONLY cannot allow multiple regions')
    if cross_border_transfer_allowed and not transfer_basis:
        raise AppError(422, 'TRANSFER_BASIS_REQUIRED', 'A transfer basis is required when cross-border transfer is enabled')
    return home, sorted(set(allowed)), mode

def run_financial_reconciliation(db, tenant_id, period_start, period_end, currency):
    cur = currency.upper()
    existing = db.query(FinancialReconciliationRun).filter_by(tenant_id=tenant_id, period_start=period_start, period_end=period_end, currency=cur).first()
    if existing and existing.status == 'COMPLETED':
        return existing
    run = existing or FinancialReconciliationRun(tenant_id=tenant_id, period_start=period_start, period_end=period_end, currency=cur)
    if not existing:
        db.add(run); db.flush()
    captured = db.query(func.coalesce(func.sum(PaymentCapture.amount_minor), 0)).filter(PaymentCapture.tenant_id==tenant_id, PaymentCapture.currency==cur, PaymentCapture.created_at>=period_start, PaymentCapture.created_at<period_end).scalar() or 0
    debit, credit = db.query(func.coalesce(func.sum(JournalLine.debit_minor),0), func.coalesce(func.sum(JournalLine.credit_minor),0)).join(JournalEntry, JournalEntry.id==JournalLine.journal_entry_id).filter(JournalLine.tenant_id==tenant_id, JournalLine.currency==cur, JournalEntry.created_at>=period_start, JournalEntry.created_at<period_end).one()
    run.payment_captured_minor=int(captured); run.ledger_debit_minor=int(debit); run.ledger_credit_minor=int(credit)
    run.delta_minor=int(debit)-int(credit)
    run.mismatch_count=0
    run.details={'double_entry_balanced': int(debit)==int(credit), 'captured_minus_ledger_debit': int(captured)-int(debit)}
    if int(debit) != int(credit):
        run.mismatch_count += 1
        db.add(FinancialReconciliationMismatch(tenant_id=tenant_id, reconciliation_run_id=run.id, category='LEDGER_UNBALANCED', reference_type='journal', reference_id=run.id, expected_minor=int(debit), observed_minor=int(credit), delta_minor=int(debit)-int(credit), currency=cur, details={'period_start':period_start.isoformat(),'period_end':period_end.isoformat()}))
    if int(captured) != int(debit):
        run.mismatch_count += 1
        db.add(FinancialReconciliationMismatch(tenant_id=tenant_id, reconciliation_run_id=run.id, category='CAPTURE_LEDGER_DELTA', reference_type='payments', reference_id=run.id, expected_minor=int(captured), observed_minor=int(debit), delta_minor=int(captured)-int(debit), currency=cur, details={}))
    captures = db.query(PaymentCapture).filter(PaymentCapture.tenant_id == tenant_id, PaymentCapture.currency == cur, PaymentCapture.created_at >= period_start, PaymentCapture.created_at < period_end).all()
    for capture in captures:
        posted = db.query(func.coalesce(func.sum(JournalLine.debit_minor), 0)).join(JournalEntry, JournalEntry.id == JournalLine.journal_entry_id).filter(
            JournalLine.tenant_id == tenant_id, JournalEntry.tenant_id == tenant_id, JournalEntry.reference_id == capture.payment_intent_id,
            JournalEntry.created_at >= period_start, JournalEntry.created_at < period_end, JournalLine.currency == cur).scalar() or 0
        if int(posted) != int(capture.amount_minor):
            run.mismatch_count += 1
            db.add(FinancialReconciliationMismatch(tenant_id=tenant_id, reconciliation_run_id=run.id, category='PAYMENT_REFERENCE_MISMATCH', reference_type='payment_capture', reference_id=capture.id, expected_minor=int(capture.amount_minor), observed_minor=int(posted), delta_minor=int(capture.amount_minor)-int(posted), currency=cur, details={'payment_intent_id': capture.payment_intent_id, 'provider_capture_id': capture.provider_capture_id}))
    run.status='MATCHED' if run.mismatch_count == 0 else 'MISMATCH'
    run.completed_at=datetime.now(timezone.utc)
    db.flush()
    return run
