import hashlib
import json
import secrets
from datetime import datetime, timezone
from app.core.errors import AppError, not_found
from app.models.domain import AppDefinition, AppInstallation, AppReview, AppListing, WorkflowDefinition, WorkflowRun, WorkflowStepRun, Coupon, Promotion, LoyaltyAccount, LoyaltyTransaction, Customer
from app.services.mailer import send_email
from app.services.core import audit, outbox

ALLOWED_STEPS = {'SEND_EMAIL', 'CREATE_COUPON', 'WEBHOOK', 'ADD_LOYALTY_POINTS'}

def validate_steps(steps):
    if not isinstance(steps, list) or len(steps) > 25:
        raise AppError(400, 'WORKFLOW_STEPS_INVALID', 'A workflow must contain 0-25 steps')
    for index, step in enumerate(steps):
        if not isinstance(step, dict) or step.get('type') not in ALLOWED_STEPS:
            raise AppError(400, 'WORKFLOW_STEP_UNSUPPORTED', f'Unsupported workflow step at position {index}')
        if step.get('type') == 'WEBHOOK' and not str(step.get('url') or '').startswith('https://'):
            raise AppError(400, 'WORKFLOW_WEBHOOK_INVALID', 'Workflow webhooks must use HTTPS')
    return steps

def _hash(value):
    return hashlib.sha256(str(value).encode()).hexdigest()

def execute_workflow(db, workflow, run, actor_id=None):
    steps = validate_steps(workflow.steps or [])
    run.status = 'RUNNING'
    run.started_at = datetime.now(timezone.utc)
    db.flush()
    outputs = []
    for position, step in enumerate(steps):
        step_type = step['type']
        row = WorkflowStepRun(
            tenant_id=run.tenant_id,
            workflow_run_id=run.id,
            position=position,
            step_type=step_type,
            input_payload={k: v for k, v in step.items() if k not in {'secret', 'headers'}},
            status='RUNNING',
            started_at=datetime.now(timezone.utc),
        )
        db.add(row)
        db.flush()
        try:
            payload = run.input_payload or {}
            if step_type == 'SEND_EMAIL':
                recipient = str(payload.get(step.get('recipient_field', 'email')) or step.get('to') or '').strip()
                if '@' not in recipient:
                    raise AppError(422, 'WORKFLOW_EMAIL_RECIPIENT', 'A valid recipient is required')
                send_email(recipient, str(step.get('subject') or workflow.name)[:255], str(step.get('body') or json.dumps(payload, ensure_ascii=False)))
                result = {'sent': True, 'recipient_sha256': _hash(recipient)}
            elif step_type == 'CREATE_COUPON':
                code = str(step.get('code') or '').strip().upper() or secrets.token_hex(5).upper()
                promotion = Promotion(
                    tenant_id=run.tenant_id,
                    name=str(step.get('name') or f'Workflow {workflow.slug}'),
                    discount_type=str(step.get('discount_type') or 'percentage'),
                    value_minor=int(step.get('value_minor') or 0),
                    percentage_bps=int(step.get('percentage_bps') or 0),
                    status='ACTIVE',
                    usage_limit=step.get('usage_limit'),
                )
                db.add(promotion)
                db.flush()
                coupon = Coupon(tenant_id=run.tenant_id, promotion_id=promotion.id, code=code, status='ACTIVE', usage_limit=step.get('usage_limit'))
                db.add(coupon)
                db.flush()
                result = {'coupon_id': coupon.id, 'code': coupon.code}
            elif step_type == 'ADD_LOYALTY_POINTS':
                customer_id = str(payload.get(step.get('customer_field', 'customer_id')) or '')
                customer = db.query(Customer).filter_by(id=customer_id, tenant_id=run.tenant_id).first()
                if not customer:
                    raise not_found('Workflow customer not found')
                account = db.query(LoyaltyAccount).filter_by(tenant_id=run.tenant_id, customer_id=customer.id).first()
                if not account:
                    account = LoyaltyAccount(tenant_id=run.tenant_id, customer_id=customer.id)
                    db.add(account)
                    db.flush()
                points = int(step.get('points') or 0)
                if points <= 0:
                    raise AppError(422, 'WORKFLOW_POINTS_INVALID', 'Points must be positive')
                idem = f'workflow:{run.id}:{position}'
                existing = db.query(LoyaltyTransaction).filter_by(tenant_id=run.tenant_id, idempotency_key=idem).first()
                if not existing:
                    account.points_balance += points
                    account.lifetime_earned += points
                    db.add(LoyaltyTransaction(tenant_id=run.tenant_id, loyalty_account_id=account.id, points_delta=points, reason='WORKFLOW', idempotency_key=idem))
                result = {'customer_id': customer.id, 'points': points}
            else:
                outbox(db, run.tenant_id, 'workflow_run', run.id, 'workflow.webhook.requested', {
                    'url': step.get('url'),
                    'payload': payload,
                    'workflow_run_id': run.id,
                    'step_position': position,
                })
                result = {'queued': True, 'url_host': str(step.get('url')).split('/')[2]}
            row.status = 'QUEUED' if step_type == 'WEBHOOK' else 'COMPLETED'
            row.output_payload = result
            row.completed_at = datetime.now(timezone.utc)
            outputs.append(result)
            db.flush()
        except Exception as exc:
            row.status = 'FAILED'
            row.error_message = str(exc)[:500]
            row.completed_at = datetime.now(timezone.utc)
            run.status = 'FAILED'
            run.error_message = str(exc)[:500]
            db.flush()
            return run
    run.status = 'COMPLETED'
    run.completed_at = datetime.now(timezone.utc)
    run.output_payload = {'steps': outputs}
    audit(db, run.tenant_id, actor_id, 'workflow.run.completed', 'workflow_run', run.id, after={'steps': len(outputs)})
    return run

def app_rating_summary(db, app_id):
    rows = db.query(AppReview).filter_by(app_id=app_id, status='PUBLISHED').all()
    if not rows:
        return {'rating': 0.0, 'review_count': 0}
    return {'rating': round(sum(r.rating for r in rows) / len(rows), 2), 'review_count': len(rows)}
