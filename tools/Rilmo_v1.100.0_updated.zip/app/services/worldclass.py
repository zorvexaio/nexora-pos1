import hashlib
from datetime import datetime, timedelta, timezone

from sqlalchemy import func

from app.core.errors import AppError
from app.models.domain import (
    InventoryItem,
    LiveStorefrontEvent,
    Order,
    Product,
    ProductVariant,
    ProductFeed,
)


def stable_variant(key: str, variants: list, traffic_bps: int) -> str:
    if not variants:
        raise AppError(422, 'EXPERIMENT_VARIANTS_REQUIRED', 'Experiment variants are required')
    try:
        traffic = int(traffic_bps)
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'EXPERIMENT_TRAFFIC_INVALID', 'traffic_bps must be an integer') from exc
    if not 0 <= traffic <= 10000:
        raise AppError(422, 'EXPERIMENT_TRAFFIC_INVALID', 'traffic_bps must be between 0 and 10000')

    bucket = int(hashlib.sha256(str(key).encode()).hexdigest()[:8], 16) % 10000
    if bucket >= traffic:
        return str(variants[0].get('key') or 'control')

    cursor = 0
    for item in variants:
        weight = max(0, int(item.get('weight_bps', 0)))
        cursor += weight
        if bucket < cursor:
            return str(item.get('key') or 'control')

    # Misconfigured weights fail safe to the first/control variant rather than
    # silently selecting an arbitrary tail variant.
    return str(variants[0].get('key') or 'control')


def storefront_metrics(db, tenant_id: str, days: int = 30) -> dict:
    try:
        window_days = max(1, min(365, int(days)))
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'ANALYTICS_WINDOW_INVALID', 'days must be an integer') from exc

    now = datetime.now(timezone.utc)
    start = now - timedelta(days=window_days)
    events = (
        db.query(LiveStorefrontEvent)
        .filter(
            LiveStorefrontEvent.tenant_id == tenant_id,
            LiveStorefrontEvent.created_at >= start,
        )
        .all()
    )
    visits = purchases = revenue = 0
    by_kind: dict[str, int] = {}
    for event in events:
        kind = getattr(event, 'event_type', None) or getattr(event, 'name', None) or 'event'
        by_kind[kind] = by_kind.get(kind, 0) + 1
        if kind in {'page_view', 'view', 'session'}:
            visits += 1

    orders = (
        db.query(Order)
        .filter(
            Order.tenant_id == tenant_id,
            Order.created_at >= start,
            Order.status.notin_({'CANCELLED', 'DRAFT'}),
        )
        .all()
    )
    for order in orders:
        revenue += int(order.total_minor or 0)
        purchases += 1

    return {
        'window_days': window_days,
        'visits': visits,
        'purchases': purchases,
        'conversion_rate_bps': int(purchases * 10000 / visits) if visits else 0,
        'revenue_minor': revenue,
        'events': by_kind,
    }


def catalog_for_agent(
    db, tenant_id: str, country_code: str = 'US', locale: str = 'en', limit: int = 100
):
    try:
        bounded_limit = max(1, min(int(limit), 250))
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'CATALOG_LIMIT_INVALID', 'limit must be an integer') from exc

    rows = (
        db.query(Product, ProductVariant)
        .join(ProductVariant, ProductVariant.product_id == Product.id)
        .filter(
            Product.tenant_id == tenant_id,
            Product.deleted_at.is_(None),
            Product.status == 'PUBLISHED',
            ProductVariant.tenant_id == tenant_id,
            ProductVariant.status == 'ACTIVE',
        )
        .order_by(Product.id, ProductVariant.id)
        .limit(bounded_limit)
        .all()
    )
    items = []
    for product, variant in rows:
        available = (
            db.query(func.coalesce(func.sum(InventoryItem.available), 0))
            .filter(
                InventoryItem.tenant_id == tenant_id,
                InventoryItem.variant_id == variant.id,
            )
            .scalar()
            or 0
        )
        items.append(
            {
                'id': product.id,
                'variant_id': variant.id,
                'title': product.title,
                'description': product.description or '',
                'sku': variant.sku,
                'currency': variant.currency,
                'price_minor': int(variant.price_amount_minor),
                'availability': 'in_stock' if int(available) > 0 else 'out_of_stock',
                'available_quantity': int(available),
                'country_code': str(country_code or 'US').upper()[:2],
                'locale': str(locale or 'en').lower()[:20],
            }
        )
    return items


def compute_feed(db, feed: ProductFeed) -> list[dict]:
    return catalog_for_agent(db, feed.tenant_id, feed.country_code, feed.locale, 250)
