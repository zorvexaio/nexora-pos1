from app.core.errors import AppError
ORDER_TRANSITIONS = {'DRAFT': {'PENDING_PAYMENT', 'CANCELLED'}, 'PENDING_PAYMENT': {'CONFIRMED',
 'CANCELLED'},
 'CONFIRMED': {'PROCESSING',
 'CANCELLED',
 'SHIPPED'},
 'PROCESSING': {'SHIPPED',
 'CANCELLED'},
    'SHIPPED': {'DELIVERED'}, 'DELIVERED': {'FULFILLED'}, 'FULFILLED': set(), 'CANCELLED': set()}

def transition(order, new_state: str):
    old = order.status
    if old == new_state:
        return
    if new_state not in ORDER_TRANSITIONS.get(old, set()):
        raise AppError(409, 'ORDER_STATE_INVALID',
            f'Cannot transition order from {old} to {new_state}')
    order.status = new_state
    return old
