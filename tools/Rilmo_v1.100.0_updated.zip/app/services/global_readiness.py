from datetime import datetime, timezone
from app.core.errors import AppError

APP_STORE_POLICY = {
    'apple': {
        'physical_goods': {'payment_method': 'merchant_processor_or_apple_pay', 'allowed': True, 'reference': 'Apple App Review Guidelines 3.1.3(e)'},
        'digital_goods': {'payment_method': 'apple_iap_or_region_exception', 'allowed': True, 'reference': 'Apple App Review Guidelines 3.1'},
    },
    'google_play': {
        'physical_goods': {'payment_method': 'merchant_processor_or_google_pay', 'allowed': True, 'reference': 'Google Play Payments policy'},
        'digital_goods': {'payment_method': 'google_play_billing_or_region_exception', 'allowed': True, 'reference': 'Google Play Payments policy'},
    },
}

DEFAULT_MARKETS = {
    'TR': {'name': 'Turkey', 'requirements': ['TR-KVKK-LEGAL-REVIEW','TR-PAYMENT-PROVIDER-LICENSE-EVIDENCE','TR-CONSUMER-DISTANCE-SALES','TR-EINVOICE']},
    'SA': {'name': 'Saudi Arabia', 'requirements': ['SA-ZATCA-EINVOICE','SA-VAT-LEGAL-REVIEW','SA-CONSUMER-COMMERCE-LEGAL-REVIEW']},
    'EU': {'name': 'European Union', 'requirements': ['EU-GDPR-LEGAL-REVIEW','EU-DSA-MARKETPLACE-TRACEABILITY','EU-VAT-OSS-IOSS-REVIEW','EU-DPP-REGULATORY-REVIEW']},
    'US': {'name': 'United States', 'requirements': ['US-SALES-TAX-NEXUS-REVIEW','US-STATE-PRIVACY-REVIEW','US-CONSUMER-POLICY-REVIEW']},
    'GB': {'name': 'United Kingdom', 'requirements': ['GB-UK-GDPR-LEGAL-REVIEW','GB-VAT-CONSUMER-REVIEW']},
}

def seed_default_market_profiles(db, uid_fn, now_fn):
    from app.models.domain import GlobalMarketProfile, AppStoreDistributionPolicy, JurisdictionCompliancePolicy, PrivacyProcessingActivity
    from app.services.legal_compliance import JURISDICTION_DEFAULTS
    changed=False
    for jurisdiction, policy in JURISDICTION_DEFAULTS.items():
        countries = policy.get('country_codes') or []
        first_country = countries[0] if len(countries) == 1 else None
        exists = db.query(JurisdictionCompliancePolicy).filter_by(jurisdiction=jurisdiction, policy_version='2026-08-20').first()
        if not exists:
            db.add(JurisdictionCompliancePolicy(
                id=uid_fn(), jurisdiction=jurisdiction, country_code=first_country, policy_version='2026-08-20',
                effective_date='2026-08-20', rights=policy.get('rights',[]), consent_categories=policy.get('consent_required_categories',[]),
                transfer_mechanisms=[policy.get('transfer_default','APPROVED_MECHANISM')],
                breach_authority_hours=policy.get('breach_authority_hours'), dsr_due_days=int(policy.get('dsr_due_days',45)),
                cookie_opt_in_required=bool(policy.get('cookie_opt_in_required',False)), gpc_signal_respected=bool(policy.get('gpc_signal_respected',False)),
                ai_interaction_disclosure_required=bool(policy.get('ai_interaction_disclosure_required',False)),
                ai_generated_marking_required=bool(policy.get('ai_generated_marking_required',False)),
                admt_risk_assessment_required=bool(policy.get('admt_risk_assessment_required',False)),
                dsa_marketplace_controls=bool(policy.get('dsa_marketplace_controls',False)),
                requirements={'country_codes':countries,'engineering_note':policy.get('dsr_due_days_authority_note')},
                created_at=now_fn(), updated_at=now_fn()
            )); changed=True
    seed_ropa = [
        ('account-service','Account, authentication and service delivery',{'GDPR':'contract','KVKK':'contract','LGPD':'legal_basis'},['account','security'],['account_holder'],['Rilmo'],['jurisdictional_controls'],'active-account-plus-legal-retention',False,False,None,'privacy_officer'),
        ('commerce-orders','Order fulfilment, support, disputes and accounting',{'GDPR':'contract/legal_obligation','KVKK':'contract/legal_obligation','LGPD':'legal_obligation'},['orders','contact','shipping','financial_records'],['buyers','merchants'],['Rilmo','payment_processor','carrier'],['approved_transfer_mechanism'],'jurisdiction-tax-and-dispute-schedule',False,False,None,'compliance_officer'),
        ('customer-ai-assistant','AI assistance for customer product discovery and support',{'GDPR':'contract/consent-as-applicable','KVKK':'applicable_lawful_basis','LGPD':'applicable_legal_basis'},['question','catalog_context','own_order_status'],['customers'],['Rilmo AI service'],['no_external_transfer_by_default'],'short-lived-cache-plus-audit-schedule',True,False,'customer-agent','privacy_officer'),
        ('merchant-ai-analysis','Merchant analytics, content suggestions and operational summaries',{'GDPR':'contract/legitimate_interest-as-assessed','KVKK':'applicable_lawful_basis','CCPA':'business_purpose'},['catalog','inventory_summary','aggregate_reports'],['merchants','staff'],['Rilmo'],['no_external_transfer_by_default'],'tenant-configured-and-minimized',True,False,'merchant-agent','privacy_officer'),
    ]
    for args in seed_ropa:
        key=args[0]
        if not db.query(PrivacyProcessingActivity).filter_by(activity_key=key).first():
            db.add(PrivacyProcessingActivity(id=uid_fn(),activity_key=args[0],purpose=args[1],legal_bases=args[2],data_categories=args[3],data_subject_categories=args[4],recipients=args[5],transfer_mechanisms=args[6],retention_rule=args[7],dpia_required=args[8],automated_decisioning=args[9],ai_system=args[10],owner_role=args[11],created_at=now_fn(),updated_at=now_fn())); changed=True
    for market_key, meta in DEFAULT_MARKETS.items():
        row=db.query(GlobalMarketProfile).filter_by(market_key=market_key).first()
        if not row:
            row=GlobalMarketProfile(id=uid_fn(), market_key=market_key, country_code='EU' if market_key=='EU' else market_key, requirements={'checks':meta['requirements']}, created_at=now_fn(), updated_at=now_fn())
            db.add(row); changed=True
        for platform, rules in APP_STORE_POLICY.items():
            for sku, rule in rules.items():
                exists=db.query(AppStoreDistributionPolicy).filter_by(platform=platform,market_key=market_key,sku_category=sku).first()
                if not exists:
                    db.add(AppStoreDistributionPolicy(id=uid_fn(),platform=platform,market_key=market_key,sku_category=sku,payment_method=rule['payment_method'],allowed=rule['allowed'],policy_reference=rule['reference'],created_at=now_fn())); changed=True
    if changed: db.commit()
    return changed

def readiness_summary(db, market_key=None):
    from app.models.domain import GlobalMarketProfile, GlobalLaunchEvidence
    markets=db.query(GlobalMarketProfile)
    if market_key: markets=markets.filter_by(market_key=market_key)
    rows=markets.all()
    out=[]
    now=datetime.now(timezone.utc)
    for m in rows:
        reqs=(m.requirements or {}).get('checks',[])
        evidence={e.requirement_code:e for e in db.query(GlobalLaunchEvidence).filter_by(market_key=m.market_key).all()}
        def _is_expired(exp):
            if not exp: return False
            if exp.tzinfo is None: exp=exp.replace(tzinfo=timezone.utc)
            return exp <= now
        missing=[r for r in reqs if evidence.get(r) is None or evidence[r].status != 'VERIFIED' or _is_expired(evidence[r].expires_at)]
        out.append({'market_key':m.market_key,'country_code':m.country_code,'status':m.status,'missing_requirements':missing,'ready':not missing and m.legal_review_status=='VERIFIED' and m.tax_invoicing_status=='VERIFIED' and m.payments_status=='VERIFIED' and m.data_transfer_status=='VERIFIED' and m.app_store_status=='VERIFIED'})
    return out

def require_market_ready(db, market_key):
    rows=readiness_summary(db, market_key)
    if not rows or not rows[0]['ready']:
        raise AppError(428,'MARKET_NOT_READY','Market is blocked until all required external evidence and reviews are verified')
    return rows[0]
