from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

from app.core.errors import AppError


class FXProvider:
    """Exchange-rate contract; production must supply fresh rates from an approved provider."""

    name = "none"

    def quote(self, *, base: str, quote: str) -> Decimal:
        base, quote = base.upper(), quote.upper()
        if base == quote:
            return Decimal("1")
        raise AppError(503, "FX_NOT_CONFIGURED", "Live exchange-rate provider is not configured")

    def convert_minor(self, *, amount_minor: int, base: str, quote: str) -> int:
        if amount_minor < 0:
            raise AppError(400, "FX_AMOUNT_INVALID", "Amount cannot be negative")
        rate = self.quote(base=base, quote=quote)
        return int((Decimal(amount_minor) * rate).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def get_fx_provider() -> FXProvider:
    return FXProvider()
