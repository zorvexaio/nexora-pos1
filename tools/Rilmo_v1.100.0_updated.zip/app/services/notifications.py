from __future__ import annotations

import base64
import urllib.parse
import httpx

from app.core.config import get_settings
from app.core.errors import AppError


class SMSProvider:
    name = "none"

    def send(self, *, to: str, message: str) -> str:
        raise AppError(503, "SMS_NOT_CONFIGURED", "SMS provider is not configured")


class TwilioSMSProvider(SMSProvider):
    name = "twilio"

    def __init__(self) -> None:
        settings = get_settings()
        if not all([settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN, settings.TWILIO_FROM_NUMBER]):
            raise AppError(503, "SMS_NOT_CONFIGURED", "Twilio credentials are not configured")
        self.sid = settings.TWILIO_ACCOUNT_SID
        self.auth = settings.TWILIO_AUTH_TOKEN
        self.from_number = settings.TWILIO_FROM_NUMBER

    def send(self, *, to: str, message: str) -> str:
        if not to or not message:
            raise AppError(400, "SMS_INVALID", "Recipient and message are required")
        url = f"https://api.twilio.com/2010-04-01/Accounts/{urllib.parse.quote(self.sid, safe='')}/Messages.json"
        token = base64.b64encode(f"{self.sid}:{self.auth}".encode()).decode()
        try:
            with httpx.Client(timeout=15.0, trust_env=False) as client:
                response = client.post(
                    url,
                    data={"To": to, "From": self.from_number, "Body": message},
                    headers={"Authorization": f"Basic {token}"},
                )
        except Exception as exc:
            raise AppError(503, "SMS_UNAVAILABLE", "SMS provider unavailable") from exc
        if response.status_code >= 400:
            raise AppError(502, "SMS_PROVIDER_ERROR", "SMS provider rejected the request")
        return str(response.json().get("sid", ""))


def get_sms_provider() -> SMSProvider:
    provider = get_settings().SMS_PROVIDER.lower().strip()
    return TwilioSMSProvider() if provider == "twilio" else SMSProvider()
