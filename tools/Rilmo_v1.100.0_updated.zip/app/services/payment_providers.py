"""Provider adapters. External calls are deliberately isolated from DB transactions."""
from dataclasses import dataclass
from typing import Any
import httpx
from app.core.config import get_settings
from app.core.errors import AppError
from abc import ABC, abstractmethod


def _provider_base(setting_name: str, supplied: str | None) -> str:
    settings = get_settings()
    # Merchant-controlled provider endpoints are a local-test feature only.
    # Production/staging must always use platform-controlled provider origins.
    if settings.ENVIRONMENT in {'test', 'development'} and supplied:
        return str(supplied).strip().rstrip('/')
    return str(getattr(settings, setting_name)).strip().rstrip('/')

@dataclass(frozen=True)
class PaymentCreateResult:
    provider_payment_id: str
    client_secret: str | None
    raw: dict[str, Any]
    redirect_url: str | None = None

@dataclass(frozen=True)
class PaymentActionResult:
    provider_id: str
    status: str
    raw: dict[str, Any]

class PaymentProvider(ABC):
    name = 'base'

    @abstractmethod
    def create_intent(self, *, amount_minor: int, currency: str, tenant_id: str,
     order_id: str | None,
     destination_account: str | None=None,
     idempotency_key: str | None=None,
     customer: dict[str,
        Any] | None=None, items: list[dict[str, Any]] | None=None) -> PaymentCreateResult:
        ...

    @abstractmethod
    def capture(self, provider_payment_id: str, amount_minor: int | None=None,
        currency: str | None=None, idempotency_key: str | None=None) -> PaymentActionResult:
        ...

    @abstractmethod
    def refund(self, provider_payment_id: str, amount_minor: int, currency: str,
        idempotency_key: str | None=None) -> PaymentActionResult:
        ...

    @abstractmethod
    def void(self, provider_payment_id: str,
        idempotency_key: str | None=None) -> PaymentActionResult:
        ...

class IyzicoProvider(PaymentProvider):
    """iyzico Checkout Form v2-style HMACSHA256 adapter for Turkey."""
    name = 'iyzico'

    def __init__(self, *, api_key: str, secret_key: str, base_url: str | None=None,
        timeout: float=15.0):
        if not api_key or not secret_key:
            raise AppError(503, 'IYZICO_NOT_CONFIGURED', 'iyzico credentials are not configured')
        import base64, hashlib, hmac, json as _json, time
        self.api_key = api_key
        self.secret_key = secret_key
        self.base = _provider_base('IYZICO_API_BASE', base_url)
        self.timeout = timeout
        self._b64 = base64
        self._hashlib = hashlib
        self._hmac = hmac
        self._json = _json

    def _auth(self, path: str, body: str='') -> dict[str, str]:
        import time
        rnd = str(int(time.time() * 1000)) + '1'
        payload = rnd + path + body
        sig = self._hmac.new(self.secret_key.encode(), payload.encode(),
            self._hashlib.sha256).hexdigest()
        auth = 'apiKey:' + self.api_key + '&randomKey:' + rnd + '&signature:' + sig
        encoded = self._b64.b64encode(auth.encode()).decode()
        return {'Authorization': 'IYZWSv2 ' + encoded, 'x-iyzi-rnd': rnd,
            'Content-Type': 'application/json', 'User-Agent': 'UnifiedGlobalCommerce/' + get_settings().APP_VERSION}

    def _post(self, path: str, payload: dict):
        import httpx, json as _json
        body = _json.dumps(payload, separators=(',', ':'), ensure_ascii=False)
        try:
            with httpx.Client(timeout=get_settings().IYZICO_TIMEOUT_SECONDS, trust_env=False) as c:
                r = c.post(self.base + path, content=body.encode(), headers=self._auth(path, body))
                data = r.json() if r.content else {}
        except Exception as exc:
            raise AppError(503, 'PAYMENT_PROVIDER_UNAVAILABLE',
                'iyzico provider unavailable') from exc
        if r.status_code >= 400 or str(data.get('status', '')).lower() == 'failure':
            raise AppError(402, 'PAYMENT_PROVIDER_ERROR', 'iyzico rejected the request')
        return data

    def create_intent(self, *, amount_minor: int, currency: str, tenant_id: str,
     order_id: str | None,
     destination_account: str | None=None, idempotency_key: str | None=None, customer=None, items=None):
        import uuid
        price = f'{amount_minor / 100:.2f}'
        buyer = customer or {}
        item_rows = []
        for x in items or []:
            item_rows.append({'id': str(x.get('sku') or x.get('reference_id') or uuid.uuid4()),
             'price': f"{float(x.get('unit_price',
             0)):.2f}",
             'name': str(x.get('name') or x.get('title') or 'Item'),
                'category1': str(x.get('category') or 'General'), 'itemType': 'PHYSICAL'})
        payload = {'locale': 'tr' if currency.upper() == 'TRY' else 'en',
         'conversationId': idempotency_key or order_id or tenant_id,
         'price': float(price),
         'paidPrice': float(price),
         'currency': currency.upper(),
         'basketId': order_id or tenant_id,
         'paymentGroup': 'PRODUCT',
         'callbackUrl': f'{get_settings().PUBLIC_BASE_URL}/v1/webhooks/iyzico',
         'buyer': {'id': str((buyer or {}).get('id') or tenant_id),
         'name': (buyer or {}).get('first_name') or (buyer or {}).get('name') or 'Customer',
         'surname': (buyer or {}).get('last_name') or 'Customer',
         'email': (buyer or {}).get('email') or '',
         'gsmNumber': (buyer or {}).get('phone') or '+900000000000',
         'registrationAddress': (buyer or {}).get('address') or 'Turkey',
         'city': (buyer or {}).get('city') or 'Istanbul',
         'country': (buyer or {}).get('country') or 'Turkey',
         'zipCode': (buyer or {}).get('zip_code') or '34000'},
         'shippingAddress': {'address': 'Turkey',
         'contactName': (buyer or {}).get('name') or 'Customer',
         'city': (buyer or {}).get('city') or 'Istanbul',
         'country': 'Turkey',
         'zipCode': (buyer or {}).get('zip_code') or '34000'},
         'billingAddress': {'address': 'Turkey',
         'contactName': (buyer or {}).get('name') or 'Customer',
         'city': (buyer or {}).get('city') or 'Istanbul',
         'country': 'Turkey',
            'zipCode': (buyer or {}).get('zip_code') or '34000'}, 'basketItems': item_rows}
        data = self._post('/payment/iyzipos/checkoutform/initialize/auth/ecom', payload)
        tok = data.get('token')
        url = data.get('paymentPageUrl')
        if not tok:
            raise AppError(502, 'PAYMENT_PROVIDER_INVALID_RESPONSE',
                'iyzico did not return a checkout token')
        return PaymentCreateResult(str(tok), None, data, url)

    def capture(self, provider_payment_id: str, amount_minor: int | None=None,
        currency: str | None=None, idempotency_key: str | None=None):
        data = self._post('/payment/iyzipos/checkoutform/auth/ecom/detail', {'locale': 'tr',
            'conversationId': idempotency_key or provider_payment_id, 'token': provider_payment_id})
        status = 'succeeded' if str(data.get('paymentStatus',
            '')).upper() == 'SUCCESS' else str(data.get('paymentStatus', 'pending')).lower()
        return PaymentActionResult(str(data.get('paymentId') or provider_payment_id), status, data)

    def refund(self, provider_payment_id: str, amount_minor: int, currency: str,
        idempotency_key: str | None=None):
        data = self._post('/v2/payment/refund', {'locale': 'tr',
         'conversationId': idempotency_key or provider_payment_id,
         'paymentId': provider_payment_id,
            'price': float(f'{amount_minor / 100:.2f}'), 'currency': currency.upper()})
        refund_reference = str(data.get('refundHostReference') or '').strip()
        if not refund_reference:
            raise AppError(502, 'PAYMENT_PROVIDER_REFUND_REFERENCE_MISSING',
                'iyzico did not return a refund-specific reference')
        return PaymentActionResult(refund_reference,
            str(data.get('status', 'success')).lower(), data)

    def void(self, provider_payment_id: str, idempotency_key: str | None=None):
        data = self._post('/payment/cancel', {'locale': 'tr',
         'conversationId': idempotency_key or provider_payment_id,
            'paymentId': provider_payment_id})
        cancel_reference = str(data.get('cancelHostReference') or '').strip()
        if not cancel_reference:
            raise AppError(502, 'PAYMENT_PROVIDER_VOID_REFERENCE_MISSING',
                'iyzico did not return a cancel-specific reference')
        return PaymentActionResult(cancel_reference,
            str(data.get('status', 'success')).lower(), data)

class PayTRProvider(PaymentProvider):
    """PayTR Direct API/iFrame token + callback compatible adapter."""
    name = 'paytr'

    def __init__(self, *, merchant_id: str, merchant_key: str, merchant_salt: str,
        base_url: str | None=None, timeout: float=15.0):
        if not merchant_id or not merchant_key or (not merchant_salt):
            raise AppError(503, 'PAYTR_NOT_CONFIGURED', 'PayTR credentials are not configured')
        self.merchant_id = merchant_id
        self.key = merchant_key
        self.salt = merchant_salt
        self.base = _provider_base('PAYTR_API_BASE', base_url)
        self.timeout = timeout

    def build_token(self, *, user_ip: str, merchant_oid: str, email: str, payment_amount: str,
     payment_type: str='card',
        installment_count: str='0', currency: str='TL', test_mode: str='1', non_3d: str='0'):
        import base64, hashlib, hmac
        hash_str = f'{self.merchant_id}{user_ip}{merchant_oid}{email}{payment_amount}{payment_type}{installment_count}{currency}{test_mode}{non_3d}'
        return base64.b64encode(hmac.new(self.key.encode(), (hash_str + self.salt).encode(),
            hashlib.sha256).digest()).decode()

    def verify_callback(self, *, merchant_oid: str, status: str, total_amount: str,
        provided_hash: str) -> bool:
        import base64, hashlib, hmac
        expected = base64.b64encode(hmac.new(self.key.encode(),
         (merchant_oid + self.salt + status + total_amount).encode(),
            hashlib.sha256).digest()).decode()
        return hmac.compare_digest(expected, provided_hash)

    def create_intent(self, *, amount_minor: int, currency: str, tenant_id: str,
     order_id: str | None,
     destination_account: str | None=None, idempotency_key: str | None=None, customer=None, items=None):
        import json, httpx
        merchant_oid = order_id or idempotency_key or 'UC' + tenant_id.replace('-', '')[:16]
        basket = []
        for x in items or []:
            basket.append([str(x.get('name') or x.get('title') or 'Item'),
                f"{float(x.get('unit_price', 0)):.2f}", int(x.get('quantity', 1))])
        email = (customer or {}).get('email') or ''
        amount = f'{amount_minor / 100:.2f}'
        currency_code = 'TL' if currency.upper() in {'TRY', 'TL'} else currency.upper()
        if currency_code != 'TL':
            raise AppError(400, 'PAYTR_CURRENCY_UNSUPPORTED', 'PayTR requires TRY/TL settlement for this integration')
        user_ip = str((customer or {}).get('ip_address') or '127.0.0.1')
        test_mode = '1' if get_settings().PAYTR_TEST_MODE else '0'
        token = self.build_token(user_ip=user_ip, merchant_oid=merchant_oid, email=email,
         payment_amount=amount, currency=currency_code, test_mode=test_mode)
        data = {'merchant_id': self.merchant_id, 'paytr_token': token, 'user_ip': user_ip,
         'merchant_oid': merchant_oid,
         'email': email,
         'payment_amount': str(int(amount_minor)),
         'payment_type': 'card',
         'installment_count': '0',
         'currency': currency_code,
         'test_mode': test_mode,
         'non_3d': '0',
         'user_name': (customer or {}).get('name') or 'Customer',
         'user_address': (customer or {}).get('address') or 'Turkey',
         'user_phone': (customer or {}).get('phone') or '',
         'merchant_ok_url': f'{get_settings().PUBLIC_BASE_URL}/checkout/paytr/success',
         'merchant_fail_url': f'{get_settings().PUBLIC_BASE_URL}/checkout/paytr/failure',
         'user_basket': json.dumps(basket,
            ensure_ascii=False), 'debug_on': '0', 'client_lang': 'tr', 'timeout_limit': '30'}
        try:
            with httpx.Client(timeout=get_settings().PAYTR_TIMEOUT_SECONDS, trust_env=False) as c:
                r = c.post(self.base + '/odeme/api/get-token', data=data)
                payload = r.json() if r.content else {}
        except Exception as exc:
            raise AppError(503, 'PAYMENT_PROVIDER_UNAVAILABLE',
                'PayTR provider unavailable') from exc
        if r.status_code >= 400 or payload.get('status') != 'success':
            raise AppError(402, 'PAYMENT_PROVIDER_ERROR', 'PayTR rejected the request')
        return PaymentCreateResult(str(merchant_oid), None, payload,
            payload.get('token') and f"https://www.paytr.com/odeme/guvenli/{payload.get('token')}")

    def capture(self, provider_payment_id: str, amount_minor: int | None=None,
        currency: str | None=None, idempotency_key: str | None=None):
        raise AppError(409, 'PAYTR_CALLBACK_FINALIZATION',
            'PayTR payments finalize by merchant callback')

    def refund(self, provider_payment_id: str, amount_minor: int, currency: str,
        idempotency_key: str | None=None):
        import base64, hashlib, hmac, httpx
        if not provider_payment_id:
            raise AppError(400, 'PAYTR_PAYMENT_REFERENCE_REQUIRED',
                'PayTR merchant order reference is required')
        if amount_minor <= 0:
            raise AppError(400, 'REFUND_AMOUNT_INVALID', 'Refund amount must be positive')
        return_amount = f'{amount_minor / 100:.2f}'
        raw = f'{self.merchant_id}{provider_payment_id}{return_amount}{self.salt}'.encode()
        token = base64.b64encode(hmac.new(self.key.encode(), raw, hashlib.sha256).digest()).decode()
        data = {'merchant_id': self.merchant_id, 'merchant_oid': provider_payment_id,
            'return_amount': return_amount, 'paytr_token': token}
        if idempotency_key:
            data['reference_no'] = idempotency_key[:64]
        try:
            with httpx.Client(timeout=self.timeout, trust_env=False) as c:
                r = c.post(self.base + '/odeme/iade', data=data)
                payload = r.json() if r.content else {}
        except Exception as exc:
            raise AppError(503, 'PAYMENT_PROVIDER_UNAVAILABLE',
                'PayTR refund service unavailable') from exc
        if r.status_code >= 400 or payload.get('status') != 'success':
            raise AppError(402, 'PAYTR_REFUND_REJECTED', 'PayTR rejected the refund request')
        refund_reference = str(payload.get('reference_no') or '').strip()
        if not refund_reference:
            raise AppError(502, 'PAYMENT_PROVIDER_REFUND_REFERENCE_MISSING',
                'PayTR did not return the submitted refund reference')
        return PaymentActionResult(refund_reference,
            'succeeded', payload)

    def void(self, provider_payment_id: str, idempotency_key: str | None=None):
        raise AppError(409, 'PAYTR_VOID_NOT_SUPPORTED',
            'PayTR Direct API finalizes payments through the provider callback; use refund after settlement')

class MockProvider(PaymentProvider):
    name = 'mock'

    def create_intent(self, *, amount_minor: int, currency: str, tenant_id: str,
     order_id: str | None,
     destination_account: str | None=None,
     idempotency_key: str | None=None,
        customer: dict[str, Any] | None=None, items: list[dict[str, Any]] | None=None):
        import uuid
        pid = 'mock_' + uuid.uuid4().hex
        return PaymentCreateResult(pid, None, {'id': pid, 'status': 'requires_capture'}, None)

    def capture(self, provider_payment_id: str, amount_minor: int | None=None,
        currency: str | None=None, idempotency_key: str | None=None):
        return PaymentActionResult('cap_' + (idempotency_key or provider_payment_id), 'succeeded',
            {})

    def refund(self, provider_payment_id: str, amount_minor: int, currency: str,
        idempotency_key: str | None=None):
        return PaymentActionResult('re_' + (idempotency_key or provider_payment_id), 'succeeded',
            {})

    def void(self, provider_payment_id: str, idempotency_key: str | None=None):
        return PaymentActionResult('void_' + (idempotency_key or provider_payment_id), 'canceled',
            {})

class CashOnDeliveryProvider(PaymentProvider):
    """Cash-on-delivery adapter. No external call: money is collected by the
    courier/staff in person. This is intentionally NOT the same class as
    MockProvider so that COD is never silently covered by the
    'mock forbidden outside test/dev' guard, and so COD activity is
    distinguishable in the raw payload for audits and reconciliation."""
    name = 'cod'

    def create_intent(self, *, amount_minor: int, currency: str, tenant_id: str,
     order_id: str | None,
     destination_account: str | None=None,
     idempotency_key: str | None=None,
        customer: dict[str, Any] | None=None, items: list[dict[str, Any]] | None=None):
        import uuid
        pid = 'cod_' + uuid.uuid4().hex
        return PaymentCreateResult(pid, None,
            {'id': pid, 'status': 'requires_capture', 'method': 'cash_on_delivery'}, None)

    def capture(self, provider_payment_id: str, amount_minor: int | None=None,
        currency: str | None=None, idempotency_key: str | None=None):
        # Capture represents cash actually collected on delivery. This endpoint
        # already requires an authenticated staff/admin finance permission (or
        # the merchant's own delivery-confirmation flow) to call - there is no
        # separate online charge to authorize, so this simply records the
        # collection event.
        return PaymentActionResult('cap_' + (idempotency_key or provider_payment_id), 'succeeded',
            {'method': 'cash_on_delivery', 'note': 'cash collected on delivery'})

    def refund(self, provider_payment_id: str, amount_minor: int, currency: str,
        idempotency_key: str | None=None):
        return PaymentActionResult('re_' + (idempotency_key or provider_payment_id), 'succeeded',
            {'method': 'cash_on_delivery', 'note': 'cash refund handled off-platform'})

    def void(self, provider_payment_id: str, idempotency_key: str | None=None):
        return PaymentActionResult('void_' + (idempotency_key or provider_payment_id), 'canceled',
            {'method': 'cash_on_delivery'})

def get_payment_provider(name: str, credentials: dict | None=None) -> PaymentProvider:
    name = name.lower()
    credentials = credentials or {}
    settings = get_settings()
    # Tenant credentials may contain provider secrets, but must never be able to
    # redirect production payment traffic to an arbitrary host (SSRF). Provider
    # endpoints are platform-controlled in production; custom endpoints remain
    # available only in test/local-development environments for sandbox mocks.
    allow_custom_base = settings.ENVIRONMENT in {'test', 'development'}
    if name == 'iyzico':
        base = str(credentials.get('base_url') or settings.IYZICO_API_BASE) if allow_custom_base else settings.IYZICO_API_BASE
        return IyzicoProvider(api_key=str(credentials.get('api_key') or settings.IYZICO_API_KEY),
            secret_key=str(credentials.get('secret_key') or settings.IYZICO_SECRET_KEY),
            base_url=base)
    if name == 'paytr':
        base = str(credentials.get('base_url') or settings.PAYTR_API_BASE) if allow_custom_base else settings.PAYTR_API_BASE
        return PayTRProvider(merchant_id=str(credentials.get('merchant_id') or settings.PAYTR_MERCHANT_ID),
            merchant_key=str(credentials.get('merchant_key') or settings.PAYTR_MERCHANT_KEY),
            merchant_salt=str(credentials.get('merchant_salt') or settings.PAYTR_MERCHANT_SALT),
            base_url=base)
    if name == 'mock':
        settings = get_settings()
        if settings.ENVIRONMENT != 'test' and not (settings.ENVIRONMENT == 'development' and settings.ALLOW_LOCAL_MOCK_PAYMENTS):
            raise AppError(400, 'MOCK_PROVIDER_FORBIDDEN',
                'Mock payment provider is available only in automated tests or explicitly enabled local development')
        return MockProvider()
    if name == 'cod':
        return CashOnDeliveryProvider()
    raise AppError(400, 'PROVIDER_UNSUPPORTED', 'Only iyzico, PayTR, COD and protected mock are supported for merchant checkout')

class PaddleBillingProvider:
    """Paddle Merchant-of-Record billing adapter for platform subscriptions."""
    def __init__(self):
        s=get_settings()
        if not s.PADDLE_API_KEY:
            raise AppError(503, 'PADDLE_NOT_CONFIGURED', 'Paddle billing is not configured')
        self.base=s.PADDLE_API_BASE.rstrip('/')
        self.client=httpx.Client(base_url=self.base, timeout=s.PADDLE_TIMEOUT_SECONDS, trust_env=False,
            headers={'Authorization': f'Bearer {s.PADDLE_API_KEY}', 'Content-Type':'application/json',
            'User-Agent':'UnifiedGlobalCommerce/' + s.APP_VERSION})
    def _request(self, method: str, path: str, payload: dict | None=None, idem: str | None=None):
        headers={} if not idem else {'Idempotency-Key': idem}
        try:
            r=self.client.request(method, path, json=payload, headers=headers)
            data=r.json() if r.content else {}
        except Exception as exc:
            raise AppError(503,'BILLING_PROVIDER_UNAVAILABLE','Paddle unavailable') from exc
        if r.status_code >= 400:
            raise AppError(402,'BILLING_PROVIDER_ERROR','Paddle rejected the billing request')
        return data.get('data', data)
    def customer(self, email: str, tenant_id: str, name: str | None=None, idem: str | None=None):
        return self._request('POST','/customers',{'email':email,'name':name or email,
            'custom_data':{'tenant_id':tenant_id}},idem)
    def checkout_transaction(self, *, customer_id: str, price_id: str, currency: str, custom_data: dict, discount: dict | None=None, idem: str | None=None):
        payload={'items':[{'price_id':price_id,'quantity':1}],
            'collection_mode':'automatic','custom_data':custom_data,'checkout':{'url':get_settings().PUBLIC_BASE_URL},
            'customer_id':customer_id}
        if discount:
            kind=str(discount.get('type') or '').lower()
            amount=discount.get('amount')
            if kind not in {'percentage','flat','flat_per_seat'} or amount in (None,'',0,'0','0.0'):
                raise AppError(400,'BILLING_DISCOUNT_INVALID','Invalid Paddle discount payload')
            d={'type':kind,'amount':str(amount),'description':str(discount.get('description') or 'SaaS subscription discount'),'recur':bool(discount.get('recur',True))}
            if kind in {'flat','flat_per_seat'}:
                d['currency_code']=currency.upper()
            payload['discount']=d
        data=self._request('POST','/transactions',payload,idem)
        return data
    def cancel(self, subscription_id: str, idem: str | None=None):
        return self._request('POST',f'/subscriptions/{subscription_id}/cancel',{'effective_at':'next_billing_period'},idem)
