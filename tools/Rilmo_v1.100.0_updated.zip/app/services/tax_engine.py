from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from app.core.errors import AppError

@dataclass(frozen=True)
class TaxResult:
    taxable_minor: int
    tax_minor: int
    rate_bps: int
    inclusive: bool

def calculate_tax(*, amount_minor: int, rate_bps: int, inclusive: bool=False) -> TaxResult:
    if amount_minor < 0 or rate_bps < 0 or rate_bps > 10000:
        raise AppError(400, 'TAX_INPUT_INVALID', 'Invalid taxable amount or tax rate')
    rate = Decimal(rate_bps) / Decimal(10000)
    if inclusive:
        tax = (Decimal(amount_minor) * rate / (Decimal(1) + rate)).quantize(Decimal('1'),
            rounding=ROUND_HALF_UP) if rate else Decimal(0)
        taxable = Decimal(amount_minor) - tax
    else:
        taxable = Decimal(amount_minor)
        tax = (taxable * rate).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
    return TaxResult(int(taxable), int(tax), rate_bps, inclusive)

def calculate_lines(lines, rate_bps: int, inclusive: bool=False):
    out = []
    total = 0
    for line in lines:
        r = calculate_tax(amount_minor=int(line), rate_bps=rate_bps, inclusive=inclusive)
        out.append(r)
        total += r.tax_minor
    return (out, total)
