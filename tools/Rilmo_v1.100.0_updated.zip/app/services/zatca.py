from datetime import datetime, timezone
from decimal import Decimal
from hashlib import sha256
from xml.etree.ElementTree import Element, SubElement, tostring
from uuid import uuid4
from app.core.errors import AppError
UBL = 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2'
CAC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2'
CBC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2'

def _el(parent, ns, name, text=None, attrs=None):
    e = SubElement(parent, f'{{{ns}}}{name}', attrs or {})
    if text is not None:
        e.text = str(text)
    return e

def build_zatca_invoice(*, invoice_number: str, issue_date: str, currency: str, seller: dict,
 buyer: dict,
 lines: list[dict],
    tax_total_minor: int, subtotal_minor: int, total_minor: int, previous_hash: str | None=None):
    if not seller.get('vat_number'):
        raise AppError(400, 'ZATCA_SELLER_VAT_REQUIRED',
            'Seller VAT number is required for ZATCA invoice generation')
    root = Element(f'{{{UBL}}}Invoice', {'xmlns:cac': CAC, 'xmlns:cbc': CBC})
    _el(root, CBC, 'ProfileID', 'reporting:1.0')
    _el(root, CBC, 'ID', invoice_number)
    _el(root, CBC, 'UUID', str(uuid4()))
    _el(root, CBC, 'IssueDate', issue_date)
    _el(root, CBC, 'InvoiceTypeCode', '388', {'name': '0200000'})
    _el(root, CBC, 'DocumentCurrencyCode', currency.upper())
    if previous_hash:
        _el(root, CBC, 'Note', f'PreviousInvoiceHash:{previous_hash}')
    sup = _el(root, CAC, 'AccountingSupplierParty')
    party = _el(sup, CAC, 'Party')
    ident = _el(party, CAC, 'PartyIdentification')
    _el(ident, CBC, 'ID', seller['vat_number'], {'schemeID': 'VAT'})
    addr = _el(party, CAC, 'PostalAddress')
    _el(addr, CBC, 'CityName', seller.get('city', ''))
    _el(addr, CBC, 'CountrySubentity', seller.get('region', ''))
    country = _el(addr, CAC, 'Country')
    _el(country, CBC, 'IdentificationCode', seller.get('country_code', 'SA'))
    tax = _el(party, CAC, 'PartyTaxScheme')
    _el(tax, CBC, 'CompanyID', seller['vat_number'])
    _el(tax, CAC, 'TaxScheme')
    cust = _el(root, CAC, 'AccountingCustomerParty')
    cp = _el(cust, CAC, 'Party')
    ca = _el(cp, CAC, 'PostalAddress')
    _el(ca, CBC, 'CityName', buyer.get('city', ''))
    bc = _el(ca, CAC, 'Country')
    _el(bc, CBC, 'IdentificationCode', buyer.get('country_code', 'SA'))
    tax_total = _el(root, CAC, 'TaxTotal')
    _el(tax_total, CBC, 'TaxAmount', f'{Decimal(tax_total_minor) / 100:.2f}',
        {'currencyID': currency.upper()})
    legal = _el(root, CAC, 'LegalMonetaryTotal')
    _el(legal, CBC, 'LineExtensionAmount', f'{Decimal(subtotal_minor) / 100:.2f}',
        {'currencyID': currency.upper()})
    _el(legal, CBC, 'TaxExclusiveAmount', f'{Decimal(subtotal_minor) / 100:.2f}',
        {'currencyID': currency.upper()})
    _el(legal, CBC, 'TaxInclusiveAmount', f'{Decimal(total_minor) / 100:.2f}',
        {'currencyID': currency.upper()})
    _el(legal, CBC, 'PayableAmount', f'{Decimal(total_minor) / 100:.2f}',
        {'currencyID': currency.upper()})
    for idx, line in enumerate(lines, 1):
        il = _el(root, CAC, 'InvoiceLine')
        _el(il, CBC, 'ID', idx)
        _el(il, CBC, 'InvoicedQuantity', line['quantity'], {'unitCode': 'PCE'})
        _el(il, CBC, 'LineExtensionAmount', f"{Decimal(line['total_minor']) / 100:.2f}",
            {'currencyID': currency.upper()})
        item = _el(il, CAC, 'Item')
        _el(item, CBC, 'Name', line.get('title', ''))
        price = _el(il, CAC, 'Price')
        _el(price, CBC, 'PriceAmount', f"{Decimal(line['unit_price_minor']) / 100:.2f}",
            {'currencyID': currency.upper()})
    raw = tostring(root, encoding='utf-8', xml_declaration=True)
    digest = sha256(raw).hexdigest()
    return (raw, digest)
