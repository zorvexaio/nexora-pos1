"""Transactional email abstraction. Development uses a local sink; production uses SMTP."""
import smtplib
from pathlib import Path
from datetime import datetime, timezone
from email.message import EmailMessage
from app.core.config import get_settings
from app.core.errors import AppError

def send_password_reset(email: str, token: str) -> None:
    s = get_settings()
    link = f"{s.PUBLIC_BASE_URL.rstrip('/')}/reset-password?token={token}"
    if s.ENVIRONMENT != 'production':
        _write_local_message(to=email, subject='Reset your password', body=f'Use this link to reset your password. It expires in {s.PASSWORD_RESET_TTL_MINUTES} minutes:\n{link}')
        return
    if not all([s.SMTP_HOST, s.SMTP_USERNAME, s.SMTP_PASSWORD, s.MAIL_FROM]):
        raise AppError(503, 'MAIL_NOT_CONFIGURED', 'Transactional email is not configured')
    msg = EmailMessage()
    msg['Subject'] = 'Reset your password'
    msg['From'] = s.MAIL_FROM
    msg['To'] = email
    msg.set_content(f'Use this link to reset your password. It expires in {s.PASSWORD_RESET_TTL_MINUTES} minutes:\n{link}')
    try:
        with smtplib.SMTP(s.SMTP_HOST, s.SMTP_PORT, timeout=15) as smtp:
            if s.SMTP_TLS:
                smtp.starttls()
            if s.SMTP_USERNAME:
                smtp.login(s.SMTP_USERNAME, s.SMTP_PASSWORD)
            smtp.send_message(msg)
    except Exception as exc:
        raise AppError(503, 'MAIL_PROVIDER_UNAVAILABLE',
            'Transactional email provider unavailable') from exc

def _write_local_message(*, to: str, subject: str, body: str) -> None:
    s = get_settings()
    path = Path(s.LOCAL_MAIL_OUTBOX)
    path.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).isoformat()
    with path.open('a', encoding='utf-8') as fh:
        fh.write(f'[{stamp}] TO={to} SUBJECT={subject}\n{body}\n---\n')


def send_email(email: str, subject: str, body: str) -> None:
    s = get_settings()
    if s.ENVIRONMENT != 'production':
        _write_local_message(to=email, subject=subject, body=body)
        return
    if not all([s.SMTP_HOST, s.SMTP_USERNAME, s.SMTP_PASSWORD, s.MAIL_FROM]):
        raise AppError(503, 'MAIL_NOT_CONFIGURED', 'Transactional email is not configured')
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = s.MAIL_FROM
    msg['To'] = email
    msg.set_content(body)
    try:
        with smtplib.SMTP(s.SMTP_HOST, s.SMTP_PORT, timeout=15) as smtp:
            if s.SMTP_TLS:
                smtp.starttls()
            if s.SMTP_USERNAME:
                smtp.login(s.SMTP_USERNAME, s.SMTP_PASSWORD)
            smtp.send_message(msg)
    except Exception as exc:
        raise AppError(503, 'MAIL_PROVIDER_UNAVAILABLE',
            'Transactional email provider unavailable') from exc
