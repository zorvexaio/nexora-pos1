from __future__ import annotations
from datetime import datetime, timezone, timedelta
import hashlib, json
from sqlalchemy.orm import Session
from app.models.domain import PrivacyRequest, PrivacyConsentEvent, User, Customer, MerchantProfile, MerchantIdentityVerification, Tenant, PrivacyAccessGrant, PrivacyIncident, PrivacyTransferRegister, MerchantReviewCase
from app.services.core import audit, outbox
from app.core.errors import AppError
from app.services.legal_compliance import policy_for, validate_dsr_type

PRIVACY_REQUEST_TYPES = {'ACCESS','RECTIFICATION','ERASURE','RESTRICTION','OBJECTION','PORTABILITY','REVIEW_AUTOMATED_DECISION'}
CONSENT_CATEGORIES = {'analytics','marketing','whatsapp_marketing','sms_marketing','preferences','personalization'}

# Jurisdiction routing is intentionally conservative: the legal team can override it via policy configuration.
EU_EEA = {'AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR','DE','GR','HU','IE','IT','LV','LT','LU','MT','NL','PL','PT','RO','SK','SI','ES','SE','IS','LI','NO'}

def jurisdiction_for_country(country_code: str | None) -> str:
    c=(country_code or '').upper()
    if c == 'TR': return 'TR-KVKK'
    if c in EU_EEA: return 'EU-GDPR'
    if c == 'GB': return 'UK-GDPR'
    if c == 'BR': return 'BR-LGPD'
    if c == 'JP': return 'JP-APPI'
    if c == 'SG': return 'SG-PDPA'
    if c == 'AU': return 'AU-PRIVACY'
    if c == 'IN': return 'IN-DPDP'
    if c == 'ZA': return 'ZA-POPIA'
    if c == 'AE': return 'AE-PDPL'
    if c == 'SA': return 'SA-PDPL'
    if c in {'US','CA'}: return 'US-STATE-PRIVACY'
    return 'GLOBAL-BASELINE'

def sha256(value: str | bytes) -> str:
    raw=value.encode() if isinstance(value,str) else value
    return hashlib.sha256(raw).hexdigest()

def record_consent_event(db: Session, *, tenant_id: str|None, user_id: str|None, customer_id: str|None, subject_type: str, subject_id: str, jurisdiction: str|None, policy_version: str, action: str, categories: dict, lawful_basis: dict|None, source: str, ip: str|None, user_agent: str|None):
    unknown=set(categories)-CONSENT_CATEGORIES
    if unknown:
        raise AppError(400,'PRIVACY_CONSENT_CATEGORY_INVALID','Unsupported consent category')
    if action not in {'GRANT','REVOKE','UPDATE'}:
        raise AppError(400,'PRIVACY_CONSENT_ACTION_INVALID','Unsupported consent action')
    row=PrivacyConsentEvent(tenant_id=tenant_id,user_id=user_id,customer_id=customer_id,subject_type=subject_type,subject_id=subject_id,jurisdiction=jurisdiction,policy_version=policy_version,action=action,categories={k:bool(v) for k,v in categories.items()},lawful_basis=lawful_basis or {},source=source,ip_hash=sha256(ip) if ip else None,user_agent_hash=sha256(user_agent) if user_agent else None)
    db.add(row); db.flush()
    audit(db, tenant_id, user_id, 'privacy.consent.'+action.lower(), 'PrivacyConsentEvent', row.id, after={'jurisdiction':jurisdiction,'categories':row.categories,'policy_version':policy_version,'source':source})
    return row

def latest_consent(db: Session, subject_type: str, subject_id: str):
    return db.query(PrivacyConsentEvent).filter_by(subject_type=subject_type, subject_id=subject_id).order_by(PrivacyConsentEvent.created_at.desc()).first()

def submit_privacy_request(db: Session, *, tenant_id: str|None, user_id: str|None, customer_id: str|None, request_type: str, jurisdiction: str|None):
    request_type=request_type.upper()
    if request_type not in PRIVACY_REQUEST_TYPES:
        raise AppError(400,'PRIVACY_REQUEST_TYPE_INVALID','Unsupported privacy request type')
    validate_dsr_type(jurisdiction, request_type)
    existing=db.query(PrivacyRequest).filter(PrivacyRequest.user_id==user_id, PrivacyRequest.request_type==request_type, PrivacyRequest.status.in_(['SUBMITTED','IN_REVIEW','READY'])).first()
    if existing: return existing
    now=datetime.now(timezone.utc)
    # Internal target is deliberately conservative; counsel can tune by jurisdiction.
    due_days=int(policy_for(jurisdiction).get('dsr_due_days') or 45)
    due=now+timedelta(days=due_days)
    row=PrivacyRequest(tenant_id=tenant_id,user_id=user_id,customer_id=customer_id,request_type=request_type,status='SUBMITTED',jurisdiction=jurisdiction,identity_verification='ACCOUNT_AUTHENTICATED',requested_at=now,due_at=due,metadata_json={'processor_action_required':True})
    db.add(row); db.flush()
    audit(db,tenant_id,user_id,'privacy.request.submitted','PrivacyRequest',row.id,after={'request_type':request_type,'jurisdiction':jurisdiction})
    outbox(db,tenant_id,'privacy_request',row.id,'privacy.request.submitted',{'request_type':request_type,'jurisdiction':jurisdiction})
    return row



def mask_reference(value: str | None, *, prefix: int = 4, suffix: int = 4) -> str | None:
    if not value:
        return None
    value = str(value)
    if len(value) <= prefix + suffix:
        return '*' * len(value)
    return value[:prefix] + '…' + value[-suffix:]


def safe_merchant_verification_view(verification, *, viewer_user_id: str | None = None) -> dict | None:
    if verification is None:
        return None
    is_owner = bool(viewer_user_id and verification.user_id == viewer_user_id)
    return {
        'id': verification.id,
        'provider': verification.provider,
        'status': verification.status,
        'decision': verification.decision,
        'risk_level': verification.risk_level,
        'country_code': verification.country_code,
        'verification_id_masked': mask_reference(verification.external_id),
        'verified_at': verification.completed_at.isoformat() if verification.completed_at else None,
        'expires_at': verification.expires_at.isoformat() if verification.expires_at else None,
        'next_action_url': verification.verification_url if is_owner else None,
    }


def safe_merchant_profile_view(profile, *, viewer_role: str | None = None, include_private: bool = False) -> dict | None:
    if profile is None:
        return None
    view = {
        'id': profile.id,
        'tenant_id': profile.tenant_id,
        'legal_name': profile.legal_name,
        'country_code': profile.country_code,
        'city': profile.city,
        'business_type': profile.business_type,
        'identity_status': profile.identity_status,
        'phone_verified_at': profile.phone_verified_at.isoformat() if profile.phone_verified_at else None,
        'google_verified_at': profile.google_verified_at.isoformat() if profile.google_verified_at else None,
        'kyc_provider': profile.kyc_provider,
        'kyc_status': profile.kyc_status,
        'kyc_verified_at': profile.kyc_verified_at.isoformat() if profile.kyc_verified_at else None,
        'risk_level': profile.risk_level,
        'risk_score': profile.risk_score,
        'review_required': profile.review_required,
        'payout_hold': profile.payout_hold,
        'trust_lock_reason': profile.trust_lock_reason,
    }
    if include_private and viewer_role in {'owner', 'admin'}:
        view.update({
            'phone': profile.phone,
            'address_line1': profile.address_line1,
            'postal_code': profile.postal_code,
            'tax_id': profile.tax_id,
        })
    else:
        view.update({'phone': None, 'address_line1': None, 'postal_code': None, 'tax_id_masked': mask_reference(profile.tax_id, prefix=2, suffix=2)})
    return view


def privacy_profile(db: Session, user_id: str, tenant_id: str|None=None) -> dict:
    user=db.get(User,user_id)
    tenant=db.get(Tenant,tenant_id) if tenant_id else None
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first() if tenant_id else None
    latest=latest_consent(db,'USER',user_id)
    reqs=db.query(PrivacyRequest).filter_by(user_id=user_id).order_by(PrivacyRequest.requested_at.desc()).limit(20).all()
    return {
      'account': {'email': user.email, 'display_name': user.display_name, 'status': user.status,
          'created_at': user.created_at.isoformat() if user.created_at else None} if user else None,
      'data_classes':['account','security','merchant_or_order_data','privacy_preferences','compliance_metadata'] if profile else ['account','security','privacy_preferences'],
      'identity_documents':'NOT_STORED_BY_RILMO_DEFAULT',
      'raw_biometric_data':'NOT_STORED_BY_RILMO_DEFAULT',
      'raw_card_data':'NOT_STORED',
      'privacy_contact_required':True,
      'current_consent': ({'id':latest.id,'action':latest.action,'policy_version':latest.policy_version,'jurisdiction':latest.jurisdiction,'categories':latest.categories,'created_at':latest.created_at.isoformat()} if latest else None),
      'requests':[{'id':r.id,'type':r.request_type,'status':r.status,'jurisdiction':r.jurisdiction,'requested_at':r.requested_at.isoformat(),'due_at':r.due_at.isoformat() if r.due_at else None,'resolved_at':r.resolved_at.isoformat() if r.resolved_at else None} for r in reqs],
      'merchant_verification': ({'provider':profile.kyc_provider,'status':profile.kyc_status,'verified_at':profile.kyc_verified_at.isoformat() if profile.kyc_verified_at else None} if profile else None),
      'organization':tenant.name if tenant else None,
    }


JURISDICTION_AUTHORITY_WINDOWS_HOURS = {
    'EU-GDPR': 72,
    'TR-KVKK': 72,
    'UK-GDPR': 72,
}

def create_privacy_access_grant(db: Session, *, tenant_id: str, verification_id: str, case_id: str,
                                requester_user_id: str, purpose: str, ticket_ref: str,
                                provider_access_reference: str | None, ip: str | None,
                                ttl_minutes: int = 15) -> PrivacyAccessGrant:
    if ttl_minutes < 1 or ttl_minutes > 60:
        raise AppError(400, 'PRIVACY_ACCESS_TTL_INVALID', 'Access window must be between 1 and 60 minutes')
    case = db.query(MerchantReviewCase).filter_by(id=case_id, tenant_id=tenant_id).first()
    verification = db.query(MerchantIdentityVerification).filter_by(id=verification_id, tenant_id=tenant_id).first()
    if not case or not verification:
        raise AppError(404, 'PRIVACY_CASE_OR_VERIFICATION_NOT_FOUND', 'Compliance case or verification not found')
    now = datetime.now(timezone.utc)
    row = PrivacyAccessGrant(tenant_id=tenant_id, verification_id=verification_id, case_id=case_id,
        requester_user_id=requester_user_id, purpose=purpose.strip()[:255], ticket_ref=ticket_ref.strip()[:120],
        provider_access_reference=provider_access_reference, status='GRANTED', granted_at=now,
        expires_at=now + timedelta(minutes=ttl_minutes), ip_hash=sha256(ip) if ip else None)
    db.add(row); db.flush()
    audit(db, tenant_id, requester_user_id, 'privacy.kyc_access.granted', 'PrivacyAccessGrant', row.id,
          after={'case_id':case_id,'verification_id':verification_id,'purpose':row.purpose,'ticket_ref':row.ticket_ref,
                 'expires_at':row.expires_at.isoformat(),'provider_access_reference_present':bool(provider_access_reference)})
    return row

def revoke_privacy_access_grant(db: Session, *, grant_id: str, requester_user_id: str | None = None):
    row = db.get(PrivacyAccessGrant, grant_id)
    if not row or row.status != 'GRANTED':
        raise AppError(404, 'PRIVACY_ACCESS_GRANT_NOT_FOUND', 'Access grant not found or inactive')
    row.status='REVOKED'; row.revoked_at=datetime.now(timezone.utc)
    audit(db, row.tenant_id, requester_user_id, 'privacy.kyc_access.revoked', 'PrivacyAccessGrant', row.id)
    return row

def open_privacy_incident(db: Session, *, jurisdiction: str, severity: str='MEDIUM', data_categories=None,
                          affected_subjects_estimate: int | None=None, owner_user_id: str | None=None):
    now=datetime.now(timezone.utc)
    hours=JURISDICTION_AUTHORITY_WINDOWS_HOURS.get(jurisdiction)
    due=now + timedelta(hours=hours) if hours else None
    row=PrivacyIncident(jurisdiction=jurisdiction,status='DETECTED',severity=severity.upper(),detected_at=now,
        authority_due_at=due,data_categories=list(data_categories or []),affected_subjects_estimate=affected_subjects_estimate,
        owner_user_id=owner_user_id,created_at=now,updated_at=now)
    db.add(row); db.flush()
    audit(db,None,owner_user_id,'privacy.incident.detected','PrivacyIncident',row.id,
          after={'jurisdiction':jurisdiction,'severity':row.severity,'authority_due_at':due.isoformat() if due else None})
    return row


PRIVACY_INCIDENT_STATUSES = {'DETECTED','CONTAINED','ASSESSED','NOTIFICATION_PENDING','NOTIFIED','REMEDIATED','CLOSED'}
PRIVACY_NOTIFICATION_DECISIONS = {'PENDING','NOT_REQUIRED','AUTHORITY','AFFECTED_USERS','BOTH'}

PRIVACY_INCIDENT_ALLOWED_TRANSITIONS = {
    'DETECTED': {'CONTAINED'},
    'CONTAINED': {'ASSESSED', 'NOTIFICATION_PENDING'},
    'ASSESSED': {'NOTIFICATION_PENDING', 'REMEDIATED'},
    'NOTIFICATION_PENDING': {'NOTIFIED', 'REMEDIATED'},
    'NOTIFIED': {'REMEDIATED'},
    'REMEDIATED': {'CLOSED'},
    'CLOSED': set(),
}

def update_privacy_incident(db: Session, *, incident_id: str, actor_user_id: str, status: str | None = None,
                            containment_notes: str | None = None, notification_decision: str | None = None,
                            affected_subjects_estimate: int | None = None):
    row=db.get(PrivacyIncident, incident_id)
    if not row:
        raise AppError(404,'PRIVACY_INCIDENT_NOT_FOUND','Privacy incident not found')
    if status and status not in PRIVACY_INCIDENT_STATUSES:
        raise AppError(400,'PRIVACY_INCIDENT_STATUS_INVALID','Unsupported privacy incident status')
    if notification_decision and notification_decision not in PRIVACY_NOTIFICATION_DECISIONS:
        raise AppError(400,'PRIVACY_NOTIFICATION_DECISION_INVALID','Unsupported notification decision')
    if status and status != row.status and status not in PRIVACY_INCIDENT_ALLOWED_TRANSITIONS.get(row.status, set()):
        raise AppError(409,'PRIVACY_INCIDENT_TRANSITION_INVALID',f'Cannot transition incident from {row.status} to {status}')
    if status == 'NOTIFIED' and notification_decision not in {'AUTHORITY','AFFECTED_USERS','BOTH'} and row.notification_decision not in {'AUTHORITY','AFFECTED_USERS','BOTH'}:
        raise AppError(409,'PRIVACY_NOTIFICATION_DECISION_REQUIRED','Notification decision is required before marking an incident notified')
    if status == 'CLOSED' and row.status != 'REMEDIATED':
        raise AppError(409,'PRIVACY_INCIDENT_NOT_REMEDIATED','Incident cannot be closed before remediation')
    now=datetime.now(timezone.utc)
    if status:
        row.status=status
    if containment_notes is not None:
        row.containment_notes=containment_notes[:4000]
    if affected_subjects_estimate is not None:
        row.affected_subjects_estimate=max(0,int(affected_subjects_estimate))
    if row.status in {'ASSESSED','NOTIFICATION_PENDING','NOTIFIED','REMEDIATED','CLOSED'} and not row.assessed_at:
        row.assessed_at=now
    if notification_decision:
        row.notification_decision=notification_decision
        if notification_decision in {'AUTHORITY','AFFECTED_USERS','BOTH'} and row.status == 'NOTIFIED':
            row.notification_at=now
    row.updated_at=now
    audit(db,None,actor_user_id,'privacy.incident.updated','PrivacyIncident',row.id,after={'status':row.status,'notification_decision':row.notification_decision,'affected_subjects_estimate':row.affected_subjects_estimate})
    return row

def privacy_export_payload(db: Session, *, user_id: str) -> dict:
    user=db.get(User,user_id)
    if not user:
        raise AppError(404,'USER_NOT_FOUND','User not found')
    memberships=db.query(__import__('app.models.domain',fromlist=['TenantMembership']).TenantMembership).filter_by(user_id=user_id).all()
    consents=db.query(PrivacyConsentEvent).filter_by(user_id=user_id).order_by(PrivacyConsentEvent.created_at.asc()).all()
    requests=db.query(PrivacyRequest).filter_by(user_id=user_id).order_by(PrivacyRequest.requested_at.asc()).all()
    installations=[]
    if memberships:
        tenant_ids=[m.tenant_id for m in memberships]
        installations=db.query(__import__('app.models.domain',fromlist=['AppInstallation','AppDefinition']).AppInstallation,
                              __import__('app.models.domain',fromlist=['AppDefinition']).AppDefinition).join(__import__('app.models.domain',fromlist=['AppDefinition']).AppDefinition,
                              __import__('app.models.domain',fromlist=['AppDefinition']).AppDefinition.id==__import__('app.models.domain',fromlist=['AppInstallation']).AppInstallation.app_id).filter(__import__('app.models.domain',fromlist=['AppInstallation']).AppInstallation.tenant_id.in_(tenant_ids)).all()
    tenant_rows=[]
    for m in memberships:
        t=db.get(Tenant,m.tenant_id)
        profile=db.query(MerchantProfile).filter_by(tenant_id=m.tenant_id).first()
        tenant_rows.append({'tenant_id':m.tenant_id,'tenant_name':t.name if t else None,'role':m.role,'status':m.status,
            'merchant_profile':({'legal_name':profile.legal_name,'country_code':profile.country_code,'city':profile.city,'identity_status':profile.identity_status,
                                 'kyc_status':profile.kyc_status,'kyc_provider':profile.kyc_provider} if profile else None)})
    return {'export_version':'privacy-export-v1','generated_at':datetime.now(timezone.utc).isoformat(),
      'user':{'id':user.id,'email':user.email,'display_name':user.display_name,'status':user.status,'created_at':user.created_at.isoformat()},
      'tenants':tenant_rows,
      'consents':[{'id':r.id,'jurisdiction':r.jurisdiction,'policy_version':r.policy_version,'action':r.action,'categories':r.categories,'created_at':r.created_at.isoformat()} for r in consents],
      'privacy_requests':[{'id':r.id,'type':r.request_type,'status':r.status,'jurisdiction':r.jurisdiction,'requested_at':r.requested_at.isoformat(),'resolved_at':r.resolved_at.isoformat() if r.resolved_at else None} for r in requests],
      'connected_apps':[{'installation_id':i.id,'app_name':a.name,'scopes':i.granted_scopes,'status':i.status,'installed_at':i.installed_at.isoformat(),'last_used_at':i.last_used_at.isoformat() if i.last_used_at else None,'revoked_at':i.revoked_at.isoformat() if i.revoked_at else None} for i,a in installations]}
