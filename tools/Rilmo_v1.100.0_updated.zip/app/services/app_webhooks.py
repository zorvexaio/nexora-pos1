import json
import ipaddress
import socket
import random
from typing import Dict
from datetime import datetime, timezone, timedelta
from urllib.parse import urlsplit

import httpx
from sqlalchemy import or_, and_

from app.core.config import get_settings
from app.core.security import decrypt_secret, hmac_sha256
from app.core.errors import AppError


def _allowed_hosts() -> set[str]:
    return {x.strip().lower().rstrip('.') for x in get_settings().APP_WEBHOOK_ALLOWED_HOSTS.split(',') if x.strip()}


def _resolve_public_https(url: str):
    p = urlsplit(url)
    if p.scheme != 'https' or not p.hostname or p.username or p.password:
        return False
    host = p.hostname.rstrip('.').lower()
    allowed = _allowed_hosts()
    if allowed and host not in allowed:
        return False
    try:
        infos = socket.getaddrinfo(host, p.port or 443, type=socket.SOCK_STREAM)
    except OSError:
        return None
    ips = []
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError:
            continue
        if not ip.is_global or ip.is_multicast:
            return None
        ips.append(str(ip))
    return {'scheme': p.scheme, 'hostname': host, 'port': p.port or 443, 'path': p.path or '/', 'query': p.query,
            'pinned_ip': ips[0]} if ips else None



def _public_https(url: str):
    return _resolve_public_https(url) is not None


def _post_pinned(url: str, content: bytes, headers: dict, timeout: float):
    resolved = _resolve_public_https(url)
    if not resolved:
        raise AppError(400, 'WEBHOOK_ENDPOINT_BLOCKED', 'Webhook endpoint is not allowed or not publicly routable')
    import httpcore

    class _PinnedBackend(httpcore.NetworkBackend):
        def __init__(self, ip: str):
            self._backend = httpcore.SyncBackend()
            self._ip = ip

        def connect_tcp(self, host: str, port: int, timeout=None, local_address=None, socket_options=None):
            return self._backend.connect_tcp(self._ip, port, timeout=timeout, local_address=local_address, socket_options=socket_options)

    pool = httpcore.ConnectionPool(network_backend=_PinnedBackend(resolved['pinned_ip']))
    try:
        request = httpcore.Request('POST', url, headers={str(k): str(v) for k, v in headers.items()}, content=content,
                                    extensions={'timeout': {'connect': timeout, 'read': timeout, 'write': timeout, 'pool': timeout}})
        response = pool.handle_request(request)
        body = response.read()
        return response.status, body, response.headers
    finally:
        pool.close()


def enqueue_event_deliveries(db, event):
    from app.models.domain import AppWebhookSubscription, AppWebhookDelivery
    subs = db.query(AppWebhookSubscription).filter_by(tenant_id=event.tenant_id, status='ACTIVE',
        event_type=event.event_type).all()
    for sub in subs:
        if not sub.secret_encrypted or not _public_https(sub.endpoint_url):
            continue
        existing = db.query(AppWebhookDelivery).filter_by(subscription_id=sub.id, event_id=event.id).first()
        if existing:
            continue
        db.add(AppWebhookDelivery(
            tenant_id=event.tenant_id,
            subscription_id=sub.id,
            event_id=event.id,
            endpoint_url=sub.endpoint_url,
            event_type=event.event_type,
            status='PENDING',
            attempt_count=0,
            next_attempt_at=datetime.now(timezone.utc),
        ))


def recover_stale_webhook_deliveries(db, stale_seconds: int = 3600, tenant_id: str | None = None):
    from app.models.domain import AppWebhookDelivery
    cutoff = datetime.now(timezone.utc) - timedelta(seconds=max(60, stale_seconds))
    q = db.query(AppWebhookDelivery).filter(
        AppWebhookDelivery.status == 'PROCESSING',
        AppWebhookDelivery.processing_started_at.isnot(None),
        AppWebhookDelivery.processing_started_at <= cutoff,
    )
    if tenant_id:
        q = q.filter(AppWebhookDelivery.tenant_id == tenant_id)
    rows = q.all()
    for delivery in rows:
        delivery.status = 'RECONCILIATION_REQUIRED'
        delivery.last_error = 'Delivery was interrupted during external I/O; manual/provider reconciliation required'
        delivery.processing_started_at = None
    db.commit()
    return len(rows)


def process_webhook_deliveries(db, batch_size: int | None = None):
    from app.models.domain import AppWebhookDelivery, AppWebhookSubscription, OutboxEvent
    settings = get_settings()
    batch = max(1, min(batch_size or settings.APP_WEBHOOK_BATCH_SIZE, 500))
    now = datetime.now(timezone.utc)
    q = db.query(AppWebhookDelivery).filter(
        AppWebhookDelivery.status.in_(['PENDING', 'RETRY']),
        or_(AppWebhookDelivery.next_attempt_at.is_(None), AppWebhookDelivery.next_attempt_at <= now),
    ).order_by(AppWebhookDelivery.created_at).limit(batch)
    if db.bind.dialect.name == 'postgresql':
        q = q.with_for_update(skip_locked=True)
    deliveries = q.all()
    sent = 0
    for delivery in deliveries:
        delivery.status = 'PROCESSING'
        delivery.attempt_count += 1
        delivery.processing_started_at = datetime.now(timezone.utc)
        db.commit()
        try:
            if not _public_https(delivery.endpoint_url):
                raise AppError(400, 'WEBHOOK_ENDPOINT_BLOCKED', 'Webhook endpoint is not allowed or not publicly routable')
            sub = db.query(AppWebhookSubscription).filter_by(id=delivery.subscription_id, status='ACTIVE').first()
            event = db.query(OutboxEvent).filter_by(id=delivery.event_id, tenant_id=delivery.tenant_id).first()
            if not sub or not event:
                raise RuntimeError('Webhook subscription or source event no longer exists')
            body = json.dumps({'id': event.id, 'type': event.event_type,
                'schema_version': event.schema_version,
                'occurred_at': event.occurred_at.isoformat(),
                'data': event.payload}, separators=(',', ':'), sort_keys=True).encode()
            secret = decrypt_secret(sub.secret_encrypted or '')
            ts = str(int(datetime.now(timezone.utc).timestamp()))
            sig = hmac_sha256(f'{ts}.'.encode() + body, secret)
            headers = {'Content-Type': 'application/json', 'User-Agent': 'UnifiedCommerce-Webhooks/1.1',
                'X-Unified-Timestamp': ts, 'X-Unified-Signature': sig, 'X-Unified-Event-Id': event.id}
            status, _resp_body, _resp_headers = _post_pinned(delivery.endpoint_url, body, headers, timeout=10.0)
            if not 200 <= status < 300:
                raise RuntimeError(f'HTTP {status}')
            delivery.status = 'SUCCEEDED'
            delivery.delivered_at = datetime.now(timezone.utc)
            delivery.next_attempt_at = None
            delivery.last_error = None
            delivery.processing_started_at = None
            sent += 1
        except Exception as exc:
            delivery.last_error = str(exc)[:2000]
            delivery.processing_started_at = None
            if delivery.attempt_count >= settings.APP_WEBHOOK_MAX_ATTEMPTS:
                delivery.status = 'FAILED'
                delivery.next_attempt_at = None
            else:
                delivery.status = 'RETRY'
                delay = min(3600, 2 ** min(delivery.attempt_count, 10))
                delivery.next_attempt_at = datetime.now(timezone.utc) + timedelta(seconds=delay + random.uniform(0, 3))
    db.commit()
    return sent


def deliver_event(db, event):
    """Backward-compatible API: enqueue isolated deliveries without performing network I/O."""
    enqueue_event_deliveries(db, event)
    db.flush()
    return True
