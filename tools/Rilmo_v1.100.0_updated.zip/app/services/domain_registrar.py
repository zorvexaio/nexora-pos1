from __future__ import annotations
import re
import httpx
from app.core.config import get_settings
from app.core.errors import AppError

DOMAIN_RE = re.compile(r'^(?=.{3,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$', re.I)

def normalize_domain(hostname: str) -> str:
    h = hostname.strip().lower().rstrip('.')
    if not DOMAIN_RE.fullmatch(h) or h.startswith('www.'):
        raise AppError(400,'DOMAIN_INVALID','Enter a valid registrable hostname without paths or www prefix')
    return h

def _cf_headers():
    s=get_settings()
    if not s.DOMAIN_PROVIDER_ACCOUNT_ID or not s.DOMAIN_PROVIDER_API_TOKEN:
        raise AppError(503,'DOMAIN_PROVIDER_NOT_CONFIGURED','Domain registrar credentials are not configured yet')
    return {'Authorization':f'Bearer {s.DOMAIN_PROVIDER_API_TOKEN}','Content-Type':'application/json'}

def check_domain(hostname: str) -> dict:
    h=normalize_domain(hostname)
    s=get_settings()
    if s.DOMAIN_PROVIDER=='cloudflare':
        url=f'https://api.cloudflare.com/client/v4/accounts/{s.DOMAIN_PROVIDER_ACCOUNT_ID}/registrar/domain-check'
        try:
            r=httpx.post(url,headers=_cf_headers(),trust_env=False,json={'domains':[h]},timeout=15)
            if r.status_code>=400: raise AppError(502,'DOMAIN_PROVIDER_ERROR','Domain provider rejected the availability check')
            data=r.json().get('result',{}).get('domains',[]) or []
            item=next((x for x in data if str(x.get('name','')).lower()==h), data[0] if data else {})
            pricing=item.get('pricing') or {}
            cost=int(round(float(pricing.get('registration_cost') or 0)*100))
            return {'hostname':h,'registrable':bool(item.get('registrable')),'tier':item.get('tier'),'reason':item.get('reason'),'registration_cost_minor':cost,'renewal_cost_minor':int(round(float(pricing.get('renewal_cost') or 0)*100))}
        except httpx.RequestError as exc:
            raise AppError(502,'DOMAIN_PROVIDER_UNAVAILABLE','Domain provider is temporarily unavailable') from exc
    raise AppError(503,'DOMAIN_PROVIDER_NOT_CONFIGURED','Unsupported domain provider')

def register_domain(hostname: str, registrant: dict, years: int) -> dict:
    h=normalize_domain(hostname)
    s=get_settings()
    if s.DOMAIN_PROVIDER!='cloudflare':
        raise AppError(503,'DOMAIN_PROVIDER_NOT_CONFIGURED','Unsupported domain provider')
    url=f'https://api.cloudflare.com/client/v4/accounts/{s.DOMAIN_PROVIDER_ACCOUNT_ID}/registrar/registrations'
    payload={'domain_name':h,'years':years,'auto_renew':True,'registrant_contact':{
        'first_name':registrant['registrant_first_name'],'last_name':registrant['registrant_last_name'],
        'email':registrant['registrant_email'],'phone':registrant['registrant_phone'],
        'country':registrant['country_code'].upper(),'city':registrant['city'],
        'address':registrant['address_line1'],'zip':registrant.get('postal_code') or ''}}
    try:
        r=httpx.post(url,headers=_cf_headers(),trust_env=False,json=payload,timeout=30)
        if r.status_code>=400: raise AppError(502,'DOMAIN_REGISTRATION_FAILED','Domain registrar rejected the registration')
        data=r.json().get('result') or {}
        reference = str(data.get('id') or '').strip()
        return {'status':'REGISTERED' if data else 'REGISTRATION_PENDING','reference':reference}
    except httpx.RequestError as exc:
        raise AppError(502,'DOMAIN_PROVIDER_UNAVAILABLE','Domain registrar is temporarily unavailable') from exc
