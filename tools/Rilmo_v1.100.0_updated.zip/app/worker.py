import random
import time
from datetime import datetime, timezone, timedelta
from sqlalchemy import or_, and_
from sqlalchemy.exc import IntegrityError
from app.core.database import SessionLocal, set_tenant_context
from app.models.domain import OutboxEvent, DeadLetterEvent, InventoryReservation, InventoryItem, Order, OrderStatusHistory, GuestSession, Cart, Tenant, NotificationDelivery, NotificationTemplate, PlatformMonthlyReport, PlatformAdmin, User, PaymentCapture, WhatsAppChannel, WhatsAppMessage, OrderAddress, WorkflowDefinition, WorkflowRun
from app.core.config import get_settings
CANONICAL_HANDLERS = {'tenant.created', 'tenant.activated', 'tenant.suspended',
 'tenant.reactivated',
 'storefront.created',
 'storefront.published',
 'storefront.suspended',
 'domain.provisioned',
 'product.created',
 'product.updated',
 'product.deleted',
 'variant.created',
 'variant.updated',
 'inventory.reserved',
 'inventory.released',
 'inventory.adjusted',
 'order.created',
 'order.confirmed',
 'order.cancelled',
 'order.shipped',
 'order.delivered',
 'order.tracking.updated',
 'payment.intent.created',
 'payment.authorized',
 'payment.captured',
 'payment.failed',
 'payment.voided',
 'refund.created',
 'refund.completed',
 'platform.commission.created',
 'coupon.redeemed',
 'promotion.usage.incremented',
 'subscription.created',
 'subscription.updated',
 'subscription.cancelled',
 'billing.payment_succeeded',
 'billing.payment_failed',
 'entitlement.changed',
 'wishlist.item_added',
 'wishlist.item_removed',
 'review.submitted',
 'review.moderated',
 'question.submitted',
 'question.answered',
 'media.created',
 'media.deleted',
 'audit.security_event',
 'theme.published',
 'loyalty.earned',
 'loyalty.redeemed',
 'marketing.abandoned_cart.scheduled',
 'app.installed',
 'app.webhook.created',
 'workflow.created',
    'workflow.run.queued', 'support.ticket.created', 'notification.send.queued', 'market.created',
 'domain.purchase.payment_captured'}

# Events that are intentionally emitted for app-webhook/audit consumers but do not
# require an internal worker side-effect. They must not be treated as poison events.
AUXILIARY_EVENT_TYPES = {
    'agent.profile.created', 'customer.order.issue.message.sent', 'customer.order.issue.opened',
    'merchant.order.issue.message.sent', 'merchant.order.issue.updated', 'merchant.review.required',
    'order.issue.refunded', 'privacy.request.submitted', 'return.approved', 'return.rejected',
    'return.requested', 'shipment.created', 'workflow.webhook.requested',
}


def _claim_events(db, batch_size, visibility, tenant_id):
    now = datetime.now(timezone.utc)
    set_tenant_context(db, tenant_id)
    q = db.query(OutboxEvent).filter(OutboxEvent.tenant_id == tenant_id).filter(or_(OutboxEvent.status == 'PENDING',
     and_(OutboxEvent.status == 'PROCESSING',
     OutboxEvent.next_attempt_at <= now))).filter(or_(OutboxEvent.next_attempt_at.is_(None),
        OutboxEvent.next_attempt_at <= now)).order_by(OutboxEvent.created_at).limit(batch_size)
    if db.bind.dialect.name == 'postgresql':
        q = q.with_for_update(skip_locked=True)
    events = q.all()
    for ev in events:
        ev.status = 'PROCESSING'
        ev.next_attempt_at = now + timedelta(seconds=visibility)
    db.commit()
    return [e.id for e in events]

def release_expired_reservations(db, batch_size=100, tenant_id=None):
    now = datetime.now(timezone.utc)
    if tenant_id:
        set_tenant_context(db, tenant_id)
    q = db.query(InventoryReservation).filter(InventoryReservation.status == 'ACTIVE',
        InventoryReservation.expires_at <= now)
    if tenant_id:
        q = q.filter(InventoryReservation.tenant_id == tenant_id)
    q = q.order_by(InventoryReservation.expires_at).limit(batch_size)
    if db.bind.dialect.name == 'postgresql':
        q = q.with_for_update(skip_locked=True)
    rows = q.all()
    released = 0
    for r in rows:
        inv = db.query(InventoryItem).filter_by(id=r.inventory_item_id,
            tenant_id=r.tenant_id).with_for_update().first()
        if not inv:
            r.status = 'RELEASE_FAILED'
            continue
        inv.reserved = max(0, inv.reserved - r.quantity)
        inv.available = inv.on_hand - inv.reserved - inv.committed
        inv.version += 1
        r.status = 'RELEASED'
        released += 1
        order = db.query(Order).filter_by(id=r.order_id,
            tenant_id=r.tenant_id).with_for_update().first()
        if order and order.status == 'PENDING_PAYMENT':
            old = order.status
            order.status = 'CANCELLED'
            order.payment_status = 'EXPIRED'
            db.add(OrderStatusHistory(tenant_id=r.tenant_id, order_id=order.id, from_state=old,
                to_state='CANCELLED', reason='inventory_reservation_expired'))
    db.commit()
    return released

def cleanup_guest_state(db, batch_size=500, tenant_id=None):
    now = datetime.now(timezone.utc)
    if tenant_id:
        set_tenant_context(db, tenant_id)
    q = db.query(GuestSession).filter(GuestSession.expires_at <= now)
    if tenant_id:
        q = q.filter(GuestSession.tenant_id == tenant_id)
    q = q.order_by(GuestSession.expires_at).limit(batch_size)
    expired = q.all()
    for g in expired:
        db.query(Cart).filter_by(guest_session_id=g.id, status='OPEN').update({'status': 'EXPIRED',
            'expires_at': now, 'updated_at': now}, synchronize_session=False)
        db.delete(g)
    carts = db.query(Cart).filter(Cart.status == 'OPEN', Cart.expires_at.is_not(None),
        Cart.expires_at <= now)
    if tenant_id:
        carts = carts.filter(Cart.tenant_id == tenant_id)
    carts.update({'status': 'EXPIRED', 'updated_at': now}, synchronize_session=False)
    db.commit()
    return len(expired)


def process_notification_deliveries(db, batch_size=50, tenant_id=None):
    """Deliver queued notifications with a durable PROCESSING boundary.

    The row is committed as PROCESSING before network I/O. If the provider succeeds
    but the process crashes before the SENT commit, the row remains PROCESSING and is
    not automatically replayed, preventing blind duplicate sends. Ambiguous failures
    are marked RECONCILIATION_REQUIRED rather than retried automatically.
    """
    now = datetime.now(timezone.utc)
    if tenant_id:
        set_tenant_context(db, tenant_id)
    rows_q = db.query(NotificationDelivery).filter(
        NotificationDelivery.status == 'QUEUED',
        or_(NotificationDelivery.scheduled_at.is_(None), NotificationDelivery.scheduled_at <= now),
    )
    if tenant_id:
        rows_q = rows_q.filter(NotificationDelivery.tenant_id == tenant_id)
    rows_q = rows_q.order_by(NotificationDelivery.created_at).limit(max(1, min(batch_size, 200)))
    if db.bind.dialect.name == 'postgresql':
        rows_q = rows_q.with_for_update(skip_locked=True)
    rows = rows_q.all()
    delivered = 0
    for row in rows:
        row.status = 'PROCESSING'
        row.error_message = None
        db.commit()
        try:
            if row.channel != 'email':
                row.status = 'FAILED'
                row.error_message = 'Only email notification delivery is enabled'
                db.commit()
                continue
            template = db.query(NotificationTemplate).filter_by(
                id=row.template_id, tenant_id=row.tenant_id, active=True
            ).first() if row.template_id else None
            from app.services.mailer import send_email
            send_email(
                row.recipient,
                template.subject if template else 'Unified Commerce notification',
                template.body if template else str(row.payload),
            )
            row.status = 'SENT'
            row.sent_at = datetime.now(timezone.utc)
            row.error_message = None
            db.commit()
            delivered += 1
        except Exception as exc:
            # Network/SMTP failures can be ambiguous: the provider may have accepted
            # the message before the client observed the exception. Never auto-retry.
            row.status = 'RECONCILIATION_REQUIRED'
            row.error_message = str(exc)[:2000]
            db.commit()
    return delivered


def process_whatsapp_deliveries(db, batch_size=50, tenant_id=None):
    """Deliver queued WhatsApp messages with durable PROCESSING semantics."""
    now = datetime.now(timezone.utc)
    if tenant_id:
        set_tenant_context(db, tenant_id)
    rows_q = db.query(WhatsAppMessage).filter(
        WhatsAppMessage.direction == 'OUTBOUND',
        WhatsAppMessage.status == 'QUEUED',
    )
    if tenant_id:
        rows_q = rows_q.filter(WhatsAppMessage.tenant_id == tenant_id)
    rows_q = rows_q.order_by(WhatsAppMessage.created_at).limit(max(1, min(batch_size, 200)))
    if db.bind.dialect.name == 'postgresql':
        rows_q = rows_q.with_for_update(skip_locked=True)
    rows = rows_q.all()
    delivered = 0
    for row in rows:
        row.status = 'PROCESSING'
        row.error_message = None
        db.commit()
        try:
            channel = db.query(WhatsAppChannel).filter_by(
                id=row.channel_id, tenant_id=row.tenant_id, status='ACTIVE'
            ).first()
            if not channel:
                row.status = 'FAILED'
                row.error_message = 'WhatsApp channel is not active'
                db.commit()
                continue
            from app.services.advanced import send_whatsapp
            meta = row.meta or {}
            provider_id, raw = send_whatsapp(
                channel, row.recipient, row.body,
                template_name=meta.get('template_name'),
                template_params=meta.get('template_params') or [],
            )
            if not provider_id:
                row.status = 'RECONCILIATION_REQUIRED'
                row.error_message = 'Provider returned no message reference'
            else:
                row.provider_message_id = provider_id
                row.meta = raw
                row.status = 'SENT'
                row.sent_at = datetime.now(timezone.utc)
                delivered += 1
            db.commit()
        except Exception as exc:
            row.status = 'RECONCILIATION_REQUIRED'
            row.error_message = str(exc)[:2000]
            db.commit()
    return delivered

def _tenant_ids(db):
    return [x for x, in db.query(Tenant.id).all()]

def _trigger_event_workflows(db, event):
    """Create at-most-once workflow runs for an outbox event.

    The source event id is part of a unique database constraint so a retrying
    worker cannot create a second run for the same workflow/event pair.
    """
    if not event.tenant_id or not event.event_type or event.event_type == 'workflow.run.queued':
        return 0
    workflows = db.query(WorkflowDefinition).filter_by(tenant_id=event.tenant_id,
        trigger_event=event.event_type, enabled=True).all()
    created = 0
    for workflow in workflows:
        dedupe_key = f'workflow.run.queued:{event.tenant_id}:{workflow.id}:{event.id}'
        exists = db.query(WorkflowRun.id).filter_by(tenant_id=event.tenant_id,
            workflow_id=workflow.id, source_event_id=event.id).first()
        if exists:
            # The run uniqueness is the primary idempotency boundary. The outbox
            # dedupe key is a second durable boundary so the queue event itself
            # can never be materialized more than once for this workflow/event pair.
            queued_exists = db.query(OutboxEvent.id).filter_by(dedupe_key=dedupe_key).first()
            if queued_exists:
                continue
            # A prior crash could theoretically leave a committed run without its
            # queue event. Repair that state exactly once rather than silently
            # skipping the automation.
            try:
                with db.begin_nested():
                    from app.services.core import outbox
                    outbox(db, event.tenant_id, 'workflow_run', exists.id, 'workflow.run.queued',
                        {'workflow_run_id': exists.id, 'workflow_id': workflow.id,
                         'tenant_id': event.tenant_id, 'source_event_id': event.id},
                        dedupe_key=dedupe_key)
                created += 1
            except IntegrityError:
                db.expire_all()
            continue
        run = WorkflowRun(tenant_id=event.tenant_id, workflow_id=workflow.id,
            source_event_id=event.id, trigger_event=event.event_type, status='QUEUED',
            input_payload={'event_id': event.id, 'event_type': event.event_type,
                'aggregate_type': event.aggregate_type, 'aggregate_id': event.aggregate_id,
                'payload': event.payload}, output_payload={})
        try:
            with db.begin_nested():
                db.add(run)
                db.flush()
                from app.services.core import outbox
                outbox(db, event.tenant_id, 'workflow_run', run.id, 'workflow.run.queued',
                    {'workflow_run_id': run.id, 'workflow_id': workflow.id,
                     'tenant_id': event.tenant_id, 'source_event_id': event.id},
                    dedupe_key=dedupe_key)
            created += 1
        except IntegrityError:
            db.expire_all()
    return created

def _execute_workflow(db, run):
    from app.models.domain import WorkflowDefinition, LoyaltyAccount, LoyaltyTransaction, Customer
    from app.services.core import audit
    wf = db.query(WorkflowDefinition).filter_by(id=run.workflow_id, tenant_id=run.tenant_id).first()
    if not wf or not wf.enabled:
        raise RuntimeError('Workflow is missing or disabled')
    run.status = 'RUNNING'
    run.started_at = datetime.now(timezone.utc)
    db.flush()
    output = {'steps': []}
    for step in wf.steps or []:
        kind = step.get('type') if isinstance(step, dict) else None
        if kind == 'ADD_LOYALTY_POINTS':
            customer_id = step.get('customer_id') or run.input_payload.get('customer_id')
            points = int(step.get('points', 0))
            if not customer_id or points <= 0:
                raise RuntimeError('Invalid loyalty workflow step')
            account = db.query(LoyaltyAccount).filter_by(tenant_id=run.tenant_id,
                customer_id=customer_id).first()
            if not account:
                raise RuntimeError('Loyalty account not found')
            account.points_balance += points
            account.lifetime_earned += points
            db.add(LoyaltyTransaction(tenant_id=run.tenant_id, loyalty_account_id=account.id,
             order_id=run.input_payload.get('order_id'),
             points_delta=points,
             reason=step.get('reason',
                'workflow'), idempotency_key=f"workflow:{run.id}:{len(output['steps'])}"))
            output['steps'].append({'type': kind, 'points': points})
        elif kind == 'TAG_CUSTOMER':
            output['steps'].append({'type': kind, 'tag': str(step.get('tag', '')).strip()})
        elif kind == 'SEND_EMAIL':
            output['steps'].append({'type': kind, 'queued': True})
        elif kind == 'CREATE_COUPON':
            output['steps'].append({'type': kind, 'queued': True})
        elif kind == 'WEBHOOK':
            output['steps'].append({'type': kind, 'queued': True})
        else:
            raise RuntimeError(f'Unsupported workflow step: {kind}')
    run.output_payload = output
    run.status = 'COMPLETED'
    run.completed_at = datetime.now(timezone.utc)
    db.flush()

def run_platform_monthly_report(db):
    from app.services.advanced import platform_metrics
    from app.services.mailer import send_email
    now = datetime.now(timezone.utc)
    if now.day != 1:
        return False
    previous = (now.replace(day=1) - timedelta(days=1)).strftime('%Y-%m')
    existing = db.query(PlatformMonthlyReport).filter_by(period_key=previous).first()
    if existing:
        return False
    start = datetime.strptime(previous + '-01', '%Y-%m-%d').replace(tzinfo=timezone.utc)
    end = now.replace(day=1)
    metrics = platform_metrics(db, start, end)
    recipients = [u.email for u in db.query(User).join(PlatformAdmin, PlatformAdmin.user_id == User.id).all()]
    report = PlatformMonthlyReport(period_key=previous, recipients=recipients, metrics=metrics, delivery_status='SENDING')
    db.add(report)
    try:
        # Durable boundary: persist that this period owns the send before any email I/O.
        db.flush()
        db.commit()
    except IntegrityError:
        db.rollback()
        return False
    subject = f'Unified Commerce — Monthly Platform Report {previous}'
    body = '\n'.join([f'{k}: {v}' for k, v in metrics.items()])
    failed = []
    for recipient in recipients:
        try:
            send_email(recipient, subject, body)
        except Exception as exc:
            failed.append(str(exc))
    report_db = SessionLocal()
    try:
        persisted = report_db.query(PlatformMonthlyReport).filter_by(period_key=previous).with_for_update().first() if report_db.bind.dialect.name == 'postgresql' else report_db.query(PlatformMonthlyReport).filter_by(period_key=previous).first()
        if not persisted:
            return False
        persisted.delivery_status = 'SENT' if not failed else 'RECONCILIATION_REQUIRED'
        report_db.commit()
    finally:
        report_db.close()
    return True


def process_domain_registration(db, purchase):
    """Perform a paid domain registration with a durable pre-call state.

    Once REGISTRATION_PROCESSING is committed, the worker never automatically retries
    the external registrar call. An interrupted call is therefore reconciled manually
    instead of risking a second real domain registration.
    """
    from app.models.domain import Domain, Storefront
    from app.services.domain_registrar import check_domain, register_domain
    tenant_id = purchase.tenant_id
    if purchase.status in {'REGISTERED', 'COMPLETED', 'REGISTRATION_PENDING'}:
        return 'NOOP'
    if purchase.status == 'REGISTRATION_RECONCILIATION_REQUIRED':
        return 'RECONCILIATION_REQUIRED'
    if purchase.status == 'REGISTRATION_PROCESSING':
        purchase.status = 'REGISTRATION_RECONCILIATION_REQUIRED'
        purchase.failure_reason = 'External registrar attempt is unresolved; manual reconciliation is required'
        db.commit()
        return 'RECONCILIATION_REQUIRED'
    if purchase.status != 'PENDING_PAYMENT':
        raise RuntimeError(f'Invalid domain purchase state: {purchase.status}')

    info = db.info if hasattr(db, 'info') else {}
    captured_amount = int(info.get('captured_amount_minor') or 0)
    captured_currency = str(info.get('captured_currency') or '').upper()
    if captured_amount != int(purchase.customer_price_minor) or captured_currency != str(purchase.currency).upper():
        raise RuntimeError('Domain purchase capture amount/currency mismatch')

    check = check_domain(purchase.hostname)
    if not check.get('registrable'):
        raise RuntimeError('Domain became unavailable before registration')
    domain = db.query(Domain).filter_by(hostname=purchase.hostname).first()
    if not domain:
        storefront = db.query(Storefront).filter_by(tenant_id=tenant_id, status='PUBLISHED').order_by(Storefront.version.desc()).first()
        if not storefront:
            raise RuntimeError('Published storefront is required before attaching a registered domain')
        domain = Domain(tenant_id=tenant_id, storefront_id=storefront.id, hostname=purchase.hostname, verified_at=None, verification_method='registrar')
        db.add(domain)
        db.flush()
    elif domain.tenant_id != tenant_id:
        raise RuntimeError('Domain is already owned by another tenant')

    purchase.domain_id = domain.id
    purchase.status = 'REGISTRATION_PROCESSING'
    purchase.failure_reason = None
    db.flush()
    db.commit()

    try:
        result = register_domain(purchase.hostname, purchase.registrant_snapshot or {}, purchase.years)
    except Exception as exc:
        purchase.status = 'REGISTRATION_RECONCILIATION_REQUIRED'
        purchase.failure_reason = str(exc)[:2000]
        db.commit()
        return 'RECONCILIATION_REQUIRED'

    provider_reference = str(result.get('reference') or '').strip()
    if not provider_reference:
        purchase.status = 'REGISTRATION_RECONCILIATION_REQUIRED'
        purchase.failure_reason = 'Registrar returned no registration reference; external outcome is not safely reconcilable'
        db.commit()
        return 'RECONCILIATION_REQUIRED'
    purchase.provider_reference = provider_reference
    purchase.status = 'COMPLETED' if result.get('status') == 'REGISTERED' else 'REGISTRATION_PENDING'
    purchase.completed_at = datetime.now(timezone.utc) if purchase.status == 'COMPLETED' else None
    db.commit()
    return purchase.status

def run_once(max_attempts=None):
    s = get_settings()
    max_attempts = max_attempts or s.OUTBOX_MAX_ATTEMPTS
    tenant_db = SessionLocal()
    try:
        tenant_ids = _tenant_ids(tenant_db)
    finally:
        tenant_db.close()
    report_db = SessionLocal()
    try:
        run_platform_monthly_report(report_db)
    finally:
        report_db.close()
    count = 0
    from app.services.app_webhooks import process_webhook_deliveries
    for tenant_id in tenant_ids:
        delivery_db = SessionLocal()
        try:
            set_tenant_context(delivery_db, tenant_id)
            from app.services.app_webhooks import recover_stale_webhook_deliveries, process_webhook_deliveries
            recover_stale_webhook_deliveries(delivery_db, stale_seconds=get_settings().OUTBOX_VISIBILITY_TIMEOUT_SECONDS, tenant_id=tenant_id)
            process_webhook_deliveries(delivery_db, get_settings().APP_WEBHOOK_BATCH_SIZE)
            from app.services.workflow_webhooks import recover_stale_workflow_webhook_deliveries, process_workflow_webhook_deliveries
            recover_stale_workflow_webhook_deliveries(delivery_db, stale_seconds=get_settings().OUTBOX_VISIBILITY_TIMEOUT_SECONDS, tenant_id=tenant_id)
            process_workflow_webhook_deliveries(delivery_db, batch_size=25, tenant_id=tenant_id)
            process_notification_deliveries(delivery_db, batch_size=50, tenant_id=tenant_id)
            process_whatsapp_deliveries(delivery_db, batch_size=50, tenant_id=tenant_id)
        finally:
            delivery_db.close()
        cleanup_db = SessionLocal()
        try:
            release_expired_reservations(cleanup_db, tenant_id=tenant_id)
            cleanup_guest_state(cleanup_db, tenant_id=tenant_id)
        finally:
            cleanup_db.close()
        claim_db = SessionLocal()
        try:
            ids = _claim_events(claim_db, s.OUTBOX_BATCH_SIZE, s.OUTBOX_VISIBILITY_TIMEOUT_SECONDS,
                tenant_id)
        finally:
            claim_db.close()
        for event_id in ids:
            db = SessionLocal()
            count += 1
            try:
                set_tenant_context(db, tenant_id)
                ev = db.query(OutboxEvent).filter_by(id=event_id, tenant_id=tenant_id).first()
                if not ev:
                    db.rollback()
                    continue
                try:
                    if ev.event_type not in CANONICAL_HANDLERS and ev.event_type not in AUXILIARY_EVENT_TYPES:
                        raise RuntimeError(f'No worker contract registered for event {ev.event_type}')
                    if ev.event_type in {'order.confirmed', 'order.shipped'}:
                        order_id = ev.payload.get('order_id')
                        order = db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).first() if order_id else None
                        channel = db.query(WhatsAppChannel).filter_by(tenant_id=tenant_id, status='ACTIVE').first()
                        address = db.query(OrderAddress).filter_by(tenant_id=tenant_id, order_id=order_id, type='SHIPPING').first() if order_id else None
                        phone = address.phone if address else None
                        if order and channel and phone:
                            text = f"طلبك {order.order_number} تم تأكيده." if ev.event_type == 'order.confirmed' else f"طلبك {order.order_number} تم شحنه."
                            template_name = (get_settings().WHATSAPP_ORDER_CONFIRMED_TEMPLATE if ev.event_type == 'order.confirmed' else get_settings().WHATSAPP_ORDER_SHIPPED_TEMPLATE)
                            db.add(WhatsAppMessage(tenant_id=tenant_id, channel_id=channel.id, recipient=str(phone), body=text, message_type='template' if template_name else 'text', status='QUEUED', meta={'template_name': template_name, 'template_params': [order.order_number]}))

                    if ev.event_type == 'marketing.abandoned_cart.scheduled':
                        campaign_id = ev.payload.get('campaign_id')
                        from app.models.domain import AbandonedCartCampaign, Customer, MarketingPreference
                        campaign = db.query(AbandonedCartCampaign).filter_by(id=campaign_id, tenant_id=tenant_id).first() if campaign_id else None
                        channel = db.query(WhatsAppChannel).filter_by(tenant_id=tenant_id, status='ACTIVE').first()
                        cart = db.query(Cart).filter_by(id=campaign.cart_id, tenant_id=tenant_id).first() if campaign else None
                        customer = db.query(Customer).filter_by(id=cart.customer_id, tenant_id=tenant_id).first() if cart and cart.customer_id else None
                        pref = db.query(MarketingPreference).filter_by(tenant_id=tenant_id, customer_id=customer.id).first() if customer else None
                        if campaign and channel and customer and customer.phone and pref and pref.whatsapp_marketing and campaign.status in {'PENDING', 'QUEUED'}:
                            text = 'لديك منتجات تنتظرك في سلة التسوق. أكمل طلبك قبل نفاد الكمية.'
                            template_name = get_settings().WHATSAPP_ABANDONED_CART_TEMPLATE
                            db.add(WhatsAppMessage(tenant_id=tenant_id, channel_id=channel.id, recipient=str(customer.phone), body=text, message_type='template' if template_name else 'text', status='QUEUED', meta={'template_name': template_name, 'campaign_id': campaign.id}))
                            campaign.status = 'QUEUED'; campaign.attempt_count += 1
                    if ev.event_type == 'notification.send.queued':
                        row = db.query(NotificationDelivery).filter_by(id=ev.payload.get('notification_delivery_id'),
                            tenant_id=tenant_id).first()
                        if not row:
                            raise RuntimeError('Notification delivery not found')
                        if row.status == 'QUEUED':
                            if row.channel != 'email':
                                raise RuntimeError('Only email notification delivery is enabled')
                            template = db.query(NotificationTemplate).filter_by(id=row.template_id,
                                tenant_id=tenant_id).first() if row.template_id else None
                            # Do not perform network I/O inside the event transaction.
                            # The committed NotificationDelivery is processed separately.
                            if row.status == 'QUEUED':
                                row.scheduled_at = row.scheduled_at or datetime.now(timezone.utc)
                    _trigger_event_workflows(db, ev)
                    if ev.event_type == 'workflow.run.queued':
                        run = db.query(__import__('app.models.domain',
                         fromlist=['WorkflowRun']).WorkflowRun).filter_by(id=ev.payload.get('workflow_run_id'),
                            tenant_id=tenant_id).first()
                        if not run:
                            raise RuntimeError('Workflow run not found')
                        _execute_workflow(db, run)
                    if ev.event_type == 'domain.purchase.payment_captured':
                        from app.models.domain import DomainPurchase
                        purchase = db.query(DomainPurchase).filter_by(id=ev.payload.get('purchase_id'), tenant_id=tenant_id).with_for_update().first()
                        if not purchase:
                            raise RuntimeError('Domain purchase not found')
                        if not hasattr(db, 'info'):
                            db.info = {}
                        db.info['captured_amount_minor'] = int(ev.payload.get('amount_minor') or 0)
                        db.info['captured_currency'] = str(ev.payload.get('currency', '')).upper()
                        process_domain_registration(db, purchase)
                    if ev.event_type:
                        from app.services.app_webhooks import deliver_event
                        deliver_event(db, ev)
                    if ev.event_type == 'workflow.webhook.requested':
                        from app.services.workflow_webhooks import materialize_workflow_webhook
                        materialize_workflow_webhook(db, ev)
                    ev.status = 'PROCESSED'
                    ev.processed_at = datetime.now(timezone.utc)
                    ev.next_attempt_at = None
                    ev.last_error = None
                    db.commit()
                    # Network delivery is deliberately outside the event transaction.
                    # If a later handler fails, an already-sent webhook must not be
                    # rolled back to PENDING and sent again because of that rollback.
                    delivery_db = SessionLocal()
                    try:
                        set_tenant_context(delivery_db, tenant_id)
                        process_webhook_deliveries(delivery_db, get_settings().APP_WEBHOOK_BATCH_SIZE)
                        from app.services.workflow_webhooks import process_workflow_webhook_deliveries
                        process_workflow_webhook_deliveries(delivery_db, batch_size=25, tenant_id=tenant_id)
                        process_notification_deliveries(delivery_db, batch_size=50, tenant_id=tenant_id)
                        process_whatsapp_deliveries(delivery_db, batch_size=50, tenant_id=tenant_id)
                        delivery_db.commit()
                    except Exception:
                        delivery_db.rollback()
                    finally:
                        delivery_db.close()
                except Exception as exc:
                    ev.attempt_count += 1
                    ev.last_error = str(exc)[:2000]
                    if ev.attempt_count >= max_attempts:
                        ev.status = 'FAILED'
                        ev.next_attempt_at = None
                        db.add(DeadLetterEvent(tenant_id=ev.tenant_id, source_event_id=ev.id,
                         event_type=ev.event_type,
                         payload=ev.payload,
                            failure_reason=str(exc)[:2000], attempt_count=ev.attempt_count))
                    else:
                        ev.status = 'PENDING'
                        base = min(900, 2 ** min(ev.attempt_count, 9))
                        ev.next_attempt_at = datetime.now(timezone.utc) + timedelta(seconds=base + random.uniform(0,
                            1.5))
                    db.commit()
            finally:
                db.close()
    return count
if __name__ == '__main__':  # pragma: no cover
    while True:
        run_once()
        time.sleep(2)
