from fastapi import FastAPI, Request, Response, Depends
from contextlib import asynccontextmanager
import json, logging, html
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from pathlib import Path
from app.core.database import SessionLocal
from app.models import domain
from app.routes.v1 import router
from app.routes.advanced import router as advanced_router
from app.routes.worldclass import router as worldclass_router
from app.routes.auth_routes import router as auth_router
from app.routes.product_routes import router as product_router
from app.routes.merchant_compliance_routes import router as merchant_router
from app.routes.apps_marketplace_routes import router as apps_router
from app.routes.theme_routes import router as theme_router
from app.routes.marketing_routes import router as marketing_router
from app.routes.tenant_setup_routes import router as tenant_setup_router
from app.routes.support_routes import router as support_router
from app.routes.workflow_market_routes import router as workflow_market_router
from app.routes.notification_routes import router as notification_router
from app.routes.risk_apikey_routes import router as risk_apikey_router
from app.routes.mfa_routes import router as mfa_router
from app.routes.media_routes import router as media_router
from app.routes.oauth_routes import router as oauth_router
from app.routes.review_qa_routes import router as review_qa_router
from app.routes.member_routes import router as member_router
from app.routes.category_routes import router as category_router
from app.routes.wishlist_routes import router as wishlist_router
from app.routes.tax_routes import router as tax_router
from app.routes.onboarding_routes import router as onboarding_router
from app.routes.shipping_routes import router as shipping_router
from app.routes.inventory_routes import router as inventory_router
from app.routes.customer_routes import router as customer_router
from app.routes.return_routes import router as return_router
from app.routes.billing_routes import router as billing_router
from app.routes.system_routes import router as system_router
from app.routes.order_routes import router as order_router
from app.routes.cart_routes import router as cart_router
from app.routes.turkey_routes import router as turkey_router
from app.routes.domain_purchase_routes import router as domain_purchase_router
from app.routes.platform_trust_routes import router as platform_trust_router
from app.routes.public_storefront_routes import router as public_storefront_router
from app.routes.checkout_routes import router as checkout_router
from app.routes.payment_routes import router as payment_router
from app.routes.auth_google_routes import router as auth_google_router
from app.routes.privacy_routes import router as privacy_router
from app.routes.buyer_protection_routes import router as buyer_protection_router
from app.routes.webhook_routes import router as webhook_router
from app.core.config import get_settings
from app.core.database import engine
from sqlalchemy import text, func
settings = get_settings()
logging.basicConfig(level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format='%(asctime)s %(levelname)s %(name)s %(message)s')
logger = logging.getLogger('unified_commerce')

def _safe_jsonld(value) -> str:
    """Serialize JSON-LD safely for embedding inside an HTML script element."""
    return (json.dumps(value, ensure_ascii=False, separators=(',', ':'))
            .replace('<', '\\u003c')
            .replace('>', '\\u003e')
            .replace('&', '\\u0026')
            .replace('\u2028', '\\u2028')
            .replace('\u2029', '\\u2029'))

def _ssr_money(amount_minor, currency: str) -> str:
    try:
        value = f'{(int(amount_minor or 0) / 100):,.2f}'
    except (TypeError, ValueError):
        value = '0.00'
    return f'{value} {html.escape(currency or "")}'

def _ssr_product_card(p, currency: str) -> str:
    """Server-rendered product card markup, matching storefront.js's renderInto()
    template exactly so there is no visual flash when the client JS hydrates over it."""
    variants = getattr(p, '_ssr_variants', None) or []
    v = variants[0] if variants else None
    sale = int(getattr(v, 'price_amount_minor', 0) or 0) if v else 0
    listp = sale
    on_sale = listp > sale
    title = html.escape(p.title or 'Product')
    desc = html.escape((p.description or '')[:90])
    media = getattr(p, '_ssr_media_url', None)
    visual = (f'<img src="{html.escape(media)}" alt="{title}" loading="lazy">' if media
        else f'<div class="visual-letter">{html.escape((p.title or "U")[:1])}</div>')
    badge = '<span style="position:absolute;right:10px;top:10px;background:#151617;color:#fff;border-radius:8px;padding:5px 7px;font-size:8px">عرض</span>' if on_sale else ''
    old_price = f'<small class="old-price">{_ssr_money(listp, currency)}</small>' if on_sale else ''
    return (f'<article class="product-card"><div class="product-visual"><button class="heart" '
        f'data-wish="{html.escape(p.id)}">♡</button>{visual}{badge}</div><div class="product-info">'
        f'<h3>{title}</h3><p>{desc}</p><div class="price-row"><span class="price">'
        f'{_ssr_money(sale, currency)} {old_price}</span><button class="product-btn" '
        f'data-open="{html.escape(p.id)}">عرض</button></div></div></article>')

def _ssr_product_grid_html(products, currency: str) -> str:
    if not products:
        return '<div class="muted">لا توجد منتجات متاحة حاليًا.</div>'
    return ''.join((_ssr_product_card(p, currency) for p in products))

def _inject_ssr_grid(page: str, grid_html: str) -> str:
    marker = '<div id="productGrid" class="product-grid"></div>'
    if marker not in page:
        return page
    return page.replace(marker, f'<div id="productGrid" class="product-grid">{grid_html}</div>', 1)

def _inject_ssr_product(page: str, *, title_text: str, description_text: str, price_text: str,
        image_url: str | None) -> str:
    """Injects a visible, crawlable product summary right after <body> for direct
    product-page hits, so a client without JavaScript still sees real content
    instead of the bare app shell. The client JS replaces/enhances this once it
    loads (openProduct() re-renders the same information as an interactive modal)."""
    title = html.escape(title_text)
    desc = html.escape(description_text[:300])
    img = f'<img src="{html.escape(image_url)}" alt="{title}" style="max-width:280px;border-radius:16px">' if image_url else ''
    block = (f'<section id="ssrProduct" style="max-width:960px;margin:24px auto;padding:0 20px">'
        f'<div style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start">{img}'
        f'<div><h1 style="margin:0 0 8px">{title}</h1><p style="color:#6b6f76;max-width:520px">{desc}</p>'
        f'<p style="font-size:20px;font-weight:700">{html.escape(price_text)}</p></div></div></section>')
    return page.replace('<body>', '<body>' + block, 1)

def _render_seo_page(*, hostname: str, title_text: str, description_text: str, canonical: str,
        og_type: str, image_url: str, jsonld: dict | None = None) -> str:
    """Single source of truth for injecting SEO head tags (title, OG, Twitter, canonical,
    JSON-LD) into storefront.html for every public-facing route (custom domain and
    platform /store/{hostname} routes alike). Centralizing this avoids the SEO-tag drift
    that previously left the /store/{hostname} routes without any JSON-LD structured data
    while the custom-domain routes had it."""
    page = Path('app/frontend/storefront.html').read_text(encoding='utf-8')
    title = html.escape(title_text)
    description = html.escape(description_text[:300])
    canonical_esc = html.escape(canonical)
    schema_tag = f'<script type="application/ld+json">{_safe_jsonld(jsonld)}</script>' if jsonld else ''
    head = f'''<meta name="description" content="{description}">
<meta property="og:type" content="{og_type}"><meta property="og:title" content="{title}">
<meta property="og:description" content="{description}"><meta property="og:url" content="{canonical_esc}"><meta property="og:image" content="{image_url}">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{title}"><meta name="twitter:description" content="{description}"><meta name="twitter:image" content="{image_url}">
<link rel="canonical" href="{canonical_esc}">{schema_tag}'''
    return (page.replace('<head>', f'<head><meta name="store-host" content="{html.escape(hostname, quote=True)}">', 1)
        .replace('<title>Store</title>', f'<title>{title}</title>', 1)
        .replace('</head>', head + '</head>', 1))

app = FastAPI(title=settings.APP_NAME, version=settings.APP_VERSION,
 docs_url='/docs' if settings.ENVIRONMENT != 'production' else None,
    redoc_url='/redoc' if settings.ENVIRONMENT != 'production' else None)
app.mount('/static', StaticFiles(directory='app/frontend'), name='static')
if settings.ENVIRONMENT == 'production':
    if settings.SECRET_KEY in {'change-me-immediately',
        'replace-with-a-32-byte-random-secret'} or len(settings.SECRET_KEY) < 32:
        raise RuntimeError('SECRET_KEY must be a strong production secret')
    if settings.WEBHOOK_SECRET in {'change-me', 'replace-me'} or len(settings.WEBHOOK_SECRET) < 32:
        raise RuntimeError('WEBHOOK_SECRET must be a strong production secret')
    if not settings.COOKIE_SECURE:
        raise RuntimeError('COOKIE_SECURE must be enabled in production')
origins = [x.strip() for x in settings.CORS_ORIGINS.split(',') if x.strip()]
allowed_hosts = [x.strip() for x in settings.ALLOWED_HOSTS.split(',') if x.strip()]
if settings.ENVIRONMENT != 'production':
    allowed_hosts += ['testserver', 'localhost', '127.0.0.1']
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True,
 allow_methods=['GET',
 'POST',
 'PATCH',
 'DELETE',
 'OPTIONS'],
 allow_headers=['Authorization',
    'Content-Type', 'Idempotency-Key', 'X-Signature', 'X-CSRF-Token', 'X-Request-ID'])

@app.middleware('http')
async def correlation_and_browser_security(request, call_next):
    
    supplied_request_id = (request.headers.get('X-Request-ID') or '').strip()
    # Never reflect arbitrary attacker-controlled bytes into response headers/logs.
    # Preserve standards-friendly trace IDs when supplied; otherwise mint one.
    if supplied_request_id and len(supplied_request_id) <= 128 and all(c.isalnum() or c in '-._:' for c in supplied_request_id):
        request.state.request_id = supplied_request_id
    else:
        request.state.request_id = __import__('uuid').uuid4().hex
    host = (request.headers.get('host') or '').split(':', 1)[0].strip().lower().rstrip('.')
    host_ok = host in {h.lower().rstrip('.') for h in allowed_hosts if h and h != '*'}
    if not host_ok and host:
        db = SessionLocal()
        try:
            host_ok = db.query(domain.Domain).filter(func.lower(domain.Domain.hostname) == host, domain.Domain.verified_at.is_not(None)).first() is not None
        finally:
            db.close()
    if not host_ok:
        from fastapi.responses import JSONResponse
        return JSONResponse({'error': {'code': 'HOST_NOT_ALLOWED', 'message': 'Untrusted host'}}, status_code=400)
    content_length = request.headers.get('content-length')
    try:
        declared = int(content_length) if content_length else 0
    except ValueError:
        declared = 0
    path = request.url.path
    limit = settings.MAX_JSON_BODY_BYTES
    if path.endswith('/media'):
        limit = settings.MAX_MEDIA_BODY_BYTES
    elif '/webhook' in path:
        limit = settings.MAX_WEBHOOK_BODY_BYTES
    if declared > limit:
        from fastapi.responses import JSONResponse
        return JSONResponse({'error': {'code': 'REQUEST_TOO_LARGE', 'message': 'Request body exceeds the configured limit'}}, status_code=413)

    # Content-Length is optional for chunked requests. Enforce the limit on the
    # actual ASGI receive stream as well so an attacker cannot bypass limits by
    # omitting the header.
    received = 0
    original_receive = request._receive
    async def limited_receive():
        nonlocal received
        message = await original_receive()
        if message.get('type') == 'http.request':
            chunk = message.get('body', b'') or b''
            received += len(chunk)
            if received > limit:
                from fastapi import HTTPException
                raise HTTPException(status_code=413, detail='Request body exceeds the configured limit')
        return message
    request._receive = limited_receive
    cookie_authenticated = bool(request.cookies.get('session') or request.cookies.get('customer_session'))
    csrf_exempt_paths = {'/v1/auth/register', '/v1/auth/login',
        '/v1/auth/password-reset/request', '/v1/auth/password-reset/confirm', '/v1/oauth/token',
        '/v1/auth/mfa/verify-login'}
    customer_auth_bootstrap = (request.url.path.endswith('/auth/email/start') or
        request.url.path.endswith('/auth/email/verify') or
        request.url.path.endswith('/auth/google/callback') or
        request.url.path.endswith('/auth/google/start'))
    external_webhook = (request.url.path.startswith('/v1/webhooks/') or request.url.path == '/v1/merchant/identity/veriff/webhook' or request.url.path.startswith('/v1/whatsapp/webhook/'))
    public_agentic_api = request.url.path.startswith('/v1/public/storefront/') and ('/ucp/' in request.url.path or request.url.path.endswith('/assistant'))
    if request.method in {'POST', 'PATCH', 'PUT', 'DELETE'} and cookie_authenticated and (not request.headers.get('Authorization')) and (not external_webhook) and (not public_agentic_api) and (request.url.path not in csrf_exempt_paths) and (not customer_auth_bootstrap):
        if getattr(request.state, 'read_only_impersonation', False):
            from fastapi.responses import JSONResponse
            return JSONResponse({'error': {'code': 'IMPERSONATION_READ_ONLY', 'message': 'This support session is read-only'}}, status_code=403)
        csrf = request.cookies.get('impersonation_csrf_token') if request.cookies.get('impersonation_session') else request.cookies.get('csrf_token')
        sent = request.headers.get('X-CSRF-Token')
        origin = request.headers.get('Origin')
        allowed = set(origins)
        same_origin = f'{request.url.scheme}://{host}' if host else ''
        origin_ok = (not origin) or (origin in allowed) or (origin == same_origin)
        if not csrf or not sent or csrf != sent or not origin_ok:
            from fastapi.responses import JSONResponse, FileResponse
            return JSONResponse({'error': {'code': 'CSRF_VALIDATION_FAILED',
                'message': 'CSRF validation failed'}}, status_code=403)
    response = await call_next(request)
    response.headers['X-Request-ID'] = request.state.request_id
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains' if request.url.scheme == 'https' else response.headers.get('Strict-Transport-Security',
        '')
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Cross-Origin-Opener-Policy'] = 'same-origin'
    response.headers['Cross-Origin-Resource-Policy'] = 'same-origin'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' https:; frame-src 'self' https:; frame-ancestors 'none'; object-src 'none'; base-uri 'self'; form-action 'self' https:"
    response.headers['X-Permitted-Cross-Domain-Policies'] = 'none'
    response.headers['Cache-Control'] = 'no-store' if (request.url.path.startswith('/v1') and (request.cookies.get('session') or request.headers.get('Authorization'))) else response.headers.get('Cache-Control', 'no-cache')
    return response

@asynccontextmanager
async def lifespan(app: FastAPI):
    if settings.ENVIRONMENT in {'production', 'staging'}:
        db = SessionLocal()
        try:
            from app.core.runtime import assert_migration_head
            assert_migration_head(db)
        finally:
            db.close()
    yield
app.router.lifespan_context = lifespan
app.include_router(router)
app.include_router(advanced_router)
app.include_router(worldclass_router)
app.include_router(auth_router)
app.include_router(product_router)
app.include_router(merchant_router)
app.include_router(apps_router)
app.include_router(theme_router)
app.include_router(marketing_router)
app.include_router(tenant_setup_router)
app.include_router(support_router)
app.include_router(workflow_market_router)
app.include_router(notification_router)
app.include_router(risk_apikey_router)
app.include_router(mfa_router)
app.include_router(media_router)
app.include_router(oauth_router)
app.include_router(review_qa_router)
app.include_router(member_router)
app.include_router(category_router)
app.include_router(wishlist_router)
app.include_router(tax_router)
app.include_router(onboarding_router)
app.include_router(shipping_router)
app.include_router(inventory_router)
app.include_router(customer_router)
app.include_router(return_router)
app.include_router(billing_router)
app.include_router(system_router)
app.include_router(order_router)
app.include_router(cart_router)
app.include_router(turkey_router)
app.include_router(domain_purchase_router)
app.include_router(platform_trust_router)
app.include_router(public_storefront_router)
app.include_router(checkout_router)
app.include_router(payment_router)
app.include_router(auth_google_router)
app.include_router(privacy_router)
app.include_router(buyer_protection_router)
app.include_router(webhook_router)

@app.get('/.well-known/ucp', include_in_schema=False)
def ucp_discovery(request: Request, response: Response):
    base = str(request.base_url).rstrip('/')
    response.headers['Cache-Control'] = 'public, max-age=300'
    return {
        'ucp': {
            'version': '2026-04-08',
            'services': {
                'dev.ucp.shopping': [{
                    'version': '2026-04-08',
                    'spec': 'https://ucp.dev/2026-04-08/specification/overview',
                    'transport': 'rest',
                    'schema': 'https://ucp.dev/2026-04-08/services/shopping/rest.openapi.json',
                    'endpoint': f'{base}/v1/public/storefront/{{hostname}}/ucp',
                }]
            },
            'capabilities': {
                'dev.ucp.shopping.checkout': [{
                    'version': '2026-04-08',
                    'spec': 'https://ucp.dev/2026-04-08/specification/checkout',
                    'schema': 'https://ucp.dev/2026-04-08/schemas/shopping/checkout.json',
                }],
                'dev.ucp.shopping.fulfillment': [{
                    'version': '2026-04-08',
                    'spec': 'https://ucp.dev/2026-04-08/specification/fulfillment',
                    'schema': 'https://ucp.dev/2026-04-08/schemas/shopping/fulfillment.json',
                    'extends': 'dev.ucp.shopping.checkout',
                }],
            },
        },
        'keys': [],
    }

@app.get('/v1/metrics-lite')
def metrics_lite(admin=Depends(__import__('app.core.auth',
    fromlist=['current_platform_admin']).current_platform_admin)):
    db = SessionLocal()
    try:
        from app.models.domain import OutboxEvent, DeadLetterEvent
        return {'outbox_pending': db.query(OutboxEvent).filter(OutboxEvent.status.in_(['PENDING',
         'PROCESSING'])).count(),
            'dlq_failed': db.query(DeadLetterEvent).filter(DeadLetterEvent.resolved_at.is_(None)).count()}
    finally:
        db.close()

def _ssr_store_products(db, tenant_id: str, storefront_id: str, limit: int = 24):
    """Fetch a small product list with first variant for SSR — intentionally
    lightweight (no translations, no full pricing engine) since this only
    needs to produce crawlable content, not the full interactive catalog the
    client JS fetches afterward. Media URLs are attached by the caller, which
    knows the request hostname."""
    from app.models.domain import Product, ProductVariant
    products = db.query(Product).filter(Product.tenant_id == tenant_id,
        Product.storefront_id == storefront_id, Product.deleted_at.is_(None),
        Product.status == 'ACTIVE').order_by(Product.created_at.desc()).limit(limit).all()
    for p in products:
        v = db.query(ProductVariant).filter_by(tenant_id=tenant_id, product_id=p.id,
            status='ACTIVE').order_by(ProductVariant.sku.asc()).first()
        p._ssr_variants = [v] if v else []
        p._ssr_media_url = None
    return products

def _custom_domain_store(hostname: str):
    from app.models.domain import Domain, Storefront, Tenant
    db = SessionLocal()
    try:
        row = db.query(Domain, Storefront, Tenant).join(Storefront, Storefront.id == Domain.storefront_id).join(Tenant, Tenant.id == Domain.tenant_id).filter(func.lower(Domain.hostname) == hostname.lower(), Domain.verified_at.is_not(None)).first()
        if not row:
            return None
        d, s, t = row
        if t.status != 'ACTIVE' or s.status != 'PUBLISHED':
            return None
        schema = {'@context': 'https://schema.org', '@type': 'Store', 'name': t.name,
            'url': f'https://{d.hostname}/', 'description': f'{t.name} online store'}
        page = _render_seo_page(hostname=d.hostname, title_text=f'{t.name} — Unified Commerce',
            description_text=f'{t.name} online store', canonical=f'https://{d.hostname}/',
            og_type='website', image_url=f'https://{d.hostname}/icon-512.png', jsonld=schema)
        try:
            products = _ssr_store_products(db, t.id, s.id)
            from app.models.domain import ProductMedia, MediaAsset
            for p in products:
                m = db.query(ProductMedia, MediaAsset).join(MediaAsset, MediaAsset.id == ProductMedia.media_asset_id).filter(ProductMedia.tenant_id == t.id, ProductMedia.product_id == p.id, MediaAsset.status == 'READY').order_by(ProductMedia.position.asc()).first()
                if m:
                    p._ssr_media_url = f'/v1/public/storefront/{d.hostname}/media/{m[1].id}'
            grid = _ssr_product_grid_html(products, s.default_currency or t.default_currency)
            page = _inject_ssr_grid(page, grid)
        except Exception:
            logger.warning('ssr_store_grid_failed hostname=%s', d.hostname, exc_info=True)
        return page
    finally:
        db.close()

@app.get('/')
def root(request: Request):
    host = (request.headers.get('host') or '').split(':',1)[0].strip().lower().rstrip('.')
    if host:
        page = _custom_domain_store(host)
        if page:
            return HTMLResponse(page, media_type='text/html')
    return FileResponse('app/frontend/index.html', media_type='text/html')
for _asset in ('app.js', 'styles.css', 'manifest.json', 'sw.js', 'offline.html', 'icon-192.svg',
    'icon-512.svg', 'icon-192.png', 'icon-512.png', 'storefront.js', 'storefront.css', 'locales.json', 'privacy.html', 'terms.html', 'kvkk.html'):
    _path = 'app/frontend/' + _asset
    _media = {'js': 'application/javascript', 'css': 'text/css',
     'json': 'application/manifest+json',
     'svg': 'image/svg+xml',
     'png': 'image/png',
        'html': 'text/html'}.get(_asset.rsplit('.', 1)[-1], 'application/octet-stream')
    app.add_api_route('/' + _asset, lambda _path=_path, _media=_media: FileResponse(_path,
        media_type=_media), methods=['GET'], include_in_schema=False)

@app.get('/product/{slug}', include_in_schema=False)
def custom_domain_product(request: Request, slug: str):
    from app.models.domain import Domain, Storefront, Tenant, Product, ProductTranslation, ProductVariant, Review
    host=(request.headers.get('host') or '').split(':',1)[0].strip().lower().rstrip('.')
    if not host:
        return HTMLResponse('<h1>Storefront not found</h1>', status_code=404)
    db=SessionLocal()
    try:
        row=db.query(Domain,Storefront,Tenant).join(Storefront,Storefront.id==Domain.storefront_id).join(Tenant,Tenant.id==Domain.tenant_id).filter(func.lower(Domain.hostname)==host,Domain.verified_at.is_not(None)).first()
        if not row: return HTMLResponse('<h1>Storefront not found</h1>',status_code=404)
        d,st,t=row
        p=db.query(Product).filter(Product.tenant_id==t.id,Product.storefront_id==st.id,Product.slug==slug,Product.deleted_at.is_(None),Product.status=='ACTIVE').first()
        if t.status!='ACTIVE' or st.status!='PUBLISHED' or not p: return HTMLResponse('<h1>Product not found</h1>',status_code=404)
        tr=db.query(ProductTranslation).filter_by(product_id=p.id,tenant_id=t.id,locale=st.default_locale).first()
        title_text=tr.name if tr else p.title
        desc_text=tr.description if tr and tr.description else (p.description or f'{title_text} — {t.name}')
        rating=db.query(func.avg(Review.rating),func.count(Review.id)).filter(Review.tenant_id==t.id,Review.product_id==p.id,Review.status=='APPROVED').first()
        canonical=f'https://{d.hostname}/product/{p.slug}'
        product_schema={'@context':'https://schema.org','@type':'Product','name':title_text,'description':desc_text[:300],'url':canonical,'brand':{'@type':'Brand','name':t.name}}
        if rating[1]: product_schema['aggregateRating']={'@type':'AggregateRating','ratingValue':float(rating[0] or 0),'reviewCount':int(rating[1])}
        v=db.query(ProductVariant).filter(ProductVariant.tenant_id==t.id,ProductVariant.product_id==p.id,ProductVariant.status=='ACTIVE').order_by(ProductVariant.sku.asc()).first()
        if v and v.price_amount_minor is not None:
            product_schema['offers']={'@type':'Offer','price':float(v.price_amount_minor)/100,'priceCurrency':v.currency or t.currency,'availability':'https://schema.org/InStock','url':canonical}
        page = _render_seo_page(hostname=d.hostname, title_text=f'{title_text} — {t.name}',
            description_text=desc_text, canonical=canonical, og_type='product',
            image_url=f'https://{d.hostname}/icon-512.png', jsonld=product_schema)
        try:
            from app.models.domain import ProductMedia, MediaAsset
            m = db.query(ProductMedia, MediaAsset).join(MediaAsset, MediaAsset.id == ProductMedia.media_asset_id).filter(ProductMedia.tenant_id == t.id, ProductMedia.product_id == p.id, MediaAsset.status == 'READY').order_by(ProductMedia.position.asc()).first()
            img_url = f'/v1/public/storefront/{d.hostname}/media/{m[1].id}' if m else None
            price_text = _ssr_money(v.price_amount_minor, v.currency or t.currency) if v and v.price_amount_minor is not None else ''
            page = _inject_ssr_product(page, title_text=title_text, description_text=desc_text,
                price_text=price_text, image_url=img_url)
        except Exception:
            logger.warning('ssr_product_detail_failed hostname=%s slug=%s', d.hostname, slug, exc_info=True)
        return HTMLResponse(page,media_type='text/html')
    finally: db.close()

@app.get('/store/{hostname}', include_in_schema=False)
def public_store_html(hostname: str):
    from app.models.domain import Domain, Storefront, Tenant
    db = SessionLocal()
    try:
        row = db.query(Domain, Storefront, Tenant).join(Storefront,
         Storefront.id == Domain.storefront_id).join(Tenant,
         Tenant.id == Domain.tenant_id).filter(func.lower(Domain.hostname) == hostname.lower(),
            Domain.verified_at.is_not(None)).first()
        if not row:
            return HTMLResponse('<!doctype html><meta charset="utf-8"><title>Storefront not found</title><h1>Storefront not found</h1>',
                status_code=404)
        d, s, t = row
        if t.status != 'ACTIVE' or s.status != 'PUBLISHED':
            return HTMLResponse('<!doctype html><meta charset="utf-8"><title>Storefront unavailable</title><h1>Storefront unavailable</h1>',
                status_code=404)
        schema = {'@context': 'https://schema.org', '@type': 'Store', 'name': t.name,
            'url': f'https://{d.hostname}/', 'description': f'{t.name} online store'}
        page = _render_seo_page(hostname=d.hostname, title_text=f'{t.name} — Unified Commerce',
            description_text=f'{t.name} online store', canonical=f'https://{d.hostname}/',
            og_type='website', image_url=f'https://{d.hostname}/icon-512.png', jsonld=schema)
        try:
            products = _ssr_store_products(db, t.id, s.id)
            from app.models.domain import ProductMedia, MediaAsset
            for p in products:
                m = db.query(ProductMedia, MediaAsset).join(MediaAsset, MediaAsset.id == ProductMedia.media_asset_id).filter(ProductMedia.tenant_id == t.id, ProductMedia.product_id == p.id, MediaAsset.status == 'READY').order_by(ProductMedia.position.asc()).first()
                if m:
                    p._ssr_media_url = f'/v1/public/storefront/{d.hostname}/media/{m[1].id}'
            grid = _ssr_product_grid_html(products, s.default_currency or t.default_currency)
            page = _inject_ssr_grid(page, grid)
        except Exception:
            logger.warning('ssr_store_grid_failed hostname=%s', d.hostname, exc_info=True)
        return HTMLResponse(page, media_type='text/html')
    finally:
        db.close()

@app.get('/store/{hostname}/product/{slug}', include_in_schema=False)
def public_product_html(hostname: str, slug: str):
    from app.models.domain import Domain, Storefront, Tenant, Product, ProductTranslation, ProductVariant, Review
    db = SessionLocal()
    try:
        row = db.query(Domain, Storefront, Tenant).join(Storefront,
         Storefront.id == Domain.storefront_id).join(Tenant,
         Tenant.id == Domain.tenant_id).filter(func.lower(Domain.hostname) == hostname.lower(),
            Domain.verified_at.is_not(None)).first()
        if not row:
            return HTMLResponse('<h1>Storefront not found</h1>', status_code=404)
        d, st, t = row
        p = db.query(Product).filter(Product.tenant_id == t.id, Product.storefront_id == st.id,
            Product.slug == slug, Product.deleted_at.is_(None), Product.status == 'ACTIVE').first()
        if t.status != 'ACTIVE' or st.status != 'PUBLISHED' or not p:
            return HTMLResponse('<h1>Product not found</h1>', status_code=404)
        tr = db.query(ProductTranslation).filter_by(product_id=p.id, tenant_id=t.id,
            locale=st.default_locale).first()
        title_text = tr.name if tr else p.title
        desc_text = tr.description if tr and tr.description else (p.description or f'{title_text} — {t.name}')
        rating = db.query(func.avg(Review.rating), func.count(Review.id)).filter(Review.tenant_id == t.id, Review.product_id == p.id, Review.status == 'APPROVED').first()
        canonical = f'https://{d.hostname}/product/{p.slug}'
        product_schema = {'@context': 'https://schema.org', '@type': 'Product', 'name': title_text,
            'description': desc_text[:300], 'url': canonical, 'brand': {'@type': 'Brand', 'name': t.name}}
        if rating[1]:
            product_schema['aggregateRating'] = {'@type': 'AggregateRating', 'ratingValue': float(rating[0] or 0), 'reviewCount': int(rating[1])}
        v = db.query(ProductVariant).filter(ProductVariant.tenant_id == t.id, ProductVariant.product_id == p.id, ProductVariant.status == 'ACTIVE').order_by(ProductVariant.sku.asc()).first()
        if v and v.price_amount_minor is not None:
            product_schema['offers'] = {'@type': 'Offer', 'price': float(v.price_amount_minor) / 100, 'priceCurrency': v.currency or t.currency, 'availability': 'https://schema.org/InStock', 'url': canonical}
        page = _render_seo_page(hostname=d.hostname, title_text=f'{title_text} — {t.name}',
            description_text=desc_text, canonical=canonical, og_type='product',
            image_url=f'https://{d.hostname}/icon-512.png', jsonld=product_schema)
        try:
            from app.models.domain import ProductMedia, MediaAsset
            m = db.query(ProductMedia, MediaAsset).join(MediaAsset, MediaAsset.id == ProductMedia.media_asset_id).filter(ProductMedia.tenant_id == t.id, ProductMedia.product_id == p.id, MediaAsset.status == 'READY').order_by(ProductMedia.position.asc()).first()
            img_url = f'/v1/public/storefront/{d.hostname}/media/{m[1].id}' if m else None
            price_text = _ssr_money(v.price_amount_minor, v.currency or t.currency) if v and v.price_amount_minor is not None else ''
            page = _inject_ssr_product(page, title_text=title_text, description_text=desc_text,
                price_text=price_text, image_url=img_url)
        except Exception:
            logger.warning('ssr_product_detail_failed hostname=%s slug=%s', hostname, slug, exc_info=True)
        return HTMLResponse(page, media_type='text/html')
    finally:
        db.close()

@app.get('/campaign/{hostname}/{slug}', include_in_schema=False)
def campaign_landing(hostname: str, slug: str):
    from app.models.domain import Domain, Storefront, Tenant, LandingPage
    from app.core.database import SessionLocal
    from app.core.security import token_hash
    db = SessionLocal()
    try:
        row = db.query(LandingPage, Domain, Storefront, Tenant).join(Domain, Domain.tenant_id == LandingPage.tenant_id).join(Storefront, Storefront.id == Domain.storefront_id).join(Tenant, Tenant.id == Domain.tenant_id).filter(
            func.lower(Domain.hostname) == hostname.lower(), LandingPage.slug == slug, LandingPage.status == 'PUBLISHED',
            Domain.verified_at.is_not(None), Tenant.status == 'ACTIVE', Storefront.status == 'PUBLISHED').first()
        if not row:
            return HTMLResponse('<h1>Campaign not found</h1>', status_code=404)
        page_obj, domain, storefront, tenant = row
        content = page_obj.content or {}
        hero = content.get('hero') or {}
        title = html.escape(str(hero.get('title') or page_obj.title))
        subtitle = html.escape(str(hero.get('subtitle') or page_obj.seo_description or ''))
        blocks = []
        for block in content.get('sections') or []:
            if not isinstance(block, dict):
                continue
            blocks.append(f"<section class='campaign-block'><h2>{html.escape(str(block.get('title') or ''))}</h2><p>{html.escape(str(block.get('body') or ''))}</p></section>")
        body = (
            '<!doctype html><html lang="' + html.escape(page_obj.locale) + '" dir="rtl">'
            '<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>' + html.escape(page_obj.seo_title or page_obj.title) + '</title>'
            '<meta name="description" content="' + html.escape(page_obj.seo_description or '') + '">'
            '<style>body{margin:0;background:#07111f;color:#fff;font-family:system-ui;padding:28px}'
            'main{max-width:980px;margin:60px auto}.hero{padding:60px;border:1px solid rgba(255,255,255,.1);'
            'border-radius:28px;background:linear-gradient(135deg,rgba(124,140,255,.18),rgba(86,217,200,.06))}'
            'h1{font-size:56px;margin:0 0 16px}p{color:#a6b8d0;line-height:1.9}'
            '.campaign-block{padding:24px 0;border-bottom:1px solid rgba(255,255,255,.08)}'
            'a{color:#fff;background:#7c8cff;padding:12px 18px;border-radius:12px;text-decoration:none;'
            'display:inline-block;margin-top:18px}</style></head><body><main>'
            '<div class="hero"><small>' + html.escape(tenant.name) + '</small><h1>' + title + '</h1>'
            '<p>' + subtitle + '</p><a href="/store/' + html.escape(domain.hostname) + '">تسوق الآن</a></div>'
            + ''.join(blocks) + '</main></body></html>'
        )
        return HTMLResponse(body)
    finally:
        db.close()

@app.get('/robots.txt', include_in_schema=False)
def robots(request: Request):
    host=(request.headers.get('host') or '').split(':',1)[0].strip().lower().rstrip('.')
    db=SessionLocal()
    try:
        verified=db.query(domain.Domain).filter(func.lower(domain.Domain.hostname)==host,domain.Domain.verified_at.is_not(None)).first() if host else None
        if verified:
            text=f'User-agent: *\nAllow: /\nDisallow: /v1/\nSitemap: https://{host}/sitemap.xml\n'
        else:
            text='User-agent: *\nDisallow: /v1/\n'
        return HTMLResponse(text,media_type='text/plain')
    finally:
        db.close()

@app.get('/sitemap.xml', include_in_schema=False)
def sitemap(request: Request):
    from html import escape
    from app.models.domain import Domain, Storefront, Tenant, Product
    host=(request.headers.get('host') or '').split(':',1)[0].strip().lower().rstrip('.')
    db=SessionLocal()
    try:
        rows=db.query(Domain.hostname).join(Storefront,Storefront.id==Domain.storefront_id).join(Tenant,Tenant.id==Domain.tenant_id).filter(Tenant.status=='ACTIVE',Storefront.status=='PUBLISHED',Domain.verified_at.is_not(None)).all()
        hosts=[h for h, in rows]
        if host in {h.lower() for h in hosts}:
            hosts=[next(h for h in hosts if h.lower()==host)]
        urls=''
        for h in hosts:
            drow=db.query(Domain,Storefront,Tenant).join(Storefront,Storefront.id==Domain.storefront_id).join(Tenant,Tenant.id==Domain.tenant_id).filter(func.lower(Domain.hostname)==h.lower(),Tenant.status=='ACTIVE',Storefront.status=='PUBLISHED',Domain.verified_at.is_not(None)).first()
            if not drow: continue
            _,st,t=drow
            urls+=f'<url><loc>https://{escape(h)}/</loc></url>'
            products=db.query(Product.slug).filter(Product.tenant_id==t.id,Product.storefront_id==st.id,Product.status=='ACTIVE',Product.deleted_at.is_(None)).all()
            urls+=''.join(f'<url><loc>https://{escape(h)}/product/{escape(slug)}</loc></url>' for (slug,) in products)
        return HTMLResponse(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{urls}</urlset>',media_type='application/xml',headers={'Cache-Control':'public, max-age=300'})
    finally:
        db.close()
