from datetime import datetime, timezone, timedelta
import hashlib
from fastapi import Depends, Header, Request
from app.core.config import get_settings
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db, set_tenant_context, set_platform_context
from app.core.security import token_hash
from app.core.errors import forbidden
from app.models.domain import User, Session as SessionModel, TenantMembership, PlatformAdmin

def current_user(request: Request, authorization: str | None=Header(default=None),
    db: DBSession=Depends(get_db)):
    raw = authorization.split(' ',
        1)[1] if authorization and authorization.lower().startswith('bearer ') else (request.cookies.get('impersonation_session') or request.cookies.get('session'))
    if not raw:
        raise forbidden('Authentication required')
    s = db.query(SessionModel).filter(SessionModel.token_hash == token_hash(raw),
        SessionModel.revoked_at.is_(None)).first()
    now = datetime.now(timezone.utc)

    def aware(dt):
        return dt.replace(tzinfo=timezone.utc) if dt and dt.tzinfo is None else dt
    if not s or aware(s.expires_at) <= now or (s.idle_expires_at and aware(s.idle_expires_at) <= now) or (s.absolute_expires_at and aware(s.absolute_expires_at) <= now):
        raise forbidden('Session expired')
    if getattr(s, 'read_only_impersonation', False) and request.method in {'POST', 'PATCH', 'PUT', 'DELETE'} and request.url.path != '/v1/auth/impersonation/end':
        raise forbidden('Impersonation session is read-only')
    u = db.get(User, s.user_id)
    if not u or u.status != 'ACTIVE':
        raise forbidden('User inactive')
    settings = get_settings()
    activity_write = True
    if s.last_seen_at:
        last_seen = aware(s.last_seen_at)
        activity_write = (now - last_seen).total_seconds() >= settings.SESSION_ACTIVITY_WRITE_INTERVAL_SECONDS
    if activity_write:
        s.last_seen_at = now
        if s.idle_expires_at:
            s.idle_expires_at = now + timedelta(minutes=settings.SESSION_IDLE_TTL_MINUTES)
    request.state.user_id = u.id
    request.state.read_only_impersonation = bool(getattr(s, 'read_only_impersonation', False))
    request.state.impersonation_session_id = getattr(s, 'id', None) if getattr(s, 'read_only_impersonation', False) else None
    if activity_write:
        db.commit()
    return u

def tenant_user(tenant_id: str, user: User, db: DBSession):
    m = db.query(TenantMembership).filter(TenantMembership.tenant_id == tenant_id,
        TenantMembership.user_id == user.id, TenantMembership.status == 'ACTIVE').first()
    if not m:
        raise forbidden('Tenant access denied')
    return m

def assert_permission(tenant_id: str, user: User, db, permission: str):
    """Enforce a tenant permission for internal service-to-service route calls.

    Unlike FastAPI dependency injection, this helper is safe to call when one
    route delegates to another route handler directly. It intentionally reuses
    the same role/grant mapping as ``require_permission`` so internal calls
    cannot bypass a stricter permission by passing ``_ = None``.
    """
    m = tenant_user(tenant_id, user, db)
    set_tenant_context(db, tenant_id)
    grants = {
        'owner': {'*'},
        'admin': {'*'},
        'staff': {
            'products.read', 'products.write', 'orders.read', 'orders.manage',
            'inventory.read', 'inventory.write', 'finance.read',
            'customers.read', 'customers.write', 'storefront.read',
            'storefront.write', 'apps.manage', 'settings.manage',
            'billing.manage', 'staff.manage',
        },
        'viewer': {'products.read', 'orders.read', 'inventory.read', 'finance.read'},
    }
    from app.models.domain import RolePermission
    rows = {x.permission for x in db.query(RolePermission).filter_by(role=m.role).all()}
    allowed = rows or grants.get(m.role, set())
    if '*' not in allowed and permission not in allowed:
        raise forbidden('Permission denied')
    return m

def require_permission(permission: str):

    def dep(tenant_id: str, user: User=Depends(current_user), db: DBSession=Depends(get_db)):
        m = tenant_user(tenant_id, user, db)
        set_tenant_context(db, tenant_id)
        grants = {'owner': {'*'}, 'admin': {'*'}, 'staff': {'products.read', 'products.write',
         'orders.read',
         'orders.manage',
         'inventory.read',
         'inventory.write',
         'finance.read',
         'customers.read',
         'customers.write',
         'storefront.read',
         'storefront.write',
         'apps.manage',
         'settings.manage',
         'billing.manage',
         'staff.manage'},
            'viewer': {'products.read', 'orders.read', 'inventory.read', 'finance.read'}}
        rows = {x.permission for x in db.query(__import__('app.models.domain',
            fromlist=['RolePermission']).RolePermission).filter_by(role=m.role).all()}
        allowed = rows or grants.get(m.role, set())
        if '*' not in allowed and permission not in allowed:
            raise forbidden('Permission denied')
        return m
    return dep

def current_platform_compliance_officer(request: Request, user: User=Depends(current_user), db: DBSession=Depends(get_db)):
    from app.services.core import audit
    pa = db.query(PlatformAdmin).filter(PlatformAdmin.user_id == user.id).first()
    mfa = db.query(__import__('app.models.domain', fromlist=['MFAFactor']).MFAFactor).filter_by(user_id=user.id, enabled=True).first()
    if not pa or not mfa or pa.platform_role not in {'compliance_officer','privacy_officer','security_admin'}:
        audit(db, None, user.id, 'security.unauthorized_kyc_access_attempt', 'http_route', request.url.path,
              after={'method':request.method,'outcome':'DENIED'})
        db.commit()
        raise forbidden('Compliance officer + MFA required')
    set_platform_context(db, pa.platform_role)
    return pa


def current_platform_admin(user: User=Depends(current_user), db: DBSession=Depends(get_db)):
    pa = db.query(PlatformAdmin).filter(PlatformAdmin.user_id == user.id).first()
    allowed_roles = {'super_admin', 'billing_admin', 'support_admin'}
    if (not pa or pa.platform_role not in allowed_roles or
            not db.query(__import__('app.models.domain',
            fromlist=['MFAFactor']).MFAFactor).filter_by(user_id=user.id, enabled=True).first()):
        raise forbidden('Platform admin role + MFA required')
    set_platform_context(db, pa.platform_role)
    return pa

def bind_tenant_context(tenant_id: str, user: User, db: DBSession):
    membership = tenant_user(tenant_id, user, db)
    set_tenant_context(db, tenant_id)
    return membership

def issue_mfa_recovery_codes(db, user_id: str, count: int=10):
    from app.core.security import random_token, token_hash
    from app.models.domain import RecoveryCode
    codes = []
    for _ in range(count):
        raw = random_token(9).replace('_', '').replace('-', '')[:12].upper()
        codes.append(raw)
        db.add(RecoveryCode(user_id=user_id, code_hash=token_hash(raw)))
    return codes

def consume_recovery_code(db: DBSession, user_id: str, raw_code: str) -> bool:
    """Atomically consume a single-use MFA recovery code."""
    from app.models.domain import RecoveryCode
    from app.core.security import token_hash
    row = db.query(RecoveryCode).filter_by(user_id=user_id, used_at=None,
        code_hash=token_hash(raw_code)).with_for_update().first()
    if not row:
        return False
    row.used_at = datetime.now(timezone.utc)
    db.flush()
    return True

def optional_user(request: Request, authorization: str | None=Header(default=None),
    db: DBSession=Depends(get_db)):
    """Best-effort authentication for guest/session commerce endpoints; returns None for anonymous shoppers."""
    raw = authorization.split(' ',
        1)[1] if authorization and authorization.lower().startswith('bearer ') else request.cookies.get('session')
    if not raw:
        return None
    s = db.query(SessionModel).filter(SessionModel.token_hash == token_hash(raw),
        SessionModel.revoked_at.is_(None)).first()
    now = datetime.now(timezone.utc)

    def aware(dt):
        return dt.replace(tzinfo=timezone.utc) if dt and dt.tzinfo is None else dt
    if not s or aware(s.expires_at) <= now or (s.idle_expires_at and aware(s.idle_expires_at) <= now) or (s.absolute_expires_at and aware(s.absolute_expires_at) <= now):
        return None
    u = db.get(User, s.user_id)
    if not u or u.status != 'ACTIVE':
        return None
    return u

def api_key_context(x_api_key: str | None=Header(default=None), db: DBSession=Depends(get_db)):
    from app.models.domain import APIKey
    if not x_api_key:
        raise forbidden('API key required')
    row = db.query(APIKey).filter(APIKey.key_hash == token_hash(x_api_key),
        APIKey.revoked_at.is_(None)).first()
    now = datetime.now(timezone.utc)
    if not row or (row.expires_at and (row.expires_at.replace(tzinfo=timezone.utc) if row.expires_at.tzinfo is None else row.expires_at) <= now):
        raise forbidden('Invalid or expired API key')
    row.last_used_at = now
    db.commit()
    set_tenant_context(db, row.tenant_id)
    return row
