from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from app.core.config import get_settings

class Base(DeclarativeBase):
    pass
settings = get_settings()
connect_args = {'check_same_thread': False} if settings.DATABASE_URL.startswith('sqlite') else {'options': f'-c statement_timeout={settings.DB_STATEMENT_TIMEOUT_MS} -c idle_in_transaction_session_timeout={settings.DB_IDLE_TX_TIMEOUT_MS}'}
pool_kwargs = {'pool_pre_ping': True, 'future': True}
if not settings.DATABASE_URL.startswith('sqlite'):
    pool_kwargs.update(pool_size=settings.DB_POOL_SIZE, max_overflow=settings.DB_MAX_OVERFLOW,
        pool_timeout=settings.DB_POOL_TIMEOUT_SECONDS)
engine = create_engine(settings.DATABASE_URL, connect_args=connect_args, **pool_kwargs)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def set_tenant_context(db, tenant_id: str | None):
    if not tenant_id or not db.bind or db.bind.dialect.name != 'postgresql':
        return
    db.execute(text('SET LOCAL app.current_tenant = :tenant_id'), {'tenant_id': tenant_id})

def set_worker_context(db):
    return None

def set_unscoped_ingest_context(db):
    return None


def set_platform_context(db, platform_role: str | None):
    if not platform_role or not db.bind or db.bind.dialect.name != 'postgresql':
        return
    db.execute(text('SET LOCAL app.platform_role = :platform_role'), {'platform_role': str(platform_role)})
