from datetime import datetime, timezone, timedelta
from fastapi import Request, Response
from sqlalchemy.orm import Session
from app.core.security import random_token, token_hash
from app.core.config import get_settings
from app.core.errors import AppError, forbidden
from app.core.database import set_tenant_context
from app.models.domain import GuestSession, Cart, Tenant, User, TenantMembership, Customer, CustomerSession
COOKIE = 'guest_session'
GUEST_TTL_DAYS = 7

def resolve_guest(request: Request, db: Session, tenant_id: str):
    raw = request.cookies.get(COOKIE)
    if not raw:
        return None
    row = db.query(GuestSession).filter_by(token_hash=token_hash(raw), tenant_id=tenant_id).first()
    now = datetime.now(timezone.utc)
    exp = row.expires_at.replace(tzinfo=timezone.utc) if row and row.expires_at.tzinfo is None else row.expires_at if row else None
    if not row or exp <= now:
        return None
    row.last_seen_at = now
    return row

def ensure_guest(request: Request, response: Response, db: Session, tenant_id: str):
    row = resolve_guest(request, db, tenant_id)
    if row:
        return row
    raw = random_token(32)
    now = datetime.now(timezone.utc)
    row = GuestSession(tenant_id=tenant_id, token_hash=token_hash(raw),
        expires_at=now + timedelta(days=GUEST_TTL_DAYS), created_at=now, last_seen_at=now)
    db.add(row)
    db.flush()
    response.set_cookie(COOKIE, raw, httponly=True, secure=get_settings().COOKIE_SECURE,
        samesite='lax', max_age=GUEST_TTL_DAYS * 86400, path='/')
    return row

def guest_cart(request: Request, response: Response, db: Session, tenant_id: str):
    set_tenant_context(db, tenant_id)
    guest = ensure_guest(request, response, db, tenant_id)
    cart = db.query(Cart).filter_by(tenant_id=tenant_id, status='OPEN',
        guest_session_id=guest.id).filter(Cart.customer_id.is_(None)).first()
    if cart and cart.expires_at and (cart.expires_at > datetime.now(timezone.utc)):
        return (cart, guest)
    tenant = db.get(Tenant, tenant_id)
    if not tenant:
        raise AppError(404, 'TENANT_NOT_FOUND', 'Tenant not found')
    cart = Cart(tenant_id=tenant_id, currency=tenant.default_currency, status='OPEN',
     guest_session_id=guest.id,
        expires_at=datetime.now(timezone.utc) + timedelta(days=GUEST_TTL_DAYS))
    db.add(cart)
    db.flush()
    return (cart, guest)

class CustomerActor:
    def __init__(self, customer):
        self.id = customer.id
        self.email = customer.email or ''
        self.customer_id = customer.id
        self.is_customer = True

def customer_session_actor(request: Request, db: Session, tenant_id: str):
    # Customer auth data is tenant-scoped. Bind the transaction context before
    # querying the session so PostgreSQL FORCE RLS protects the lookup itself.
    set_tenant_context(db, tenant_id)
    raw = request.cookies.get('customer_session')
    if not raw:
        return None
    now = datetime.now(timezone.utc)
    row = db.query(CustomerSession).filter_by(tenant_id=tenant_id, token_hash=token_hash(raw)).first()
    if not row:
        return None
    exp = row.expires_at.replace(tzinfo=timezone.utc) if row.expires_at.tzinfo is None else row.expires_at
    if exp <= now:
        return None
    customer = db.query(Customer).filter_by(id=row.customer_id, tenant_id=tenant_id).first()
    if not customer:
        return None
    row.last_seen_at = now
    return CustomerActor(customer)

def commerce_actor(request: Request, response: Response, db: Session, tenant_id: str):
    set_tenant_context(db, tenant_id)
    'Resolve authenticated merchant/customer session first; otherwise issue a tenant-bound guest session.'
    customer_actor = customer_session_actor(request, db, tenant_id)
    if customer_actor is not None:
        return (customer_actor, None)
    from app.models.domain import Session as SessionModel, User
    from datetime import timedelta
    raw = request.headers.get('Authorization', '')
    if raw.lower().startswith('bearer '):
        raw = raw.split(' ', 1)[1]
    else:
        raw = request.cookies.get('session')
    now = datetime.now(timezone.utc)
    if raw:
        s = db.query(SessionModel).filter_by(token_hash=token_hash(raw), revoked_at=None).first()
        if s:

            def aware(v):
                return v.replace(tzinfo=timezone.utc) if v and v.tzinfo is None else v
            if aware(s.expires_at) > now and (not s.idle_expires_at or aware(s.idle_expires_at) > now) and (not s.absolute_expires_at or aware(s.absolute_expires_at) > now):
                u = db.get(User, s.user_id)
                if u and u.status == 'ACTIVE':
                    set_tenant_context(db, tenant_id)
                    m = db.query(TenantMembership).filter_by(tenant_id=tenant_id, user_id=u.id,
                        status='ACTIVE').first()
                    if m:
                        return (u, None)
    guest = ensure_guest(request, response, db, tenant_id)
    return (None, guest)
