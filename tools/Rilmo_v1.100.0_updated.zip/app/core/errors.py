from fastapi import HTTPException

class AppError(HTTPException):

    def __init__(self, status_code: int, code: str, message: str, headers: dict | None=None):
        self.code = code
        self.message = message
        super().__init__(status_code=status_code, detail={'error': {'code': code,
            'message': message}}, headers=headers)

def not_found(msg='Not found'):
    return AppError(404, 'NOT_FOUND', msg)

def forbidden(msg='Forbidden'):
    return AppError(403, 'FORBIDDEN', msg)
