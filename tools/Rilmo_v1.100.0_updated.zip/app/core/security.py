import base64, hashlib, hmac, json, secrets
from datetime import datetime, timedelta, timezone
from typing import Optional
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from app.core.config import get_settings
ph = PasswordHasher()

def hash_password(password: str) -> str:
    return ph.hash(password)

def verify_password(password: str, encoded: str) -> bool:
    try:
        return ph.verify(encoded, password)
    except VerifyMismatchError:
        return False

def random_token(nbytes=32):
    return secrets.token_urlsafe(nbytes)

def token_hash(token: str):
    return hashlib.sha256(token.encode()).hexdigest()

def hmac_sha256(payload: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()

def create_session_token():
    return random_token(32)

def create_reset_token():
    return random_token(32)

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()

def _unb64(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + '=' * ((4 - len(value) % 4) % 4))

def create_platform_jwt(user_id: str):
    s = get_settings()
    now = datetime.now(timezone.utc)
    payload = {'sub': user_id, 'scope': 'platform', 'iat': int(now.timestamp()),
        'exp': int((now + timedelta(hours=1)).timestamp())}
    head = {'alg': 'HS256', 'typ': 'JWT'}
    signing = _b64(json.dumps(head, separators=(',',
        ':')).encode()) + '.' + _b64(json.dumps(payload, separators=(',', ':')).encode())
    sig = _b64(hmac.new(s.SECRET_KEY.encode(), signing.encode(), hashlib.sha256).digest())
    return signing + '.' + sig

def decode_platform_jwt(token: str) -> Optional[dict]:
    try:
        parts = token.split('.')
        if len(parts) != 3:
            return None
        signing = '.'.join(parts[:2])
        expected = _b64(hmac.new(get_settings().SECRET_KEY.encode(), signing.encode(),
            hashlib.sha256).digest())
        if not hmac.compare_digest(expected, parts[2]):
            return None
        payload = json.loads(_unb64(parts[1]))
        if payload.get('exp', 0) < int(datetime.now(timezone.utc).timestamp()):
            return None
        return payload
    except Exception:
        return None

def _fernet():
    from cryptography.fernet import Fernet
    import base64, hashlib
    settings = get_settings()
    material = settings.ENCRYPTION_KEY or settings.SECRET_KEY
    key = base64.urlsafe_b64encode(hashlib.sha256(material.encode()).digest())
    return Fernet(key)

def encrypt_secret(value: str) -> str:
    return _fernet().encrypt(value.encode()).decode()

def decrypt_secret(value: str) -> str:
    return _fernet().decrypt(value.encode()).decode()

def totp_secret() -> str:
    import base64, secrets
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip('=')

def totp_code(secret: str, counter: int | None=None) -> str:
    import base64, hashlib, hmac, struct, time
    if counter is None:
        counter = int(time.time()) // 30
    key = base64.b32decode(secret + '=' * ((8 - len(secret) % 8) % 8), casefold=True)
    digest = hmac.new(key, struct.pack('>Q', counter), hashlib.sha1).digest()
    off = digest[-1] & 15
    code = (struct.unpack('>I', digest[off:off + 4])[0] & 2147483647) % 1000000
    return f'{code:06d}'

def verify_totp(secret: str, code: str, window: int=1) -> bool:
    import time, hmac
    if not code.isdigit() or len(code) != 6:
        return False
    now = int(time.time()) // 30
    return any((hmac.compare_digest(totp_code(secret, now + i), code) for i in range(-window,
        window + 1)))

def verify_timestamped_signature(raw_body: bytes, signature: str, secret: str, timestamp: str,
    tolerance_seconds: int=300) -> bool:
    try:
        ts = int(timestamp)
    except (TypeError, ValueError):
        return False
    now = int(datetime.now(timezone.utc).timestamp())
    if abs(now - ts) > tolerance_seconds:
        return False
    signed = f'{timestamp}.'.encode() + raw_body
    expected = hmac_sha256(signed, secret)
    return hmac.compare_digest(expected, signature)
