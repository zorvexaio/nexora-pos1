"""Safe, schema-aware ORM serialization.

This module is intentionally conservative: generic API serializers must never
expose credentials, secrets, tokens, hashes, or encrypted material merely
because a new ORM column was added.  Explicit exclusions remain supported, but
name-pattern detection is the fail-safe backstop.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Any

# Keep this explicit list for legacy/sensitive columns whose names do not
# necessarily match the structural patterns below.
EXPLICIT_SENSITIVE_FIELDS = frozenset({
    'password_hash',
    'token_hash',
    'verification_token_hash',
    'secret_encrypted',
    'code_hash',
    'public_token_hash',
    'response_body',
    'guest_session_id',
    'provider_metadata',
    'provider_access_reference',
})

# A generic serializer must fail closed for newly introduced secret-like
# columns.  token_prefix is intentionally allowed because it is a display
# prefix rather than an authentication secret.
SENSITIVE_FIELD_PATTERN = re.compile(
    r'(?:hash|secret|encrypted|credential|token(?!_prefix)|api[_-]?key|private[_-]?key|biometric|raw_document|passport|selfie)', re.IGNORECASE
)


def is_sensitive_field(name: str) -> bool:
    return name in EXPLICIT_SENSITIVE_FIELDS or bool(SENSITIVE_FIELD_PATTERN.search(name))


# Audit-chain digests are intentionally exposed only by the dedicated admin
# audit view. They are integrity metadata, not credentials. Keeping them out
# of the generic serializer prevents accidental exposure elsewhere while
# preserving external verification of the tamper-evident chain.
AUDIT_CHAIN_PUBLIC_FIELDS = frozenset({'prev_hash', 'event_hash'})


def _redact_audit_value(value: Any) -> Any:
    """Recursively redact secret-like keys embedded in audit snapshots."""
    if isinstance(value, dict):
        return {str(k): ('[REDACTED]' if is_sensitive_field(str(k)) else _redact_audit_value(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact_audit_value(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_redact_audit_value(v) for v in value)
    if isinstance(value, datetime):
        return value.isoformat()
    return value


def audit_event_view(obj: Any) -> dict[str, Any]:
    """Return the minimal authorized admin audit representation.

    Audit-chain hashes are integrity metadata and are intentionally exposed only
    here. Snapshot dictionaries are recursively redacted so audit review cannot
    become a secondary secret-exfiltration channel.
    """
    allowed = {
        'id', 'tenant_id', 'actor_id', 'action', 'resource_type', 'resource_id',
        'request_id', 'correlation_id', 'before_data', 'after_data',
        'ip_hash', 'user_agent_hash', 'created_at', 'prev_hash', 'event_hash',
    }
    out: dict[str, Any] = {}
    for column in obj.__table__.columns:
        name = column.name
        if name not in allowed:
            continue
        value = getattr(obj, name)
        if name in {'before_data', 'after_data'}:
            value = _redact_audit_value(value)
        elif isinstance(value, datetime):
            value = value.isoformat()
        out[name] = value
    return out


def json_model(obj: Any) -> dict[str, Any]:
    """Serialize an ORM instance while structurally excluding secret fields."""
    out: dict[str, Any] = {}
    for column in obj.__table__.columns:
        if is_sensitive_field(column.name):
            continue
        attr = 'meta' if column.name == 'metadata' and hasattr(obj, 'meta') else column.name
        value = getattr(obj, attr)
        if isinstance(value, datetime):
            value = value.isoformat()
        out[column.name] = value
    return out
