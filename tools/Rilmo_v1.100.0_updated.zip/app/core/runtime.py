from __future__ import annotations

from pathlib import Path

from alembic.migration import MigrationContext
from alembic.script import ScriptDirectory
from sqlalchemy.orm import Session

from app.core.errors import AppError


def migration_revisions(db: Session) -> tuple[str | None, str]:
    """Return the database revision and the repository's current Alembic head."""
    bind = db.get_bind()
    current = MigrationContext.configure(bind).get_current_revision()
    script = ScriptDirectory.from_config(_alembic_config())
    head = script.get_current_head()
    if not head:
        raise RuntimeError('Alembic repository has no head revision')
    return current, head


def _alembic_config():
    from alembic.config import Config

    root = Path(__file__).resolve().parents[2]
    config = Config(str(root / 'alembic.ini'))
    config.set_main_option('script_location', str(root / 'alembic'))
    config.set_main_option('path_separator', 'os')
    return config


def assert_migration_head(db: Session) -> tuple[str, str]:
    """Fail closed when production/staging is running against a stale schema."""
    current, head = migration_revisions(db)
    if current != head:
        raise AppError(503, 'DATABASE_MIGRATION_OUT_OF_DATE',
                       f'Database revision {current!r} does not match application head {head!r}')
    return current, head
