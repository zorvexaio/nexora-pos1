from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    ENVIRONMENT: str = 'development'
    ALLOW_LOCAL_MOCK_PAYMENTS: bool = False
    LOCAL_MEDIA_ROOT: str = 'media_store'
    LOCAL_MAIL_OUTBOX: str = '.local/mail.outbox.log'
    APP_NAME: str = 'Unified Global Commerce Platform'
    APP_VERSION: str = ''
    LEGAL_ENTITY_NAME: str = ''
    PRIVACY_CONTACT_EMAIL: str = ''
    DATA_PROTECTION_OFFICER_EMAIL: str = ''
    PRIVACY_POLICY_VERSION: str = ''
    TERMS_EFFECTIVE_DATE: str = ''
    PLATFORM_MODEL: str = 'merchant_saas'
    DATABASE_URL: str = 'sqlite:///./commerce.db'
    SECRET_KEY: str = 'change-me-immediately'
    ENCRYPTION_KEY: str = ''
    SESSION_TTL_HOURS: int = 24
    SESSION_IDLE_TTL_MINUTES: int = 120
    SESSION_ABSOLUTE_TTL_DAYS: int = 30
    SESSION_ACTIVITY_WRITE_INTERVAL_SECONDS: int = 300
    PASSWORD_RESET_TTL_MINUTES: int = 30
    CUSTOMER_SESSION_TTL_DAYS: int = 30
    CUSTOMER_LOGIN_CODE_TTL_MINUTES: int = 10
    CUSTOMER_LOGIN_CODE_MAX_ATTEMPTS: int = 5
    WEBHOOK_SECRET: str = 'change-me'
    PUBLIC_BASE_URL: str = 'http://localhost:8000'
    COOKIE_SECURE: bool = False
    CORS_ORIGINS: str = 'http://localhost:8000'
    RATE_LIMIT_PER_MINUTE: int = 120
    ALLOWED_HOSTS: str = 'localhost,127.0.0.1'
    FORWARDED_ALLOW_IPS: str = '127.0.0.1'
    MAX_WEBHOOK_BYTES: int = 1024 * 1024
    WEBHOOK_TOLERANCE_SECONDS: int = 300
    OUTBOX_MAX_ATTEMPTS: int = 8
    OUTBOX_BATCH_SIZE: int = 50
    OUTBOX_VISIBILITY_TIMEOUT_SECONDS: int = 120
    PASSWORD_MIN_LENGTH: int = 12
    TRUSTED_ORIGINS: str = 'http://localhost:8000'
    IYZICO_API_BASE: str = 'https://api.iyzipay.com'
    BILLING_PROVIDER: str = 'paddle'
    PADDLE_API_BASE: str = 'https://api.paddle.com'
    PADDLE_API_KEY: str = ''
    PADDLE_WEBHOOK_SECRET: str = ''
    PADDLE_TIMEOUT_SECONDS: float = 20.0
    IYZICO_API_KEY: str = ''
    IYZICO_SECRET_KEY: str = ''
    IYZICO_TIMEOUT_SECONDS: float = 15.0
    PAYTR_API_BASE: str = 'https://www.paytr.com'
    PAYTR_MERCHANT_ID: str = ''
    PAYTR_MERCHANT_KEY: str = ''
    PAYTR_MERCHANT_SALT: str = ''
    PAYTR_TIMEOUT_SECONDS: float = 15.0
    PAYTR_TEST_MODE: bool = False
    TURKEY_EINVOICE_PROVIDER: str = 'none'
    TURKEY_EINVOICE_ENDPOINT: str = ''
    TURKEY_EINVOICE_API_TOKEN: str = ''
    TURKEY_KDV_DEFAULT_BPS: int = 2000
    TURKEY_CARRIER_TIMEOUT_SECONDS: float = 15.0
    CARRIER_ALLOWED_HOSTS: str = ''
    S3_ENDPOINT_URL: str = ''
    S3_BUCKET: str = ''
    S3_REGION: str = 'auto'
    S3_ACCESS_KEY_ID: str = ''
    S3_SECRET_ACCESS_KEY: str = ''
    DOMAIN_VERIFICATION_MODE: str = 'dns'
    DOMAIN_VERIFICATION_TXT_PREFIX: str = '_unified-commerce-verify'
    DOMAIN_VERIFICATION_TIMEOUT_SECONDS: float = 5.0
    GOOGLE_CLIENT_ID: str = ''
    GOOGLE_CLIENT_SECRET: str = ''
    GOOGLE_REDIRECT_URI: str = 'http://localhost:8000/v1/auth/google/callback'
    GOOGLE_SCOPES: str = 'openid email profile'
    GOOGLE_JWKS_URL: str = 'https://www.googleapis.com/oauth2/v3/certs'
    GOOGLE_ISSUERS: str = 'https://accounts.google.com,accounts.google.com'
    SMTP_HOST: str = ''
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = ''
    SMTP_PASSWORD: str = ''
    SMTP_TLS: bool = True
    MAIL_FROM: str = ''
    MEDIA_SCAN_REQUIRED: bool = True
    CLAMAV_HOST: str = 'clamav'
    CLAMAV_PORT: int = 3310
    CLAMAV_TIMEOUT_SECONDS: float = 10.0
    REDIS_URL: str = ''
    REDIS_SOCKET_TIMEOUT_SECONDS: float = 2.0
    REDIS_KEY_PREFIX: str = 'rilmo:rl:'
    LOG_LEVEL: str = 'INFO'
    AI_PROVIDER: str = 'ollama'
    AI_BASE_URL: str = 'http://ollama:11434'
    AI_API_KEY: str = ''
    AI_MODEL: str = 'qwen3.5:9b'
    AI_TIMEOUT_SECONDS: float = 30.0
    AI_MAX_OUTPUT_TOKENS: int = 900
    AI_MAX_CONTEXT_PRODUCTS: int = 80
    AI_PUBLIC_RATE_LIMIT_PER_MINUTE: int = 12
    AI_PUBLIC_MAX_QUESTION_CHARS: int = 700
    AI_MAX_CONCURRENT_REQUESTS: int = 8
    AI_SERVER_ONLY: bool = True
    AI_EXTERNAL_PROVIDER_ALLOWED: bool = False
    AI_DAILY_REQUEST_HARD_LIMIT: int = 5000
    # Fail-closed: AI is optional infrastructure and must be explicitly enabled.
    AI_ENABLED: bool = False
    AI_DEFAULT_TENANT_DAILY_LIMIT: int = 1000
    AI_EXTERNAL_DATA_ALLOWED: bool = False
    AI_AGENT_MAX_TOOL_CALLS: int = 8
    WHATSAPP_API_VERSION: str = 'v23.0'
    WHATSAPP_TIMEOUT_SECONDS: float = 20.0
    WHATSAPP_APP_SECRET: str = ''
    WHATSAPP_ORDER_CONFIRMED_TEMPLATE: str = ''
    WHATSAPP_ORDER_SHIPPED_TEMPLATE: str = ''
    WHATSAPP_ABANDONED_CART_TEMPLATE: str = ''
    SENTRY_DSN: str = ''
    SMS_PROVIDER: str = 'none'
    TWILIO_ACCOUNT_SID: str = ''
    TWILIO_AUTH_TOKEN: str = ''
    TWILIO_FROM_NUMBER: str = ''
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20
    DB_POOL_TIMEOUT_SECONDS: int = 30
    DB_STATEMENT_TIMEOUT_MS: int = 15000
    DB_IDLE_TX_TIMEOUT_MS: int = 30000
    MAX_JSON_BODY_BYTES: int = 2 * 1024 * 1024
    MAX_WEBHOOK_BODY_BYTES: int = 1024 * 1024
    MAX_MEDIA_BODY_BYTES: int = 12 * 1024 * 1024
    PUBLIC_EVENT_RATE_LIMIT_PER_MINUTE: int = 240
    AFFILIATE_CLICK_RATE_LIMIT_PER_MINUTE: int = 120
    CUSTOMER_LOGIN_IP_RATE_LIMIT_PER_MINUTE: int = 8
    CUSTOMER_LOGIN_EMAIL_RATE_LIMIT_PER_MINUTE: int = 4
    CUSTOMER_LOGIN_VERIFY_RATE_LIMIT_PER_MINUTE: int = 12
    DOMAIN_PROVIDER: str = 'cloudflare'
    DOMAIN_PLATFORM_PRICE_USD_MINOR: int = 1000
    DOMAIN_PROVIDER_ACCOUNT_ID: str = ''
    DOMAIN_PROVIDER_API_TOKEN: str = ''
    DOMAIN_DEFAULT_TLDS: str = 'com,shop,store,online,site,app,dev,net,org'
    PLATFORM_ROOT_DOMAIN: str = ''
    DOMAIN_SUBDOMAIN_PRICE_USD_MINOR: int = 0
    MERCHANT_PHONE_CODE_TTL_MINUTES: int = 10
    MERCHANT_PHONE_MAX_ATTEMPTS: int = 5
    MERCHANT_PHONE_RATE_LIMIT_PER_MINUTE: int = 5
    OAUTH_TOKEN_RATE_LIMIT_PER_MINUTE: int = 30
    WHATSAPP_WEBHOOK_RATE_LIMIT_PER_MINUTE: int = 120
    REQUIRE_MERCHANT_GOOGLE: bool = True
    REQUIRE_MERCHANT_PHONE: bool = True
    REQUIRE_MERCHANT_PROFILE: bool = True
    REQUIRE_TRUST_MINIMUM_TO_PUBLISH: bool = True
    MERCHANT_MIN_TRUST_SCORE_TO_PUBLISH: int = 60
    ABUSE_AUTO_SUSPEND_REPORT_THRESHOLD: int = 5
    APP_WEBHOOK_ALLOWED_HOSTS: str = ''
    IMPERSONATION_TICKET_REQUIRED_PRODUCTION: bool = True
    APP_WEBHOOK_MAX_ATTEMPTS: int = 8
    APP_WEBHOOK_BATCH_SIZE: int = 50
    TRUST_REVIEW_MIN_ORDER_PROOF: bool = True
    REQUIRE_MERCHANT_IDENTITY: bool = True
    MERCHANT_KYC_PROVIDER: str = 'mock'
    KYC_WEBHOOK_TOLERANCE_SECONDS: int = 300
    VERIFF_API_BASE_URL: str = ''
    VERIFF_API_KEY: str = ''
    VERIFF_SHARED_SECRET: str = ''
    VERIFF_TIMEOUT_SECONDS: float = 20.0
    MERCHANT_RISK_HIGH_THRESHOLD: int = 70
    MERCHANT_RISK_REVIEW_THRESHOLD: int = 40
    MERCHANT_MAX_OPEN_REVIEW_CASES: int = 3
    CARD_INSTALLMENT_SAME_PRICE_ONLY: bool = True
    CARD_INSTALLMENT_MAX_COUNT: int = 12
    AI_REQUEST_RATE_LIMIT_PER_MINUTE: int = 20
    PUBLIC_CATALOG_MAX_PAGE_SIZE: int = 48
    MIGRATION_MODE: bool = False
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    def validate_runtime(self):
        if not self.APP_VERSION:
            version_path = __import__('pathlib').Path(__file__).resolve().parents[2] / 'VERSION'
            if version_path.exists():
                self.APP_VERSION = version_path.read_text(encoding='utf-8').strip()
        if self.ENVIRONMENT not in {'development', 'test', 'staging', 'production'}:
            raise RuntimeError('ENVIRONMENT must be one of development/test/staging/production')
        if self.MIGRATION_MODE:
            if not self.DATABASE_URL.startswith(('postgresql://','postgresql+psycopg://','postgresql+psycopg2://')):
                raise RuntimeError('MIGRATION_MODE requires PostgreSQL')
            return
        if self.PLATFORM_MODEL not in {'merchant_saas', 'marketplace'}:
            raise RuntimeError('PLATFORM_MODEL must be merchant_saas or marketplace')
        if self.ENVIRONMENT == 'production':
            if not self.LEGAL_ENTITY_NAME.strip():
                raise RuntimeError('LEGAL_ENTITY_NAME must be configured in production')
            if not self.PRIVACY_CONTACT_EMAIL.strip() or '@' not in self.PRIVACY_CONTACT_EMAIL:
                raise RuntimeError('PRIVACY_CONTACT_EMAIL must be configured in production')
            if not self.PRIVACY_POLICY_VERSION.strip():
                raise RuntimeError('PRIVACY_POLICY_VERSION must be configured in production')
            if not self.TERMS_EFFECTIVE_DATE.strip():
                raise RuntimeError('TERMS_EFFECTIVE_DATE must be configured in production')
            if self.DATABASE_URL.startswith('sqlite'):
                raise RuntimeError('SQLite is forbidden in production; PostgreSQL is required')
            if self.AI_SERVER_ONLY and (not self.AI_EXTERNAL_PROVIDER_ALLOWED) and self.AI_PROVIDER.lower().strip() != 'ollama':
                raise RuntimeError('Production AI is restricted to the internal provider unless the external-provider exception is explicitly enabled')
            if self.CARD_INSTALLMENT_SAME_PRICE_ONLY is not True:
                raise RuntimeError('CARD_INSTALLMENT_SAME_PRICE_ONLY must remain enabled in production')
            if self.CARD_INSTALLMENT_MAX_COUNT < 0 or self.CARD_INSTALLMENT_MAX_COUNT > 24:
                raise RuntimeError('CARD_INSTALLMENT_MAX_COUNT must be between 0 and 24')
            if self.SECRET_KEY in {'change-me-immediately',
                'replace-with-a-32-byte-random-secret'} or len(self.SECRET_KEY) < 32:
                raise RuntimeError('SECRET_KEY must be a strong production secret')
            if not self.ENCRYPTION_KEY or len(self.ENCRYPTION_KEY) < 32:
                raise RuntimeError('ENCRYPTION_KEY must be a dedicated strong production secret')
            if self.WEBHOOK_SECRET in {'change-me', 'replace-me'} or len(self.WEBHOOK_SECRET) < 32:
                raise RuntimeError('WEBHOOK_SECRET must be a strong production secret')
            if not self.COOKIE_SECURE:
                raise RuntimeError('COOKIE_SECURE must be enabled in production')
            if not self.ALLOWED_HOSTS.strip() or '*' in {x.strip() for x in self.ALLOWED_HOSTS.split(',')}:
                raise RuntimeError('ALLOWED_HOSTS must be explicit in production')
            if not self.CORS_ORIGINS.strip() or '*' in {x.strip() for x in self.CORS_ORIGINS.split(',')}:
                raise RuntimeError('CORS_ORIGINS must be explicit in production')
            if not self.TRUSTED_ORIGINS.strip() or '*' in {x.strip() for x in self.TRUSTED_ORIGINS.split(',')}:
                raise RuntimeError('TRUSTED_ORIGINS must be explicit in production')
            if not self.FORWARDED_ALLOW_IPS.strip() or self.FORWARDED_ALLOW_IPS.strip() in {'*', '0.0.0.0/0'}:
                raise RuntimeError('FORWARDED_ALLOW_IPS must explicitly trust only the real reverse proxy addresses/ranges in production')
            if not self.PUBLIC_BASE_URL.startswith('https://'):
                raise RuntimeError('PUBLIC_BASE_URL must use HTTPS in production')
            if self.AI_SERVER_ONLY:
                from urllib.parse import urlparse
                ai_host = (urlparse(self.AI_BASE_URL).hostname or '').lower()
                if urlparse(self.AI_BASE_URL).scheme != 'http' or ai_host not in {'ollama', 'ollama.internal'}:
                    raise RuntimeError('AI_SERVER_ONLY requires an internal Ollama endpoint (ollama/ollama.internal)')
            if self.BILLING_PROVIDER != 'paddle':
                raise RuntimeError('BILLING_PROVIDER must be paddle in production')
            if not all([self.S3_BUCKET, self.S3_ACCESS_KEY_ID, self.S3_SECRET_ACCESS_KEY]):
                raise RuntimeError('S3/R2 object storage credentials must be configured in production')
            if self.BILLING_PROVIDER == 'paddle' and not self.PADDLE_API_KEY:
                raise RuntimeError('PADDLE_API_KEY must be configured in production')
            if self.BILLING_PROVIDER == 'paddle' and not self.PADDLE_WEBHOOK_SECRET:
                raise RuntimeError('PADDLE_WEBHOOK_SECRET must be configured in production')
            if self.PAYTR_TEST_MODE:
                raise RuntimeError('PAYTR_TEST_MODE must be disabled in production')
            if self.DOMAIN_PLATFORM_PRICE_USD_MINOR < 1:
                raise RuntimeError('DOMAIN_PLATFORM_PRICE_USD_MINOR must be positive')
            if not all([self.GOOGLE_CLIENT_ID, self.GOOGLE_CLIENT_SECRET,
                self.GOOGLE_REDIRECT_URI]):
                raise RuntimeError('Google OAuth credentials/redirect URI must be configured in production')
            if self.DOMAIN_VERIFICATION_MODE != 'dns':
                raise RuntimeError('DOMAIN_VERIFICATION_MODE must be dns in production')
            if not all([self.SMTP_HOST, self.SMTP_USERNAME, self.SMTP_PASSWORD, self.MAIL_FROM]):
                raise RuntimeError('SMTP transactional email must be configured in production')
            if self.MEDIA_SCAN_REQUIRED and (not self.CLAMAV_HOST):
                raise RuntimeError('CLAMAV_HOST must be configured when malware scanning is required')
            if self.REQUIRE_MERCHANT_PHONE and self.SMS_PROVIDER == 'none':
                raise RuntimeError('SMS_PROVIDER must be configured when merchant phone verification is required')
            if self.SMS_PROVIDER == 'twilio' and not all([self.TWILIO_ACCOUNT_SID, self.TWILIO_AUTH_TOKEN, self.TWILIO_FROM_NUMBER]):
                raise RuntimeError('Twilio SMS credentials must be configured when SMS_PROVIDER=twilio')
            if self.WHATSAPP_API_VERSION and not self.WHATSAPP_APP_SECRET:
                raise RuntimeError('WHATSAPP_APP_SECRET must be configured in production when WhatsApp webhooks are enabled')
            if not self.APP_WEBHOOK_ALLOWED_HOSTS.strip():
                raise RuntimeError('APP_WEBHOOK_ALLOWED_HOSTS must be configured in production')
            if not self.REDIS_URL or not self.REDIS_URL.startswith(('redis://', 'rediss://')):
                raise RuntimeError('REDIS_URL must be configured for distributed rate limiting in production')
            if self.REQUIRE_MERCHANT_IDENTITY and self.MERCHANT_KYC_PROVIDER not in {'veriff'}:
                raise RuntimeError('A real KYC provider (currently Veriff) must be configured in production')
            if self.MERCHANT_KYC_PROVIDER == 'veriff' and not all([self.VERIFF_API_BASE_URL, self.VERIFF_API_KEY, self.VERIFF_SHARED_SECRET]):
                raise RuntimeError('Veriff API and shared-secret credentials must be configured in production')

@lru_cache
def get_settings() -> Settings:
    s = Settings()
    s.validate_runtime()
    return s
