"""Outbound network safety for tenant-configurable endpoints."""
from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlparse

from app.core.config import get_settings
from app.core.errors import AppError


def _public_ip(host: str) -> bool:
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_global and not ip.is_multicast
    except ValueError:
        return True


def validate_outbound_url(url: str, *, allowed_hosts: set[str] | None = None) -> str:
    """Validate an outbound URL before a tenant-controlled connection.

    Production requires HTTPS, forbids userinfo, local/reserved IP literals, and
    resolves hostnames to ensure every resolved address is globally routable.
    An explicit hostname allowlist can further restrict destinations.
    """
    if not url or len(url) > 2048:
        raise AppError(400, "OUTBOUND_URL_INVALID", "Outbound URL is invalid")
    parsed = urlparse(url)
    settings = get_settings()
    configured = {h.strip().lower().rstrip('.') for h in settings.CARRIER_ALLOWED_HOSTS.split(',') if h.strip()}
    if allowed_hosts is None and configured:
        allowed_hosts = configured
    if settings.ENVIRONMENT == 'production' and not allowed_hosts and parsed.hostname not in {'api.iyzipay.com', 'www.paytr.com', 'api.paddle.com'}:
        raise AppError(400, 'OUTBOUND_HOST_NOT_ALLOWLISTED', 'Production outbound host must be allowlisted')
    if parsed.scheme not in {"https"} and settings.ENVIRONMENT == "production":
        raise AppError(400, "OUTBOUND_HTTPS_REQUIRED", "HTTPS is required for outbound providers")
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise AppError(400, "OUTBOUND_URL_INVALID", "Outbound URL is invalid")
    if parsed.username or parsed.password:
        raise AppError(400, "OUTBOUND_URL_INVALID", "Userinfo is not allowed in outbound URLs")
    host = parsed.hostname.rstrip(".").lower()
    if allowed_hosts is not None and allowed_hosts and host not in allowed_hosts:
        raise AppError(400, "OUTBOUND_HOST_NOT_ALLOWED", "Outbound host is not allowlisted")
    if not _public_ip(host):
        raise AppError(400, "OUTBOUND_HOST_BLOCKED", "Outbound destination is not publicly routable")
    try:
        infos = socket.getaddrinfo(host, parsed.port or 443 if parsed.scheme == "https" else 80, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise AppError(400, "OUTBOUND_DNS_FAILED", "Outbound hostname could not be resolved") from exc
    if not infos:
        raise AppError(400, "OUTBOUND_DNS_FAILED", "Outbound hostname could not be resolved")
    for info in infos:
        address = info[4][0]
        if not _public_ip(address):
            raise AppError(400, "OUTBOUND_HOST_BLOCKED", "Outbound hostname resolves to a blocked address")
    return url
