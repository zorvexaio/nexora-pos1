import uuid
from datetime import datetime, timezone
from sqlalchemy import String, Boolean, DateTime, ForeignKey, Integer, BigInteger, Text, JSON, UniqueConstraint, Index, CheckConstraint, Numeric
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base

def uid():
    return str(uuid.uuid4())

def now():
    return datetime.now(timezone.utc)

class User(Base):
    __tablename__ = 'users'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(Text)
    display_name: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(32), default='ACTIVE')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class UserIdentity(Base):
    __tablename__ = 'user_identities'
    __table_args__ = (UniqueConstraint('provider', 'provider_subject'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    provider: Mapped[str] = mapped_column(String(50))
    provider_subject: Mapped[str] = mapped_column(String(255))
    provider_email: Mapped[str | None] = mapped_column(String(320))
    email_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class OAuthState(Base):
    __tablename__ = 'oauth_states'
    __table_args__ = (UniqueConstraint('state_hash', 'provider'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    provider: Mapped[str] = mapped_column(String(50))
    state_hash: Mapped[str] = mapped_column(String(128), index=True)
    nonce_hash: Mapped[str] = mapped_column(String(128), index=True)
    redirect_uri: Mapped[str] = mapped_column(String(1000))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'), index=True)

class RateLimitCounter(Base):
    __tablename__ = 'rate_limit_counters'
    __table_args__ = (UniqueConstraint('scope_key', 'window_start'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    scope_key: Mapped[str] = mapped_column(String(500), index=True)
    window_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Tenant(Base):
    __tablename__ = 'tenants'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    slug: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(32), default='PROVISIONING')
    default_currency: Mapped[str] = mapped_column(String(3), default='USD')
    default_locale: Mapped[str] = mapped_column(String(20), default='ar')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class TenantMembership(Base):
    __tablename__ = 'tenant_memberships'
    __table_args__ = (UniqueConstraint('tenant_id', 'user_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    role: Mapped[str] = mapped_column(String(50), default='owner')
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class RolePermission(Base):
    __tablename__ = 'role_permissions'
    __table_args__ = (UniqueConstraint('role', 'permission'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    role: Mapped[str] = mapped_column(String(50), index=True)
    permission: Mapped[str] = mapped_column(String(100), index=True)
    role_id: Mapped[str | None] = mapped_column(ForeignKey('roles.id'))
    permission_id: Mapped[str | None] = mapped_column(ForeignKey('permissions.id'))

class Session(Base):
    __tablename__ = 'sessions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    idle_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    absolute_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True),
        index=True)
    replaced_by: Mapped[str | None] = mapped_column(ForeignKey('sessions.id'))
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    ip_hash: Mapped[str | None] = mapped_column(String(128))
    user_agent_hash: Mapped[str | None] = mapped_column(String(128))
    impersonator_user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'), index=True)
    read_only_impersonation: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

class MFALoginChallenge(Base):
    __tablename__ = 'mfa_login_challenges'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class MFAFactor(Base):
    __tablename__ = 'mfa_factors'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    factor_type: Mapped[str] = mapped_column(String(30), default='TOTP')
    secret_encrypted: Mapped[str | None] = mapped_column(Text)
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class RecoveryCode(Base):
    __tablename__ = 'recovery_codes'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    code_hash: Mapped[str] = mapped_column(String(128), unique=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class PasswordResetToken(Base):
    __tablename__ = 'password_reset_tokens'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class AuditEvent(Base):
    __tablename__ = 'audit_events'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'), index=True)
    actor_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    action: Mapped[str] = mapped_column(String(100))
    resource_type: Mapped[str | None] = mapped_column(String(100))
    resource_id: Mapped[str | None] = mapped_column(String(36))
    request_id: Mapped[str | None] = mapped_column(String(36))
    correlation_id: Mapped[str | None] = mapped_column(String(36))
    ip_hash: Mapped[str | None] = mapped_column(String(128))
    user_agent_hash: Mapped[str | None] = mapped_column(String(128))
    before_data: Mapped[dict | None] = mapped_column(JSON)
    after_data: Mapped[dict | None] = mapped_column(JSON)
    prev_hash: Mapped[str | None] = mapped_column(String(128))
    event_hash: Mapped[str | None] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Market(Base):
    __tablename__ = 'markets'
    __table_args__ = (UniqueConstraint('tenant_id', 'code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    code: Mapped[str] = mapped_column(String(32))
    name: Mapped[str] = mapped_column(String(120))
    country_code: Mapped[str] = mapped_column(String(2))
    currency: Mapped[str] = mapped_column(String(3))
    locale: Mapped[str] = mapped_column(String(16), default='en')
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class NotificationTemplate(Base):
    __tablename__ = 'notification_templates'
    __table_args__ = (UniqueConstraint('tenant_id', 'code', 'channel', 'locale'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    code: Mapped[str] = mapped_column(String(100))
    channel: Mapped[str] = mapped_column(String(20))
    locale: Mapped[str] = mapped_column(String(16))
    subject: Mapped[str] = mapped_column(String(255), default='')
    body: Mapped[str] = mapped_column(Text())
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class NotificationDelivery(Base):
    __tablename__ = 'notification_deliveries'
    __table_args__ = (UniqueConstraint('tenant_id', 'idempotency_key',
        name='uq_notification_delivery_idem'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    template_id: Mapped[str | None] = mapped_column(ForeignKey('notification_templates.id'))
    channel: Mapped[str] = mapped_column(String(20))
    recipient: Mapped[str] = mapped_column(String(320))
    status: Mapped[str] = mapped_column(String(20), default='QUEUED')
    idempotency_key: Mapped[str] = mapped_column(String(200))
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    provider_message_id: Mapped[str | None] = mapped_column(String(255))
    scheduled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    error_message: Mapped[str | None] = mapped_column(Text())
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class RiskAssessment(Base):
    __tablename__ = 'risk_assessments'
    __table_args__ = (UniqueConstraint('tenant_id', 'order_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    score: Mapped[int] = mapped_column(Integer)
    decision: Mapped[str] = mapped_column(String(20))
    reasons: Mapped[list] = mapped_column(JSON, default=list)
    engine_version: Mapped[str] = mapped_column(String(40), default='rules-v1')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class APIKey(Base):
    __tablename__ = 'api_keys'
    __table_args__ = (UniqueConstraint('tenant_id', 'name'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    name: Mapped[str] = mapped_column(String(100))
    key_prefix: Mapped[str] = mapped_column(String(16))
    key_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    scopes: Mapped[list] = mapped_column(JSON, default=list)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Storefront(Base):
    __tablename__ = 'storefronts'
    __table_args__ = (UniqueConstraint('tenant_id', 'slug'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    name: Mapped[str] = mapped_column(String(255))
    slug: Mapped[str] = mapped_column(String(120))
    default_locale: Mapped[str] = mapped_column(String(20), default='ar')
    default_currency: Mapped[str] = mapped_column(String(3), default='USD')
    price_display_mode: Mapped[str] = mapped_column(String(20), default='tax_exclusive')
    status: Mapped[str] = mapped_column(String(20), default='DRAFT')
    version: Mapped[int] = mapped_column(Integer, default=1)

class Domain(Base):
    __tablename__ = 'domains'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    storefront_id: Mapped[str] = mapped_column(ForeignKey('storefronts.id'))
    hostname: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)
    verification_token_hash: Mapped[str | None] = mapped_column(String(128))
    verification_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    verification_method: Mapped[str | None] = mapped_column(String(20))
    verified_hostname: Mapped[str | None] = mapped_column(String(255))
    verification_version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)

class Product(Base):
    __tablename__ = 'products'
    __table_args__ = (UniqueConstraint('tenant_id', 'slug'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    storefront_id: Mapped[str | None] = mapped_column(ForeignKey('storefronts.id'))
    slug: Mapped[str] = mapped_column(String(160))
    status: Mapped[str] = mapped_column(String(20), default='DRAFT')
    product_type: Mapped[str] = mapped_column(String(30), default='PHYSICAL')
    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[str | None] = mapped_column(Text)
    tax_class_id: Mapped[str | None] = mapped_column(String(36))
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ProductTranslation(Base):
    __tablename__ = 'product_translations'
    __table_args__ = (UniqueConstraint('tenant_id', 'product_id', 'locale'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'), index=True)
    locale: Mapped[str] = mapped_column(String(20))
    name: Mapped[str] = mapped_column(String(255))
    description: Mapped[str | None] = mapped_column(Text)
    seo_title: Mapped[str | None] = mapped_column(String(255))
    seo_description: Mapped[str | None] = mapped_column(Text)

class ProductVariant(Base):
    __tablename__ = 'product_variants'
    __table_args__ = (UniqueConstraint('tenant_id', 'sku'),
        CheckConstraint('price_amount_minor>=0'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'), index=True)
    sku: Mapped[str] = mapped_column(String(120))
    price_amount_minor: Mapped[int] = mapped_column(BigInteger)
    cost_amount_minor: Mapped[int | None] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')

class Category(Base):
    __tablename__ = 'categories'
    __table_args__ = (UniqueConstraint('tenant_id', 'slug'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    parent_id: Mapped[str | None] = mapped_column(ForeignKey('categories.id'))
    slug: Mapped[str] = mapped_column(String(120))
    name: Mapped[str] = mapped_column(String(255))

class ProductSEO(Base):
    __tablename__ = 'product_seo'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'), unique=True)
    title: Mapped[str | None] = mapped_column(String(255))
    description: Mapped[str | None] = mapped_column(Text)
    canonical_url: Mapped[str | None] = mapped_column(Text)
    meta_title: Mapped[str | None] = mapped_column(String(255))
    meta_description: Mapped[str | None] = mapped_column(Text)
    og_title: Mapped[str | None] = mapped_column(String(255))
    og_description: Mapped[str | None] = mapped_column(Text)
    robots: Mapped[str | None] = mapped_column(String(100))

class MediaAsset(Base):
    __tablename__ = 'media_assets'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    storage_key: Mapped[str] = mapped_column(String(500), unique=True)
    mime_type: Mapped[str] = mapped_column(String(100))
    size_bytes: Mapped[int] = mapped_column(BigInteger)
    status: Mapped[str] = mapped_column(String(30), default='READY')
    alt_text: Mapped[str | None] = mapped_column(Text)

class MediaVariant(Base):
    __tablename__ = 'media_variants'
    __table_args__ = (UniqueConstraint('tenant_id', 'media_asset_id', 'variant'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    media_asset_id: Mapped[str] = mapped_column(ForeignKey('media_assets.id'), index=True)
    variant: Mapped[str] = mapped_column(String(30))
    storage_key: Mapped[str] = mapped_column(String(500), unique=True)
    mime_type: Mapped[str] = mapped_column(String(100))
    width: Mapped[int | None] = mapped_column(Integer)
    height: Mapped[int | None] = mapped_column(Integer)
    size_bytes: Mapped[int] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Price(Base):
    __tablename__ = 'prices'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    variant_id: Mapped[str] = mapped_column(ForeignKey('product_variants.id'), index=True)
    price_list_id: Mapped[str | None] = mapped_column(ForeignKey('price_lists.id'))
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    valid_from: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    valid_to: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class Promotion(Base):
    __tablename__ = 'promotions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    name: Mapped[str] = mapped_column(String(255))
    discount_type: Mapped[str] = mapped_column(String(20))
    value_minor: Mapped[int | None] = mapped_column(BigInteger)
    percentage_bps: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    usage_limit: Mapped[int | None] = mapped_column(BigInteger)
    usage_count: Mapped[int] = mapped_column(BigInteger, default=0)

class Coupon(Base):
    __tablename__ = 'coupons'
    __table_args__ = (UniqueConstraint('tenant_id', 'code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    promotion_id: Mapped[str] = mapped_column(ForeignKey('promotions.id'))
    code: Mapped[str] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    usage_limit: Mapped[int | None] = mapped_column(BigInteger)
    usage_count: Mapped[int] = mapped_column(BigInteger, default=0)

class CouponRedemption(Base):
    __tablename__ = 'coupon_redemptions'
    __table_args__ = (UniqueConstraint('tenant_id', 'coupon_id', 'order_id'),
        UniqueConstraint('tenant_id', 'idempotency_key'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    coupon_id: Mapped[str] = mapped_column(ForeignKey('coupons.id'))
    promotion_id: Mapped[str] = mapped_column(ForeignKey('promotions.id'))
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'))
    customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'))
    idempotency_key: Mapped[str | None] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Customer(Base):
    __tablename__ = 'customers'
    __table_args__ = (UniqueConstraint('tenant_id', 'email'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    email: Mapped[str | None] = mapped_column(String(320))
    phone: Mapped[str | None] = mapped_column(String(50))
    first_name: Mapped[str | None] = mapped_column(String(120))
    last_name: Mapped[str | None] = mapped_column(String(120))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class CustomerIdentity(Base):
    __tablename__ = 'customer_identities'
    __table_args__ = (UniqueConstraint('tenant_id', 'provider', 'provider_subject'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'), index=True)
    provider: Mapped[str] = mapped_column(String(40), index=True)
    provider_subject: Mapped[str] = mapped_column(String(255), index=True)
    provider_email: Mapped[str | None] = mapped_column(String(320))
    email_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class CustomerSession(Base):
    __tablename__ = 'customer_sessions'
    __table_args__ = (UniqueConstraint('tenant_id', 'token_hash'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class CustomerLoginCode(Base):
    __tablename__ = 'customer_login_codes'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'), index=True)
    email: Mapped[str] = mapped_column(String(320), index=True)
    code_hash: Mapped[str] = mapped_column(String(128), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class StorefrontOAuthState(Base):
    __tablename__ = 'storefront_oauth_states'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    hostname: Mapped[str] = mapped_column(String(255), index=True)
    provider: Mapped[str] = mapped_column(String(40), default='google')
    state_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    nonce_hash: Mapped[str] = mapped_column(String(128), index=True)
    redirect_uri: Mapped[str] = mapped_column(String(1000))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class GuestSession(Base):
    __tablename__ = 'guest_sessions'
    __table_args__ = (UniqueConstraint('tenant_id', 'token_hash'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Cart(Base):
    __tablename__ = 'carts'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'))
    status: Mapped[str] = mapped_column(String(20), default='OPEN')
    currency: Mapped[str] = mapped_column(String(3))
    version: Mapped[int] = mapped_column(Integer, default=0)
    guest_session_id: Mapped[str | None] = mapped_column(ForeignKey('guest_sessions.id'),
        index=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class CartItem(Base):
    __tablename__ = 'cart_items'
    __table_args__ = (UniqueConstraint('tenant_id', 'cart_id', 'variant_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    cart_id: Mapped[str] = mapped_column(ForeignKey('carts.id'), index=True)
    variant_id: Mapped[str] = mapped_column(ForeignKey('product_variants.id'))
    quantity: Mapped[int] = mapped_column(BigInteger)
    unit_price_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))

class Order(Base):
    __tablename__ = 'orders'
    __table_args__ = (UniqueConstraint('tenant_id', 'order_number'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    storefront_id: Mapped[str | None] = mapped_column(ForeignKey('storefronts.id'))
    customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'))
    order_number: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(32), default='DRAFT')
    payment_status: Mapped[str] = mapped_column(String(32), default='PENDING')
    fulfillment_status: Mapped[str] = mapped_column(String(32), default='UNFULFILLED')
    risk_status: Mapped[str] = mapped_column(String(32), default='NOT_REVIEWED')
    customer_email_snapshot: Mapped[str | None] = mapped_column(String(320))
    guest_session_id: Mapped[str | None] = mapped_column(ForeignKey('guest_sessions.id'),
        index=True)
    currency: Mapped[str] = mapped_column(String(3))
    subtotal_minor: Mapped[int] = mapped_column(BigInteger)
    discount_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    shipping_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    shipping_list_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    shipping_discount_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    shipping_method_id: Mapped[str | None] = mapped_column(ForeignKey('shipping_methods.id'), index=True)
    shipping_carrier_code: Mapped[str | None] = mapped_column(String(40))
    shipping_service_code: Mapped[str | None] = mapped_column(String(80))
    tax_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    fee_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    total_minor: Mapped[int] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class OrderItem(Base):
    __tablename__ = 'order_items'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    variant_id: Mapped[str | None] = mapped_column(ForeignKey('product_variants.id'))
    sku_snapshot: Mapped[str] = mapped_column(String(120))
    title_snapshot: Mapped[str] = mapped_column(String(255))
    quantity: Mapped[int] = mapped_column(BigInteger)
    unit_price_minor: Mapped[int] = mapped_column(BigInteger)
    # Immutable historical cost basis captured at order creation.
    # Variant.cost_amount_minor can change later, so profitability reports must
    # never reconstruct old COGS from the mutable catalog value.
    cost_amount_minor: Mapped[int | None] = mapped_column(BigInteger)
    discount_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    tax_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    total_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))

class OrderStatusHistory(Base):
    __tablename__ = 'order_status_history'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'))
    from_state: Mapped[str | None] = mapped_column(String(32))
    to_state: Mapped[str] = mapped_column(String(32))
    actor_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class InventoryLocation(Base):
    __tablename__ = 'inventory_locations'
    __table_args__ = (UniqueConstraint('tenant_id', 'name'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    name: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')

class InventoryItem(Base):
    __tablename__ = 'inventory_items'
    __table_args__ = (UniqueConstraint('tenant_id', 'variant_id', 'location_id'),
        CheckConstraint('on_hand>=0'), CheckConstraint('available>=0'), CheckConstraint('reserved>=0'), CheckConstraint('committed>=0'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    variant_id: Mapped[str] = mapped_column(ForeignKey('product_variants.id'))
    location_id: Mapped[str] = mapped_column(ForeignKey('inventory_locations.id'))
    on_hand: Mapped[int] = mapped_column(BigInteger, default=0)
    reserved: Mapped[int] = mapped_column(BigInteger, default=0)
    committed: Mapped[int] = mapped_column(BigInteger, default=0)
    available: Mapped[int] = mapped_column(BigInteger, default=0)
    version: Mapped[int] = mapped_column(BigInteger, default=0)

class InventoryReservation(Base):
    __tablename__ = 'inventory_reservations'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    inventory_item_id: Mapped[str] = mapped_column(ForeignKey('inventory_items.id'))
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'))
    quantity: Mapped[int] = mapped_column(BigInteger)
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    version: Mapped[int] = mapped_column(Integer, default=1)

class InventoryAdjustment(Base):
    __tablename__ = 'inventory_adjustments'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    inventory_item_id: Mapped[str] = mapped_column(ForeignKey('inventory_items.id'))
    delta: Mapped[int] = mapped_column(BigInteger)
    reason: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PaymentIntent(Base):
    __tablename__ = 'payment_intents'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str | None] = mapped_column(ForeignKey('orders.id'))
    ucp_checkout_session_id: Mapped[str | None] = mapped_column(ForeignKey('ucp_checkout_sessions.id'), index=True)
    domain_purchase_id: Mapped[str | None] = mapped_column(ForeignKey('domain_purchases.id'), index=True)
    provider: Mapped[str] = mapped_column(String(50), default='iyzico')
    provider_payment_id: Mapped[str | None] = mapped_column(String(255), unique=True)
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(32), default='PENDING')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PaymentCapture(Base):
    __tablename__ = 'payment_captures'
    __table_args__ = (UniqueConstraint('tenant_id', 'provider_capture_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    payment_intent_id: Mapped[str] = mapped_column(ForeignKey('payment_intents.id'))
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    provider_capture_id: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Refund(Base):
    __tablename__ = 'refunds'
    __table_args__ = (UniqueConstraint('tenant_id', 'provider_refund_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'))
    payment_intent_id: Mapped[str] = mapped_column(ForeignKey('payment_intents.id'))
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(32), default='PENDING')
    provider_refund_id: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class LedgerAccount(Base):
    __tablename__ = 'ledger_accounts'
    __table_args__ = (UniqueConstraint('tenant_id', 'code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    code: Mapped[str] = mapped_column(String(80))
    name: Mapped[str] = mapped_column(String(255))
    account_type: Mapped[str] = mapped_column(String(40))
    currency: Mapped[str | None] = mapped_column(String(3))

class JournalEntry(Base):
    __tablename__ = 'journal_entries'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    currency: Mapped[str] = mapped_column(String(3))
    reference_type: Mapped[str] = mapped_column(String(80))
    reference_id: Mapped[str] = mapped_column(String(36))
    reversal_of: Mapped[str | None] = mapped_column(ForeignKey('journal_entries.id'))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class JournalLine(Base):
    __tablename__ = 'journal_lines'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    journal_entry_id: Mapped[str] = mapped_column(ForeignKey('journal_entries.id'))
    account_id: Mapped[str] = mapped_column(ForeignKey('ledger_accounts.id'))
    debit_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    credit_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    currency: Mapped[str] = mapped_column(String(3))

class OutboxEvent(Base):
    __tablename__ = 'outbox_events'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'), index=True)
    aggregate_type: Mapped[str] = mapped_column(String(80))
    aggregate_id: Mapped[str] = mapped_column(String(36))
    event_type: Mapped[str] = mapped_column(String(120))
    schema_version: Mapped[int] = mapped_column(Integer, default=1)
    payload: Mapped[dict] = mapped_column(JSON)
    correlation_id: Mapped[str | None] = mapped_column(String(36))
    causation_id: Mapped[str | None] = mapped_column(String(36))
    producer: Mapped[str] = mapped_column(String(100), default='commerce-api')
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    attempt_count: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(20), default='PENDING')
    last_error: Mapped[str | None] = mapped_column(Text)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    dedupe_key: Mapped[str | None] = mapped_column(String(255), unique=True, index=True)

class DeadLetterEvent(Base):
    __tablename__ = 'dead_letter_events'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'))
    source_event_id: Mapped[str | None] = mapped_column(String(36))
    event_type: Mapped[str] = mapped_column(String(120))
    payload: Mapped[dict] = mapped_column(JSON)
    failure_reason: Mapped[str] = mapped_column(Text)
    attempt_count: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class IdempotencyKey(Base):
    __tablename__ = 'idempotency_keys'
    __table_args__ = (UniqueConstraint('tenant_id', 'endpoint', 'key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    actor_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    endpoint: Mapped[str] = mapped_column(String(160))
    key: Mapped[str] = mapped_column(String(200))
    request_hash: Mapped[str] = mapped_column(String(128))
    status: Mapped[str] = mapped_column(String(20), default='IN_PROGRESS')
    response_status: Mapped[int | None] = mapped_column(Integer)
    response_body: Mapped[dict | None] = mapped_column(JSON)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

class PlatformIdempotencyKey(Base):
    __tablename__ = 'platform_idempotency_keys'
    __table_args__ = (UniqueConstraint('actor_id', 'endpoint', 'key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    actor_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    endpoint: Mapped[str] = mapped_column(String(160))
    key: Mapped[str] = mapped_column(String(200))
    request_hash: Mapped[str] = mapped_column(String(128))
    status: Mapped[str] = mapped_column(String(20), default='IN_PROGRESS')
    response_status: Mapped[int | None] = mapped_column(Integer)
    response_body: Mapped[dict | None] = mapped_column(JSON)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

class ProviderTenantBinding(Base):
    __tablename__ = 'provider_tenant_bindings'
    __table_args__ = (UniqueConstraint('provider', 'external_id', name='uq_provider_tenant_binding'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    provider: Mapped[str] = mapped_column(String(50))
    external_id: Mapped[str] = mapped_column(String(255), index=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class WebhookEvent(Base):
    __tablename__ = 'webhook_events'
    __table_args__ = (UniqueConstraint('provider', 'provider_event_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'))
    provider: Mapped[str] = mapped_column(String(50))
    provider_event_id: Mapped[str] = mapped_column(String(255))
    event_type: Mapped[str] = mapped_column(String(120))
    payload_hash: Mapped[str] = mapped_column(String(128))
    payload: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(20), default='RECEIVED')
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class ProviderIngestEvent(Base):
    __tablename__ = 'provider_ingest_events'
    __table_args__ = (UniqueConstraint('provider', 'provider_event_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    provider: Mapped[str] = mapped_column(String(50))
    provider_event_id: Mapped[str] = mapped_column(String(255))
    event_type: Mapped[str] = mapped_column(String(120))
    payload_hash: Mapped[str] = mapped_column(String(128))
    payload: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(30), default='QUARANTINED')
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    resolved_tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'), index=True)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class ShippingMethod(Base):
    __tablename__ = 'shipping_methods'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    name: Mapped[str] = mapped_column(String(120))
    carrier_code: Mapped[str] = mapped_column(String(40), default='platform')
    service_code: Mapped[str | None] = mapped_column(String(80))
    mode: Mapped[str] = mapped_column(String(20), default='FLAT')
    amount_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    currency: Mapped[str] = mapped_column(String(3))
    free_shipping: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    free_shipping_threshold_minor: Mapped[int | None] = mapped_column(BigInteger)
    offer_label: Mapped[str | None] = mapped_column(String(255))
    estimated_days_min: Mapped[int | None] = mapped_column(Integer)
    estimated_days_max: Mapped[int | None] = mapped_column(Integer)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

class TaxRate(Base):
    __tablename__ = 'tax_rates'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    country_code: Mapped[str] = mapped_column(String(2))
    region: Mapped[str | None] = mapped_column(String(100))
    rate_bps: Mapped[int] = mapped_column(Integer)
    inclusive: Mapped[bool] = mapped_column(Boolean, default=False)

class MerchantPaymentAccount(Base):
    __tablename__ = 'merchant_payment_accounts'
    __table_args__ = (UniqueConstraint('tenant_id', 'provider'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    provider: Mapped[str] = mapped_column(String(50), default='iyzico')
    provider_account_id: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(30), default='PENDING')
    onboarding_url: Mapped[str | None] = mapped_column(Text)
    charges_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    payouts_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    requirements_due: Mapped[dict | None] = mapped_column(JSON)
    credentials_encrypted: Mapped[str | None] = mapped_column(Text)

class Plan(Base):
    __tablename__ = 'plans'
    __table_args__ = (UniqueConstraint('code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    code: Mapped[str] = mapped_column(String(80))
    name: Mapped[str] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

class PlanVersion(Base):
    __tablename__ = 'plan_versions'
    __table_args__ = (UniqueConstraint('plan_id', 'version'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    plan_id: Mapped[str] = mapped_column(ForeignKey('plans.id'), index=True)
    version: Mapped[int] = mapped_column(Integer)
    is_current: Mapped[bool] = mapped_column(Boolean, default=True)
    provider_price_id: Mapped[str | None] = mapped_column(String(255))

class PlanFeature(Base):
    __tablename__ = 'plan_features'
    __table_args__ = (UniqueConstraint('plan_version_id', 'feature_key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    plan_version_id: Mapped[str] = mapped_column(ForeignKey('plan_versions.id'))
    feature_key: Mapped[str] = mapped_column(String(100))
    value_type: Mapped[str] = mapped_column(String(20))
    value_boolean: Mapped[bool | None] = mapped_column(Boolean)
    value_integer: Mapped[int | None] = mapped_column(Integer)

class BillingCustomer(Base):
    __tablename__ = 'billing_customers'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), unique=True)
    provider_customer_id: Mapped[str | None] = mapped_column(String(255), unique=True)
    email: Mapped[str | None] = mapped_column(String(320))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Subscription(Base):
    __tablename__ = 'subscriptions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    plan_version_id: Mapped[str] = mapped_column(ForeignKey('plan_versions.id'))
    status: Mapped[str] = mapped_column(String(30), default='active')
    pricing_model: Mapped[str] = mapped_column(String(20), default='saas_subscription')
    billing_provider: Mapped[str] = mapped_column(String(40), default='paddle')
    provider_customer_id: Mapped[str | None] = mapped_column(String(255))
    provider_subscription_id: Mapped[str | None] = mapped_column(String(255), unique=True)
    current_period_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class Entitlement(Base):
    __tablename__ = 'entitlements'
    __table_args__ = (UniqueConstraint('tenant_id', 'feature_key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    feature_key: Mapped[str] = mapped_column(String(100))
    value_type: Mapped[str] = mapped_column(String(20))
    value_boolean: Mapped[bool | None] = mapped_column(Boolean)
    value_integer: Mapped[int | None] = mapped_column(Integer)
    version: Mapped[int] = mapped_column(Integer, default=1)

class Wishlist(Base):
    __tablename__ = 'wishlists'
    __table_args__ = (UniqueConstraint('tenant_id', 'customer_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'))
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'))

class WishlistItem(Base):
    __tablename__ = 'wishlist_items'
    __table_args__ = (UniqueConstraint('tenant_id', 'wishlist_id', 'product_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    wishlist_id: Mapped[str] = mapped_column(ForeignKey('wishlists.id'))
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'))

class Review(Base):
    __tablename__ = 'reviews'
    __table_args__ = (UniqueConstraint('tenant_id', 'order_id', 'product_id', 'customer_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'))
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'))
    order_id: Mapped[str | None] = mapped_column(ForeignKey('orders.id'))
    rating: Mapped[int] = mapped_column(Integer)
    body: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default='PENDING')

class Question(Base):
    __tablename__ = 'questions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'))
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default='PUBLISHED')

class Answer(Base):
    __tablename__ = 'answers'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    question_id: Mapped[str] = mapped_column(ForeignKey('questions.id'))
    author_id: Mapped[str] = mapped_column(ForeignKey('users.id'))
    body: Mapped[str] = mapped_column(Text)

class OrderTrackingReference(Base):
    __tablename__ = 'order_tracking_references'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    carrier: Mapped[str | None] = mapped_column(String(100))
    tracking_number: Mapped[str] = mapped_column(String(255))
    public_token_hash: Mapped[str] = mapped_column(String(128), unique=True)

class ConsentRecord(Base):
    __tablename__ = 'consent_records'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'))
    anonymous_id: Mapped[str | None] = mapped_column(String(120))
    categories_accepted: Mapped[dict] = mapped_column(JSON)
    consent_version: Mapped[str] = mapped_column(String(50))
    policy_snapshot: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PrivacyRequest(Base):
    __tablename__ = 'privacy_requests'
    __table_args__ = (
        Index('ix_privacy_requests_user_status', 'user_id', 'status'),
        Index('ix_privacy_requests_tenant_status', 'tenant_id', 'status'),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'), index=True)
    user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'), index=True)
    customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'), index=True)
    request_type: Mapped[str] = mapped_column(String(32), index=True)
    status: Mapped[str] = mapped_column(String(24), default='SUBMITTED', index=True)
    jurisdiction: Mapped[str | None] = mapped_column(String(40))
    identity_verification: Mapped[str] = mapped_column(String(24), default='ACCOUNT_AUTHENTICATED')
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    data_export_ready_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolution_note: Mapped[str | None] = mapped_column(Text)
    metadata_json: Mapped[dict | None] = mapped_column(JSON)

class PrivacyConsentEvent(Base):
    __tablename__ = 'privacy_consent_events'
    __table_args__ = (Index('ix_privacy_consent_subject_created', 'subject_type', 'subject_id', 'created_at'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'), index=True)
    user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'), index=True)
    customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'), index=True)
    subject_type: Mapped[str] = mapped_column(String(24), default='USER')
    subject_id: Mapped[str] = mapped_column(String(120), index=True)
    jurisdiction: Mapped[str | None] = mapped_column(String(40))
    policy_version: Mapped[str] = mapped_column(String(50))
    action: Mapped[str] = mapped_column(String(16))
    categories: Mapped[dict] = mapped_column(JSON, default=dict)
    lawful_basis: Mapped[dict | None] = mapped_column(JSON)
    source: Mapped[str] = mapped_column(String(40), default='privacy_center')
    ip_hash: Mapped[str | None] = mapped_column(String(128))
    user_agent_hash: Mapped[str | None] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PrivacyAccessGrant(Base):
    __tablename__ = 'privacy_access_grants'
    __table_args__ = (
        Index('ix_privacy_access_grants_tenant_status', 'tenant_id', 'status'),
        Index('ix_privacy_access_grants_expires_at', 'expires_at'),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    verification_id: Mapped[str] = mapped_column(ForeignKey('merchant_identity_verifications.id'), index=True)
    case_id: Mapped[str] = mapped_column(ForeignKey('merchant_review_cases.id'), index=True)
    requester_user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    purpose: Mapped[str] = mapped_column(String(255))
    ticket_ref: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(24), default='GRANTED', index=True)
    provider_access_reference: Mapped[str | None] = mapped_column(String(255))
    granted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ip_hash: Mapped[str | None] = mapped_column(String(128))

class PrivacyIncident(Base):
    __tablename__ = 'privacy_incidents'
    __table_args__ = (Index('ix_privacy_incidents_status_created', 'status', 'detected_at'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    jurisdiction: Mapped[str] = mapped_column(String(40), index=True)
    status: Mapped[str] = mapped_column(String(24), default='DETECTED', index=True)
    severity: Mapped[str] = mapped_column(String(16), default='MEDIUM')
    detected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)
    assessed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    authority_due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    affected_subjects_estimate: Mapped[int | None] = mapped_column(Integer)
    data_categories: Mapped[list | None] = mapped_column(JSON)
    containment_notes: Mapped[str | None] = mapped_column(Text)
    notification_decision: Mapped[str | None] = mapped_column(String(32))
    notification_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    owner_user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PrivacyTransferRegister(Base):
    __tablename__ = 'privacy_transfer_register'
    __table_args__ = (UniqueConstraint('processor_name', 'destination_country', 'mechanism', name='uq_privacy_transfer_register_route'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    processor_name: Mapped[str] = mapped_column(String(160))
    role: Mapped[str] = mapped_column(String(32), default='PROCESSOR')
    destination_country: Mapped[str] = mapped_column(String(2))
    mechanism: Mapped[str] = mapped_column(String(80))
    data_categories: Mapped[list] = mapped_column(JSON, default=list)
    purpose: Mapped[str] = mapped_column(Text)
    contract_reference: Mapped[str | None] = mapped_column(String(160))
    contract_type: Mapped[str | None] = mapped_column(String(80))
    signed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    signatory_authority_reference: Mapped[str | None] = mapped_column(String(255))
    regulatory_notification_reference: Mapped[str | None] = mapped_column(String(255))
    regulatory_notified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    approval_status: Mapped[str] = mapped_column(String(32), default='PENDING_REVIEW', index=True)
    policy_version: Mapped[str] = mapped_column(String(50), default='privacy-v1')
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PlatformAdmin(Base):
    __tablename__ = 'platform_admins'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), unique=True)
    platform_role: Mapped[str] = mapped_column(String(50), default='super_admin')

class OrderAddress(Base):
    __tablename__ = 'order_addresses'
    __table_args__ = (UniqueConstraint('order_id', 'type'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    type: Mapped[str] = mapped_column(String(20))
    recipient_name: Mapped[str | None] = mapped_column(String(255))
    phone: Mapped[str | None] = mapped_column(String(50))
    country_code: Mapped[str] = mapped_column(String(2))
    region: Mapped[str | None] = mapped_column(String(120))
    city: Mapped[str | None] = mapped_column(String(120))
    postal_code: Mapped[str | None] = mapped_column(String(30))
    address_line1: Mapped[str] = mapped_column(String(255))
    address_line2: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PaymentAttempt(Base):
    __tablename__ = 'payment_attempts'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    payment_intent_id: Mapped[str] = mapped_column(ForeignKey('payment_intents.id'), index=True)
    provider_attempt_id: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(32))
    error_code: Mapped[str | None] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PaymentOperation(Base):
    __tablename__ = 'payment_operations'
    __table_args__ = (UniqueConstraint('tenant_id', 'idempotency_key',
     name='uq_payment_operation_key'),
     Index('uq_payment_operation_active',
     'tenant_id',
     'payment_intent_id',
     'operation_type',
     unique=True,
     sqlite_where=__import__('sqlalchemy').text("status IN ('PENDING','PROVIDER_PENDING')"),
        postgresql_where=__import__('sqlalchemy').text("status IN ('PENDING','PROVIDER_PENDING')")))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    payment_intent_id: Mapped[str] = mapped_column(ForeignKey('payment_intents.id'), index=True)
    operation_type: Mapped[str] = mapped_column(String(32))
    idempotency_key: Mapped[str] = mapped_column(String(255))
    request_hash: Mapped[str | None] = mapped_column(String(128), index=True)
    requested_amount_minor: Mapped[int | None] = mapped_column(BigInteger)
    currency: Mapped[str | None] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(32), default='PENDING')
    provider_reference: Mapped[str | None] = mapped_column(String(255))
    error_code: Mapped[str | None] = mapped_column(String(100))
    response_body: Mapped[dict | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class ProviderEvent(Base):
    __tablename__ = 'provider_events'
    __table_args__ = (UniqueConstraint('provider', 'provider_event_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'), index=True)
    provider: Mapped[str] = mapped_column(String(50))
    provider_event_id: Mapped[str] = mapped_column(String(255))
    event_type: Mapped[str] = mapped_column(String(100))
    payload_hash: Mapped[str] = mapped_column(String(128))
    payload: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(32))
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class ReconciliationRecord(Base):
    __tablename__ = 'reconciliation_records'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    provider: Mapped[str] = mapped_column(String(50))
    external_reference: Mapped[str] = mapped_column(String(255))
    internal_reference: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(32))
    amount_minor: Mapped[int | None] = mapped_column(BigInteger)
    currency: Mapped[str | None] = mapped_column(String(3))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Settlement(Base):
    __tablename__ = 'settlements'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    provider: Mapped[str] = mapped_column(String(50))
    provider_reference: Mapped[str] = mapped_column(String(255))
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Payout(Base):
    __tablename__ = 'payouts'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    provider: Mapped[str] = mapped_column(String(50))
    provider_reference: Mapped[str | None] = mapped_column(String(255))
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class FinancialTransaction(Base):
    __tablename__ = 'financial_transactions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    reference_type: Mapped[str] = mapped_column(String(50))
    reference_id: Mapped[str] = mapped_column(String(36))
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    direction: Mapped[str] = mapped_column(String(20))
    status: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PriceList(Base):
    __tablename__ = 'price_lists'
    __table_args__ = (UniqueConstraint('tenant_id', 'code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    code: Mapped[str] = mapped_column(String(80))
    name: Mapped[str] = mapped_column(String(255))
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')

class MarketPrice(Base):
    __tablename__ = 'market_prices'
    __table_args__ = (UniqueConstraint('tenant_id', 'variant_id', 'market', 'currency'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    variant_id: Mapped[str] = mapped_column(ForeignKey('product_variants.id'), index=True)
    market: Mapped[str] = mapped_column(String(50))
    currency: Mapped[str] = mapped_column(String(3))
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    valid_from: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    valid_to: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class DiscountApplication(Base):
    __tablename__ = 'discount_applications'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    promotion_id: Mapped[str | None] = mapped_column(ForeignKey('promotions.id'))
    coupon_id: Mapped[str | None] = mapped_column(ForeignKey('coupons.id'))
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ProductOption(Base):
    __tablename__ = 'product_options'
    __table_args__ = (UniqueConstraint('tenant_id', 'product_id', 'name'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'), index=True)
    name: Mapped[str] = mapped_column(String(100))
    position: Mapped[int] = mapped_column(Integer, default=0)

class ProductOptionValue(Base):
    __tablename__ = 'product_option_values'
    __table_args__ = (UniqueConstraint('tenant_id', 'option_id', 'value'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    option_id: Mapped[str] = mapped_column(ForeignKey('product_options.id'), index=True)
    value: Mapped[str] = mapped_column(String(100))
    position: Mapped[int] = mapped_column(Integer, default=0)

class ProductVariantOptionValue(Base):
    __tablename__ = 'product_variant_option_values'
    __table_args__ = (UniqueConstraint('tenant_id', 'variant_id', 'option_value_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    variant_id: Mapped[str] = mapped_column(ForeignKey('product_variants.id'), index=True)
    option_value_id: Mapped[str] = mapped_column(ForeignKey('product_option_values.id'), index=True)

class Role(Base):
    __tablename__ = 'roles'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'), index=True)
    name: Mapped[str] = mapped_column(String(100))
    system_role: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (UniqueConstraint('tenant_id', 'name'),)

class Permission(Base):
    __tablename__ = 'permissions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    code: Mapped[str] = mapped_column(String(120), unique=True)

class ProductCategory(Base):
    __tablename__ = 'product_categories'
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'), primary_key=True)
    category_id: Mapped[str] = mapped_column(ForeignKey('categories.id'), primary_key=True)

class ProductMedia(Base):
    __tablename__ = 'product_media'
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), primary_key=True)
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'), primary_key=True)
    media_asset_id: Mapped[str] = mapped_column(ForeignKey('media_assets.id'), primary_key=True)
    position: Mapped[int] = mapped_column(Integer, default=0)
    alt_text: Mapped[str | None] = mapped_column(Text)

class CustomerAddress(Base):
    __tablename__ = 'customer_addresses'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'), index=True)
    country_code: Mapped[str] = mapped_column(String(2))
    region: Mapped[str | None] = mapped_column(String(120))
    city: Mapped[str | None] = mapped_column(String(120))
    postal_code: Mapped[str | None] = mapped_column(String(32))
    address_line1: Mapped[str] = mapped_column(Text)
    address_line2: Mapped[str | None] = mapped_column(Text)
    type: Mapped[str] = mapped_column(String(20), default='SHIPPING')

class TaxJurisdiction(Base):
    __tablename__ = 'tax_jurisdictions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    country_code: Mapped[str] = mapped_column(String(2))
    region_code: Mapped[str | None] = mapped_column(String(80))
    city: Mapped[str | None] = mapped_column(String(120))
    name: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    __table_args__ = (UniqueConstraint('tenant_id', 'country_code', 'region_code', 'city'),)

class TaxClass(Base):
    __tablename__ = 'tax_classes'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    code: Mapped[str] = mapped_column(String(80))
    name: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    __table_args__ = (UniqueConstraint('tenant_id', 'code'),)

class TaxCalculation(Base):
    __tablename__ = 'tax_calculations'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str | None] = mapped_column(ForeignKey('orders.id'))
    currency: Mapped[str] = mapped_column(String(3))
    provider: Mapped[str | None] = mapped_column(String(80))
    provider_reference: Mapped[str | None] = mapped_column(String(255))
    subtotal_minor: Mapped[int] = mapped_column(BigInteger)
    tax_total_minor: Mapped[int] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class TaxLine(Base):
    __tablename__ = 'tax_lines'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    tax_calculation_id: Mapped[str] = mapped_column(ForeignKey('tax_calculations.id'), index=True)
    jurisdiction_id: Mapped[str | None] = mapped_column(ForeignKey('tax_jurisdictions.id'))
    tax_class_id: Mapped[str | None] = mapped_column(ForeignKey('tax_classes.id'))
    taxable_amount_minor: Mapped[int] = mapped_column(BigInteger)
    tax_amount_minor: Mapped[int] = mapped_column(BigInteger)
    rate_bps: Mapped[int | None] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3))

class PlanPrice(Base):
    __tablename__ = 'plan_prices'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    plan_version_id: Mapped[str] = mapped_column(ForeignKey('plan_versions.id'), index=True)
    billing_interval: Mapped[str] = mapped_column(String(20))
    amount_minor_units: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    billing_provider: Mapped[str] = mapped_column(String(40), default='paddle')
    provider_price_id: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    __table_args__ = (UniqueConstraint('plan_version_id', 'billing_interval', 'currency'),)

class PlatformBillingDiscount(Base):
    __tablename__ = 'platform_billing_discounts'
    __table_args__ = (UniqueConstraint('code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    code: Mapped[str] = mapped_column(String(100))
    plan_id: Mapped[str | None] = mapped_column(ForeignKey('plans.id'), index=True)
    discount_type: Mapped[str] = mapped_column(String(20))
    value_minor: Mapped[int | None] = mapped_column(BigInteger)
    percentage_bps: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    usage_limit: Mapped[int | None] = mapped_column(BigInteger)
    usage_count: Mapped[int] = mapped_column(BigInteger, default=0)
    starts_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ends_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ProductDiscount(Base):
    __tablename__ = 'product_discounts'
    __table_args__ = (UniqueConstraint('tenant_id', 'variant_id'),
        CheckConstraint('percentage_bps IS NULL OR (percentage_bps >= 0 AND percentage_bps <= 10000)'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    variant_id: Mapped[str] = mapped_column(ForeignKey('product_variants.id'), index=True)
    percentage_bps: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    starts_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ends_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class SubscriptionItem(Base):
    __tablename__ = 'subscription_items'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    subscription_id: Mapped[str] = mapped_column(ForeignKey('subscriptions.id'), index=True)
    plan_price_id: Mapped[str] = mapped_column(ForeignKey('plan_prices.id'))
    quantity: Mapped[int] = mapped_column(Integer, default=1)

class BillingEvent(Base):
    __tablename__ = 'billing_events'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    subscription_id: Mapped[str | None] = mapped_column(ForeignKey('subscriptions.id'))
    event_type: Mapped[str] = mapped_column(String(120))
    provider_event_id: Mapped[str] = mapped_column(String(255), unique=True)
    payload: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(20), default='RECEIVED')
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class TenantEntitlement(Base):
    __tablename__ = 'tenant_entitlements'
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), primary_key=True)
    feature_key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value_type: Mapped[str] = mapped_column(String(20))
    value_boolean: Mapped[bool | None] = mapped_column(Boolean)
    value_integer: Mapped[int | None] = mapped_column(Integer)
    source_subscription_id: Mapped[str | None] = mapped_column(ForeignKey('subscriptions.id'))
    resolved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ReviewQuestion(Base):
    __tablename__ = 'review_questions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'))
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default='unanswered')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ReviewAnswer(Base):
    __tablename__ = 'review_answers'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    question_id: Mapped[str] = mapped_column(ForeignKey('review_questions.id'))
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    answered_by_user_id: Mapped[str] = mapped_column(ForeignKey('users.id'))
    body: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class CarrierAccount(Base):
    __tablename__ = 'carrier_accounts'
    __table_args__ = (UniqueConstraint('tenant_id', 'carrier_code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    carrier_code: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    api_base_url: Mapped[str | None] = mapped_column(Text)
    api_token_encrypted: Mapped[str | None] = mapped_column(Text)
    metadata_json: Mapped[dict | None] = mapped_column(JSON)

class Shipment(Base):
    __tablename__ = 'shipments'
    __table_args__ = (UniqueConstraint('tenant_id', 'provider_shipment_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    carrier_code: Mapped[str] = mapped_column(String(40))
    service_code: Mapped[str | None] = mapped_column(String(80))
    provider_shipment_id: Mapped[str | None] = mapped_column(String(255))
    tracking_number: Mapped[str | None] = mapped_column(String(255))
    label_url: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default='PENDING')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ShipmentEvent(Base):
    __tablename__ = 'shipment_events'
    __table_args__ = (UniqueConstraint('tenant_id', 'provider_event_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    shipment_id: Mapped[str] = mapped_column(ForeignKey('shipments.id'), index=True)
    provider_event_id: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(40))
    payload: Mapped[dict] = mapped_column(JSON)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class TaxInvoice(Base):
    __tablename__ = 'tax_invoices'
    __table_args__ = (UniqueConstraint('tenant_id', 'invoice_number'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), unique=True)
    invoice_number: Mapped[str] = mapped_column(String(80))
    invoice_type: Mapped[str] = mapped_column(String(30), default='STANDARD')
    status: Mapped[str] = mapped_column(String(30), default='DRAFT')
    currency: Mapped[str] = mapped_column(String(3))
    subtotal_minor: Mapped[int] = mapped_column(BigInteger)
    tax_minor: Mapped[int] = mapped_column(BigInteger)
    total_minor: Mapped[int] = mapped_column(BigInteger)
    xml_sha256: Mapped[str | None] = mapped_column(String(64))
    xml_content: Mapped[str | None] = mapped_column(Text)
    zatca_uuid: Mapped[str | None] = mapped_column(String(64))
    reported_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class OrderIssue(Base):
    __tablename__ = 'order_issues'
    __table_args__ = (UniqueConstraint('tenant_id', 'idempotency_key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'), index=True)
    issue_type: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(24), default='OPEN', index=True)
    customer_message: Mapped[str] = mapped_column(Text)
    merchant_message: Mapped[str | None] = mapped_column(Text)
    resolution: Mapped[str | None] = mapped_column(String(40))
    idempotency_key: Mapped[str] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class OrderIssueMessage(Base):
    __tablename__ = 'order_issue_messages'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    issue_id: Mapped[str] = mapped_column(ForeignKey('order_issues.id'), index=True)
    author_type: Mapped[str] = mapped_column(String(20))
    author_id: Mapped[str | None] = mapped_column(String(36), index=True)
    message: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)


class ReturnRequest(Base):
    __tablename__ = 'return_requests'
    __table_args__ = (UniqueConstraint('tenant_id', 'idempotency_key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'))
    type: Mapped[str] = mapped_column(String(20), default='REFUND')
    status: Mapped[str] = mapped_column(String(24), default='REQUESTED', index=True)
    reason_code: Mapped[str] = mapped_column(String(80))
    reason_note: Mapped[str | None] = mapped_column(Text)
    requested_amount_minor: Mapped[int] = mapped_column(BigInteger)
    approved_amount_minor: Mapped[int | None] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    idempotency_key: Mapped[str] = mapped_column(String(200))
    provider_refund_id: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ReturnItem(Base):
    __tablename__ = 'return_items'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    return_request_id: Mapped[str] = mapped_column(ForeignKey('return_requests.id'), index=True)
    order_item_id: Mapped[str] = mapped_column(ForeignKey('order_items.id'))
    quantity: Mapped[int] = mapped_column(BigInteger)
    amount_minor: Mapped[int] = mapped_column(BigInteger)

class Theme(Base):
    __tablename__ = 'themes'
    __table_args__ = (UniqueConstraint('tenant_id', 'slug'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    slug: Mapped[str] = mapped_column(String(100))
    name: Mapped[str] = mapped_column(String(160))
    version: Mapped[str] = mapped_column(String(30), default='1.0.0')
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    template_key: Mapped[str] = mapped_column(String(80), default='catalog')
    settings: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ThemeAssignment(Base):
    __tablename__ = 'theme_assignments'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), unique=True)
    theme_id: Mapped[str] = mapped_column(ForeignKey('themes.id'))
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class LoyaltyAccount(Base):
    __tablename__ = 'loyalty_accounts'
    __table_args__ = (UniqueConstraint('tenant_id', 'customer_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'), index=True)
    points_balance: Mapped[int] = mapped_column(BigInteger, default=0)
    lifetime_earned: Mapped[int] = mapped_column(BigInteger, default=0)
    lifetime_redeemed: Mapped[int] = mapped_column(BigInteger, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class LoyaltyTransaction(Base):
    __tablename__ = 'loyalty_transactions'
    __table_args__ = (UniqueConstraint('tenant_id', 'idempotency_key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    loyalty_account_id: Mapped[str] = mapped_column(ForeignKey('loyalty_accounts.id'), index=True)
    order_id: Mapped[str | None] = mapped_column(ForeignKey('orders.id'))
    points_delta: Mapped[int] = mapped_column(BigInteger)
    reason: Mapped[str] = mapped_column(String(120))
    idempotency_key: Mapped[str] = mapped_column(String(200))
    request_hash: Mapped[str | None] = mapped_column(String(128), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AbandonedCartCampaign(Base):
    __tablename__ = 'abandoned_cart_campaigns'
    __table_args__ = (UniqueConstraint('tenant_id', 'cart_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    cart_id: Mapped[str] = mapped_column(ForeignKey('carts.id'), index=True)
    status: Mapped[str] = mapped_column(String(30), default='PENDING')
    scheduled_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    attempt_count: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str | None] = mapped_column(Text)

class MarketingPreference(Base):
    __tablename__ = 'marketing_preferences'
    __table_args__ = (UniqueConstraint('tenant_id', 'customer_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'), index=True)
    email_marketing: Mapped[bool] = mapped_column(Boolean, default=False)
    sms_marketing: Mapped[bool] = mapped_column(Boolean, default=False)
    whatsapp_marketing: Mapped[bool] = mapped_column(Boolean, default=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AppDefinition(Base):
    __tablename__ = 'app_definitions'
    __table_args__ = (UniqueConstraint('client_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    name: Mapped[str] = mapped_column(String(160))
    slug: Mapped[str] = mapped_column(String(100), unique=True)
    client_id: Mapped[str] = mapped_column(String(160))
    client_secret_hash: Mapped[str] = mapped_column(String(128))
    redirect_uris: Mapped[list] = mapped_column(JSON)
    scopes: Mapped[list] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(20), default='PENDING_REVIEW')
    publisher_name: Mapped[str | None] = mapped_column(String(160))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AppInstallation(Base):
    __tablename__ = 'app_installations'
    __table_args__ = (UniqueConstraint('tenant_id', 'app_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    app_id: Mapped[str] = mapped_column(ForeignKey('app_definitions.id'), index=True)
    granted_scopes: Mapped[list] = mapped_column(JSON)
    access_token_hash: Mapped[str] = mapped_column(String(128), unique=True)
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    installed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class AppOAuthAuthorizationCode(Base):
    __tablename__ = 'app_oauth_authorization_codes'
    __table_args__ = (UniqueConstraint('code_hash'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    app_id: Mapped[str] = mapped_column(ForeignKey('app_definitions.id'), index=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    code_hash: Mapped[str] = mapped_column(String(128), unique=True)
    redirect_uri: Mapped[str] = mapped_column(Text)
    scopes: Mapped[list] = mapped_column(JSON)
    code_challenge: Mapped[str | None] = mapped_column(String(128))
    code_challenge_method: Mapped[str | None] = mapped_column(String(20))
    expires_at: Mapped[datetime]
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AppAccessToken(Base):
    __tablename__ = 'app_access_tokens'
    __table_args__ = (UniqueConstraint('token_hash'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    installation_id: Mapped[str] = mapped_column(ForeignKey('app_installations.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True)
    scopes: Mapped[list] = mapped_column(JSON)
    expires_at: Mapped[datetime]
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AppRefreshToken(Base):
    __tablename__ = 'app_refresh_tokens'
    __table_args__ = (UniqueConstraint('token_hash'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    installation_id: Mapped[str] = mapped_column(ForeignKey('app_installations.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True)
    expires_at: Mapped[datetime]
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AppWebhookSubscription(Base):
    __tablename__ = 'app_webhook_subscriptions'
    __table_args__ = (UniqueConstraint('installation_id', 'event_type', 'endpoint_url'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    installation_id: Mapped[str] = mapped_column(ForeignKey('app_installations.id'), index=True)
    event_type: Mapped[str] = mapped_column(String(120))
    endpoint_url: Mapped[str] = mapped_column(Text)
    secret_hash: Mapped[str] = mapped_column(String(128))
    secret_encrypted: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AppWebhookDelivery(Base):
    __tablename__ = 'app_webhook_deliveries'
    __table_args__ = (UniqueConstraint('subscription_id', 'event_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    subscription_id: Mapped[str] = mapped_column(ForeignKey('app_webhook_subscriptions.id'), index=True)
    event_id: Mapped[str] = mapped_column(ForeignKey('outbox_events.id'), index=True)
    endpoint_url: Mapped[str] = mapped_column(Text)
    event_type: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(20), default='PENDING')
    attempt_count: Mapped[int] = mapped_column(Integer, default=0)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_error: Mapped[str | None] = mapped_column(Text)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    processing_started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)

class MerchantOnboardingStep(Base):
    __tablename__ = 'merchant_onboarding_steps'
    __table_args__ = (UniqueConstraint('tenant_id', 'step_key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    step_key: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(24), default='PENDING')
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    meta: Mapped[dict] = mapped_column('metadata', JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class SupportTicket(Base):
    __tablename__ = 'support_tickets'
    __table_args__ = (UniqueConstraint('tenant_id', 'ticket_number'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    ticket_number: Mapped[str] = mapped_column(String(40))
    subject: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    priority: Mapped[str] = mapped_column(String(20), default='NORMAL')
    status: Mapped[str] = mapped_column(String(20), default='OPEN')
    category: Mapped[str] = mapped_column(String(50), default='GENERAL')
    requester_user_id: Mapped[str] = mapped_column(ForeignKey('users.id'))
    assigned_user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    sla_due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class WorkflowDefinition(Base):
    __tablename__ = 'workflow_definitions'
    __table_args__ = (UniqueConstraint('tenant_id', 'slug'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    slug: Mapped[str] = mapped_column(String(120))
    name: Mapped[str] = mapped_column(String(200))
    trigger_event: Mapped[str] = mapped_column(String(120))
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    steps: Mapped[list] = mapped_column(JSON, default=list)
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class WorkflowRun(Base):
    __tablename__ = 'workflow_runs'
    __table_args__ = (UniqueConstraint('tenant_id', 'workflow_id', 'source_event_id', name='uq_workflow_run_source_event'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    workflow_id: Mapped[str] = mapped_column(ForeignKey('workflow_definitions.id'), index=True)
    source_event_id: Mapped[str | None] = mapped_column(ForeignKey('outbox_events.id'), index=True)
    trigger_event: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(20), default='QUEUED')
    input_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    output_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    error_message: Mapped[str | None] = mapped_column(Text)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class WorkflowWebhookDelivery(Base):
    __tablename__ = 'workflow_webhook_deliveries'
    __table_args__ = (UniqueConstraint('workflow_run_id', 'step_position'), Index('ix_workflow_webhook_tenant_status', 'tenant_id', 'status'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    workflow_run_id: Mapped[str] = mapped_column(ForeignKey('workflow_runs.id'), index=True)
    step_position: Mapped[int] = mapped_column(Integer)
    endpoint_url: Mapped[str] = mapped_column(Text)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default='PENDING')
    attempt_count: Mapped[int] = mapped_column(Integer, default=0)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_error: Mapped[str | None] = mapped_column(Text)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    processing_started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)

class TurkeyTaxProfile(Base):
    __tablename__ = 'turkey_tax_profiles'
    __table_args__ = (UniqueConstraint('tenant_id', 'code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    code: Mapped[str] = mapped_column(String(50))
    name: Mapped[str] = mapped_column(String(120))
    kdv_bps: Mapped[int] = mapped_column(Integer)
    inclusive: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class TurkeyEInvoice(Base):
    __tablename__ = 'turkey_einvoices'
    __table_args__ = (UniqueConstraint('tenant_id', 'invoice_number'), UniqueConstraint('tenant_id',
        'order_id'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'))
    invoice_number: Mapped[str] = mapped_column(String(80))
    invoice_type: Mapped[str] = mapped_column(String(30), default='E_ARCHIVE')
    status: Mapped[str] = mapped_column(String(30), default='DRAFT')
    currency: Mapped[str] = mapped_column(String(3))
    subtotal_minor: Mapped[int] = mapped_column(BigInteger)
    kdv_minor: Mapped[int] = mapped_column(BigInteger)
    total_minor: Mapped[int] = mapped_column(BigInteger)
    xml_sha256: Mapped[str | None] = mapped_column(String(64))
    xml_content: Mapped[str | None] = mapped_column(Text)
    provider_reference: Mapped[str | None] = mapped_column(String(255))
    reported_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class TurkeyEInvoiceSubmission(Base):
    __tablename__ = 'turkey_einvoice_submissions'
    __table_args__ = (UniqueConstraint('tenant_id', 'idempotency_key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    invoice_id: Mapped[str] = mapped_column(ForeignKey('turkey_einvoices.id'), index=True)
    provider: Mapped[str] = mapped_column(String(40))
    idempotency_key: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(30), default='PENDING')
    response: Mapped[dict | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class TurkeyCarrierConfig(Base):
    __tablename__ = 'turkey_carrier_configs'
    __table_args__ = (UniqueConstraint('tenant_id', 'carrier_code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    carrier_code: Mapped[str] = mapped_column(String(40))
    api_base_url: Mapped[str | None] = mapped_column(Text)
    api_token_encrypted: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    metadata_json: Mapped[dict | None] = mapped_column(JSON)

class LiveStorefrontEvent(Base):
    __tablename__ = 'live_storefront_events'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    storefront_id: Mapped[str] = mapped_column(ForeignKey('storefronts.id'), index=True)
    visitor_key_hash: Mapped[str] = mapped_column(String(128), index=True)
    event_type: Mapped[str] = mapped_column(String(60), index=True)
    path: Mapped[str | None] = mapped_column(Text)
    product_id: Mapped[str | None] = mapped_column(ForeignKey('products.id'), index=True)
    meta: Mapped[dict] = mapped_column('metadata', JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)

class TenantAIPolicy(Base):
    __tablename__ = 'tenant_ai_policies'
    __table_args__ = (UniqueConstraint('tenant_id'), Index('ix_tenant_ai_policies_enabled', 'enabled'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True, unique=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    customer_agent_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    merchant_agent_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    daily_request_limit: Mapped[int] = mapped_column(Integer, default=1000)
    allow_external_data: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AIDailyUsage(Base):
    __tablename__ = 'ai_daily_usage'
    __table_args__ = (UniqueConstraint('tenant_id', 'agent_role', 'usage_date'),
                      Index('ix_ai_daily_usage_tenant_date', 'tenant_id', 'usage_date'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    agent_role: Mapped[str] = mapped_column(String(24))
    usage_date: Mapped[str] = mapped_column(String(10))
    requests_count: Mapped[int] = mapped_column(Integer, default=0)
    fallback_count: Mapped[int] = mapped_column(Integer, default=0)
    blocked_count: Mapped[int] = mapped_column(Integer, default=0)
    last_provider: Mapped[str | None] = mapped_column(String(40))
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AIContentGeneration(Base):
    __tablename__ = 'ai_content_generations'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    product_id: Mapped[str | None] = mapped_column(ForeignKey('products.id'), index=True)
    kind: Mapped[str] = mapped_column(String(40), index=True)
    locale: Mapped[str] = mapped_column(String(20), default='ar')
    provider: Mapped[str] = mapped_column(String(40), default='local')
    model: Mapped[str | None] = mapped_column(String(120))
    prompt: Mapped[str] = mapped_column(Text)
    result: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(24), default='COMPLETED')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)

class WhatsAppChannel(Base):
    __tablename__ = 'whatsapp_channels'
    __table_args__ = (UniqueConstraint('tenant_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    phone_number_id: Mapped[str] = mapped_column(String(120))
    business_account_id: Mapped[str | None] = mapped_column(String(120))
    access_token_encrypted: Mapped[str] = mapped_column(Text)
    app_secret_encrypted: Mapped[str | None] = mapped_column(Text)
    verify_token_hash: Mapped[str] = mapped_column(String(128))
    api_version: Mapped[str] = mapped_column(String(30), default='v23.0')
    status: Mapped[str] = mapped_column(String(24), default='ACTIVE')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class WhatsAppMessage(Base):
    __tablename__ = 'whatsapp_messages'
    __table_args__ = (UniqueConstraint('tenant_id', 'provider_message_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    channel_id: Mapped[str] = mapped_column(ForeignKey('whatsapp_channels.id'), index=True)
    direction: Mapped[str] = mapped_column(String(12), default='OUTBOUND')
    recipient: Mapped[str] = mapped_column(String(40), index=True)
    message_type: Mapped[str] = mapped_column(String(30), default='text')
    body: Mapped[str] = mapped_column(Text)
    provider_message_id: Mapped[str | None] = mapped_column(String(255), index=True)
    status: Mapped[str] = mapped_column(String(24), default='QUEUED')
    error_message: Mapped[str | None] = mapped_column(Text)
    meta: Mapped[dict] = mapped_column('metadata', JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class LandingPage(Base):
    __tablename__ = 'landing_pages'
    __table_args__ = (UniqueConstraint('tenant_id', 'slug'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    slug: Mapped[str] = mapped_column(String(120))
    title: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(20), default='DRAFT')
    locale: Mapped[str] = mapped_column(String(20), default='ar')
    seo_title: Mapped[str | None] = mapped_column(String(255))
    seo_description: Mapped[str | None] = mapped_column(Text)
    content: Mapped[dict] = mapped_column(JSON, default=dict)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AffiliateProgram(Base):
    __tablename__ = 'affiliate_programs'
    __table_args__ = (UniqueConstraint('tenant_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    name: Mapped[str] = mapped_column(String(160), default='Affiliate Program')
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    commission_bps: Mapped[int] = mapped_column(Integer, default=1000)
    cookie_days: Mapped[int] = mapped_column(Integer, default=30)
    min_payout_minor: Mapped[int] = mapped_column(BigInteger, default=5000)
    currency: Mapped[str] = mapped_column(String(3), default='USD')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AffiliatePartner(Base):
    __tablename__ = 'affiliate_partners'
    __table_args__ = (UniqueConstraint('tenant_id', 'code'), UniqueConstraint('tenant_id', 'email'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    program_id: Mapped[str] = mapped_column(ForeignKey('affiliate_programs.id'), index=True)
    code: Mapped[str] = mapped_column(String(80))
    name: Mapped[str] = mapped_column(String(160))
    email: Mapped[str] = mapped_column(String(320))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    payout_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AffiliateReferral(Base):
    __tablename__ = 'affiliate_referrals'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    partner_id: Mapped[str] = mapped_column(ForeignKey('affiliate_partners.id'), index=True)
    visitor_key_hash: Mapped[str] = mapped_column(String(128), index=True)
    order_id: Mapped[str | None] = mapped_column(ForeignKey('orders.id'), unique=True)
    status: Mapped[str] = mapped_column(String(20), default='CLICKED')
    landing_path: Mapped[str | None] = mapped_column(Text)
    revenue_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    commission_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    converted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class AffiliateCommission(Base):
    __tablename__ = 'affiliate_commissions'
    __table_args__ = (UniqueConstraint('referral_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    partner_id: Mapped[str] = mapped_column(ForeignKey('affiliate_partners.id'), index=True)
    referral_id: Mapped[str] = mapped_column(ForeignKey('affiliate_referrals.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    amount_minor: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(20), default='PENDING')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class PlatformMonthlyReport(Base):
    __tablename__ = 'platform_monthly_reports'
    __table_args__ = (UniqueConstraint('period_key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    period_key: Mapped[str] = mapped_column(String(7))
    generated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    recipients: Mapped[list] = mapped_column(JSON, default=list)
    metrics: Mapped[dict] = mapped_column(JSON, default=dict)
    delivery_status: Mapped[str] = mapped_column(String(20), default='NOT_SENT')

class ImpersonationSession(Base):
    __tablename__ = 'impersonation_sessions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    admin_user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    target_user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    session_id: Mapped[str | None] = mapped_column(ForeignKey('sessions.id'), index=True)
    reason: Mapped[str] = mapped_column(String(500))
    ticket_id: Mapped[str | None] = mapped_column(String(120), index=True)
    read_only: Mapped[bool] = mapped_column(Boolean, default=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class MerchantProfile(Base):
    __tablename__ = 'merchant_profiles'
    __table_args__ = (UniqueConstraint('tenant_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    legal_name: Mapped[str] = mapped_column(String(255))
    phone: Mapped[str] = mapped_column(String(32))
    country_code: Mapped[str] = mapped_column(String(2))
    city: Mapped[str] = mapped_column(String(120))
    address_line1: Mapped[str] = mapped_column(String(255))
    postal_code: Mapped[str | None] = mapped_column(String(30))
    tax_id: Mapped[str | None] = mapped_column(String(120))
    registration_number: Mapped[str | None] = mapped_column(String(160))
    business_registry_country: Mapped[str | None] = mapped_column(String(2))
    beneficial_owner_name: Mapped[str | None] = mapped_column(String(255))
    beneficial_owner_country: Mapped[str | None] = mapped_column(String(2))
    business_type: Mapped[str] = mapped_column(String(40), default='individual')
    identity_status: Mapped[str] = mapped_column(String(24), default='PENDING')
    phone_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    google_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    kyc_provider: Mapped[str | None] = mapped_column(String(40))
    kyc_status: Mapped[str] = mapped_column(String(32), default='NOT_STARTED')
    kyc_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    kyc_external_id: Mapped[str | None] = mapped_column(String(255))
    kyb_status: Mapped[str] = mapped_column(String(32), default='NOT_STARTED')
    kyb_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    kyb_verification_method: Mapped[str | None] = mapped_column(String(40))
    kyb_evidence_hash: Mapped[str | None] = mapped_column(String(128))
    risk_level: Mapped[str] = mapped_column(String(24), default='UNKNOWN')
    risk_score: Mapped[int] = mapped_column(Integer, default=0)
    review_required: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    payout_hold: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    trust_lock_reason: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class MerchantPhoneVerification(Base):
    __tablename__ = 'merchant_phone_verifications'
    __table_args__ = (UniqueConstraint('tenant_id', 'phone'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    phone: Mapped[str] = mapped_column(String(32))
    code_hash: Mapped[str] = mapped_column(String(128), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class MerchantIdentityVerification(Base):
    __tablename__ = 'merchant_identity_verifications'
    __table_args__ = (
        UniqueConstraint('tenant_id', 'provider', 'external_id', name='uq_merchant_identity_provider_external'),
        Index('ix_merchant_identity_tenant_status', 'tenant_id', 'status'),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    provider: Mapped[str] = mapped_column(String(40))
    external_id: Mapped[str] = mapped_column(String(255), index=True)
    status: Mapped[str] = mapped_column(String(32), default='CREATED', index=True)
    decision: Mapped[str | None] = mapped_column(String(32))
    risk_level: Mapped[str | None] = mapped_column(String(24))
    country_code: Mapped[str | None] = mapped_column(String(2))
    verification_url: Mapped[str | None] = mapped_column(String(2000))
    vendor_data_hash: Mapped[str | None] = mapped_column(String(128))
    provider_event_id: Mapped[str | None] = mapped_column(String(255), index=True)
    provider_metadata: Mapped[dict | None] = mapped_column(JSON)
    failure_code: Mapped[str | None] = mapped_column(String(120))
    failure_reason: Mapped[str | None] = mapped_column(Text)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class MerchantRiskEvent(Base):
    __tablename__ = 'merchant_risk_events'
    __table_args__ = (Index('ix_merchant_risk_events_tenant_created', 'tenant_id', 'created_at'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    event_type: Mapped[str] = mapped_column(String(80), index=True)
    severity: Mapped[str] = mapped_column(String(16), default='INFO')
    score_delta: Mapped[int] = mapped_column(Integer, default=0)
    source: Mapped[str] = mapped_column(String(40), default='system')
    dedupe_key: Mapped[str | None] = mapped_column(String(255), unique=True)
    metadata_json: Mapped[dict | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class MerchantReviewCase(Base):
    __tablename__ = 'merchant_review_cases'
    __table_args__ = (UniqueConstraint('tenant_id', 'open_reason', name='uq_merchant_review_open_reason'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    verification_id: Mapped[str | None] = mapped_column(ForeignKey('merchant_identity_verifications.id'), index=True)
    open_reason: Mapped[str] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(24), default='OPEN', index=True)
    priority: Mapped[str] = mapped_column(String(16), default='NORMAL')
    assigned_user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    reviewer_note: Mapped[str | None] = mapped_column(Text)
    resolution: Mapped[str | None] = mapped_column(String(40))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class TenantReview(Base):
    __tablename__ = 'tenant_reviews'
    __table_args__ = (UniqueConstraint('tenant_id', 'customer_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    customer_id: Mapped[str] = mapped_column(ForeignKey('customers.id'), index=True)
    order_id: Mapped[str | None] = mapped_column(ForeignKey('orders.id'), index=True)
    rating: Mapped[int] = mapped_column(Integer)
    body: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default='PENDING')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class TrustReport(Base):
    __tablename__ = 'trust_reports'
    __table_args__ = (Index('ix_trust_reports_tenant_status', 'tenant_id', 'status'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    reporter_customer_id: Mapped[str | None] = mapped_column(ForeignKey('customers.id'), index=True)
    reporter_user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'), index=True)
    reason: Mapped[str] = mapped_column(String(80))
    details: Mapped[str] = mapped_column(Text)
    evidence_url: Mapped[str | None] = mapped_column(String(1000))
    status: Mapped[str] = mapped_column(String(24), default='OPEN')
    risk_score: Mapped[int] = mapped_column(Integer, default=0)
    reviewer_note: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class MerchantTrustScore(Base):
    __tablename__ = 'merchant_trust_scores'
    __table_args__ = (UniqueConstraint('tenant_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    rating_average: Mapped[float] = mapped_column(Numeric(4,2), default=0)
    rating_count: Mapped[int] = mapped_column(Integer, default=0)
    report_count: Mapped[int] = mapped_column(Integer, default=0)
    resolved_report_count: Mapped[int] = mapped_column(Integer, default=0)
    trust_score: Mapped[int] = mapped_column(Integer, default=50)
    trust_level: Mapped[str] = mapped_column(String(20), default='NEW')
    badge: Mapped[str] = mapped_column(String(40), default='NEW_STORE')
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class DomainPurchase(Base):
    __tablename__ = 'domain_purchases'
    __table_args__ = (UniqueConstraint('tenant_id', 'idempotency_key'), Index('ix_domain_purchases_tenant_status', 'tenant_id', 'status'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    domain_id: Mapped[str | None] = mapped_column(ForeignKey('domains.id'), index=True)
    hostname: Mapped[str] = mapped_column(String(255), index=True)
    years: Mapped[int] = mapped_column(Integer, default=1)
    provider: Mapped[str] = mapped_column(String(40), default='cloudflare')
    provider_reference: Mapped[str | None] = mapped_column(String(255))
    provider_cost_minor: Mapped[int | None] = mapped_column(BigInteger)
    customer_price_minor: Mapped[int] = mapped_column(BigInteger, default=1000)
    currency: Mapped[str] = mapped_column(String(3), default='USD')
    status: Mapped[str] = mapped_column(String(30), default='PENDING_PAYMENT')
    idempotency_key: Mapped[str] = mapped_column(String(200))
    registrant_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    failure_reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


# v1.49 World-class commerce layer
class B2BCompany(Base):
    __tablename__ = 'b2b_companies'
    __table_args__ = (UniqueConstraint('tenant_id', 'external_code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    name: Mapped[str] = mapped_column(String(255))
    external_code: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(24), default='ACTIVE')
    currency: Mapped[str] = mapped_column(String(3), default='USD')
    payment_terms_days: Mapped[int] = mapped_column(Integer, default=0)
    credit_limit_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class B2BCompanyContact(Base):
    __tablename__ = 'b2b_company_contacts'
    __table_args__ = (UniqueConstraint('tenant_id', 'company_id', 'email'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    company_id: Mapped[str] = mapped_column(ForeignKey('b2b_companies.id'), index=True)
    email: Mapped[str] = mapped_column(String(320))
    name: Mapped[str | None] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(40), default='BUYER')
    status: Mapped[str] = mapped_column(String(24), default='ACTIVE')

class B2BCatalog(Base):
    __tablename__ = 'b2b_catalogs'
    __table_args__ = (UniqueConstraint('tenant_id', 'code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    code: Mapped[str] = mapped_column(String(80))
    name: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(24), default='ACTIVE')
    currency: Mapped[str] = mapped_column(String(3), default='USD')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class B2BCatalogAssignment(Base):
    __tablename__ = 'b2b_catalog_assignments'
    __table_args__ = (UniqueConstraint('tenant_id', 'company_id', 'catalog_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    company_id: Mapped[str] = mapped_column(ForeignKey('b2b_companies.id'), index=True)
    catalog_id: Mapped[str] = mapped_column(ForeignKey('b2b_catalogs.id'), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class B2BCatalogItem(Base):
    __tablename__ = 'b2b_catalog_items'
    __table_args__ = (UniqueConstraint('tenant_id', 'catalog_id', 'variant_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    catalog_id: Mapped[str] = mapped_column(ForeignKey('b2b_catalogs.id'), index=True)
    variant_id: Mapped[str] = mapped_column(ForeignKey('product_variants.id'), index=True)
    price_minor: Mapped[int | None] = mapped_column(BigInteger)
    min_quantity: Mapped[int] = mapped_column(BigInteger, default=1)
    max_quantity: Mapped[int | None] = mapped_column(BigInteger)
    discount_bps: Mapped[int] = mapped_column(Integer, default=0)

class POSLocation(Base):
    __tablename__ = 'pos_locations'
    __table_args__ = (UniqueConstraint('tenant_id', 'code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    code: Mapped[str] = mapped_column(String(80))
    name: Mapped[str] = mapped_column(String(160))
    address: Mapped[dict | None] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    inventory_location_id: Mapped[str | None] = mapped_column(ForeignKey('inventory_locations.id'))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class POSRegister(Base):
    __tablename__ = 'pos_registers'
    __table_args__ = (UniqueConstraint('tenant_id', 'register_code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    location_id: Mapped[str] = mapped_column(ForeignKey('pos_locations.id'), index=True)
    register_code: Mapped[str] = mapped_column(String(80))
    name: Mapped[str] = mapped_column(String(160))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    device_public_key: Mapped[str | None] = mapped_column(Text)

class POSSession(Base):
    __tablename__ = 'pos_sessions'
    __table_args__ = (
        Index('ix_pos_sessions_tenant_status', 'tenant_id', 'status'),
        Index(
            'uq_pos_session_open_register',
            'tenant_id', 'register_id',
            unique=True,
            postgresql_where=(__import__('sqlalchemy').text("status = 'OPEN'")),
            sqlite_where=(__import__('sqlalchemy').text("status = 'OPEN'")),
        ),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    register_id: Mapped[str] = mapped_column(ForeignKey('pos_registers.id'), index=True)
    opened_by_user_id: Mapped[str] = mapped_column(ForeignKey('users.id'))
    status: Mapped[str] = mapped_column(String(20), default='OPEN')
    opening_cash_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    closing_cash_minor: Mapped[int | None] = mapped_column(BigInteger)
    expected_cash_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class POSOrderLink(Base):
    __tablename__ = 'pos_order_links'
    __table_args__ = (UniqueConstraint('tenant_id', 'order_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey('orders.id'), index=True)
    pos_session_id: Mapped[str] = mapped_column(ForeignKey('pos_sessions.id'), index=True)
    channel: Mapped[str] = mapped_column(String(20), default='POS')

class CommerceExperiment(Base):
    __tablename__ = 'commerce_experiments'
    __table_args__ = (UniqueConstraint('tenant_id', 'key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    key: Mapped[str] = mapped_column(String(100))
    name: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(20), default='DRAFT')
    traffic_bps: Mapped[int] = mapped_column(Integer, default=10000)
    variants: Mapped[list] = mapped_column(JSON, default=list)
    target_metric: Mapped[str] = mapped_column(String(80), default='conversion_rate')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class CommerceExperimentAssignment(Base):
    __tablename__ = 'commerce_experiment_assignments'
    __table_args__ = (UniqueConstraint('tenant_id', 'experiment_id', 'subject_key'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    experiment_id: Mapped[str] = mapped_column(ForeignKey('commerce_experiments.id'), index=True)
    subject_key: Mapped[str] = mapped_column(String(160))
    variant_key: Mapped[str] = mapped_column(String(100))
    assigned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class CommerceExperimentObservation(Base):
    __tablename__ = 'commerce_experiment_observations'
    __table_args__ = (
        UniqueConstraint('tenant_id', 'experiment_id', 'subject_key', 'metric_key', name='uq_commerce_experiment_observation_once'),
        Index('ix_commerce_experiment_observations_tenant_experiment', 'tenant_id', 'experiment_id'),
        Index('ix_commerce_experiment_observations_metric', 'tenant_id', 'experiment_id', 'metric_key'),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    experiment_id: Mapped[str] = mapped_column(ForeignKey('commerce_experiments.id'), index=True)
    assignment_id: Mapped[str] = mapped_column(ForeignKey('commerce_experiment_assignments.id'), index=True)
    subject_key: Mapped[str] = mapped_column(String(160))
    variant_key: Mapped[str] = mapped_column(String(100))
    metric_key: Mapped[str] = mapped_column(String(80))
    value_numeric: Mapped[float] = mapped_column(Numeric(20, 6), default=1)
    value_minor: Mapped[int | None] = mapped_column(BigInteger)
    currency: Mapped[str | None] = mapped_column(String(3))
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)

class ProductFeed(Base):
    __tablename__ = 'product_feeds'
    __table_args__ = (UniqueConstraint('tenant_id', 'channel', 'locale', 'country_code'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    channel: Mapped[str] = mapped_column(String(40))
    locale: Mapped[str] = mapped_column(String(20), default='en')
    country_code: Mapped[str] = mapped_column(String(2), default='US')
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    last_generated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_item_count: Mapped[int] = mapped_column(Integer, default=0)
    config: Mapped[dict] = mapped_column(JSON, default=dict)

class UCPCheckoutSession(Base):
    __tablename__ = 'ucp_checkout_sessions'
    __table_args__ = (UniqueConstraint('tenant_id', 'external_session_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    external_session_id: Mapped[str] = mapped_column(String(160))
    status: Mapped[str] = mapped_column(String(24), default='OPEN')
    currency: Mapped[str] = mapped_column(String(3))
    line_items: Mapped[list] = mapped_column(JSON, default=list)
    subtotal_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    total_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    buyer: Mapped[dict | None] = mapped_column(JSON)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class UCPEvent(Base):
    __tablename__ = 'ucp_events'
    __table_args__ = (UniqueConstraint('tenant_id', 'event_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    event_id: Mapped[str] = mapped_column(String(160))
    event_type: Mapped[str] = mapped_column(String(120))
    payload_hash: Mapped[str] = mapped_column(String(128))
    payload: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

# v1.50 Platform ecosystem
class AppListing(Base):
    __tablename__ = 'app_listings'
    __table_args__ = (UniqueConstraint('app_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    app_id: Mapped[str] = mapped_column(ForeignKey('app_definitions.id'), unique=True, index=True)
    category: Mapped[str] = mapped_column(String(80), default='GENERAL')
    description: Mapped[str] = mapped_column(Text, default='')
    icon_url: Mapped[str | None] = mapped_column(String(1000))
    pricing_model: Mapped[str] = mapped_column(String(32), default='FREE')
    monthly_price_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    currency: Mapped[str] = mapped_column(String(3), default='USD')
    supported_locales: Mapped[list] = mapped_column(JSON, default=list)
    supported_countries: Mapped[list] = mapped_column(JSON, default=list)
    featured: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(24), default='DRAFT')
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AppReview(Base):
    __tablename__ = 'app_reviews'
    __table_args__ = (UniqueConstraint('app_id', 'tenant_id'), Index('ix_app_reviews_app_status', 'app_id', 'status'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    app_id: Mapped[str] = mapped_column(ForeignKey('app_definitions.id'), index=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    rating: Mapped[int] = mapped_column(Integer)
    title: Mapped[str | None] = mapped_column(String(160))
    body: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default='PUBLISHED')
    verified_installation: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class WorkflowStepRun(Base):
    __tablename__ = 'workflow_step_runs'
    __table_args__ = (UniqueConstraint('workflow_run_id', 'position'), Index('ix_workflow_step_runs_tenant_status', 'tenant_id', 'status'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    workflow_run_id: Mapped[str] = mapped_column(ForeignKey('workflow_runs.id'), index=True)
    position: Mapped[int] = mapped_column(Integer)
    step_type: Mapped[str] = mapped_column(String(60))
    status: Mapped[str] = mapped_column(String(20), default='QUEUED')
    input_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    output_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    error_message: Mapped[str | None] = mapped_column(Text)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class CommerceEventSchema(Base):
    __tablename__ = 'commerce_event_schemas'
    __table_args__ = (UniqueConstraint('event_type', 'schema_version'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    event_type: Mapped[str] = mapped_column(String(120))
    schema_version: Mapped[int] = mapped_column(Integer, default=1)
    schema_json: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class CommerceEventSubscription(Base):
    __tablename__ = 'commerce_event_subscriptions'
    __table_args__ = (UniqueConstraint('tenant_id', 'event_type', 'endpoint_url'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    event_type: Mapped[str] = mapped_column(String(120))
    endpoint_url: Mapped[str] = mapped_column(Text)
    secret_hash: Mapped[str] = mapped_column(String(128))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

# v1.51 Global Control Plane
class AgentProfile(Base):
    __tablename__ = 'agent_profiles'
    __table_args__ = (UniqueConstraint('tenant_id', 'client_id'), UniqueConstraint('tenant_id', 'slug'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    client_id: Mapped[str] = mapped_column(String(160))
    client_secret_hash: Mapped[str] = mapped_column(String(128), default='')
    slug: Mapped[str] = mapped_column(String(100))
    name: Mapped[str] = mapped_column(String(160))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    scopes: Mapped[list] = mapped_column(JSON, default=list)
    allowed_countries: Mapped[list] = mapped_column(JSON, default=list)
    require_confirmation: Mapped[bool] = mapped_column(Boolean, default=False)
    max_checkout_total_minor: Mapped[int | None] = mapped_column(BigInteger)
    allowed_currencies: Mapped[list] = mapped_column(JSON, default=list)
    rate_limit_per_minute: Mapped[int] = mapped_column(Integer, default=120)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AgentActionAudit(Base):
    __tablename__ = 'agent_action_audits'
    __table_args__ = (UniqueConstraint('tenant_id', 'agent_profile_id', 'idempotency_key'),
                      Index('ix_agent_action_audits_tenant_created', 'tenant_id', 'created_at'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    agent_profile_id: Mapped[str] = mapped_column(ForeignKey('agent_profiles.id'), index=True)
    action: Mapped[str] = mapped_column(String(120))
    resource_type: Mapped[str] = mapped_column(String(80))
    resource_id: Mapped[str | None] = mapped_column(String(36))
    decision: Mapped[str] = mapped_column(String(20))
    reason: Mapped[str] = mapped_column(String(255))
    idempotency_key: Mapped[str] = mapped_column(String(200))
    request_hash: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class MerchantDecisionAction(Base):
    __tablename__ = 'merchant_decision_actions'
    __table_args__ = (
        UniqueConstraint('tenant_id', 'decision_key', name='uq_merchant_decision_action_key'),
        Index('ix_merchant_decision_actions_tenant_status', 'tenant_id', 'status'),
        Index('ix_merchant_decision_actions_tenant_created', 'tenant_id', 'created_at'),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    decision_key: Mapped[str] = mapped_column(String(240))
    decision_code: Mapped[str] = mapped_column(String(100), index=True)
    priority: Mapped[str] = mapped_column(String(20), default='MEDIUM')
    status: Mapped[str] = mapped_column(String(20), default='OPEN', index=True)
    currency: Mapped[str | None] = mapped_column(String(3))
    expected_impact_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    actual_impact_minor: Mapped[int | None] = mapped_column(BigInteger)
    confidence: Mapped[str] = mapped_column(String(20), default='HIGH')
    evidence: Mapped[list] = mapped_column(JSON, default=list)
    recommended_action: Mapped[str | None] = mapped_column(Text)
    outcome_note: Mapped[str | None] = mapped_column(Text)
    created_by_user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    completed_by_user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    accepted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class TenantRegionPolicy(Base):
    __tablename__ = 'tenant_region_policies'
    __table_args__ = (UniqueConstraint('tenant_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True, unique=True)
    home_region: Mapped[str] = mapped_column(String(40), default='eu-west-1')
    allowed_regions: Mapped[list] = mapped_column(JSON, default=list)
    residency_mode: Mapped[str] = mapped_column(String(32), default='HOME_REGION_ONLY')
    cross_border_transfer_allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    transfer_basis: Mapped[str | None] = mapped_column(String(80))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    approved_by: Mapped[str | None] = mapped_column(String(36))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class FinancialReconciliationRun(Base):
    __tablename__ = 'financial_reconciliation_runs'
    __table_args__ = (UniqueConstraint('tenant_id', 'period_start', 'period_end', 'currency'),
                      Index('ix_fin_recon_tenant_status', 'tenant_id', 'status'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    period_start: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    period_end: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(20), default='RUNNING')
    payment_captured_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    ledger_debit_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    ledger_credit_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    delta_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    mismatch_count: Mapped[int] = mapped_column(Integer, default=0)
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

# v1.53 Digital Product Passport / Product Compliance Graph
class ProductPassport(Base):
    __tablename__ = 'product_passports'
    __table_args__ = (UniqueConstraint('tenant_id', 'product_id'),
                      Index('ix_product_passports_tenant_status', 'tenant_id', 'status'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    product_id: Mapped[str] = mapped_column(ForeignKey('products.id'), index=True)
    public_token: Mapped[str] = mapped_column(String(96), unique=True)
    scheme: Mapped[str] = mapped_column(String(80), default='Rilmo-DPP-1')
    conformance_profile: Mapped[str] = mapped_column(String(120), default='ESPR-DPP-2026')
    identifier_scheme: Mapped[str | None] = mapped_column(String(80))
    unique_product_identifier: Mapped[str | None] = mapped_column(String(255), index=True)
    data_carrier: Mapped[str | None] = mapped_column(String(80))
    registry_status: Mapped[str] = mapped_column(String(30), default='NOT_REGISTERED')
    registry_reference: Mapped[str | None] = mapped_column(String(255))
    version: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(20), default='DRAFT')
    origin_country: Mapped[str | None] = mapped_column(String(2))
    manufacturer_name: Mapped[str | None] = mapped_column(String(255))
    manufacturer_address: Mapped[str | None] = mapped_column(Text)
    manufacturer_contact: Mapped[str | None] = mapped_column(String(320))
    responsible_person_name: Mapped[str | None] = mapped_column(String(255))
    responsible_person_address: Mapped[str | None] = mapped_column(Text)
    responsible_person_contact: Mapped[str | None] = mapped_column(String(320))
    economic_operator_role: Mapped[str | None] = mapped_column(String(80))
    product_identifier: Mapped[str | None] = mapped_column(String(255))
    safety_warnings: Mapped[list] = mapped_column(JSON, default=list)
    recall_information: Mapped[dict] = mapped_column(JSON, default=dict)
    materials: Mapped[list] = mapped_column(JSON, default=list)
    certifications: Mapped[list] = mapped_column(JSON, default=list)
    compliance_claims: Mapped[list] = mapped_column(JSON, default=list)
    circularity: Mapped[dict] = mapped_column(JSON, default=dict)
    sustainability: Mapped[dict] = mapped_column(JSON, default=dict)
    public_data: Mapped[dict] = mapped_column(JSON, default=dict)
    effective_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ProductPassportRevision(Base):
    __tablename__ = 'product_passport_revisions'
    __table_args__ = (UniqueConstraint('product_passport_id', 'version'),
                      Index('ix_product_passport_revisions_tenant_passport', 'tenant_id', 'product_passport_id'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    product_passport_id: Mapped[str] = mapped_column(ForeignKey('product_passports.id'), index=True)
    version: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    change_reason: Mapped[str] = mapped_column(String(255), default='update')
    actor_id: Mapped[str | None] = mapped_column(String(36))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
class FinancialReconciliationMismatch(Base):
    __tablename__ = 'financial_reconciliation_mismatches'
    __table_args__ = (Index('ix_fin_recon_mismatch_run', 'reconciliation_run_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    reconciliation_run_id: Mapped[str] = mapped_column(ForeignKey('financial_reconciliation_runs.id'), index=True)
    category: Mapped[str] = mapped_column(String(80))
    reference_type: Mapped[str] = mapped_column(String(80))
    reference_id: Mapped[str] = mapped_column(String(36))
    expected_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    observed_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    delta_minor: Mapped[int] = mapped_column(BigInteger, default=0)
    currency: Mapped[str] = mapped_column(String(3))
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class GlobalMarketProfile(Base):
    __tablename__ = 'global_market_profiles'
    __table_args__ = (UniqueConstraint('market_key'), Index('ix_global_market_profiles_country', 'country_code'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    market_key: Mapped[str] = mapped_column(String(80), index=True)
    country_code: Mapped[str] = mapped_column(String(2))
    region_code: Mapped[str | None] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(24), default='PLANNED')
    legal_review_status: Mapped[str] = mapped_column(String(24), default='REQUIRED')
    tax_invoicing_status: Mapped[str] = mapped_column(String(24), default='REQUIRED')
    payments_status: Mapped[str] = mapped_column(String(24), default='REQUIRED')
    data_transfer_status: Mapped[str] = mapped_column(String(24), default='REQUIRED')
    app_store_status: Mapped[str] = mapped_column(String(24), default='REQUIRED')
    requirements: Mapped[dict] = mapped_column(JSON, default=dict)
    last_reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class GlobalLaunchEvidence(Base):
    __tablename__ = 'global_launch_evidence'
    __table_args__ = (UniqueConstraint('market_key', 'requirement_code'), Index('ix_global_launch_evidence_market_status', 'market_key', 'status'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    market_key: Mapped[str] = mapped_column(String(80), index=True)
    requirement_code: Mapped[str] = mapped_column(String(100), index=True)
    status: Mapped[str] = mapped_column(String(24), default='MISSING')
    evidence_ref: Mapped[str | None] = mapped_column(String(500))
    source_url: Mapped[str | None] = mapped_column(String(2000))
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reviewer_user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    notes: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class JurisdictionCompliancePolicy(Base):
    __tablename__ = 'jurisdiction_compliance_policies'
    __table_args__ = (UniqueConstraint('jurisdiction', 'policy_version'), Index('ix_jurisdiction_compliance_policies_country', 'country_code'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    jurisdiction: Mapped[str] = mapped_column(String(80), index=True)
    country_code: Mapped[str | None] = mapped_column(String(2), index=True)
    policy_version: Mapped[str] = mapped_column(String(50))
    effective_date: Mapped[str] = mapped_column(String(10))
    rights: Mapped[list] = mapped_column(JSON, default=list)
    consent_categories: Mapped[list] = mapped_column(JSON, default=list)
    transfer_mechanisms: Mapped[list] = mapped_column(JSON, default=list)
    breach_authority_hours: Mapped[int | None] = mapped_column(Integer)
    dsr_due_days: Mapped[int] = mapped_column(Integer, default=45)
    cookie_opt_in_required: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    gpc_signal_respected: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    ai_interaction_disclosure_required: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    ai_generated_marking_required: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    admt_risk_assessment_required: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    dsa_marketplace_controls: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    requirements: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(24), default='ENGINEERING_BASELINE')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PrivacyProcessingActivity(Base):
    __tablename__ = 'privacy_processing_activities'
    __table_args__ = (UniqueConstraint('activity_key'), Index('ix_privacy_processing_activities_status', 'status'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    activity_key: Mapped[str] = mapped_column(String(120), unique=True)
    purpose: Mapped[str] = mapped_column(Text)
    legal_bases: Mapped[dict] = mapped_column(JSON, default=dict)
    data_categories: Mapped[list] = mapped_column(JSON, default=list)
    data_subject_categories: Mapped[list] = mapped_column(JSON, default=list)
    recipients: Mapped[list] = mapped_column(JSON, default=list)
    transfer_mechanisms: Mapped[list] = mapped_column(JSON, default=list)
    retention_rule: Mapped[str] = mapped_column(String(255))
    dpia_required: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    automated_decisioning: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    ai_system: Mapped[str | None] = mapped_column(String(120))
    owner_role: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(24), default='ACTIVE')
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class DSAComplianceCase(Base):
    __tablename__ = 'dsa_compliance_cases'
    __table_args__ = (Index('ix_dsa_cases_status_created', 'status', 'created_at'), Index('ix_dsa_cases_tenant_status', 'tenant_id', 'status'))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey('tenants.id'), index=True)
    reporter_user_id: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    reporter_email: Mapped[str | None] = mapped_column(String(320))
    content_type: Mapped[str] = mapped_column(String(40))
    content_id: Mapped[str] = mapped_column(String(120))
    jurisdiction: Mapped[str] = mapped_column(String(80), default='GLOBAL')
    reason_code: Mapped[str] = mapped_column(String(80))
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(32), default='SUBMITTED')
    decision: Mapped[str | None] = mapped_column(String(32))
    decision_reason: Mapped[str | None] = mapped_column(Text)
    appeal_status: Mapped[str] = mapped_column(String(32), default='NOT_REQUESTED')
    appeal_decision: Mapped[str | None] = mapped_column(String(32))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class AppStoreDistributionPolicy(Base):
    __tablename__ = 'app_store_distribution_policies'
    __table_args__ = (UniqueConstraint('platform', 'market_key', 'sku_category'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    platform: Mapped[str] = mapped_column(String(30))
    market_key: Mapped[str] = mapped_column(String(80), index=True)
    sku_category: Mapped[str] = mapped_column(String(40))
    payment_method: Mapped[str] = mapped_column(String(80))
    allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    policy_reference: Mapped[str] = mapped_column(String(255))
    notes: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class MerchantMarketplaceTraceability(Base):
    __tablename__ = 'merchant_marketplace_traceability'
    __table_args__ = (UniqueConstraint('tenant_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'), index=True)
    trade_register_name: Mapped[str | None] = mapped_column(String(255))
    trade_register_number: Mapped[str | None] = mapped_column(String(120))
    payout_account_reference: Mapped[str | None] = mapped_column(String(255))
    seller_self_certification: Mapped[bool] = mapped_column(Boolean, default=False)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
