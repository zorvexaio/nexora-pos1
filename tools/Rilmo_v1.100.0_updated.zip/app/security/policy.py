import ipaddress, socket, urllib.parse, re
from typing import Iterable

def is_private_ip(host: str) -> bool:
    try:
        ip = ipaddress.ip_address(host)
        return (not ip.is_global) or ip.is_multicast
    except ValueError:
        return False

def validate_outbound_url(url: str, *, allowed_hosts: set[str] | None=None) -> str:
    p = urllib.parse.urlparse(url)
    if p.scheme not in {'https', 'http'}:
        raise ValueError('URL scheme is not allowed')
    if not p.hostname:
        raise ValueError('URL hostname is required')
    host = p.hostname.lower().rstrip('.')
    if allowed_hosts and host not in {h.lower().rstrip('.') for h in allowed_hosts}:
        raise ValueError('Host is not allowlisted')
    if host in {'localhost', 'metadata.google.internal'} or is_private_ip(host):
        raise ValueError('Private or metadata target is forbidden')
    try:
        for family, _, _, _, sockaddr in socket.getaddrinfo(host,
            p.port or (443 if p.scheme == 'https' else 80), type=socket.SOCK_STREAM):
            ip = sockaddr[0]
            if is_private_ip(ip):
                raise ValueError('Resolved private target is forbidden')
    except socket.gaierror:
        raise ValueError('DNS resolution failed')
    return urllib.parse.urlunparse((p.scheme, host + (':' + str(p.port) if p.port else ''), p.path,
        p.params, p.query, ''))

def validate_upload(*, filename: str, content_type: str, size_bytes: int, magic: bytes):
    if size_bytes <= 0 or size_bytes > 10 * 1024 * 1024:
        raise ValueError('File size exceeds P0 limit')
    ext = filename.lower().rsplit('.', 1)[-1] if '.' in filename else ''
    if ext in {'svg', 'html', 'htm', 'js', 'mjs', 'php', 'exe', 'dll'}:
        raise ValueError('Executable content type is forbidden')
    if content_type in {'text/html', 'image/svg+xml', 'application/javascript', 'text/javascript'}:
        raise ValueError('Active content type is forbidden')
    forbidden_magic = (b'PK\x03\x04', b'MZ', b'\x7fELF')
    if any((magic.startswith(sig) for sig in forbidden_magic)):
        raise ValueError('Archive or executable content is forbidden')
    if magic.startswith(b'<?xml') and ext == 'svg':
        raise ValueError('SVG is not accepted')
    return True

def normalize_hostname(hostname: str) -> str:
    host = hostname.strip().lower().rstrip('.')
    if len(host) > 253 or not re.fullmatch('[a-z0-9.-]+', host):
        raise ValueError('Invalid hostname')
    if host.startswith('.') or host.endswith('.') or '..' in host:
        raise ValueError('Invalid hostname')
    return host

def verification_txt_name(hostname: str, prefix: str='_unified-commerce-verify') -> str:
    return f"{prefix.strip().strip('.')}.{normalize_hostname(hostname)}"

def verify_dns_txt(hostname: str, expected_token: str, *, prefix: str='_unified-commerce-verify',
    timeout: float=5.0) -> bool:
    import dns.resolver
    name = verification_txt_name(hostname, prefix)
    try:
        answers = dns.resolver.resolve(name, 'TXT', lifetime=timeout)
        for rr in answers:
            value = ''.join((part.decode() if isinstance(part, (bytes,
                bytearray)) else str(part) for part in rr.strings))
            if hmac_compare(value, expected_token):
                return True
    except Exception:
        return False
    return False

def hmac_compare(a: str, b: str) -> bool:
    import hmac
    return hmac.compare_digest(a.strip(), b.strip())
