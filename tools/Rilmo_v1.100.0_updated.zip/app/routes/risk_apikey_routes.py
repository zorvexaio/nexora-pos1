"""Order risk-assessment routes, API key CRUD, and the public API-key-scoped
tenant lookup endpoint.

Extracted out of app/routes/v1.py (Phase 3, step 11).
"""
import secrets
from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission, api_key_context
from app.core.errors import AppError, not_found, forbidden
from app.core.security import token_hash
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import audit, require_entitlement
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.get('/risk/orders/{order_id}')
def get_order_risk(order_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.read'))):
    tenant_scope(tenant_id, user, db)
    row = db.query(RiskAssessment).filter_by(tenant_id=tenant_id, order_id=order_id).first()
    if not row:
        raise not_found('Risk assessment not found')
    return json_model(row)

@router.post('/risk/orders/{order_id}/assess')
def assess_order_risk(order_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.manage'))):
    tenant_scope(tenant_id, user, db)
    order = db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).first()
    if not order:
        raise not_found('Order not found')
    score = 0
    reasons = []
    if order.total_minor >= 100000:
        score += 35
        reasons.append('high_order_value')
    if order.guest_session_id:
        score += 10
        reasons.append('guest_checkout')
    if order.payment_status in {'PENDING', 'FAILED'}:
        score += 15
        reasons.append('payment_not_confirmed')
    if order.discount_minor > order.subtotal_minor // 2 if order.subtotal_minor else False:
        score += 20
        reasons.append('high_discount_ratio')
    decision = 'BLOCK' if score >= 70 else 'REVIEW' if score >= 40 else 'ALLOW'
    row = db.query(RiskAssessment).filter_by(tenant_id=tenant_id, order_id=order.id).first()
    if not row:
        row = RiskAssessment(tenant_id=tenant_id, order_id=order.id, score=score, decision=decision,
            reasons=reasons)
        db.add(row)
    else:
        row.score = score
        row.decision = decision
        row.reasons = reasons
    order.risk_status = decision
    audit(db, tenant_id, user.id, 'risk.assess', 'order', order.id, after={'score': score,
        'decision': decision})
    db.commit()
    return json_model(row)

@router.post('/api-keys')
def create_api_key(tenant_id: str, data: APIKeyIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('apps.manage'))):
    tenant_scope(tenant_id, user, db)
    require_entitlement(db, tenant_id, 'api_access')
    name = data.name.strip()
    if not name:
        raise AppError(400, 'API_KEY_NAME_INVALID', 'API key name is required')
    allowed_scopes = {'tenant.read'}
    scopes = list(dict.fromkeys(str(scope).strip() for scope in data.scopes if str(scope).strip()))
    invalid_scopes = sorted(set(scopes) - allowed_scopes)
    if invalid_scopes:
        raise AppError(400, 'API_KEY_SCOPE_INVALID', 'Unsupported API key scope')
    if db.query(APIKey).filter_by(tenant_id=tenant_id, name=name).first():
        raise AppError(409, 'API_KEY_EXISTS', 'API key name already exists')
    raw = 'ugc_' + secrets.token_urlsafe(32)
    key_hash = token_hash(raw)
    prefix = raw[:10]
    row = APIKey(tenant_id=tenant_id, name=name, key_prefix=prefix, key_hash=key_hash,
        scopes=scopes, expires_at=data.expires_at)
    db.add(row)
    db.flush()
    audit(db, tenant_id, user.id, 'api_key.create', 'api_key', row.id, after={'name': row.name,
        'scopes': row.scopes})
    db.commit()
    return {'id': row.id, 'name': row.name, 'key': raw, 'key_prefix': prefix, 'scopes': row.scopes,
        'expires_at': row.expires_at.isoformat() if row.expires_at else None}

@router.get('/api-keys')
def list_api_keys(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('apps.manage'))):
    tenant_scope(tenant_id, user, db)
    return {'items': [json_model(x) for x in db.query(APIKey).filter_by(tenant_id=tenant_id,
        revoked_at=None).order_by(APIKey.created_at.desc()).all()]}

@router.delete('/api-keys/{key_id}')
def revoke_api_key(key_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('apps.manage'))):
    tenant_scope(tenant_id, user, db)
    row = db.query(APIKey).filter_by(id=key_id, tenant_id=tenant_id, revoked_at=None).first()
    if not row:
        raise not_found('API key not found')
    row.revoked_at = datetime.now(timezone.utc)
    audit(db, tenant_id, user.id, 'api_key.revoke', 'api_key', row.id)
    db.commit()
    return {'ok': True}

@router.get('/api/v1/tenant')
def api_tenant(api=Depends(api_key_context), db: DBSession=Depends(get_db)):
    if 'tenant.read' not in set(api.scopes) and '*' not in set(api.scopes):
        raise forbidden('API key lacks tenant.read scope')
    tenant = db.get(Tenant, api.tenant_id)
    if not tenant:
        raise not_found('Tenant not found')
    return {'id': tenant.id, 'name': tenant.name, 'slug': tenant.slug,
     'currency': tenant.default_currency,
        'locale': tenant.default_locale, 'api_key_prefix': api.key_prefix}
