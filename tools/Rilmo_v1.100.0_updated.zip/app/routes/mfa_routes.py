"""MFA (TOTP) factor routes: create, verify/enable, delete.

Extracted out of app/routes/v1.py (Phase 3, step 12).
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, issue_mfa_recovery_codes
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.services.core import audit

router = APIRouter(prefix='/v1')


@router.post('/mfa/factors')
def create_mfa_factor(user=Depends(current_user), db: DBSession=Depends(get_db)):
    from app.core.security import totp_secret, encrypt_secret
    existing = db.query(MFAFactor).filter_by(user_id=user.id, factor_type='TOTP',
        enabled=True).first()
    if existing:
        raise AppError(409, 'MFA_ALREADY_ENABLED', 'MFA is already enabled')
    secret = totp_secret()
    factor = MFAFactor(user_id=user.id, factor_type='TOTP', secret_encrypted=encrypt_secret(secret),
        enabled=False)
    db.add(factor)
    db.flush()
    codes = issue_mfa_recovery_codes(db, user.id)
    db.commit()
    return {'factor_id': factor.id, 'type': 'TOTP', 'secret': secret, 'recovery_codes': codes}

@router.post('/mfa/factors/{factor_id}/verify')
def verify_mfa_factor(factor_id: str, code: str, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    from app.core.security import decrypt_secret, verify_totp
    f = db.query(MFAFactor).filter_by(id=factor_id, user_id=user.id, factor_type='TOTP').first()
    if not f:
        raise not_found('MFA factor not found')
    if not f.secret_encrypted:
        raise AppError(400, 'MFA_SECRET_MISSING', 'MFA factor is not initialized')
    if not verify_totp(decrypt_secret(f.secret_encrypted), code):
        raise AppError(400, 'MFA_CODE_INVALID', 'Invalid MFA code')
    f.enabled = True
    audit(db, None, user.id, 'mfa.enable', 'mfa_factor', f.id)
    db.commit()
    return {'ok': True, 'factor_id': f.id, 'enabled': True}

@router.delete('/mfa/factors/{factor_id}')
def delete_mfa_factor(factor_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    f = db.query(MFAFactor).filter_by(id=factor_id, user_id=user.id).first()
    if not f:
        raise not_found('MFA factor not found')
    audit(db, None, user.id, 'mfa.disable', 'mfa_factor', f.id)
    db.delete(f)
    db.query(RecoveryCode).filter_by(user_id=user.id).delete(synchronize_session=False)
    db.commit()
    return {'ok': True}
