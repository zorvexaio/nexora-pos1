from datetime import datetime, timezone, timedelta
import hashlib
import hmac
import secrets
import urllib.parse
import httpx
from fastapi import APIRouter, Depends, Header, Query, Request, Response
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy import func, update
from sqlalchemy.orm import Session as DBSession

from app.core.database import get_db, set_tenant_context
from app.core.auth import current_user, optional_user, current_platform_admin, tenant_user
from app.core.errors import AppError, not_found, forbidden
from app.core.security import encrypt_secret, decrypt_secret, token_hash, create_session_token, hash_password
from app.core.config import get_settings
from app.models.domain import *
from app.models.domain import Session as DomainSession
from app.services.advanced import *
from app.services.advanced import _get_ai_policy, _agent_allowed, _reserve_ai_usage, run_agent
from app.services.core import audit, outbox, enforce_rate_limit
from app.services.mailer import send_email

SessionModel = DomainSession

router = APIRouter(prefix='/v1')


def _assert_permission(tenant_id: str, user, db: DBSession, permission: str):
    membership = tenant_user(tenant_id, user, db)
    if membership.role in {'owner', 'admin'}:
        set_tenant_context(db, tenant_id)
        return membership
    defaults = {
        'staff': {'products.read', 'products.write', 'orders.read', 'orders.manage',
                  'storefront.read', 'storefront.write', 'settings.manage', 'finance.read'},
        'viewer': {'products.read', 'orders.read', 'storefront.read'},
    }
    rows = {x.permission for x in db.query(RolePermission).filter_by(role=membership.role).all()}
    allowed = rows or defaults.get(membership.role, set())
    if '*' not in allowed and permission not in allowed:
        raise forbidden('Permission denied')
    set_tenant_context(db, tenant_id)
    return membership


def _tenant(tenant_id, user, db):
    m = tenant_user(tenant_id, user, db)
    set_tenant_context(db, tenant_id)
    return m


@router.get('/ai/policy')
def get_ai_policy(tenant_id: str, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db); _assert_permission(tenant_id, user, db, 'settings.manage')
    policy = _get_ai_policy(db, tenant_id)
    return {'tenant_id': tenant_id, 'enabled': policy.enabled, 'customer_agent_enabled': policy.customer_agent_enabled,
            'merchant_agent_enabled': policy.merchant_agent_enabled, 'daily_request_limit': policy.daily_request_limit,
            'allow_external_data': policy.allow_external_data, 'provider': get_settings().AI_PROVIDER,
            'external_provider_allowed': get_settings().AI_EXTERNAL_PROVIDER_ALLOWED}

@router.put('/ai/policy')
def update_ai_policy(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db); _assert_permission(tenant_id, user, db, 'settings.manage')
    policy = _get_ai_policy(db, tenant_id)
    for key in ('enabled', 'customer_agent_enabled', 'merchant_agent_enabled', 'allow_external_data'):
        if key in data: setattr(policy, key, bool(data[key]))
    if 'daily_request_limit' in data:
        value = int(data['daily_request_limit'])
        if value < 0 or value > get_settings().AI_DAILY_REQUEST_HARD_LIMIT: raise AppError(400, 'AI_QUOTA_INVALID', 'Invalid AI daily request limit')
        policy.daily_request_limit = value
    audit(db, tenant_id, user.id, 'ai.policy.updated', 'tenant_ai_policy', policy.id,
          after={'enabled': policy.enabled, 'customer_agent_enabled': policy.customer_agent_enabled,
                 'merchant_agent_enabled': policy.merchant_agent_enabled, 'daily_request_limit': policy.daily_request_limit,
                 'allow_external_data': policy.allow_external_data})
    db.commit()
    return {'ok': True}

@router.get('/ai/usage')
def ai_usage(tenant_id: str, limit: int = 30, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db); _assert_permission(tenant_id, user, db, 'settings.manage')
    rows = db.query(AIDailyUsage).filter_by(tenant_id=tenant_id).order_by(AIDailyUsage.usage_date.desc(), AIDailyUsage.agent_role.asc()).limit(max(1, min(limit, 100))).all()
    return {'items': [json_model(x) for x in rows]}

@router.get('/ai/agents/{role}/capabilities')
def ai_agent_capabilities(role: str, tenant_id: str, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    if role == 'merchant': _assert_permission(tenant_id, user, db, 'products.read')
    else: _assert_permission(tenant_id, user, db, 'settings.manage')
    return agent_capabilities(role)

@router.post('/ai/agents/merchant/run')
def ai_merchant_agent(tenant_id: str, question: str, locale: str = 'ar', user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db); _assert_permission(tenant_id, user, db, 'products.read')
    q = str(question or '').strip()
    if not 1 <= len(q) <= 4000: raise AppError(400, 'AI_QUESTION_INVALID', 'Question must be between 1 and 4000 characters')
    products = db.query(Product).filter_by(tenant_id=tenant_id, status='ACTIVE', deleted_at=None).limit(get_settings().AI_MAX_CONTEXT_PRODUCTS).all()
    variants = db.query(ProductVariant).filter_by(tenant_id=tenant_id, status='ACTIVE').all()
    ctx = {'catalog': [{'id': p.id, 'title': p.title, 'description': (p.description or '')[:500]} for p in products],
           'inventory_summary': {'active_variants': len(variants)},
           'orders_summary': {'recent_orders': db.query(Order).filter_by(tenant_id=tenant_id).count()},
           'customers_aggregate': {'customer_count': db.query(Customer).filter_by(tenant_id=tenant_id).count()}}
    result = run_agent('merchant', q, tenant_id, db, locale=locale, context=ctx)
    result.setdefault('ai_disclosure', {})['http_header'] = 'X-Rilmo-AI-Generated: true'
    audit(db, tenant_id, user.id, 'ai.agent.merchant.run', 'tenant_ai_agent', tenant_id,
          after={'role':'merchant','provider':result.get('provider'),'model':result.get('model')}); db.commit()
    return result

@router.post('/admin/ai/agents/platform/run')
def ai_platform_agent(question: str, locale: str = 'ar', admin=Depends(current_platform_admin), db: DBSession = Depends(get_db)):
    # Platform AI is intentionally analytical/proposal-only. It has no mutation tools.
    q = str(question or '').strip()
    if not 1 <= len(q) <= 4000: raise AppError(400, 'AI_QUESTION_INVALID', 'Question must be between 1 and 4000 characters')
    # Use a platform-global pseudo tenant bucket for quota isolation without exposing tenant secrets.
    # NOTE: this used to be created but never actually passed to run_agent() (a leftover 'None'
    # meant the tenant-scoped AI usage/quota reservation path was silently skipped for platform
    # admins). A tenant_id-shaped string can't be used there anyway (tenant_id is a real foreign
    # key), so the fix is a separate, generic rate limit on this bucket instead.
    bucket = 'platform-global-ai'
    enforce_rate_limit(db, bucket, get_settings().AI_DAILY_REQUEST_HARD_LIMIT, window_seconds=86400)
    result = run_agent('platform', q, None, db, locale=locale, context={'system_health': {}, 'risk_summary': {}, 'support_summary': {}, 'performance_summary': {}})
    audit(db, None, admin.id, 'ai.agent.platform.run', 'platform_ai_agent', None,
          after={'role':'platform','provider':result.get('provider'),'model':result.get('model')}); db.commit()
    return result

@router.post('/ai/products/{product_id}/generate')
def ai_product(product_id: str, tenant_id: str, locale: str = 'ar', apply: bool = False,
               user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'products.read')
    if apply:
        _assert_permission(tenant_id, user, db, 'products.write')
    enforce_rate_limit(db, f'ai:product:{tenant_id}:{user.id}', get_settings().AI_REQUEST_RATE_LIMIT_PER_MINUTE)
    ai_allowed, _policy = _agent_allowed(db, tenant_id, 'merchant')
    if ai_allowed:
        _reserve_ai_usage(db, tenant_id, 'merchant')
    if len(locale) > 20:
        raise AppError(400, 'LOCALE_INVALID', 'Locale is too long')
    p = db.query(Product).filter_by(id=product_id, tenant_id=tenant_id, deleted_at=None).first()
    if not p:
        raise not_found('Product not found')
    result, provider, model, prompt = generate_product_content(p, locale, merchant_context='merchant catalog context', ai_allowed=ai_allowed)
    row = AIContentGeneration(tenant_id=tenant_id, user_id=user.id, product_id=p.id, kind='PRODUCT_COPY',
                              locale=locale, provider=provider, model=model, prompt=prompt, result=result)
    db.add(row)
    if apply:
        p.title = str(result.get('title') or p.title)[:255]
        p.description = str(result.get('description') or p.description or '')
        tr = db.query(ProductTranslation).filter_by(product_id=p.id, tenant_id=tenant_id, locale=locale).first()
        if not tr:
            tr = ProductTranslation(tenant_id=tenant_id, product_id=p.id, locale=locale, name=p.title)
            db.add(tr)
        tr.name = p.title
        tr.description = str(result.get('description') or p.description or '')
        tr.seo_title = str(result.get('seo_title') or p.title)[:255]
        tr.seo_description = str(result.get('seo_description') or '')[:500]
    audit(db, tenant_id, user.id, 'ai.product_copy.generate', 'product', p.id,
          after={'provider': provider, 'model': model, 'locale': locale, 'applied': apply})
    db.commit()
    return {'generation_id': row.id, 'provider': provider, 'model': model, 'applied': apply, 'result': result}


@router.post('/ai/assistant')
def ai_assistant(tenant_id: str, question: str, locale: str = 'ar', user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'products.read')
    enforce_rate_limit(db, f'ai:assistant:{tenant_id}:{user.id}', get_settings().AI_REQUEST_RATE_LIMIT_PER_MINUTE)
    question = str(question or '').strip()
    if not 1 <= len(question) <= 4000:
        raise AppError(400, 'AI_QUESTION_INVALID', 'Question must be between 1 and 4000 characters')
    if len(locale) > 20:
        raise AppError(400, 'LOCALE_INVALID', 'Locale is too long')
    products = db.query(Product).filter_by(tenant_id=tenant_id, status='ACTIVE', deleted_at=None).limit(get_settings().AI_MAX_CONTEXT_PRODUCTS).all()
    variants = db.query(ProductVariant).filter_by(tenant_id=tenant_id, status='ACTIVE').all()
    ctx = {
        'catalog': [{'id': p.id, 'title': p.title, 'description': (p.description or '')[:500]} for p in products],
        'inventory_summary': {'active_variants': len(variants)},
        'orders_summary': {'recent_orders': db.query(Order).filter_by(tenant_id=tenant_id).count()},
        'customers_aggregate': {'customer_count': db.query(Customer).filter_by(tenant_id=tenant_id).count()},
    }
    result = run_agent('merchant', question, tenant_id, db, locale=locale, context=ctx)
    audit(db, tenant_id, user.id, 'ai.agent.merchant.run', 'tenant_ai_agent', tenant_id,
          after={'role': 'merchant', 'provider': result.get('provider'), 'model': result.get('model'), 'source': 'assistant'})
    db.commit()
    return result


@router.get('/ai/generations')
def ai_generations(tenant_id: str, limit: int = 50, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'products.read')
    rows = db.query(AIContentGeneration).filter_by(tenant_id=tenant_id).order_by(AIContentGeneration.created_at.desc()).limit(max(1, min(limit, 100))).all()
    return {'items': [json_model(x) for x in rows]}



def _public_storefront(hostname: str, db):
    row = db.query(Domain, Storefront, Tenant).join(Storefront, Storefront.id == Domain.storefront_id).join(Tenant, Tenant.id == Domain.tenant_id).filter(
        func.lower(Domain.hostname) == hostname.lower(), Domain.verified_at.is_not(None),
        Tenant.status == 'ACTIVE', Storefront.status == 'PUBLISHED').first()
    if not row:
        raise not_found('Storefront not found')
    return row

def _customer_session_cookie(response, raw: str, max_age: int):
    s = get_settings()
    response.set_cookie('customer_session', raw, httponly=True, secure=s.COOKIE_SECURE,
                        samesite='lax', max_age=max_age, path='/')
    response.set_cookie('csrf_token', secrets.token_urlsafe(24), httponly=False, secure=s.COOKIE_SECURE,
                        samesite='lax', max_age=max_age, path='/')

def _customer_payload(c):
    return {'id': c.id, 'email': c.email, 'first_name': c.first_name, 'last_name': c.last_name,
            'phone': c.phone, 'created_at': c.created_at.isoformat() if c.created_at else None}

@router.get('/public/storefront/{hostname}/customer/session')
def storefront_customer_session(hostname: str, request: Request, db: DBSession = Depends(get_db)):
    _, _, tenant = _public_storefront(hostname, db)
    raw = request.cookies.get('customer_session')
    if not raw:
        return {'authenticated': False, 'customer': None}
    row = db.query(CustomerSession).filter_by(tenant_id=tenant.id, token_hash=token_hash(raw)).first()
    now = datetime.now(timezone.utc)
    if not row or (row.expires_at.replace(tzinfo=timezone.utc) if row.expires_at.tzinfo is None else row.expires_at) <= now:
        return {'authenticated': False, 'customer': None}
    c = db.query(Customer).filter_by(id=row.customer_id, tenant_id=tenant.id).first()
    if not c:
        return {'authenticated': False, 'customer': None}
    row.last_seen_at = now
    db.commit()
    return {'authenticated': True, 'customer': _customer_payload(c)}

@router.post('/public/storefront/{hostname}/auth/email/start')
def storefront_customer_email_start(hostname: str, data: dict, request: Request, db: DBSession = Depends(get_db)):
    _, _, tenant = _public_storefront(hostname, db)
    email = str(data.get('email') or '').strip().lower()
    if '@' not in email or len(email) > 320:
        raise AppError(400, 'EMAIL_INVALID', 'A valid email address is required')
    enforce_rate_limit(db, f'customer:login:ip:{tenant.id}:{request.client.host or "unknown"}', get_settings().CUSTOMER_LOGIN_IP_RATE_LIMIT_PER_MINUTE)
    enforce_rate_limit(db, f'customer:login:email:{tenant.id}:{hashlib.sha256(email.encode()).hexdigest()}', get_settings().CUSTOMER_LOGIN_EMAIL_RATE_LIMIT_PER_MINUTE)
    c = db.query(Customer).filter_by(tenant_id=tenant.id, email=email).first()
    if not c:
        c = Customer(tenant_id=tenant.id, email=email)
        db.add(c); db.flush()
    code = f'{secrets.randbelow(1000000):06d}'
    row = CustomerLoginCode(tenant_id=tenant.id, customer_id=c.id, email=email,
                            code_hash=token_hash(code),
                            expires_at=datetime.now(timezone.utc) + timedelta(minutes=get_settings().CUSTOMER_LOGIN_CODE_TTL_MINUTES))
    db.add(row); db.commit()
    send_email(email, 'Your sign-in code', f'Your sign-in code is {code}. It expires in {get_settings().CUSTOMER_LOGIN_CODE_TTL_MINUTES} minutes. If you did not request this, ignore this message.')
    return {'ok': True, 'message': 'If the address is eligible, a sign-in code has been sent.'}

@router.post('/public/storefront/{hostname}/auth/email/verify')
def storefront_customer_email_verify(hostname: str, data: dict, request: Request, response: Response, db: DBSession = Depends(get_db)):
    _, _, tenant = _public_storefront(hostname, db)
    email = str(data.get('email') or '').strip().lower()
    code = str(data.get('code') or '').strip()
    if not (len(code) == 6 and code.isdigit()):
        raise AppError(400, 'CODE_INVALID', 'Invalid sign-in code')
    enforce_rate_limit(db, f'customer:verify:ip:{tenant.id}:{request.client.host or "unknown"}', get_settings().CUSTOMER_LOGIN_VERIFY_RATE_LIMIT_PER_MINUTE)
    enforce_rate_limit(db, f'customer:verify:email:{tenant.id}:{hashlib.sha256(email.encode()).hexdigest()}', get_settings().CUSTOMER_LOGIN_VERIFY_RATE_LIMIT_PER_MINUTE)
    row = db.query(CustomerLoginCode).filter_by(tenant_id=tenant.id, email=email, used_at=None).order_by(CustomerLoginCode.created_at.desc()).with_for_update().first()
    now = datetime.now(timezone.utc)
    exp = row.expires_at.replace(tzinfo=timezone.utc) if row and row.expires_at.tzinfo is None else row.expires_at if row else None
    if not row or exp <= now or row.attempts >= get_settings().CUSTOMER_LOGIN_CODE_MAX_ATTEMPTS or not hmac.compare_digest(row.code_hash, token_hash(code)):
        if row: row.attempts += 1; db.commit()
        raise AppError(400, 'CODE_INVALID', 'Invalid or expired sign-in code')
    row.used_at = now
    c = db.query(Customer).filter_by(id=row.customer_id, tenant_id=tenant.id).first()
    if not c:
        raise AppError(400, 'CUSTOMER_NOT_FOUND', 'Customer account not found')
    raw = create_session_token()
    db.add(CustomerSession(tenant_id=tenant.id, customer_id=c.id, token_hash=token_hash(raw),
                            expires_at=now + timedelta(days=get_settings().CUSTOMER_SESSION_TTL_DAYS), last_seen_at=now))
    # Merge guest cart into the authenticated customer's open cart.
    guest_raw = request.cookies.get('guest_session')
    guest = db.query(GuestSession).filter_by(tenant_id=tenant.id, token_hash=token_hash(guest_raw)).first() if guest_raw else None
    guest_cart_row = db.query(Cart).filter_by(tenant_id=tenant.id, guest_session_id=guest.id, status='OPEN').first() if guest else None
    customer_cart = db.query(Cart).filter_by(tenant_id=tenant.id, customer_id=c.id, status='OPEN').order_by(Cart.updated_at.desc()).first()
    if guest_cart_row:
        if not customer_cart:
            guest_cart_row.customer_id = c.id; guest_cart_row.guest_session_id = None; customer_cart = guest_cart_row
        else:
            for gi in db.query(CartItem).filter_by(tenant_id=tenant.id, cart_id=guest_cart_row.id).all():
                existing = db.query(CartItem).filter_by(tenant_id=tenant.id, cart_id=customer_cart.id, variant_id=gi.variant_id).first()
                if existing: existing.quantity += gi.quantity
                else: db.add(CartItem(tenant_id=tenant.id, cart_id=customer_cart.id, variant_id=gi.variant_id, quantity=gi.quantity, unit_price_minor=gi.unit_price_minor, currency=gi.currency))
            db.delete(guest_cart_row)
    db.commit()
    _customer_session_cookie(response, raw, get_settings().CUSTOMER_SESSION_TTL_DAYS * 86400)
    response.delete_cookie('guest_session', path='/')
    return {'ok': True, 'customer': _customer_payload(c)}

@router.post('/public/storefront/{hostname}/auth/logout')
def storefront_customer_logout(hostname: str, request: Request, response: Response, db: DBSession = Depends(get_db)):
    _, _, tenant = _public_storefront(hostname, db)
    raw = request.cookies.get('customer_session')
    if raw:
        row = db.query(CustomerSession).filter_by(tenant_id=tenant.id, token_hash=token_hash(raw)).first()
        if row:
            db.delete(row); db.commit()
    response.delete_cookie('customer_session', path='/')
    response.delete_cookie('csrf_token', path='/')
    return {'ok': True}


def _consume_storefront_oauth_state(db, state_id, now):
    result = db.execute(update(StorefrontOAuthState).where(StorefrontOAuthState.id == state_id, StorefrontOAuthState.used_at.is_(None)).values(used_at=now))
    if result.rowcount != 1:
        raise AppError(400, 'OAUTH_STATE_REPLAY', 'OAuth state has already been consumed')

@router.get('/public/storefront/{hostname}/auth/google/start')
def storefront_customer_google_start(hostname: str, request: Request, response: Response, db: DBSession = Depends(get_db)):
    _, _, tenant = _public_storefront(hostname, db)
    s = get_settings()
    if not s.GOOGLE_CLIENT_ID or not s.GOOGLE_CLIENT_SECRET:
        raise AppError(503, 'GOOGLE_OAUTH_NOT_CONFIGURED', 'Google sign-in is not configured')
    state = secrets.token_urlsafe(32); nonce = secrets.token_urlsafe(32); now = datetime.now(timezone.utc)
    db.add(StorefrontOAuthState(tenant_id=tenant.id, hostname=hostname.lower(), state_hash=token_hash(state), nonce_hash=token_hash(nonce), redirect_uri=s.GOOGLE_REDIRECT_URI, expires_at=now + timedelta(minutes=10)))
    db.commit()
    params={'client_id':s.GOOGLE_CLIENT_ID,'redirect_uri':s.GOOGLE_REDIRECT_URI,'response_type':'code','scope':s.GOOGLE_SCOPES,'state':state,'nonce':nonce,'prompt':'select_account'}
    response.set_cookie('sf_oauth_state', state, httponly=True, secure=s.COOKIE_SECURE, samesite='lax', max_age=600, path='/')
    return {'authorization_url':'https://accounts.google.com/o/oauth2/v2/auth?'+urllib.parse.urlencode(params)}

@router.get('/public/storefront/auth/google/callback')
def storefront_customer_google_callback(code: str, state: str, request: Request, response: Response, db: DBSession = Depends(get_db)):
    s=get_settings(); now=datetime.now(timezone.utc)
    if not request.cookies.get('sf_oauth_state') or not hmac.compare_digest(token_hash(request.cookies.get('sf_oauth_state')), token_hash(state)):
        raise AppError(400,'OAUTH_STATE_INVALID','Invalid OAuth state')
    st=db.query(StorefrontOAuthState).filter_by(state_hash=token_hash(state),used_at=None).first()
    if not st or (st.expires_at.replace(tzinfo=timezone.utc) if st.expires_at.tzinfo is None else st.expires_at)<=now:
        raise AppError(400,'OAUTH_STATE_EXPIRED','OAuth state expired')
    try:
        tok=httpx.post('https://oauth2.googleapis.com/token',trust_env=False,data={'client_id':s.GOOGLE_CLIENT_ID,'client_secret':s.GOOGLE_CLIENT_SECRET,'code':code,'grant_type':'authorization_code','redirect_uri':st.redirect_uri},timeout=10).json()
        access=tok.get('access_token'); id_token=tok.get('id_token')
        if not access or not id_token: raise ValueError('missing token')
        info=httpx.get('https://openidconnect.googleapis.com/v1/userinfo',trust_env=False,headers={'Authorization':f'Bearer {access}'},timeout=10).json()
        import jwt
        key=jwt.PyJWKClient(s.GOOGLE_JWKS_URL).get_signing_key_from_jwt(id_token).key
        claims=jwt.decode(id_token,key,algorithms=['RS256'],audience=s.GOOGLE_CLIENT_ID,issuer=[x.strip() for x in s.GOOGLE_ISSUERS.split(',') if x.strip()])
        subject=str(claims.get('sub') or ''); email=str(claims.get('email') or '').lower()
        if not subject or not email or not claims.get('email_verified') or str(claims.get('nonce') or '')=='': raise ValueError('invalid identity')
        if not hmac.compare_digest(token_hash(str(claims.get('nonce'))), st.nonce_hash): raise ValueError('nonce mismatch')
    except Exception as exc:
        raise AppError(502,'GOOGLE_OAUTH_FAILED','Unable to complete Google sign-in') from exc
    identity=db.query(CustomerIdentity).filter_by(tenant_id=st.tenant_id,provider='google',provider_subject=subject).first()
    if identity: c=db.query(Customer).filter_by(id=identity.customer_id,tenant_id=st.tenant_id).first()
    else:
        c=db.query(Customer).filter_by(tenant_id=st.tenant_id,email=email).first()
        if not c:
            c=Customer(tenant_id=st.tenant_id,email=email,first_name=str(info.get('given_name') or '')[:120],last_name=str(info.get('family_name') or '')[:120]); db.add(c); db.flush()
        db.add(CustomerIdentity(tenant_id=st.tenant_id,customer_id=c.id,provider='google',provider_subject=subject,provider_email=email,email_verified_at=now))
    raw=create_session_token(); db.add(CustomerSession(tenant_id=st.tenant_id,customer_id=c.id,token_hash=token_hash(raw),expires_at=now+timedelta(days=get_settings().CUSTOMER_SESSION_TTL_DAYS),last_seen_at=now)); _consume_storefront_oauth_state(db, st.id, now); db.commit()
    _customer_session_cookie(response,raw,30*86400); response.delete_cookie('sf_oauth_state',path='/')
    scheme='https' if s.ENVIRONMENT=='production' else request.url.scheme
    return RedirectResponse(url=f'{scheme}://{st.hostname}/?customer_signed_in=1',status_code=303)

@router.post('/public/storefront/{hostname}/assistant')
def public_storefront_assistant(hostname: str, data: dict, request: Request, db: DBSession = Depends(get_db)):
    """Public Customer AI. Read-only, tenant-scoped and governed by tenant AI policy."""
    _, storefront, tenant = _public_storefront(hostname, db)
    s = get_settings()
    enforce_rate_limit(db, f'public:assistant:{tenant.id}:{request.client.host or "unknown"}', s.AI_PUBLIC_RATE_LIMIT_PER_MINUTE)
    question = str(data.get('question') or '').strip()
    if not question:
        raise AppError(400, 'ASSISTANT_QUESTION_REQUIRED', 'Question is required')
    if len(question) > s.AI_PUBLIC_MAX_QUESTION_CHARS:
        raise AppError(413, 'ASSISTANT_QUESTION_TOO_LONG', 'Question is too long')
    products = db.query(Product).filter(Product.tenant_id == tenant.id,
        Product.status == 'ACTIVE', Product.deleted_at.is_(None)).order_by(Product.created_at.desc()).limit(s.AI_MAX_CONTEXT_PRODUCTS).all()
    catalog = [{'id': p.id, 'title': p.title, 'description': (p.description or '')[:500]} for p in products]
    customer_summary = []
    raw = request.cookies.get('customer_session')
    session = db.query(CustomerSession).filter_by(tenant_id=tenant.id, token_hash=token_hash(raw or '')).first() if raw else None
    if session and session.expires_at:
        now = datetime.now(timezone.utc)
        exp = session.expires_at.replace(tzinfo=timezone.utc) if session.expires_at.tzinfo is None else session.expires_at
        if exp > now:
            orders = db.query(Order).filter_by(tenant_id=tenant.id, customer_id=session.customer_id).order_by(Order.created_at.desc()).limit(8).all()
            customer_summary = [{'order_number': o.order_number, 'status': o.status,
                                 'fulfillment_status': o.fulfillment_status,
                                 'created_at': o.created_at.isoformat() if o.created_at else None} for o in orders]
    result = run_agent('customer', question, tenant.id, db, locale=storefront.default_locale,
                       context={'catalog': catalog, 'own_orders': customer_summary})
    result.setdefault('ai_disclosure', {})['http_header'] = 'X-Rilmo-AI-Generated: true'
    # Never expose database primary keys to shoppers.
    result['recommended_product_ids'] = []
    return result

@router.get('/public/storefront/{hostname}/customer/orders')
def storefront_customer_orders(hostname: str, request: Request, db: DBSession = Depends(get_db)):
    _, _, tenant = _public_storefront(hostname, db)
    raw=request.cookies.get('customer_session')
    row=db.query(CustomerSession).filter_by(tenant_id=tenant.id,token_hash=token_hash(raw or '')).first() if raw else None
    if not row: raise forbidden('Customer sign-in required')
    orders=db.query(Order).filter_by(tenant_id=tenant.id,customer_id=row.customer_id).order_by(Order.created_at.desc()).limit(50).all()
    return {'items':[{'id':o.id,'order_number':o.order_number,'status':o.status,'total_minor':o.total_minor,'currency':o.currency,'created_at':o.created_at.isoformat() if o.created_at else None} for o in orders]}

@router.post('/public/storefront/{hostname}/events')
def live_event(hostname: str, data: dict, request: Request, response: Response, db: DBSession = Depends(get_db)):
    row = db.query(Domain, Storefront, Tenant).join(Storefront, Storefront.id == Domain.storefront_id).join(Tenant, Tenant.id == Domain.tenant_id).filter(
        func.lower(Domain.hostname) == hostname.lower(), Domain.verified_at.is_not(None), Tenant.status == 'ACTIVE', Storefront.status == 'PUBLISHED').first()
    if not row:
        raise not_found('Storefront not found')
    d, storefront, tenant = row
    enforce_rate_limit(db, f'public:event:{tenant.id}:{request.client.host or "unknown"}', get_settings().PUBLIC_EVENT_RATE_LIMIT_PER_MINUTE)
    if len(data) > 30:
        raise AppError(400, 'LIVE_EVENT_INVALID', 'Event payload contains too many fields')
    event_type = str(data.get('event_type') or 'page_view')[:60]
    allowed = {'page_view', 'product_view', 'search', 'add_to_cart', 'begin_checkout', 'purchase', 'wishlist'}
    if event_type not in allowed:
        raise AppError(400, 'LIVE_EVENT_INVALID', 'Unsupported live event')
    gpc = request.headers.get('Sec-GPC') == '1'
    # Respect a browser-level opt-out signal before creating any analytics identifier.
    if gpc:
        return {'ok': True, 'stored': False, 'privacy_signal': 'GPC'}
    visitor = request.cookies.get('live_visitor') or secrets.token_urlsafe(18)
    if not request.cookies.get('live_visitor'):
        response.set_cookie('live_visitor', visitor, max_age=60 * 60 * 24 * 180, httponly=False, samesite='lax', secure=get_settings().COOKIE_SECURE)
    product_id = data.get('product_id')
    if product_id:
        # Never accept a foreign-tenant product identifier from an untrusted
        # storefront event.  LiveStorefrontEvent carries both tenant_id and
        # product_id, so persisting a cross-tenant FK would corrupt analytics
        # attribution and could expose another merchant's catalog identity.
        product = db.query(Product).filter_by(
            id=str(product_id), tenant_id=tenant.id, storefront_id=storefront.id,
            status='ACTIVE', deleted_at=None).first()
        if not product:
            raise AppError(400, 'LIVE_EVENT_PRODUCT_INVALID', 'Product does not belong to this storefront')
        product_id = product.id
    row_event = LiveStorefrontEvent(tenant_id=tenant.id, storefront_id=storefront.id,
        visitor_key_hash=token_hash(visitor), event_type=event_type,
        path=str(data.get('path') or request.headers.get('referer') or '')[:2000],
        product_id=product_id, meta=data.get('metadata') or {})
    db.add(row_event)
    db.commit()
    return {'ok': True}


@router.get('/analytics/live')
def analytics_live(tenant_id: str, minutes: int = 5, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'finance.read')
    return live_summary(tenant_id, db, minutes)


@router.get('/admin/live')
def admin_live(minutes: int = 5, admin=Depends(current_platform_admin), db: DBSession = Depends(get_db)):
    since = datetime.now(timezone.utc) - timedelta(minutes=max(1, min(minutes, 60)))
    active_merchants = db.query(func.count(func.distinct(LiveStorefrontEvent.tenant_id))).filter(LiveStorefrontEvent.created_at >= since).scalar() or 0
    sales = db.query(func.count(Order.id)).filter(Order.created_at >= since, Order.status.notin_(['CANCELLED'])).scalar() or 0
    tenants = db.query(Tenant).filter(Tenant.status == 'ACTIVE').count()
    return {'window_minutes': minutes, 'active_merchants': int(active_merchants), 'sales_last_window': int(sales), 'active_tenants': tenants,
            'plan_mix': [{'plan': name or 'unknown', 'tenants': int(count)} for name, count in db.query(Plan.name, func.count(Subscription.id)).join(Subscription, Subscription.plan_id == Plan.id, isouter=True).filter(Subscription.status.in_(['ACTIVE','TRIALING'])).group_by(Plan.name).all()]}


@router.get('/admin/monthly-report')
def monthly_report(period: str | None = None, admin=Depends(current_platform_admin), db: DBSession = Depends(get_db)):
    now = datetime.now(timezone.utc)
    period = period or now.strftime('%Y-%m')
    row = db.query(PlatformMonthlyReport).filter_by(period_key=period).first()
    if row:
        return json_model(row)
    start = datetime.strptime(period + '-01', '%Y-%m-%d').replace(tzinfo=timezone.utc)
    end = (start + timedelta(days=32)).replace(day=1)
    metrics = platform_metrics(db, start, end)
    recipients = [x.email for x in db.query(User).join(PlatformAdmin, PlatformAdmin.user_id == User.id).all()]
    row = PlatformMonthlyReport(period_key=period, recipients=recipients, metrics=metrics, delivery_status='NOT_SENT')
    db.add(row)
    db.commit()
    return json_model(row)


@router.post('/admin/impersonate/{tenant_id}')
def start_impersonation(tenant_id: str, reason: str, request: Request, response: Response, ticket_id: str | None = None,
                        admin=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    if len(reason.strip()) < 8:
        raise AppError(400, 'IMPERSONATION_REASON_REQUIRED', 'A support reason is required')
    settings = get_settings()
    if settings.ENVIRONMENT == 'production' and settings.IMPERSONATION_TICKET_REQUIRED_PRODUCTION and len((ticket_id or '').strip()) < 6:
        raise AppError(400, 'IMPERSONATION_TICKET_REQUIRED', 'A support/compliance case or ticket reference is required')
    target_member = db.query(TenantMembership).filter_by(tenant_id=tenant_id, status='ACTIVE').order_by(TenantMembership.created_at.asc()).first()
    tenant = db.get(Tenant, tenant_id)
    if not tenant or not target_member:
        raise not_found('Tenant or tenant member not found')
    target = db.get(User, target_member.user_id)
    if not target:
        raise not_found('Target user not found')
    raw = create_session_token()
    now = datetime.now(timezone.utc)
    session = SessionModel(user_id=target.id, token_hash=token_hash(raw), expires_at=now + timedelta(minutes=20),
        idle_expires_at=now + timedelta(minutes=20), absolute_expires_at=now + timedelta(minutes=20),
        last_seen_at=now, impersonator_user_id=admin.user_id, read_only_impersonation=True)
    db.add(session)
    db.flush()
    imp = ImpersonationSession(admin_user_id=admin.user_id, target_user_id=target.id, tenant_id=tenant_id,
                               session_id=session.id, reason=reason.strip()[:500], ticket_id=(ticket_id or '').strip()[:120] or None, read_only=True,
                               expires_at=now + timedelta(minutes=20))
    db.add(imp)
    audit(db, tenant_id, admin.user_id, 'admin.impersonation.start', 'tenant', tenant_id,
          after={'target_user_id': target.id, 'reason': reason[:500], 'ticket_id': imp.ticket_id, 'expires_at': imp.expires_at.isoformat(), 'read_only': True})
    db.commit()
    response.set_cookie('impersonation_session', raw, httponly=True, secure=get_settings().COOKIE_SECURE, samesite='lax', max_age=1200, path='/')
    response.set_cookie('impersonation_csrf_token', secrets.token_urlsafe(24), httponly=False, secure=get_settings().COOKIE_SECURE, samesite='lax', max_age=1200, path='/')
    return {'ok': True, 'expires_at': imp.expires_at.isoformat(), 'tenant_id': tenant_id, 'target_user_id': target.id, 'ticket_id': imp.ticket_id, 'read_only': True}


@router.post('/admin/impersonate/{impersonation_id}/end')
def end_impersonation(impersonation_id: str, admin=Depends(current_platform_admin), db: DBSession = Depends(get_db)):
    row = db.query(ImpersonationSession).filter_by(id=impersonation_id, admin_user_id=admin.user_id, ended_at=None).first()
    if not row:
        raise not_found('Impersonation session not found')
    row.ended_at = datetime.now(timezone.utc)
    if row.session_id:
        s = db.get(SessionModel, row.session_id)
        if s:
            s.revoked_at = row.ended_at
    db.commit()
    return {'ok': True}


@router.post('/auth/impersonation/end')
def end_current_impersonation(request: Request, user=Depends(current_user), db: DBSession = Depends(get_db)):
    sid = getattr(request.state, 'impersonation_session_id', None)
    if not sid:
        raise not_found('Impersonation session not found')
    session = db.get(SessionModel, sid)
    if not session or not getattr(session, 'read_only_impersonation', False):
        raise not_found('Impersonation session not found')
    now = datetime.now(timezone.utc)
    row = db.query(ImpersonationSession).filter_by(session_id=session.id, ended_at=None).first()
    if row:
        row.ended_at = now
    session.revoked_at = now
    db.commit()
    response = Response(content="{\"ok\":true}", media_type='application/json')
    response.delete_cookie('impersonation_session', path='/')
    response.delete_cookie('impersonation_csrf_token', path='/')
    return response


@router.post('/whatsapp/configure')
def whatsapp_configure(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'settings.manage')
    token = str(data.get('access_token') or '')
    phone_number_id = str(data.get('phone_number_id') or '')
    verify_token = str(data.get('verify_token') or '')
    app_secret = str(data.get('app_secret') or get_settings().WHATSAPP_APP_SECRET or '')
    if not token or not phone_number_id or not verify_token or not app_secret:
        raise AppError(400, 'WHATSAPP_CONFIG_INVALID', 'phone_number_id, access_token, verify_token and app_secret are required')
    row = db.query(WhatsAppChannel).filter_by(tenant_id=tenant_id).first()
    if not row:
        row = WhatsAppChannel(tenant_id=tenant_id, phone_number_id=phone_number_id,
                              business_account_id=data.get('business_account_id'),
                              access_token_encrypted=encrypt_secret(token), app_secret_encrypted=encrypt_secret(app_secret) if app_secret else None, verify_token_hash=token_hash(verify_token),
                              api_version=str(data.get('api_version') or get_settings().WHATSAPP_API_VERSION))
        db.add(row)
    else:
        row.phone_number_id = phone_number_id
        row.business_account_id = data.get('business_account_id')
        row.access_token_encrypted = encrypt_secret(token)
        row.app_secret_encrypted = encrypt_secret(app_secret) if app_secret else row.app_secret_encrypted
        row.verify_token_hash = token_hash(verify_token)
        row.api_version = str(data.get('api_version') or row.api_version)
        row.updated_at = datetime.now(timezone.utc)
    audit(db, tenant_id, user.id, 'whatsapp.configure', 'whatsapp_channel', row.id if row.id else 'new', after={'phone_number_id': phone_number_id})
    db.commit()
    return {'ok': True, 'phone_number_id': phone_number_id, 'status': row.status, 'api_version': row.api_version}


@router.get('/whatsapp/webhook/{tenant_id}')
def whatsapp_webhook_verify(tenant_id: str, hub_mode: str | None = Query(default=None, alias='hub.mode'),
                            hub_verify_token: str | None = Query(default=None, alias='hub.verify_token'),
                            hub_challenge: str | None = Query(default=None, alias='hub.challenge'),
                            db: DBSession = Depends(get_db)):
    row = db.query(WhatsAppChannel).filter_by(tenant_id=tenant_id, status='ACTIVE').first()
    if not row or hub_mode != 'subscribe' or not hub_verify_token or token_hash(hub_verify_token) != row.verify_token_hash:
        return JSONResponse({'error': 'verification failed'}, status_code=403)
    return Response(content=hub_challenge or '', media_type='text/plain')


@router.post('/whatsapp/webhook/{tenant_id}')
async def whatsapp_webhook(tenant_id: str, request: Request, db: DBSession = Depends(get_db), x_hub_signature_256: str | None = Header(default=None)):
    settings = get_settings()
    row = db.query(WhatsAppChannel).filter_by(tenant_id=tenant_id, status='ACTIVE').first()
    if not row:
        raise not_found('WhatsApp channel not configured')
    enforce_rate_limit(db, 'whatsapp:webhook:' + tenant_id + ':' + str(request.client.host if request.client else 'unknown'), settings.WHATSAPP_WEBHOOK_RATE_LIMIT_PER_MINUTE)
    content_length = request.headers.get('content-length')
    if content_length:
        try:
            if int(content_length) > settings.MAX_WEBHOOK_BODY_BYTES:
                raise AppError(413, 'WEBHOOK_TOO_LARGE', 'Webhook payload too large')
        except ValueError:
            raise AppError(400, 'WEBHOOK_CONTENT_LENGTH_INVALID', 'Invalid Content-Length header')
    body = await request.body()
    if len(body) > settings.MAX_WEBHOOK_BODY_BYTES:
        raise AppError(413, 'WEBHOOK_TOO_LARGE', 'Webhook payload too large')
    secret = decrypt_secret(row.app_secret_encrypted) if row.app_secret_encrypted else get_settings().WHATSAPP_APP_SECRET
    if not secret:
        raise AppError(503, 'WHATSAPP_SIGNATURE_NOT_CONFIGURED', 'WhatsApp webhook verification secret is not configured')
    expected = 'sha256=' + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    if not x_hub_signature_256 or not hmac.compare_digest(expected, x_hub_signature_256):
        raise AppError(403, 'WHATSAPP_SIGNATURE_INVALID', 'WhatsApp webhook signature is invalid')
    try:
        payload = __import__('json').loads(body.decode('utf-8') or '{}')
    except (UnicodeDecodeError, ValueError, TypeError) as exc:
        raise AppError(400, 'WHATSAPP_WEBHOOK_INVALID_JSON', 'Invalid WhatsApp webhook JSON') from exc
    if not isinstance(payload, dict):
        raise AppError(400, 'WHATSAPP_WEBHOOK_INVALID_JSON', 'Invalid WhatsApp webhook JSON')
    for entry in payload.get('entry', []) or []:
        for change in entry.get('changes', []) or []:
            value = change.get('value') or {}
            for message in value.get('messages', []) or []:
                sender = str(message.get('from') or '')
                text = str(((message.get('text') or {}).get('body') or ''))
                provider_message_id = str(message.get('id') or '').strip() or None
                if provider_message_id and db.query(WhatsAppMessage).filter_by(tenant_id=tenant_id, provider_message_id=provider_message_id).first():
                    continue
                db.add(WhatsAppMessage(tenant_id=tenant_id, channel_id=row.id, direction='INBOUND', recipient=sender,
                                       message_type=str(message.get('type') or 'unknown'), body=text,
                                       provider_message_id=provider_message_id, status='RECEIVED', metadata=message))
    db.commit()
    return {'ok': True}


@router.post('/whatsapp/send')
def whatsapp_send(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'settings.manage')
    row = db.query(WhatsAppChannel).filter_by(tenant_id=tenant_id, status='ACTIVE').first()
    if not row:
        raise AppError(409, 'WHATSAPP_NOT_CONFIGURED', 'WhatsApp channel is not configured')
    recipient, body = str(data.get('recipient') or '').strip(), str(data.get('body') or '').strip()
    if not recipient or not body or len(recipient) > 40 or len(body) > 4096:
        raise AppError(400, 'WHATSAPP_MESSAGE_INVALID', 'recipient and body are required within safe limits')
    msg = WhatsAppMessage(tenant_id=tenant_id, channel_id=row.id, recipient=recipient, body=body, status='QUEUED')
    db.add(msg)
    try:
        provider_id, raw = send_whatsapp(row, recipient, body)
        msg.provider_message_id = provider_id
        msg.status = 'SENT'
        msg.sent_at = datetime.now(timezone.utc)
        msg.meta = raw
    except Exception as exc:
        msg.status = 'FAILED'
        msg.error_message = str(exc)[:2000]
        db.commit()
        raise
    db.commit()
    return json_model(msg)


@router.get('/whatsapp/messages')
def whatsapp_messages(tenant_id: str, limit: int = 100, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'settings.manage')
    rows = db.query(WhatsAppMessage).filter_by(tenant_id=tenant_id).order_by(WhatsAppMessage.created_at.desc()).limit(max(1, min(limit, 200))).all()
    return {'items': [json_model(x) for x in rows]}


@router.get('/landing-pages')
def landing_pages(tenant_id: str, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'storefront.read')
    return {'items': [json_model(x) for x in db.query(LandingPage).filter_by(tenant_id=tenant_id).order_by(LandingPage.updated_at.desc()).all()]}


@router.post('/landing-pages')
def create_landing_page(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'storefront.write')
    slug = str(data.get('slug') or '').strip().lower()
    if not slug or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in slug):
        raise AppError(400, 'LANDING_SLUG_INVALID', 'Landing page slug may contain lowercase letters, digits and hyphens')
    if db.query(LandingPage).filter_by(tenant_id=tenant_id, slug=slug).first():
        raise AppError(409, 'LANDING_EXISTS', 'Landing page already exists')
    content = data.get('content') or {}
    if not isinstance(content, dict) or len(content) > 50:
        raise AppError(400, 'LANDING_CONTENT_INVALID', 'Landing content must be a bounded object')
    row = LandingPage(tenant_id=tenant_id, slug=slug, title=str(data.get('title') or slug)[:200], locale=str(data.get('locale') or 'ar'),
                      seo_title=str(data.get('seo_title') or '')[:255], seo_description=str(data.get('seo_description') or '')[:1000], content=content)
    db.add(row)
    db.commit()
    return json_model(row)


@router.patch('/landing-pages/{page_id}')
def update_landing_page(page_id: str, tenant_id: str, data: dict, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'storefront.write')
    row = db.query(LandingPage).filter_by(id=page_id, tenant_id=tenant_id).first()
    if not row:
        raise not_found('Landing page not found')
    if 'content' in data:
        if not isinstance(data['content'], dict) or len(data['content']) > 50:
            raise AppError(400, 'LANDING_CONTENT_INVALID', 'Landing content must be a bounded object')
    for key in ('title', 'seo_title', 'seo_description', 'locale', 'content'):
        if key in data:
            value = data[key]
            if key == 'title': value = str(value)[:200]
            elif key == 'seo_title': value = str(value)[:255]
            elif key == 'seo_description': value = str(value)[:1000]
            setattr(row, key, value)
    if data.get('status') in {'DRAFT', 'PUBLISHED'}:
        row.status = data['status']
        row.published_at = datetime.now(timezone.utc) if row.status == 'PUBLISHED' else None
    row.updated_at = datetime.now(timezone.utc)
    db.commit()
    return json_model(row)


@router.get('/public/storefront/{hostname}/landing/{slug}')
def public_landing(hostname: str, slug: str, db: DBSession = Depends(get_db)):
    row = db.query(LandingPage, Domain, Storefront, Tenant).join(Domain, Domain.tenant_id == LandingPage.tenant_id).join(Storefront, Storefront.id == Domain.storefront_id).join(Tenant, Tenant.id == Domain.tenant_id).filter(
        LandingPage.slug == slug, LandingPage.status == 'PUBLISHED', func.lower(Domain.hostname) == hostname.lower(), Domain.verified_at.is_not(None),
        Tenant.status == 'ACTIVE', Storefront.status == 'PUBLISHED').first()
    if not row:
        raise not_found('Landing page not found')
    p, d, s, t = row
    return {'tenant': {'name': t.name}, 'page': json_model(p), 'storefront': {'hostname': d.hostname, 'slug': s.slug}}


@router.get('/affiliate/program')
def affiliate_program(tenant_id: str, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'finance.read')
    row = db.query(AffiliateProgram).filter_by(tenant_id=tenant_id).first()
    return json_model(row) if row else {'enabled': False}


@router.post('/affiliate/program')
def save_affiliate_program(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'settings.manage')
    row = db.query(AffiliateProgram).filter_by(tenant_id=tenant_id).first()
    if not row:
        row = AffiliateProgram(tenant_id=tenant_id)
        db.add(row)
    for key in ('name', 'status', 'commission_bps', 'cookie_days', 'min_payout_minor', 'currency'):
        if key in data:
            setattr(row, key, data[key])
    if not (0 <= int(row.commission_bps) <= 5000):
        raise AppError(400, 'AFFILIATE_RATE_INVALID', 'Commission must be between 0% and 50%')
    db.commit()
    return json_model(row)


@router.post('/affiliate/partners')
def create_affiliate_partner(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'settings.manage')
    program = db.query(AffiliateProgram).filter_by(tenant_id=tenant_id).first()
    if not program:
        program = AffiliateProgram(tenant_id=tenant_id)
        db.add(program); db.flush()
    code = str(data.get('code') or secrets.token_urlsafe(6)).upper().replace('_', '').replace('-', '')[:20]
    if db.query(AffiliatePartner).filter_by(tenant_id=tenant_id, code=code).first():
        raise AppError(409, 'AFFILIATE_CODE_EXISTS', 'Affiliate code already exists')
    row = AffiliatePartner(tenant_id=tenant_id, program_id=program.id, code=code,
                           name=str(data.get('name') or code), email=str(data.get('email') or ''))
    db.add(row); db.commit()
    return json_model(row) | {'link_path': f'/v1/public/affiliate/{tenant_id}/{code}'}


@router.get('/affiliate/partners')
def list_affiliate_partners(tenant_id: str, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'finance.read')
    rows = db.query(AffiliatePartner).filter_by(tenant_id=tenant_id).order_by(AffiliatePartner.created_at.desc()).all()
    return {'items': [json_model(x) for x in rows]}


@router.get('/public/affiliate/{tenant_id}/{code}')
def affiliate_click(tenant_id: str, code: str, request: Request, response: Response, path: str = '/', db: DBSession = Depends(get_db)):
    program = db.query(AffiliateProgram).filter_by(tenant_id=tenant_id, status='ACTIVE').first()
    partner = db.query(AffiliatePartner).filter_by(tenant_id=tenant_id, code=code.upper(), status='ACTIVE').first()
    if not program or not partner:
        raise not_found('Affiliate link not found')
    visitor = request.cookies.get('live_visitor') or secrets.token_urlsafe(18)
    referral = AffiliateReferral(tenant_id=tenant_id, partner_id=partner.id, visitor_key_hash=token_hash(visitor), landing_path=path[:2000])
    db.add(referral); db.commit()
    target = path if path.startswith('/') else '/'
    redirect = RedirectResponse(target, status_code=302)
    redirect.set_cookie('affiliate_code', partner.code, max_age=program.cookie_days * 86400, httponly=False, samesite='lax', secure=get_settings().COOKIE_SECURE)
    return redirect


@router.get('/affiliate/commissions')
def affiliate_commissions(tenant_id: str, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    _assert_permission(tenant_id, user, db, 'finance.read')
    rows = db.query(AffiliateCommission).filter_by(tenant_id=tenant_id).order_by(AffiliateCommission.created_at.desc()).limit(200).all()
    return {'items': [json_model(x) for x in rows]}


@router.get('/recommendations/{product_id}')
def recommendations(product_id: str, tenant_id: str, limit: int = 6, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _tenant(tenant_id, user, db)
    p = db.query(Product).filter_by(id=product_id, tenant_id=tenant_id, deleted_at=None).first()
    if not p:
        raise not_found('Product not found')
    candidates = db.query(Product).filter(Product.tenant_id == tenant_id, Product.id != product_id,
                                          Product.status == 'ACTIVE', Product.deleted_at.is_(None)).limit(100).all()
    p_tokens = set(re.findall(r'[^\W_]+', f'{p.title} {p.description or ""}'.lower(), flags=re.UNICODE))
    scored = []
    for c in candidates:
        c_tokens = set(re.findall(r'[^\W_]+', f'{c.title} {c.description or ""}'.lower(), flags=re.UNICODE))
        overlap = len(p_tokens & c_tokens)
        scored.append((overlap, c))
    scored.sort(key=lambda x: (-x[0], x[1].created_at), reverse=False)
    return {'items': [json_model(x) for _, x in scored[:max(1, min(limit, 12))]]}
