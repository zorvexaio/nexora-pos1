from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Header, Request, Response, Form
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func, update
from app.core.database import get_db, set_tenant_context
from app.core.security import *
from app.core.auth import current_user, optional_user, tenant_user, bind_tenant_context, require_permission, current_platform_admin, current_platform_compliance_officer, issue_mfa_recovery_codes, api_key_context, assert_permission
from app.core.errors import AppError, not_found, forbidden
from app.models.domain import *
SessionModel = globals()['Session']
from app.schemas.api import *
from app.core.config import get_settings
import hmac, uuid, secrets, urllib.parse, httpx, logging, hashlib
logger = logging.getLogger('unified_commerce')
from app.services.core import audit, outbox, idem, finalize_idem, body_hash, ensure_seed, enforce_rate_limit, post_ledger_entry, post_split_ledger_entry, resolve_variant_price, calculate_coupon_discount, resolve_variant_price_details, get_entitlement, require_entitlement, begin_payment_operation, complete_payment_operation, fail_payment_operation, claim_webhook_event, quarantine_provider_ingest_event, bind_provider_tenant, resolve_provider_tenant
from app.services.payment_providers import get_payment_provider, PaddleBillingProvider
from app.services.order_state import transition
from app.security.policy import normalize_hostname, verification_txt_name, verify_dns_txt
from app.core.guest import commerce_actor, guest_cart, CustomerActor, customer_session_actor
from app.core.serialization import json_model, audit_event_view, EXPLICIT_SENSITIVE_FIELDS
from app.services.merchant_trust import start_identity_verification, apply_identity_decision, add_risk_event, open_review_case, recalc_merchant_risk, verify_hmac_sha256
from app.services.privacy import record_consent_event, latest_consent, submit_privacy_request, privacy_profile, jurisdiction_for_country, create_privacy_access_grant, revoke_privacy_access_grant, open_privacy_incident, update_privacy_incident, privacy_export_payload, safe_merchant_verification_view, safe_merchant_profile_view
router = APIRouter(prefix='/v1')

def tenant_scope(tenant_id, user, db):
    return bind_tenant_context(tenant_id, user, db)

def provider_credentials(tenant_id: str, provider: str, db):
    row = db.query(MerchantPaymentAccount).filter_by(tenant_id=tenant_id, provider=provider,
        status='ACTIVE').first()
    if row and row.credentials_encrypted:
        try:
            return __import__('json').loads(decrypt_secret(row.credentials_encrypted))
        except Exception as exc:
            raise AppError(500, 'PROVIDER_CREDENTIALS_INVALID',
                'Stored provider credentials could not be decrypted') from exc
    return {}

def assert_cart_owner(cart, actor, guest, db):
    if not cart:
        raise not_found('Cart not found')
    if actor is None:
        if not guest or cart.guest_session_id != guest.id:
            raise forbidden('Guest cart access denied')
        return
    customer = db.query(Customer).filter_by(id=cart.customer_id,
        tenant_id=cart.tenant_id).first() if cart.customer_id else None
    if not customer or customer.email.lower() != actor.email.lower():
        raise forbidden('Cart access denied')

def require_if_match(obj, if_match: str | None):
    if if_match is None:
        raise AppError(428, 'IF_MATCH_REQUIRED', 'If-Match version is required for this mutation')
    value = if_match.strip().strip('"')
    try:
        expected = int(value)
    except ValueError:
        raise AppError(400, 'IF_MATCH_INVALID', 'If-Match must contain an integer resource version')
    if int(getattr(obj, 'version', 1)) != expected:
        raise AppError(412, 'VERSION_CONFLICT', 'Resource was modified by another request')
    obj.version = int(getattr(obj, 'version', 1)) + 1
SENSITIVE_FIELDS = EXPLICIT_SENSITIVE_FIELDS
# NOTE: register/login/mfa-verify-login/logout/sessions/me/password-reset were
# extracted to app/routes/auth_routes.py (Phase 3 of the monolith split).

def idem_start(db, tenant_id, actor_id, endpoint, key, payload):
    if not key:
        return None
    rec, ok = idem(db, tenant_id, actor_id, endpoint, key, body_hash(payload))
    if not ok:
        raise AppError(409, 'IDEMPOTENCY_MISMATCH',
            'Same idempotency key used with a different request')
    if rec and rec.status == 'COMPLETED':
        return rec
    return rec

def idem_return(rec, body, status, db):
    if rec:
        finalize_idem(rec, body, status)
    return body

SUPPORTED_SHIPPING_CARRIERS = {
    'platform': 'Rilmo Shipping',
    'yurtici': 'Yurtiçi Kargo',
    'aras': 'Aras Kargo',
    'mng': 'MNG Kargo',
    'ptt': 'PTT Kargo',
    'dhl': 'DHL',
    'ups': 'UPS',
    'fedex': 'FedEx',
    'aramex': 'Aramex',
    'gls': 'GLS',
    'dpd': 'DPD',
    'usps': 'USPS',
    'royal_mail': 'Royal Mail',
    'canada_post': 'Canada Post',
    'australia_post': 'Australia Post',
}

def _validate_shipping_offer(data: ShippingIn):
    code = data.carrier_code.strip().lower()
    if code not in SUPPORTED_SHIPPING_CARRIERS:
        raise AppError(400, 'SHIPPING_CARRIER_UNSUPPORTED', 'Unsupported shipping carrier')
    if data.free_shipping_threshold_minor is not None and not data.free_shipping:
        raise AppError(400, 'FREE_SHIPPING_THRESHOLD_REQUIRES_FREE_SHIPPING', 'Enable free shipping to use a free-shipping threshold')
    if data.estimated_days_min is not None and data.estimated_days_max is not None and data.estimated_days_max < data.estimated_days_min:
        raise AppError(400, 'SHIPPING_ESTIMATE_INVALID', 'Maximum estimated days cannot be below minimum estimated days')
    return code

def _shipping_public_view(method, subtotal_minor: int | None = None):
    subtotal = int(subtotal_minor or 0)
    qualifies = bool(method.free_shipping and (method.free_shipping_threshold_minor is None or subtotal >= int(method.free_shipping_threshold_minor)))
    amount = 0 if qualifies else int(method.amount_minor)
    return {
        'id': method.id, 'name': method.name, 'carrier_code': method.carrier_code,
        'carrier_name': SUPPORTED_SHIPPING_CARRIERS.get(method.carrier_code, method.carrier_code),
        'service_code': method.service_code, 'currency': method.currency,
        'amount_minor': amount, 'original_amount_minor': int(method.amount_minor),
        'free_shipping': qualifies, 'free_shipping_threshold_minor': method.free_shipping_threshold_minor,
        'offer_label': method.offer_label, 'estimated_days_min': method.estimated_days_min,
        'estimated_days_max': method.estimated_days_max, 'is_active': method.is_active,
    }

def _tenant_membership_or_403(tenant_id, user, db):
    return bind_tenant_context(tenant_id, user, db)

def _merchant_profile_complete(profile):
    if not profile or not all([profile.legal_name, profile.phone, profile.country_code, profile.city, profile.address_line1]):
        return False
    btype=(profile.business_type or 'individual').lower()
    if btype != 'individual':
        return bool(profile.tax_id and profile.registration_number and profile.business_registry_country and profile.beneficial_owner_name and profile.beneficial_owner_country)
    return bool(profile.beneficial_owner_name or profile.legal_name)

def _merchant_business_verification_complete(profile):
    return bool(profile and profile.kyb_status == 'VERIFIED' and profile.kyb_verified_at and profile.kyb_evidence_hash)

def _merchant_payment_ready(db, tenant_id):
    return db.query(MerchantPaymentAccount).filter_by(tenant_id=tenant_id,status='ACTIVE',charges_enabled=True,payouts_enabled=True).first() is not None

def _google_verified(db, user_id):
    return db.query(UserIdentity).filter_by(user_id=user_id, provider='google').filter(UserIdentity.email_verified_at.is_not(None)).first() is not None

def _ensure_trust_score(db, tenant_id):
    score = db.query(MerchantTrustScore).filter_by(tenant_id=tenant_id).first()
    if not score:
        score = MerchantTrustScore(tenant_id=tenant_id)
        db.add(score)
        db.flush()
    reviews = db.query(TenantReview).filter_by(tenant_id=tenant_id, status='APPROVED').all()
    reports = db.query(TrustReport).filter_by(tenant_id=tenant_id).all()
    avg = (sum(r.rating for r in reviews) / len(reviews)) if reviews else 0.0
    open_reports = sum(1 for r in reports if r.status in {'OPEN','UNDER_REVIEW'})
    resolved_reports = sum(1 for r in reports if r.status == 'RESOLVED')
    verified = db.query(MerchantProfile).filter_by(tenant_id=tenant_id, identity_status='VERIFIED').first() is not None
    review_component = int(round(avg * 16)) if reviews else 0
    base = 40 + review_component + (15 if verified else 0) + min(10, len(reviews))
    penalty = min(45, open_reports * 7 + resolved_reports * 2)
    score.trust_score = max(0, min(100, base - penalty))
    score.rating_average = round(avg,2)
    score.rating_count = len(reviews)
    score.report_count = len(reports)
    score.resolved_report_count = resolved_reports
    if score.trust_score >= 90:
        score.trust_level='EXCELLENT'; score.badge='TOP_RATED'
    elif score.trust_score >= 80:
        score.trust_level='TRUSTED'; score.badge='VERIFIED_STORE'
    elif score.trust_score >= 60:
        score.trust_level='GOOD'; score.badge='GOOD_STANDING'
    else:
        score.trust_level='WATCH'; score.badge='UNDER_REVIEW'
    score.updated_at=datetime.now(timezone.utc)
    db.flush()
    return score

def _merchant_gate(db, tenant_id, user):
    s=get_settings(); profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    google=_google_verified(db,user.id)
    if s.REQUIRE_MERCHANT_PROFILE and not _merchant_profile_complete(profile):
        raise AppError(428,'MERCHANT_PROFILE_REQUIRED','Complete your legal and contact information first')
    if s.REQUIRE_MERCHANT_PHONE and not (profile and profile.phone_verified_at):
        raise AppError(428,'MERCHANT_PHONE_REQUIRED','Verify your merchant phone number first')
    if s.REQUIRE_MERCHANT_GOOGLE and not google:
        raise AppError(428,'MERCHANT_GOOGLE_REQUIRED','Link a verified Google account before activation')
    if s.REQUIRE_MERCHANT_IDENTITY and (not profile or profile.kyc_status != 'VERIFIED' or profile.identity_status != 'VERIFIED'):
        code = 'MERCHANT_IDENTITY_REJECTED' if profile and profile.kyc_status == 'DECLINED' else 'MERCHANT_IDENTITY_REVIEW_REQUIRED'
        raise AppError(428, code, 'Merchant identity verification must be completed before activation')
    if not _merchant_business_verification_complete(profile):
        raise AppError(428,'MERCHANT_KYB_REQUIRED','Business verification must be completed before the store can sell')
    if not _merchant_payment_ready(db, tenant_id):
        raise AppError(428,'MERCHANT_PAYMENT_ONBOARDING_REQUIRED','A verified payment account with charges and payouts enabled is required before the store can sell')
    recalc_merchant_risk(db, tenant_id)
    if profile and profile.review_required:
        raise AppError(423, 'MERCHANT_REVIEW_REQUIRED', 'Merchant account is under compliance review')
    if profile and profile.payout_hold:
        raise AppError(423, 'MERCHANT_PAYOUT_HOLD', 'Merchant payout capability is currently on hold')
    score=_ensure_trust_score(db,tenant_id)
    if s.REQUIRE_TRUST_MINIMUM_TO_PUBLISH and score.trust_score < s.MERCHANT_MIN_TRUST_SCORE_TO_PUBLISH:
        raise AppError(403,'MERCHANT_TRUST_TOO_LOW','Merchant trust score is below the publishing threshold')
    return profile, score

