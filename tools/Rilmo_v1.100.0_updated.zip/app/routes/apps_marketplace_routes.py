"""Platform app marketplace routes: app definition CRUD (admin), app
installation, installation listing/revocation, and app webhook subscription.

Extracted out of app/routes/v1.py (Phase 3, step 4). Ends right before the
OAuth authorize/token routes, which use their own private helpers
(_app_client, _oauth_redirect) that this block does not need — those stay in
v1.py for now as a separate future step.
"""
import secrets, hmac
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db, set_tenant_context
from app.core.security import *
from app.core.auth import current_user, require_permission, current_platform_admin
from app.core.errors import AppError, not_found, forbidden
from app.models.domain import *
from app.schemas.api import *
from app.services.core import audit
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.post('/apps')
def create_app(data: AppCreateIn, admin=Depends(current_platform_admin),
    db: DBSession=Depends(get_db)):
    if db.query(AppDefinition).filter((AppDefinition.slug == data.slug) | (AppDefinition.client_id == data.slug)).first():
        raise AppError(409, 'APP_EXISTS', 'Application already exists')
    client_id = 'ugc_' + secrets.token_urlsafe(18)
    client_secret = secrets.token_urlsafe(36)
    app_def = AppDefinition(name=data.name, slug=data.slug, client_id=client_id,
     client_secret_hash=token_hash(client_secret),
     redirect_uris=data.redirect_uris,
        scopes=data.scopes, status='PENDING_REVIEW', publisher_name=data.publisher_name)
    db.add(app_def)
    db.commit()
    return {'id': app_def.id, 'client_id': client_id, 'client_secret': client_secret,
        'status': app_def.status, 'warning': 'Store the client secret now; it is never returned again'}

@router.get('/apps')
def list_apps(admin=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    return [{'id': a.id, 'name': a.name, 'slug': a.slug, 'client_id': a.client_id,
     'scopes': a.scopes,
        'status': a.status} for a in db.query(AppDefinition).order_by(AppDefinition.created_at.desc()).all()]

@router.post('/apps/{app_id}/approve')
def approve_app(app_id: str, admin=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    a = db.get(AppDefinition, app_id)
    if not a:
        raise not_found('App not found')
    a.status = 'APPROVED'
    db.commit()
    return {'id': a.id, 'status': a.status}

@router.post('/apps/install')
def install_app(tenant_id: str, data: AppInstallIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('apps.manage'))):
    tenant_scope(tenant_id, user, db)
    app_def = db.query(AppDefinition).filter_by(id=data.app_id, status='APPROVED').first()
    if not app_def:
        raise not_found('Approved app not found')
    requested = set(data.scopes)
    allowed = set(app_def.scopes)
    if not requested or not requested.issubset(allowed):
        raise AppError(400, 'APP_SCOPE_INVALID', 'Requested scopes exceed app-approved scopes')
    existing = db.query(AppInstallation).filter_by(tenant_id=tenant_id, app_id=app_def.id).first()
    if existing and existing.status == 'ACTIVE':
        raise AppError(409, 'APP_ALREADY_INSTALLED', 'App is already installed')
    raw = secrets.token_urlsafe(40)
    inst = existing or AppInstallation(tenant_id=tenant_id, app_id=app_def.id,
        granted_scopes=sorted(requested), access_token_hash=token_hash(raw), status='ACTIVE')
    if existing:
        existing.granted_scopes = sorted(requested)
        existing.access_token_hash = token_hash(raw)
        existing.status = 'ACTIVE'
        existing.revoked_at = None
    else:
        db.add(inst)
    db.flush()
    db.add(AppAccessToken(tenant_id=tenant_id, installation_id=inst.id, token_hash=token_hash(raw),
        scopes=inst.granted_scopes, expires_at=datetime.now(timezone.utc) + timedelta(hours=1)))
    db.commit()
    return {'installation_id': inst.id, 'access_token': raw, 'expires_in': 3600,
        'scopes': inst.granted_scopes}

@router.get('/apps/installations')
def list_installations(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    rows = db.query(AppInstallation, AppDefinition).join(AppDefinition,
     AppDefinition.id == AppInstallation.app_id).filter(AppInstallation.tenant_id == tenant_id,
        AppInstallation.status == 'ACTIVE').all()
    return [{'id': i.id, 'app_id': a.id, 'name': a.name, 'publisher_name': a.publisher_name, 'scopes': i.granted_scopes,
        'installed_at': i.installed_at.isoformat(), 'last_used_at': i.last_used_at.isoformat() if i.last_used_at else None} for i, a in rows]

@router.post('/apps/installations/{installation_id}/revoke')
def revoke_app_installation(tenant_id: str, installation_id: str, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('apps.manage'))):
    tenant_scope(tenant_id, user, db)
    inst = db.query(AppInstallation).filter_by(id=installation_id, tenant_id=tenant_id).first()
    if not inst:
        raise not_found('App installation not found')
    inst.status='REVOKED'; inst.revoked_at=datetime.now(timezone.utc)
    db.query(AppAccessToken).filter_by(installation_id=inst.id, tenant_id=tenant_id, revoked_at=None).update({'revoked_at':datetime.now(timezone.utc)})
    db.query(AppRefreshToken).filter_by(installation_id=inst.id, tenant_id=tenant_id, revoked_at=None).update({'revoked_at':datetime.now(timezone.utc)})
    audit(db, tenant_id, user.id, 'app.installation.revoke', 'AppInstallation', inst.id, after={'status':'REVOKED'})
    db.commit()
    return {'ok':True,'installation_id':inst.id,'status':inst.status}

@router.post('/apps/installations/{installation_id}/webhooks')
def subscribe_app_webhook(tenant_id: str, installation_id: str, data: AppWebhookIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('apps.manage'))):
    tenant_scope(tenant_id, user, db)
    inst = db.query(AppInstallation).filter_by(id=installation_id, tenant_id=tenant_id,
        status='ACTIVE').first()
    if not inst:
        raise not_found('App installation not found')
    if 'webhooks.write' not in set(inst.granted_scopes):
        raise forbidden('App lacks webhooks.write scope')
    from urllib.parse import urlparse
    import ipaddress, socket
    parsed = urlparse(data.endpoint_url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or (parsed.port in {80,
        443}):
        raise AppError(400, 'WEBHOOK_ENDPOINT_INVALID',
            'Webhook endpoint must be a public HTTPS URL')
    host = parsed.hostname.lower().rstrip('.')
    try:
        addresses = {ipaddress.ip_address(info[4][0]) for info in socket.getaddrinfo(host, 443,
            type=socket.SOCK_STREAM)}
    except OSError as exc:
        raise AppError(400, 'WEBHOOK_DNS_INVALID',
            'Webhook hostname could not be resolved') from exc
    if not addresses or any((not a.is_global for a in addresses)):
        raise AppError(400, 'WEBHOOK_PRIVATE_NETWORK',
            'Webhook endpoint must resolve only to globally routable IP addresses')
    secret = secrets.token_urlsafe(32)
    sub = AppWebhookSubscription(tenant_id=tenant_id, installation_id=installation_id,
     event_type=data.event_type,
     endpoint_url=data.endpoint_url,
        secret_hash=token_hash(secret), secret_encrypted=encrypt_secret(secret))
    db.add(sub)
    db.commit()
    return {'id': sub.id, 'event_type': sub.event_type, 'endpoint_url': sub.endpoint_url,
        'secret': secret}

def _app_bearer(request: Request, db: DBSession, scope: str | None=None):
    raw = request.headers.get('Authorization', '')
    if not raw.lower().startswith('bearer '):
        raise AppError(401, 'APP_TOKEN_REQUIRED', 'Bearer token required')
    token = raw.split(' ', 1)[1].strip()
    now = datetime.now(timezone.utc)
    at = db.query(AppAccessToken).filter_by(token_hash=token_hash(token), revoked_at=None).first()
    if not at:
        raise AppError(401, 'APP_TOKEN_INVALID', 'Invalid application access token')
    expires = at.expires_at.replace(tzinfo=timezone.utc) if at.expires_at and at.expires_at.tzinfo is None else at.expires_at
    if expires <= now:
        raise AppError(401, 'APP_TOKEN_EXPIRED', 'Application access token expired')
    inst = db.query(AppInstallation).filter_by(id=at.installation_id, tenant_id=at.tenant_id,
        status='ACTIVE').first()
    if not inst:
        raise AppError(401, 'APP_INSTALLATION_INVALID', 'Application installation is not active')
    if scope and scope not in set(at.scopes or []):
        raise AppError(403, 'APP_SCOPE_REQUIRED', f'Required scope: {scope}')
    inst.last_used_at = now
    set_tenant_context(db, at.tenant_id)
    return inst

@router.get('/apps/api/v1/tenant')
def app_api_tenant(request: Request, db: DBSession=Depends(get_db)):
    inst = _app_bearer(request, db, 'store.read')
    tenant = db.query(Tenant).filter_by(id=inst.tenant_id).first()
    if not tenant:
        raise not_found('Tenant not found')
    return {'id': tenant.id, 'name': tenant.name, 'slug': tenant.slug,
        'currency': tenant.default_currency, 'locale': tenant.default_locale, 'app_id': inst.app_id}
