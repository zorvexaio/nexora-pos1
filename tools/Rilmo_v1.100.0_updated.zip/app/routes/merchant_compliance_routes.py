"""Merchant onboarding/compliance routes: profile, phone verification, identity
(KYC) start/status/webhook, risk signals/actions, business verification (KYB),
payment-account decisions, activation readiness — plus the closely-related
platform merchant-review-case endpoints they feed into.

Extracted out of app/routes/v1.py (Phase 3, step 3). The gating helpers this
block depends on (_tenant_membership_or_403, _ensure_trust_score,
_google_verified, _merchant_profile_complete,
_merchant_business_verification_complete, _merchant_payment_ready) are also
used by unrelated route groups still living in v1.py (e.g. subscription and
public-storefront-trust routes), so they stay defined there and are imported
here rather than duplicated.
"""
import hmac, hashlib
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.security import *
from app.core.auth import current_user, require_permission, tenant_user, current_platform_admin, current_platform_compliance_officer
from app.core.errors import AppError, not_found, forbidden
from app.models.domain import *
from app.schemas.api import *
from app.core.config import get_settings
from app.core.serialization import json_model
from app.services.core import audit, body_hash, enforce_rate_limit
from app.services.merchant_trust import start_identity_verification, apply_identity_decision, add_risk_event, open_review_case, recalc_merchant_risk, verify_hmac_sha256
from app.services.privacy import safe_merchant_verification_view, safe_merchant_profile_view
from app.routes.v1 import (tenant_scope, _tenant_membership_or_403, _ensure_trust_score, _google_verified,
    _merchant_profile_complete, _merchant_business_verification_complete, _merchant_payment_ready)

router = APIRouter(prefix='/v1')


@router.get('/merchant/profile')
def merchant_profile(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _tenant_membership_or_403(tenant_id,user,db)
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    score=_ensure_trust_score(db,tenant_id); db.commit()
    return {'profile': json_model(profile) if profile else None, 'google_verified': _google_verified(db,user.id), 'trust': json_model(score)}

@router.put('/merchant/profile')
def update_merchant_profile(tenant_id: str, data: MerchantProfileIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    _tenant_membership_or_403(tenant_id,user,db)
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    if not profile:
        profile=MerchantProfile(tenant_id=tenant_id); db.add(profile)
    for k,v in data.model_dump().items(): setattr(profile,k,v.upper() if k in {'country_code','business_registry_country','beneficial_owner_country'} and v else v)
    if not profile.beneficial_owner_name:
        profile.beneficial_owner_name=profile.legal_name
    if not profile.beneficial_owner_country:
        profile.beneficial_owner_country=profile.country_code.upper()
    profile.identity_status='PENDING'
    profile.payout_hold=True
    profile.review_required=True
    profile.trust_lock_reason='MERCHANT_PROFILE_CHANGED'
    profile.kyb_status='NOT_STARTED'
    profile.kyb_verified_at=None
    profile.kyb_verification_method=None
    profile.kyb_evidence_hash=None
    profile.updated_at=datetime.now(timezone.utc)
    db.commit()
    membership=tenant_user(tenant_id,user,db)
    return {'profile':safe_merchant_profile_view(profile, viewer_role=membership.role, include_private=True),'message':'Profile saved; verification review is required.'}

@router.post('/merchant/phone/send')
def merchant_phone_send(tenant_id: str, data: PhoneVerifyRequestIn, request: Request, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    _tenant_membership_or_403(tenant_id,user,db)
    enforce_rate_limit(db, 'merchant:phone:'+tenant_id+':'+str(request.client.host if request.client else 'unknown'), get_settings().MERCHANT_PHONE_RATE_LIMIT_PER_MINUTE)
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    if not profile: raise AppError(428,'MERCHANT_PROFILE_REQUIRED','Complete the merchant profile first')
    raw=random_token(8).replace('_','').replace('-','')[:6].upper()
    row=db.query(MerchantPhoneVerification).filter_by(tenant_id=tenant_id, phone=data.phone).first()
    now=datetime.now(timezone.utc)
    if not row: row=MerchantPhoneVerification(tenant_id=tenant_id,phone=data.phone,code_hash=token_hash(raw)); db.add(row)
    else: row.code_hash=token_hash(raw); row.attempts=0; row.used_at=None
    row.expires_at=now+timedelta(minutes=get_settings().MERCHANT_PHONE_CODE_TTL_MINUTES)
    profile.phone=data.phone; db.commit()
    # In development/tests the code is returned for deterministic local setup; production must use an SMS provider.
    if get_settings().SMS_PROVIDER == 'none':
        if get_settings().ENVIRONMENT in {'development','test'}:
            return {'ok':True,'expires_in':get_settings().MERCHANT_PHONE_CODE_TTL_MINUTES*60,'dev_code':raw}
        raise AppError(503,'SMS_PROVIDER_NOT_CONFIGURED','Phone verification delivery is not configured')
    try:
        from app.services.sms import send_verification_sms
        send_verification_sms(data.phone, raw, get_settings().MERCHANT_PHONE_CODE_TTL_MINUTES)
    except Exception as exc:
        db.rollback()
        raise AppError(503,'SMS_DELIVERY_FAILED','Verification SMS could not be delivered') from exc
    return {'ok':True,'expires_in':get_settings().MERCHANT_PHONE_CODE_TTL_MINUTES*60}

@router.post('/merchant/phone/verify')
def merchant_phone_verify(tenant_id: str, data: PhoneVerifyConfirmIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    _tenant_membership_or_403(tenant_id,user,db)
    row=db.query(MerchantPhoneVerification).filter_by(tenant_id=tenant_id,used_at=None).order_by(MerchantPhoneVerification.created_at.desc()).with_for_update().first()
    now=datetime.now(timezone.utc)
    if not row or (row.expires_at.replace(tzinfo=timezone.utc) if row.expires_at.tzinfo is None else row.expires_at) <= now:
        raise forbidden('Phone verification expired')
    if row.attempts >= get_settings().MERCHANT_PHONE_MAX_ATTEMPTS:
        raise forbidden('Phone verification locked')
    row.attempts+=1
    if not hmac.compare_digest(row.code_hash, token_hash(data.code)):
        db.commit(); raise forbidden('Invalid phone verification code')
    row.used_at=now
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    profile.phone_verified_at=now; profile.identity_status='PENDING'; db.commit()
    return {'ok':True,'verified_at':now.isoformat()}


@router.post('/merchant/identity/start')
def merchant_identity_start(tenant_id: str, data: MerchantIdentityStartIn, request: Request,
    user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    _tenant_membership_or_403(tenant_id, user, db)
    if not data.confirm_terms:
        raise AppError(400, 'IDENTITY_CONSENT_REQUIRED', 'Identity verification consent is required')
    enforce_rate_limit(db, 'merchant:identity:start:'+tenant_id+':'+str(request.client.host if request.client else 'unknown'), 3, 3600)
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    if not profile or not _merchant_profile_complete(profile):
        raise AppError(428, 'MERCHANT_PROFILE_REQUIRED', 'Complete the legal merchant profile first')
    row=start_identity_verification(db, tenant_id, user.id, country_code=data.country_code.upper(), full_name=data.full_name.strip(), request_host=str(request.base_url.hostname or ''))
    return {'verification':safe_merchant_verification_view(row, viewer_user_id=user.id),'next_action':'open_verification_url' if row.verification_url else 'provider_dashboard'}

@router.get('/merchant/identity/status')
def merchant_identity_status(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _tenant_membership_or_403(tenant_id, user, db)
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    row=db.query(MerchantIdentityVerification).filter_by(tenant_id=tenant_id).order_by(MerchantIdentityVerification.created_at.desc()).first()
    recalc_merchant_risk(db, tenant_id)
    db.commit()
    membership=_tenant_membership_or_403(tenant_id,user,db)
    if row and row.user_id != user.id:
        audit(db, tenant_id, user.id, 'privacy.kyc.status.view', 'MerchantIdentityVerification', row.id, after={'viewer_role':membership.role})
    return {'profile':safe_merchant_profile_view(profile, viewer_role=membership.role, include_private=(membership.role in {'owner','admin'} and row is not None and row.user_id == user.id)) if profile else None, 'verification':safe_merchant_verification_view(row, viewer_user_id=user.id) if row else None,
            'risk': {'score': profile.risk_score if profile else 100, 'level': profile.risk_level if profile else 'HIGH',
                     'review_required': bool(profile and profile.review_required), 'payout_hold': bool(profile and profile.payout_hold)}}

@router.post('/merchant/risk-signal')
def merchant_risk_signal(tenant_id: str, data: MerchantRiskSignalIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    _tenant_membership_or_403(tenant_id, user, db)
    add_risk_event(db, tenant_id, data.event_type, severity=data.severity, score_delta=data.score_delta, source='merchant', metadata=data.metadata, dedupe_key=f'merchant:{tenant_id}:{data.event_type}:{body_hash(data.metadata)}', actor_id=user.id)
    profile=recalc_merchant_risk(db, tenant_id)
    if profile.risk_score >= get_settings().MERCHANT_RISK_HIGH_THRESHOLD:
        open_review_case(db, tenant_id, 'HIGH_RISK_SCORE', priority='HIGH', actor_id=user.id)
    db.commit()
    return {'risk':{'score':profile.risk_score,'level':profile.risk_level,'review_required':profile.review_required,'payout_hold':profile.payout_hold}}

@router.post('/merchant/risk-action')
def merchant_risk_action(tenant_id: str, data: MerchantRiskActionIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('finance.manage'))):
    _tenant_membership_or_403(tenant_id, user, db)
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    if not profile: raise not_found('Merchant profile not found')
    if data.action in {'FREEZE','HOLD_PAYOUT','REQUIRE_REVERIFICATION'}:
        profile.payout_hold=True; profile.review_required=True; profile.trust_lock_reason=data.reason
        if data.action=='REQUIRE_REVERIFICATION': profile.kyc_status='REVERIFICATION_REQUIRED'; profile.identity_status='PENDING'
        if data.action=='FREEZE': db.get(Tenant, tenant_id).status='SUSPENDED'
    elif data.action=='UNFREEZE':
        profile.review_required=False; profile.trust_lock_reason=None
        if profile.kyc_status!='VERIFIED': profile.payout_hold=True
        else: profile.payout_hold=False
        db.get(Tenant, tenant_id).status='ACTIVE'
    elif data.action=='RELEASE_PAYOUT':
        if profile.kyc_status!='VERIFIED' or profile.review_required or profile.risk_score>=get_settings().MERCHANT_RISK_HIGH_THRESHOLD:
            raise AppError(409,'PAYOUT_RELEASE_BLOCKED','Payout cannot be released while verification or risk gates are unresolved')
        profile.payout_hold=False
    add_risk_event(db, tenant_id, 'ADMIN_'+data.action, severity='HIGH' if data.action in {'FREEZE','REQUIRE_REVERIFICATION'} else 'WARN', source='platform', score_delta=10 if data.action in {'FREEZE','REQUIRE_REVERIFICATION'} else 0, metadata={'reason':data.reason}, dedupe_key=f'admin-action:{tenant_id}:{data.action}:{body_hash({'reason':data.reason})}', actor_id=user.id)
    audit(db, tenant_id, user.id, 'merchant.risk.action', 'MerchantProfile', profile.id, after={'action':data.action,'reason':data.reason,'payout_hold':profile.payout_hold,'review_required':profile.review_required})
    db.commit()
    membership=tenant_user(tenant_id,user,db)
    return {'profile':safe_merchant_profile_view(profile, viewer_role=membership.role, include_private=False),'tenant':json_model(db.get(Tenant,tenant_id))}

@router.get('/platform/merchant-review-cases')
def platform_merchant_review_cases(status: str='OPEN', limit: int=100, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(current_platform_admin)):
    rows=db.query(MerchantReviewCase).filter(MerchantReviewCase.status==status).order_by(MerchantReviewCase.created_at.asc()).limit(max(1,min(limit,200))).all()
    return {'items':[json_model(x) for x in rows]}

@router.patch('/platform/merchant-review-cases/{case_id}')
def platform_decide_merchant_review_case(case_id: str, data: MerchantReviewDecisionIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(current_platform_admin)):
    case=db.get(MerchantReviewCase, case_id)
    if not case: raise not_found('Merchant review case not found')
    profile=db.query(MerchantProfile).filter_by(tenant_id=case.tenant_id).first()
    if not profile: raise not_found('Merchant profile not found')
    now=datetime.now(timezone.utc)
    case.resolution=data.action; case.reviewer_note=data.note; case.assigned_user_id=user.id
    if data.action=='REVERIFY':
        case.status='OPEN'; case.resolved_at=None
    else:
        case.status='RESOLVED'; case.resolved_at=now
    if data.action=='APPROVE':
        if profile.kyc_status != 'VERIFIED': raise AppError(409,'KYC_NOT_VERIFIED','A compliance reviewer cannot bypass provider identity verification')
        profile.review_required=False; profile.trust_lock_reason=None; profile.payout_hold=False
    elif data.action=='REJECT':
        profile.review_required=False; profile.payout_hold=True; profile.kyc_status='DECLINED'; profile.identity_status='REJECTED'; profile.trust_lock_reason='MANUAL_REJECTION'; db.get(Tenant,case.tenant_id).status='SUSPENDED'
    elif data.action=='REVERIFY':
        profile.review_required=True; profile.payout_hold=True; profile.kyc_status='REVERIFICATION_REQUIRED'; profile.identity_status='PENDING'
        open_review_case(db, case.tenant_id, 'REVERIFICATION_REQUIRED', verification_id=case.verification_id, priority='HIGH', actor_id=user.id)
    add_risk_event(db, case.tenant_id, 'MANUAL_REVIEW_'+data.action, severity='HIGH' if data.action=='REJECT' else 'WARN', source='platform', score_delta=20 if data.action=='REJECT' else 0, metadata={'case_id':case.id}, dedupe_key=f'case-decision:{case.id}:{data.action}', actor_id=user.id)
    audit(db, case.tenant_id, user.id, 'merchant.review.decided', 'MerchantReviewCase', case.id, after={'action':data.action,'note':data.note})
    db.commit()
    return {'case':json_model(case),'profile':safe_merchant_profile_view(profile, viewer_role='viewer', include_private=False)}

@router.post('/merchant/identity/veriff/webhook')
async def veriff_identity_webhook(request: Request, db: DBSession=Depends(get_db)):
    s=get_settings()
    raw=await request.body()
    signature=request.headers.get('x-hmac-signature','')
    client_key=request.headers.get('x-auth-client','')
    if s.MERCHANT_KYC_PROVIDER!='veriff' or not verify_hmac_sha256(raw, signature, s.VERIFF_SHARED_SECRET):
        raise AppError(401,'KYC_WEBHOOK_SIGNATURE_INVALID','Invalid identity provider webhook signature')
    if client_key and client_key != s.VERIFF_API_KEY:
        raise AppError(401,'KYC_WEBHOOK_CLIENT_INVALID','Invalid identity provider client')
    if len(raw) > s.MAX_WEBHOOK_BODY_BYTES:
        raise AppError(413,'KYC_WEBHOOK_TOO_LARGE','Webhook body is too large')
    try:
        payload=__import__('json').loads(raw.decode('utf-8'))
    except Exception as exc:
        raise AppError(400,'KYC_WEBHOOK_INVALID_JSON','Invalid webhook payload') from exc
    verification=payload.get('verification') or {}
    external_id=str(verification.get('id') or payload.get('id') or '')
    decision=str(verification.get('status') or payload.get('status') or '').upper()
    event_id=str(payload.get('id') or verification.get('attemptId') or '')
    if not external_id or not decision:
        return {'ok':True,'ignored':True}
    mapping={'APPROVED':'APPROVED','DECLINED':'DECLINED','RESUBMISSION_REQUESTED':'REVIEW','ABANDONED':'ABANDONED','EXPIRED':'EXPIRED','REVIEW':'REVIEW'}
    apply_identity_decision(db, provider='veriff', external_id=external_id, event_id=event_id, decision=mapping.get(decision, decision), status=decision, risk_level=str((verification.get('risk') or {}).get('level') or ''), metadata={'event_id':event_id,'status':decision})
    return {'ok':True}

@router.post('/merchant/business-verification/submit')
def submit_merchant_business_verification(tenant_id: str, data: MerchantBusinessVerificationSubmitIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    _tenant_membership_or_403(tenant_id,user,db)
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    if not profile or not _merchant_profile_complete(profile):
        raise AppError(428,'MERCHANT_PROFILE_REQUIRED','Complete all legal business information before submitting verification')
    if not data.confirm_truthfulness:
        raise AppError(400,'MERCHANT_TRUTHFULNESS_CONFIRMATION_REQUIRED','Confirm that the merchant information is truthful and current')
    profile.kyb_status='SUBMITTED'
    profile.kyb_verification_method=data.verification_method
    profile.kyb_evidence_hash=hashlib.sha256(data.evidence_reference.encode()).hexdigest()
    profile.kyb_verified_at=None
    profile.payout_hold=True
    profile.review_required=True
    profile.trust_lock_reason='KYB_PENDING'
    open_review_case(db,tenant_id,'KYB_SUBMITTED',priority='HIGH',actor_id=user.id)
    audit(db,tenant_id,user.id,'merchant.kyb.submitted','MerchantProfile',profile.id,after={'method':data.verification_method,'status':'SUBMITTED'})
    db.commit()
    return {'status':'SUBMITTED','message':'Business verification submitted. The store remains unavailable for selling until verification is approved.'}

@router.post('/merchant/payment-account/decision')
def merchant_payment_account_decision(tenant_id: str, provider: str, data: MerchantPaymentAccountDecisionIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(current_platform_compliance_officer)):
    _tenant_membership_or_403(tenant_id,user,db)
    row=db.query(MerchantPaymentAccount).filter_by(tenant_id=tenant_id,provider=provider.lower()).first()
    if not row:
        raise not_found('Payment account not found')
    row.provider_account_id=data.provider_account_id
    row.requirements_due=data.requirements_due
    if data.action=='APPROVE':
        row.status='ACTIVE'; row.charges_enabled=True; row.payouts_enabled=True
    elif data.action=='REVERIFY':
        row.status='PENDING'; row.charges_enabled=False; row.payouts_enabled=False
    else:
        row.status='REJECTED'; row.charges_enabled=False; row.payouts_enabled=False
    audit(db,tenant_id,user.id,'merchant.payment_account.decision','MerchantPaymentAccount',row.id,after={'provider':row.provider,'status':row.status,'charges_enabled':row.charges_enabled,'payouts_enabled':row.payouts_enabled,'evidence_reference_sha256':hashlib.sha256(data.evidence_reference.encode()).hexdigest()})
    db.commit()
    return {'id':row.id,'provider':row.provider,'status':row.status,'charges_enabled':row.charges_enabled,'payouts_enabled':row.payouts_enabled}

@router.get('/merchant/activation-readiness')
def activation_readiness(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _tenant_membership_or_403(tenant_id,user,db)
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    score=_ensure_trust_score(db,tenant_id)
    google=_google_verified(db,user.id)
    checks={
        'profile':_merchant_profile_complete(profile),
        'phone_verified':bool(profile and profile.phone_verified_at),
        'google_verified':google,
        'identity_verified':bool(profile and profile.identity_status=='VERIFIED' and profile.kyc_status=='VERIFIED'),
        'kyc_status': bool(profile and profile.kyc_status=='VERIFIED'),
        'kyb_verified': _merchant_business_verification_complete(profile),
        'payment_account_ready': _merchant_payment_ready(db, tenant_id),
        'risk_acceptable': bool(profile and profile.risk_score < get_settings().MERCHANT_RISK_HIGH_THRESHOLD and not profile.review_required),
        'payout_hold_clear': bool(profile and not profile.payout_hold),
        'trust_threshold':score.trust_score>=get_settings().MERCHANT_MIN_TRUST_SCORE_TO_PUBLISH,
    }
    db.commit(); return {'ready':all(checks.values()),'checks':checks,'trust':json_model(score)}

@router.post('/merchant/payment-account/configure')
def configure_payment_account(tenant_id: str, data: ProviderAccountConfigIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id,user,db)
    provider=data.provider.lower().strip()
    required={'iyzico':{'api_key','secret_key'},'paytr':{'merchant_id','merchant_key','merchant_salt'},'cod':set()}
    if provider not in required: raise AppError(400,'PROVIDER_UNSUPPORTED','Merchant checkout supports only iyzico, PayTR, or cash-on-delivery')
    if not required[provider].issubset(data.credentials): raise AppError(400,'PROVIDER_CREDENTIALS_INCOMPLETE','Required provider credentials are missing')
    row=db.query(MerchantPaymentAccount).filter_by(tenant_id=tenant_id,provider=provider).first()
    if not row: row=MerchantPaymentAccount(tenant_id=tenant_id,provider=provider,status='PENDING'); db.add(row); db.flush()
    if provider=='cod':
        # Cash-on-delivery has no external processor to onboard with: it is a
        # local fulfillment/settlement choice the merchant is opting into, so
        # it activates immediately rather than sitting PENDING on a verification
        # step that will never arrive.
        row.credentials_encrypted=None; row.status='ACTIVE'; row.charges_enabled=True; row.payouts_enabled=True
        audit(db,tenant_id,user.id,'merchant_payment_account.configure','merchant_payment_account',row.id,after={'provider':provider,'status':row.status,'charges_enabled':True,'payouts_enabled':True})
        db.commit()
        return {'id':row.id,'provider':row.provider,'status':row.status,'charges_enabled':True,'payouts_enabled':True,'message':'Cash-on-delivery enabled for checkout.'}
    row.credentials_encrypted=encrypt_secret(__import__('json').dumps(data.credentials,separators=(',',':'),ensure_ascii=False)); row.status='PENDING'; row.charges_enabled=False; row.payouts_enabled=False
    audit(db,tenant_id,user.id,'merchant_payment_account.configure','merchant_payment_account',row.id,after={'provider':provider,'status':row.status,'charges_enabled':False,'payouts_enabled':False}); db.commit()
    return {'id':row.id,'provider':row.provider,'status':row.status,'charges_enabled':False,'payouts_enabled':False,'message':'Credentials stored; payment-provider onboarding and verification are required before acceptance of customer payments.'}

@router.get('/merchant/payment-accounts')
def payment_accounts(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id,user,db)
    return [json_model(x) for x in db.query(MerchantPaymentAccount).filter_by(tenant_id=tenant_id).order_by(MerchantPaymentAccount.provider).all()]

@router.post('/merchant/payment-account/{provider}/disable')
def disable_payment_account(tenant_id: str, provider: str, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id,user,db)
    provider=provider.lower().strip()
    row=db.query(MerchantPaymentAccount).filter_by(tenant_id=tenant_id,provider=provider).first()
    if not row: raise not_found('Payment account not found')
    row.status='DISABLED'; row.charges_enabled=False
    audit(db,tenant_id,user.id,'merchant_payment_account.disable','merchant_payment_account',row.id,after={'provider':provider,'status':'DISABLED','charges_enabled':False})
    db.commit()
    return {'id':row.id,'provider':row.provider,'status':row.status,'charges_enabled':False}

@router.get('/merchant/payment-account')
def payment_account(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id,user,db)
    rows=db.query(MerchantPaymentAccount).filter_by(tenant_id=tenant_id).order_by(MerchantPaymentAccount.provider).all()
    return {'accounts':[json_model(x) for x in rows]}
