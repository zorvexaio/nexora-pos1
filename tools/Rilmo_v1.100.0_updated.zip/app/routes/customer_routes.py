"""Customer routes: anonymize (GDPR-style), list — plus the consent-record
route, which lives in the same privacy/customer surface.

Extracted out of app/routes/v1.py (Phase 3, step 23).
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import audit
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.delete('/customers/{customer_id}/anonymize')
def anonymize_customer(customer_id: str, tenant_id: str, data: AnonymizeIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('customers.read'))):
    tenant_scope(tenant_id, user, db)
    if not data.confirm:
        raise AppError(400, 'CONFIRMATION_REQUIRED', 'Explicit confirmation required')
    c = db.query(Customer).filter_by(id=customer_id, tenant_id=tenant_id).first()
    if not c:
        raise not_found('Customer not found')
    c.email = None
    c.phone = None
    c.first_name = 'ANONYMIZED'
    c.last_name = 'ANONYMIZED'
    audit(db, tenant_id, user.id, 'customer.anonymize', 'customer', c.id,
        after={'anonymized': True})
    db.commit()
    return {'ok': True, 'customer_id': c.id}

@router.post('/consent')
def record_consent(tenant_id: str, data: dict, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    categories = data.get('categories_accepted')
    if not isinstance(categories, dict) or not categories.get('essential', False):
        raise AppError(400, 'CONSENT_INVALID', 'Essential consent category must remain enabled')
    allowed = {'essential', 'analytics', 'marketing', 'preferences'}
    if set(categories) - allowed:
        raise AppError(400, 'CONSENT_CATEGORIES_INVALID', 'Unknown consent category')
    row = ConsentRecord(tenant_id=tenant_id, customer_id=None,
     anonymous_id=data.get('anonymous_id'),
     categories_accepted={k: bool(categories.get(k,
     False)) for k in allowed},
     consent_version=str(data.get('consent_version',
        'v1')), policy_snapshot=str(data.get('policy_snapshot', 'P0 cookie policy')))
    db.add(row)
    db.commit()
    return {'ok': True, 'consent_id': row.id}

@router.get('/customers')
def list_customers(tenant_id: str, q: str='', limit: int=50, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    limit = max(1, min(limit, 100))
    term = q.strip()[:120]
    query = db.query(Customer).filter_by(tenant_id=tenant_id)
    if term:
        like = f'%{term}%'
        query = query.filter(Customer.email.ilike(like) | Customer.first_name.ilike(like) | Customer.last_name.ilike(like))
    rows = query.order_by(Customer.created_at.desc()).limit(limit).all()
    return {'items': [json_model(x) for x in rows], 'count': len(rows)}
