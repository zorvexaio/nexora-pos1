"""Order routes, part 1: get order detail, add tracking, public tracking
lookup, get tracking.

Extracted out of app/routes/v1.py (Phase 3, step 27). This is the first of
several passes over the `orders` domain — order creation, cancel, list,
shipments, ZATCA invoice, and order-returns are handled in later passes since
they are not contiguous with this block and each carries its own dependency
chain (checkout/payment/inventory coupling) that needs separate verification.
"""
import hmac
from fastapi import APIRouter, Depends, Header, Request, Response
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found, forbidden
from app.core.security import random_token, token_hash, decrypt_secret
from app.core.config import get_settings
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import outbox, idem, body_hash, finalize_idem
from app.services.order_state import transition
from app.routes.v1 import tenant_scope, idem_start
from app.routes.checkout_routes import checkout
from sqlalchemy import func

router = APIRouter(prefix='/v1')


@router.get('/orders/{order_id}')
def get_order(order_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    o = db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).first()
    if not o:
        raise not_found('Order not found')
    return {'order': json_model(o),
     'items': [json_model(i) for i in db.query(OrderItem).filter_by(order_id=o.id,
     tenant_id=tenant_id).all()],
     'addresses': [json_model(a) for a in db.query(OrderAddress).filter_by(order_id=o.id,
        tenant_id=tenant_id).all()]}

@router.post('/orders/{order_id}/tracking')
def add_tracking(order_id: str, tenant_id: str, data: dict, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.manage'))):
    tenant_scope(tenant_id, user, db)
    o = db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).first()
    if not o:
        raise not_found('Order not found')
    raw = random_token(32)
    tr = OrderTrackingReference(tenant_id=tenant_id, order_id=order_id, carrier=data.get('carrier'),
        tracking_number=data['tracking_number'], public_token_hash=token_hash(raw))
    db.add(tr)
    db.flush()
    outbox(db, tenant_id, 'order', order_id, 'order.tracking.updated', {'order_id': order_id,
        'tracking_reference_id': tr.id, 'carrier': tr.carrier, 'tenant_id': tenant_id})
    db.commit()
    return {'id': tr.id, 'tracking_number': tr.tracking_number, 'public_token': raw}

@router.get('/public/orders/tracking/{public_token}')
def public_tracking(public_token: str, db: DBSession=Depends(get_db)):
    row = db.query(OrderTrackingReference).filter(OrderTrackingReference.public_token_hash == token_hash(public_token)).first()
    if not row:
        raise not_found('Tracking not found')
    o = db.query(Order).filter_by(id=row.order_id, tenant_id=row.tenant_id).first()
    if not o:
        raise not_found('Tracking not found')
    return {'order_status': o.status, 'payment_status': o.payment_status,
     'fulfillment_status': o.fulfillment_status,
        'carrier': row.carrier, 'tracking_number': row.tracking_number}

@router.get('/orders/{order_id}/tracking')
def tracking(order_id: str, tenant_id: str, token: str | None=None, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    t = db.query(OrderTrackingReference).filter_by(order_id=order_id, tenant_id=tenant_id).first()
    if not t:
        raise not_found('Tracking not found')
    if token and (not hmac.compare_digest(token_hash(token), t.public_token_hash)):
        raise forbidden('Invalid tracking token')
    return json_model(t)

@router.post('/orders/{order_id}/shipments')
def create_shipment(order_id: str, tenant_id: str, data: ShipmentCreateIn,
 user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('orders.manage')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    order = db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).first()
    if not order:
        raise not_found('Order not found')
    payload = data.model_dump() if hasattr(data, 'model_dump') else data.__dict__
    rec, fresh = idem(db, tenant_id, user.id, f'POST /v1/orders/{order_id}/shipments',
        idempotency_key, body_hash(payload))
    if rec and not fresh:
        raise AppError(409, 'IDEMPOTENCY_MISMATCH', 'Idempotency key reused with different request')
    if rec and rec.status == 'COMPLETED':
        return rec.response_body
    from app.services.shipping import FlatRateCarrier, ConfiguredCarrier
    code = data.carrier_code.lower()
    carrier = None
    if code == 'platform':
        carrier = FlatRateCarrier(0, order.currency, data.service_code or 'standard')
    else:
        cfg = db.query(TurkeyCarrierConfig).filter_by(tenant_id=tenant_id, carrier_code=code,
            status='ACTIVE').first()
        account = db.query(CarrierAccount).filter_by(tenant_id=tenant_id, carrier_code=code,
            status='ACTIVE').first()
        cfg = cfg or account
        if not cfg or not cfg.api_base_url or not cfg.api_token_encrypted:
            raise AppError(503, 'CARRIER_NOT_CONFIGURED',
                'Requested carrier has not been configured for this tenant')
        carrier = ConfiguredCarrier(name=code, base_url=cfg.api_base_url,
            api_token=decrypt_secret(cfg.api_token_encrypted),
            rate_path=(cfg.metadata_json or {}).get('rate_path', '/rates'),
            shipment_path=(cfg.metadata_json or {}).get('shipment_path', '/shipments'),
            tracking_path=(cfg.metadata_json or {}).get('tracking_path', '/shipments/{tracking_number}'),
            timeout=get_settings().TURKEY_CARRIER_TIMEOUT_SECONDS)
    result = carrier.create_shipment(order_id=order.id, origin=data.origin,
        destination=data.destination, parcels=data.parcels, service=data.service_code or 'standard')
    shipment = Shipment(tenant_id=tenant_id, order_id=order.id, carrier_code=code,
        service_code=data.service_code,
        provider_shipment_id=str(result.get('shipment_id') or result.get('id') or '') or None,
        tracking_number=result.get('tracking_number'), label_url=result.get('label_url'),
        status=str(result.get('status', 'CREATED')).upper())
    db.add(shipment)
    db.flush()
    outbox(db, tenant_id, 'shipment', shipment.id, 'shipment.created',
        {'shipment_id': shipment.id, 'order_id': order.id, 'tenant_id': tenant_id, 'carrier': code})
    body = json_model(shipment)
    finalize_idem(rec, body, 200)
    db.commit()
    return body

@router.get('/orders/{order_id}/shipments')
def list_order_shipments(order_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.read'))):
    tenant_scope(tenant_id, user, db)
    if not db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).first():
        raise not_found('Order not found')
    rows = db.query(Shipment).filter_by(order_id=order_id, tenant_id=tenant_id).order_by(Shipment.created_at.desc()).all()
    return {'items': [json_model(x) for x in rows]}

@router.post('/orders/{order_id}/zatca/invoice')
def generate_zatca_invoice(order_id: str, tenant_id: str, data: ZatcaSellerIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.read'))):
    tenant_scope(tenant_id, user, db)
    order = db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).first()
    if not order:
        raise not_found('Order not found')
    existing = db.query(TaxInvoice).filter_by(tenant_id=tenant_id, order_id=order.id).first()
    if existing and existing.xml_content:
        return {'invoice_number': existing.invoice_number, 'status': existing.status,
            'xml': existing.xml_content, 'sha256': existing.xml_sha256}
    items = db.query(OrderItem).filter_by(tenant_id=tenant_id, order_id=order.id).all()
    from app.services.zatca import build_zatca_invoice
    lines = [{'quantity': i.quantity, 'title': i.title_snapshot,
        'unit_price_minor': i.unit_price_minor, 'total_minor': i.total_minor} for i in items]
    raw, digest = build_zatca_invoice(invoice_number='INV-' + order.order_number,
     issue_date=order.created_at.date().isoformat(),
     currency=order.currency,
     seller=data.model_dump(),
     buyer={'country_code': 'SA'},
     lines=lines,
     tax_total_minor=order.tax_minor,
        subtotal_minor=order.subtotal_minor - order.discount_minor, total_minor=order.total_minor)
    inv = TaxInvoice(tenant_id=tenant_id, order_id=order.id,
     invoice_number='INV-' + order.order_number,
     currency=order.currency,
     subtotal_minor=order.subtotal_minor - order.discount_minor,
     tax_minor=order.tax_minor,
        total_minor=order.total_minor, status='GENERATED', xml_sha256=digest, xml_content=raw.decode())
    db.add(inv)
    db.commit()
    return {'invoice_number': inv.invoice_number, 'status': inv.status, 'xml': inv.xml_content,
        'sha256': digest, 'zatca_submission_required': True}

@router.post('/orders/{order_id}/returns')
def create_return_request(order_id: str, tenant_id: str, data: ReturnCreateIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.manage'))):
    tenant_scope(tenant_id, user, db)
    existing_idem = db.query(ReturnRequest).filter_by(tenant_id=tenant_id,
        idempotency_key=data.idempotency_key).first()
    if existing_idem:
        return json_model(existing_idem)
    # Serialize return creation per order. Without an order-level lock, two
    # concurrent requests can both observe the same remaining quantity and
    # create overlapping return reservations. This is especially important on
    # PostgreSQL where the API is expected to remain correct under concurrency.
    order = db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).with_for_update().first()
    if not order:
        raise not_found('Order not found')
    if order.payment_status not in {'CAPTURED', 'REFUNDED'}:
        raise AppError(409, 'ORDER_NOT_REFUNDABLE', 'Order has no captured payment')
    if order.status in {'CANCELED', 'DRAFT'}:
        raise AppError(409, 'ORDER_NOT_RETURNABLE', 'Order is not returnable')
    requested = 0
    rows = []
    # Normalize duplicate order_item_id entries inside one request before
    # checking availability. Otherwise two entries for the same line could
    # each pass the individual quantity check and over-return the line.
    requested_quantities = {}
    for item in data.items:
        qty = int(item.quantity)
        if qty <= 0:
            raise AppError(422, 'RETURN_QUANTITY_INVALID', 'Return quantity must be positive')
        requested_quantities[item.order_item_id] = requested_quantities.get(item.order_item_id, 0) + qty

    for order_item_id, quantity in requested_quantities.items():
        oi = db.query(OrderItem).filter_by(id=order_item_id, order_id=order.id,
            tenant_id=tenant_id).with_for_update().first()
        if not oi:
            raise not_found('Order item not found')
        if quantity > oi.quantity:
            raise AppError(409, 'RETURN_QUANTITY_EXCEEDED',
                'Return quantity exceeds purchased quantity')
        unit = max(0, oi.total_minor // max(1, int(oi.quantity)))
        amount = unit * quantity
        prior = db.query(ReturnItem).join(ReturnRequest,
         ReturnRequest.id == ReturnItem.return_request_id).filter(ReturnItem.tenant_id == tenant_id,
         ReturnItem.order_item_id == oi.id,
         ReturnRequest.status.notin_(['REJECTED',
            'CANCELED'])).with_entities(func.coalesce(func.sum(ReturnItem.quantity), 0)).scalar() or 0
        if int(prior) + quantity > int(oi.quantity):
            raise AppError(409, 'RETURN_ALREADY_REQUESTED',
                'Requested quantity has already been returned or reserved for return')
        requested += amount
        rows.append((oi, quantity, amount))
    if requested <= 0 or requested > order.total_minor:
        raise AppError(409, 'RETURN_AMOUNT_INVALID', 'Return amount is invalid')
    customer_id = order.customer_id
    rr = ReturnRequest(tenant_id=tenant_id, order_id=order.id, customer_id=customer_id,
     type=data.type,
     status='REQUESTED',
     reason_code=data.reason_code,
     reason_note=data.reason_note,
     requested_amount_minor=requested,
        currency=order.currency, idempotency_key=data.idempotency_key)
    db.add(rr)
    db.flush()
    for oi, qty, amount in rows:
        db.add(ReturnItem(tenant_id=tenant_id, return_request_id=rr.id, order_item_id=oi.id,
            quantity=qty, amount_minor=amount))
    outbox(db, tenant_id, 'return', rr.id, 'return.requested', {'return_id': rr.id,
        'order_id': order.id, 'amount_minor': requested, 'tenant_id': tenant_id})
    db.commit()
    return json_model(rr)

@router.get('/orders/{order_id}/returns')
def list_returns(order_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.read'))):
    tenant_scope(tenant_id, user, db)
    if not db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).first():
        raise not_found('Order not found')
    rows = db.query(ReturnRequest).filter_by(order_id=order_id,
        tenant_id=tenant_id).order_by(ReturnRequest.created_at.desc()).all()
    return {'items': [json_model(x) for x in rows]}

@router.post('/orders/{order_id}/cancel')
def cancel_order(order_id: str, tenant_id: str, user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('orders.cancel')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    rec = idem_start(db, tenant_id, user.id, 'POST /v1/orders/{id}/cancel', idempotency_key,
        {'order_id': order_id})
    if rec and rec.status == 'COMPLETED':
        return rec.response_body
    o = db.query(Order).filter_by(id=order_id, tenant_id=tenant_id).with_for_update().first()
    if not o:
        raise not_found('Order not found')
    if o.status in {'SHIPPED', 'DELIVERED', 'FULFILLED', 'CANCELLED'}:
        raise AppError(409, 'ORDER_STATE_INVALID', 'Order cannot be cancelled in current state')
    old_state = transition(o, 'CANCELLED')
    db.add(OrderStatusHistory(tenant_id=tenant_id, order_id=o.id, from_state=old_state,
        to_state='CANCELLED', actor_id=user.id, reason='merchant_cancel'))
    for r in db.query(InventoryReservation).filter_by(tenant_id=tenant_id, order_id=o.id,
        status='ACTIVE').all():
        inv = db.get(InventoryItem, r.inventory_item_id)
        inv.reserved = max(0, inv.reserved - r.quantity)
        inv.available += r.quantity
        inv.version += 1
        r.status = 'RELEASED'
    outbox(db, tenant_id, 'order', o.id, 'order.cancelled', {'order_id': o.id,
        'tenant_id': tenant_id})
    body = json_model(o)
    finalize_idem(rec, body, 200)
    db.commit()
    return body

@router.post('/orders')
def create_order_from_checkout(tenant_id: str, data: CheckoutIn, request: Request, response: Response,
 user=Depends(current_user),
 db: DBSession=Depends(get_db),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    return checkout(tenant_id=tenant_id, data=data, request=request, response=response, user=user, db=db,
        idempotency_key=idempotency_key)

@router.get('/orders')
def list_orders(tenant_id: str, limit: int=50, offset: int=0, status: str | None=None,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.read'))):
    tenant_scope(tenant_id, user, db)
    limit = max(1, min(limit, 100))
    offset = max(0, offset)
    q = db.query(Order).filter_by(tenant_id=tenant_id)
    if status:
        q = q.filter(Order.status == status)
    total = q.count()
    rows = q.order_by(Order.created_at.desc()).offset(offset).limit(limit).all()
    return {'items': [json_model(x) for x in rows], 'total': total, 'limit': limit,
        'offset': offset}
