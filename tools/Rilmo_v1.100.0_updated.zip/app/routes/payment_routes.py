"""Core payment routes: create payment intent, capture, refund, void.

Extracted out of app/routes/v1.py (Phase 3, step 35). This is the most
financially sensitive block moved so far (real money capture/refund/void),
so extra care was taken: every shared helper is imported rather than
duplicated, and the full 907-test suite (including concurrency/idempotency
and provider-mock tests) was run and passed before this file was finalized.

provider_credentials, idem_start and tenant_scope are also used by callers
still in v1.py (customer_cancel_order, iyzico/paytr webhooks), so they stay
defined there and are imported here.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Header, Request, Response
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func
from app.core.database import get_db
from app.core.auth import optional_user, current_user, require_permission, assert_permission
from app.core.guest import commerce_actor
from app.core.errors import AppError, not_found, forbidden
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.payment_providers import get_payment_provider
from app.services.order_state import transition
from app.services.core import (outbox, finalize_idem, body_hash, begin_payment_operation,
    complete_payment_operation, fail_payment_operation, post_split_ledger_entry, bind_provider_tenant)
from app.routes.v1 import tenant_scope, idem_start, provider_credentials

router = APIRouter(prefix='/v1')


@router.post('/payments/intents')
def payment_intent(tenant_id: str, data: PaymentIn, request: Request, response: Response,
 user=Depends(optional_user),
 db: DBSession=Depends(get_db),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    actor, guest = commerce_actor(request, response, db, tenant_id)
    if user is not None:
        actor = user
    if actor is not None and not getattr(actor, 'is_customer', False):
        tenant_scope(tenant_id, actor, db)
    elif actor is None and not guest:
        raise forbidden('Guest session required')
    payload = data.model_dump() if hasattr(data, 'model_dump') else data.__dict__
    rec = idem_start(db, tenant_id, actor.id if actor else None, 'POST /v1/payments/intents',
        idempotency_key, payload)
    if rec and rec.status == 'COMPLETED':
        return rec.response_body
    order = None
    ucp_checkout = None
    if data.ucp_external_session_id:
        from app.models.domain import UCPCheckoutSession
        ucp_checkout = db.query(UCPCheckoutSession).filter_by(tenant_id=tenant_id, external_session_id=data.ucp_external_session_id).first()
        if not ucp_checkout:
            raise not_found('UCP checkout session not found')
        if str(ucp_checkout.status).upper() != 'OPEN':
            raise AppError(409, 'UCP_CHECKOUT_NOT_OPEN', 'UCP checkout session is not open for payment')
        if data.order_id:
            raise AppError(422, 'PAYMENT_TARGET_AMBIGUOUS', 'A payment intent cannot target both an order and a UCP checkout session')
        if int(data.amount_minor) != int(ucp_checkout.total_minor) or str(data.currency).upper() != str(ucp_checkout.currency).upper():
            raise AppError(409, 'UCP_PAYMENT_AMOUNT_MISMATCH', 'Payment amount/currency must exactly match the UCP checkout total')
    domain_purchase = None
    if data.domain_purchase_id:
        from app.models.domain import DomainPurchase
        domain_purchase = db.query(DomainPurchase).filter_by(id=data.domain_purchase_id, tenant_id=tenant_id).with_for_update().first()
        if not domain_purchase:
            raise not_found('Domain purchase not found')
        if domain_purchase.status != 'PENDING_PAYMENT':
            raise AppError(409, 'DOMAIN_PURCHASE_NOT_PAYABLE', 'Domain purchase is not awaiting payment')
        if int(data.amount_minor) != int(domain_purchase.customer_price_minor) or str(data.currency).upper() != str(domain_purchase.currency).upper():
            raise AppError(409, 'DOMAIN_PURCHASE_AMOUNT_MISMATCH', 'Payment amount/currency does not match domain purchase')
        if data.order_id or data.ucp_external_session_id:
            raise AppError(422, 'PAYMENT_TARGET_AMBIGUOUS', 'A payment intent cannot target a domain purchase and another checkout target')
    if data.order_id:
        order = db.query(Order).filter_by(id=data.order_id, tenant_id=tenant_id).first()
        if not order:
            raise not_found('Order not found')
        if actor is None and (not guest or order.guest_session_id != guest.id):
            raise forbidden('Payment access denied')
        if actor is not None and getattr(actor, 'is_customer', False):
            # A storefront customer may only create a payment intent for their
            # own order. Tenant membership alone is never sufficient for a
            # customer actor: otherwise one customer could target another
            # customer's order by id while preserving the correct amount.
            if order.customer_id != getattr(actor, 'customer_id', None):
                raise forbidden('Payment access denied')
        elif actor is not None and order.customer_id is not None:
            if order.tenant_id != tenant_id:
                raise forbidden('Payment access denied')
        if order.currency != data.currency.upper() or order.total_minor != data.amount_minor:
            raise AppError(409, 'PAYMENT_AMOUNT_MISMATCH',
                'Payment amount/currency does not match order')
    provider_name=data.provider.lower()
    if provider_name in {'iyzico','paytr'}:
        account=db.query(MerchantPaymentAccount).filter_by(tenant_id=tenant_id,provider=provider_name,status='ACTIVE').first()
        if not account or not account.credentials_encrypted or not account.charges_enabled:
            raise AppError(409,'MERCHANT_PAYMENT_ACCOUNT_REQUIRED','Merchant must configure an active iyzico or PayTR account before accepting payments')
    if provider_name == 'cod':
        # Cash-on-delivery is opt-in per merchant: it must be explicitly
        # enabled the same way as any other provider, so it never appears
        # as a checkout option unless the tenant turned it on.
        cod_account=db.query(MerchantPaymentAccount).filter_by(tenant_id=tenant_id,provider='cod',status='ACTIVE').first()
        if not cod_account or not cod_account.charges_enabled:
            raise AppError(409,'MERCHANT_PAYMENT_ACCOUNT_REQUIRED','Merchant must enable cash-on-delivery before offering it at checkout')
    provider=get_payment_provider(provider_name,provider_credentials(tenant_id,provider_name,db))
    pi=PaymentIntent(tenant_id=tenant_id,order_id=data.order_id,ucp_checkout_session_id=(ucp_checkout.id if ucp_checkout else None),domain_purchase_id=(domain_purchase.id if domain_purchase else None),amount_minor=data.amount_minor,currency=data.currency.upper(),provider=provider.name,status='PENDING')
    db.add(pi)
    db.flush()
    outbox(db, tenant_id, 'payment_intent', pi.id, 'payment.intent.created',
        {'payment_intent_id': pi.id, 'tenant_id': tenant_id})
    db.commit()
    provider_customer = None
    provider_items = []
    if order:
        customer = db.query(Customer).filter_by(id=order.customer_id,
            tenant_id=tenant_id).first() if order.customer_id else None
        provider_customer = {'email': (customer.email if customer else order.customer_email_snapshot) or '',
         'phone': (customer.phone if customer else '') or '',
         'first_name': (customer.first_name if customer else 'Customer') or 'Customer',
         'last_name': (customer.last_name if customer else '') or '',
         'name': ' '.join([x for x in [customer.first_name if customer else 'Customer',
            customer.last_name if customer else ''] if x]).strip() or 'Customer', 'country_code': 'SA'}
        for oi in db.query(OrderItem).filter_by(order_id=order.id, tenant_id=tenant_id).all():
            provider_items.append({'title': oi.title_snapshot, 'name': oi.title_snapshot,
             'reference_id': oi.sku_snapshot,
             'sku': oi.sku_snapshot,
             'quantity': int(oi.quantity),
             'unit_price': f'{oi.unit_price_minor / 100:.2f}',
             'total_amount': f'{oi.total_minor / 100:.2f}',
                'currency': oi.currency, 'category': 'General', 'description': oi.title_snapshot})
        provider_customer['ip_address'] = str(request.client.host if request.client else '127.0.0.1')
    try:
        result = provider.create_intent(amount_minor=pi.amount_minor, currency=pi.currency,
         tenant_id=tenant_id,
         order_id=pi.order_id,
         idempotency_key=idempotency_key or (rec.id if rec else pi.id),
            customer=provider_customer, items=provider_items)
    except AppError:
        db.query(PaymentIntent).filter_by(id=pi.id,
            tenant_id=tenant_id).update({'status': 'FAILED'})
        db.commit()
        raise
    pi = db.query(PaymentIntent).filter_by(id=pi.id, tenant_id=tenant_id).first()
    pi.provider_payment_id = result.provider_payment_id
    bind_provider_tenant(db, provider=provider_name, external_id=pi.provider_payment_id, tenant_id=tenant_id)
    pi.status = 'REQUIRES_ACTION' if result.client_secret else 'PENDING'
    body = json_model(pi)
    body['client_secret'] = result.client_secret
    body['redirect_url'] = result.redirect_url
    finalize_idem(rec, body, 200)
    db.commit()
    return body

@router.post('/payments/{payment_id}/capture')
def capture(payment_id: str, tenant_id: str, user=Depends(current_user),
 db: DBSession=Depends(get_db),
    _=Depends(require_permission('finance.manage')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    assert_permission(tenant_id, user, db, 'finance.manage')
    pi = db.query(PaymentIntent).filter_by(id=payment_id, tenant_id=tenant_id).first()
    if not pi:
        raise not_found('Payment intent not found')
    idempotency_key = idempotency_key or 'auto:capture:' + pi.id
    op, state = begin_payment_operation(db, tenant_id, pi.id, 'CAPTURE', idempotency_key,
        amount_minor=pi.amount_minor, currency=pi.currency,
        request_hash=body_hash({'payment_intent_id': pi.id, 'operation_type': 'CAPTURE',
            'amount_minor': pi.amount_minor, 'currency': pi.currency.upper()}))
    if state == 'COMPLETED':
        return op.response_body
    if state == 'IN_PROGRESS':
        raise AppError(409, 'PAYMENT_OPERATION_IN_PROGRESS',
            'Another payment operation is already in progress for this payment')
    pi = db.query(PaymentIntent).filter_by(id=payment_id,
        tenant_id=tenant_id).with_for_update().first()
    captured = db.query(PaymentCapture).filter_by(payment_intent_id=pi.id,
     tenant_id=tenant_id).with_entities(func.coalesce(func.sum(PaymentCapture.amount_minor),
        0)).scalar() or 0
    if captured >= pi.amount_minor:
        pi.status = 'CAPTURED'
        body = json_model(pi)
        complete_payment_operation(op, body)
        finalize_idem(None, body, 200)
        db.commit()
        return body
    if not pi.provider_payment_id:
        fail_payment_operation(op, 'PROVIDER_INTENT_MISSING')
        db.commit()
        raise AppError(409, 'PROVIDER_INTENT_MISSING', 'Provider payment intent is missing')
    amount = pi.amount_minor - captured
    attempt = PaymentAttempt(tenant_id=tenant_id, payment_intent_id=pi.id,
        provider_attempt_id='cap_' + op.id, status='CAPTURE_PENDING', error_code=None)
    db.add(attempt)
    op.status = 'PROVIDER_PENDING'
    db.flush()
    db.commit()
    try:
        result = get_payment_provider(pi.provider).capture(pi.provider_payment_id,
            amount_minor=amount, currency=pi.currency, idempotency_key=op.idempotency_key)
        if pi.provider == 'iyzico' and result.provider_id and (result.provider_id != pi.provider_payment_id):
            pi.provider_payment_id = result.provider_id
    except AppError as exc:
        db.rollback()
        db.query(PaymentAttempt).filter_by(id=attempt.id,
            tenant_id=tenant_id).update({'status': 'FAILED', 'error_code': exc.code})
        db.query(PaymentOperation).filter_by(id=op.id,
         tenant_id=tenant_id).update({'status': 'FAILED',
            'error_code': exc.code, 'completed_at': datetime.now(timezone.utc)})
        outbox(db, tenant_id, 'payment_intent', pi.id, 'payment.failed',
            {'payment_intent_id': pi.id, 'tenant_id': tenant_id, 'error_code': exc.code})
        db.commit()
        raise
    pi = db.query(PaymentIntent).filter_by(id=payment_id,
        tenant_id=tenant_id).with_for_update().first()
    captured_now = db.query(PaymentCapture).filter_by(payment_intent_id=pi.id,
     tenant_id=tenant_id).with_entities(func.coalesce(func.sum(PaymentCapture.amount_minor),
        0)).scalar() or 0
    if captured_now + amount > pi.amount_minor:
        db.rollback()
        db.query(PaymentOperation).filter_by(id=op.id,
         tenant_id=tenant_id).update({'status': 'FAILED',
            'error_code': 'CAPTURE_TOTAL_EXCEEDED', 'completed_at': datetime.now(timezone.utc)})
        db.commit()
        raise AppError(409, 'CAPTURE_TOTAL_EXCEEDED',
            'Provider capture would exceed the authorized amount; reconciliation required')
    if not result.provider_id:
        db.rollback()
        db.query(PaymentOperation).filter_by(id=op.id, tenant_id=tenant_id).update({
            'status': 'FAILED', 'error_code': 'PROVIDER_CAPTURE_REFERENCE_MISSING',
            'completed_at': datetime.now(timezone.utc)})
        db.commit()
        raise AppError(502, 'PROVIDER_CAPTURE_REFERENCE_MISSING',
            'Payment provider did not return a capture reference; reconciliation required')
    db.query(PaymentAttempt).filter_by(id=attempt.id,
        tenant_id=tenant_id).update({'status': 'CAPTURED', 'provider_attempt_id': result.provider_id})
    cap = PaymentCapture(tenant_id=tenant_id, payment_intent_id=pi.id, amount_minor=amount,
        currency=pi.currency, provider_capture_id=result.provider_id)
    db.add(cap)
    db.flush()
    pi.status = 'CAPTURED'
    order = db.query(Order).filter_by(id=pi.order_id,
        tenant_id=tenant_id).first() if pi.order_id else None
    if order:
        order.payment_status = 'CAPTURED'
        old_state = transition(order, 'CONFIRMED')
        db.add(OrderStatusHistory(tenant_id=tenant_id, order_id=order.id, from_state=old_state,
            to_state='CONFIRMED', actor_id=user.id, reason='payment_captured'))
        outbox(db, tenant_id, 'order', order.id, 'order.confirmed', {'order_id': order.id,
            'tenant_id': tenant_id})
    cash = db.query(LedgerAccount).filter_by(tenant_id=tenant_id,
        code='cash').with_for_update().first()
    revenue = db.query(LedgerAccount).filter_by(tenant_id=tenant_id,
        code='sales_revenue').with_for_update().first()
    if not cash:
        cash = LedgerAccount(tenant_id=tenant_id, code='cash', name='Cash', account_type='ASSET', currency=pi.currency); db.add(cash)
    if not revenue:
        revenue = LedgerAccount(tenant_id=tenant_id, code='sales_revenue', name='Sales Revenue', account_type='REVENUE', currency=pi.currency); db.add(revenue)
    db.flush()
    post_split_ledger_entry(db, tenant_id, pi.currency, 'merchant_sale', pi.id, revenue, [(cash, amount)])
    outbox(db, tenant_id, 'payment_intent', pi.id, 'payment.captured', {'payment_intent_id': pi.id,
        'provider_id': result.provider_id, 'amount_minor': amount, 'tenant_id': tenant_id})
    if pi.domain_purchase_id:
        outbox(db, tenant_id, 'domain_purchase', pi.domain_purchase_id, 'domain.purchase.payment_captured', {
            'purchase_id': pi.domain_purchase_id, 'payment_intent_id': pi.id, 'provider_id': result.provider_id,
            'amount_minor': amount, 'currency': pi.currency, 'tenant_id': tenant_id})
    if order:
        ref = db.query(AffiliateReferral).filter_by(order_id=order.id, tenant_id=tenant_id).first()
        if ref:
            ref.status = 'CONVERTED'
            ref.converted_at = datetime.now(timezone.utc)
            commission = db.query(AffiliateCommission).filter_by(referral_id=ref.id, tenant_id=tenant_id).first()
            if commission:
                commission.status = 'APPROVED'
                commission.approved_at = datetime.now(timezone.utc)
                partner = db.get(AffiliatePartner, commission.partner_id)
                if partner:
                    partner.payout_minor += commission.amount_minor
    body = json_model(pi)
    complete_payment_operation(op, body, provider_reference=result.provider_id)
    finalize_idem(None, body, 200)
    db.commit()
    return body

@router.post('/refunds')
def refund(tenant_id: str, data: RefundIn, user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('orders.refund')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    # Route dependencies are skipped when this handler is called internally.
    # Preserve the dedicated refund permission at the canonical boundary.
    assert_permission(tenant_id, user, db, 'orders.refund')
    tenant_scope(tenant_id, user, db)
    idempotency_key = idempotency_key or 'auto:refund:' + body_hash({'payment_intent_id': data.payment_intent_id,
     'order_id': data.order_id,
        'amount_minor': data.amount_minor, 'currency': data.currency.upper()})
    pi = db.query(PaymentIntent).filter_by(id=data.payment_intent_id, tenant_id=tenant_id).first()
    order = db.query(Order).filter_by(id=data.order_id, tenant_id=tenant_id).first()
    if not pi or not order:
        raise not_found('Order/payment not found')
    if pi.order_id != order.id:
        raise AppError(409, 'PAYMENT_ORDER_MISMATCH', 'Payment does not belong to order')
    op, state = begin_payment_operation(db, tenant_id, pi.id, 'REFUND', idempotency_key,
        amount_minor=data.amount_minor, currency=data.currency.upper(),
        request_hash=body_hash({'payment_intent_id': pi.id, 'operation_type': 'REFUND',
            'amount_minor': data.amount_minor, 'currency': data.currency.upper(), 'order_id': order.id}))
    if state == 'COMPLETED':
        return op.response_body
    if state == 'IN_PROGRESS':
        raise AppError(409, 'PAYMENT_OPERATION_IN_PROGRESS',
            'Another payment operation is already in progress for this payment')
    pi = db.query(PaymentIntent).filter_by(id=pi.id, tenant_id=tenant_id).with_for_update().first()
    captured = db.query(PaymentCapture).filter_by(payment_intent_id=pi.id,
     tenant_id=tenant_id).with_entities(func.coalesce(func.sum(PaymentCapture.amount_minor),
        0)).scalar() or 0
    refunded = db.query(Refund).filter_by(payment_intent_id=pi.id,
     tenant_id=tenant_id).with_entities(func.coalesce(func.sum(Refund.amount_minor),
        0)).scalar() or 0
    if data.amount_minor <= 0:
        fail_payment_operation(op, 'REFUND_AMOUNT_INVALID')
        db.commit()
        raise AppError(400, 'REFUND_AMOUNT_INVALID', 'Refund amount must be positive')
    if data.currency.upper() != pi.currency:
        fail_payment_operation(op, 'CURRENCY_MISMATCH')
        db.commit()
        raise AppError(409, 'CURRENCY_MISMATCH', 'Refund currency does not match payment currency')
    if refunded + data.amount_minor > captured:
        fail_payment_operation(op, 'REFUND_CAP')
        db.commit()
        raise AppError(409, 'REFUND_CAP', 'Refund exceeds captured amount')
    if not pi.provider_payment_id:
        fail_payment_operation(op, 'PROVIDER_INTENT_MISSING')
        db.commit()
        raise AppError(409, 'PROVIDER_INTENT_MISSING', 'Provider payment intent is missing')
    attempt = PaymentAttempt(tenant_id=tenant_id, payment_intent_id=pi.id,
        provider_attempt_id='ref_' + op.id, status='REFUND_PENDING')
    db.add(attempt)
    op.status = 'PROVIDER_PENDING'
    db.flush()
    db.commit()
    try:
        result = get_payment_provider(pi.provider).refund(pi.provider_payment_id, data.amount_minor,
            data.currency.upper(), idempotency_key=op.idempotency_key)
    except AppError as exc:
        db.rollback()
        db.query(PaymentAttempt).filter_by(id=attempt.id,
            tenant_id=tenant_id).update({'status': 'FAILED', 'error_code': exc.code})
        db.query(PaymentOperation).filter_by(id=op.id,
         tenant_id=tenant_id).update({'status': 'FAILED',
            'error_code': exc.code, 'completed_at': datetime.now(timezone.utc)})
        db.commit()
        raise
    if not result.provider_id:
        db.rollback()
        db.query(PaymentOperation).filter_by(id=op.id, tenant_id=tenant_id).update({
            'status': 'FAILED', 'error_code': 'PROVIDER_REFUND_REFERENCE_MISSING',
            'completed_at': datetime.now(timezone.utc)})
        db.commit()
        raise AppError(502, 'PROVIDER_REFUND_REFERENCE_MISSING',
            'Payment provider did not return a refund reference; reconciliation required')
    db.query(PaymentAttempt).filter_by(id=attempt.id,
        tenant_id=tenant_id).update({'status': 'REFUNDED', 'provider_attempt_id': result.provider_id})
    pi = db.query(PaymentIntent).filter_by(id=pi.id, tenant_id=tenant_id).with_for_update().first()
    captured_now = db.query(PaymentCapture).filter_by(payment_intent_id=pi.id,
     tenant_id=tenant_id).with_entities(func.coalesce(func.sum(PaymentCapture.amount_minor),
        0)).scalar() or 0
    refunded_now = db.query(Refund).filter_by(payment_intent_id=pi.id,
     tenant_id=tenant_id).with_entities(func.coalesce(func.sum(Refund.amount_minor),
        0)).scalar() or 0
    if refunded_now + data.amount_minor > captured_now:
        db.rollback()
        db.query(PaymentOperation).filter_by(id=op.id,
         tenant_id=tenant_id).update({'status': 'FAILED',
            'error_code': 'REFUND_TOTAL_EXCEEDED', 'completed_at': datetime.now(timezone.utc)})
        db.commit()
        raise AppError(409, 'REFUND_TOTAL_EXCEEDED',
            'Provider refund would exceed captured amount; reconciliation required')
    existing_refund = db.query(Refund).filter_by(tenant_id=tenant_id, provider_refund_id=result.provider_id).with_for_update().first()
    if existing_refund:
        if (existing_refund.payment_intent_id != pi.id or
                existing_refund.order_id != order.id or
                int(existing_refund.amount_minor) != int(data.amount_minor) or
                str(existing_refund.currency).upper() != str(data.currency).upper()):
            db.rollback()
            db.query(PaymentOperation).filter_by(id=op.id, tenant_id=tenant_id).update({
                'status': 'FAILED',
                'error_code': 'PROVIDER_REFUND_REFERENCE_REUSED',
                'completed_at': datetime.now(timezone.utc)})
            db.commit()
            raise AppError(409, 'PROVIDER_REFUND_REFERENCE_REUSED',
                'Provider refund reference is already bound to different refund data; reconciliation required')
        body = json_model(existing_refund)
        complete_payment_operation(op, body, provider_reference=result.provider_id)
        db.commit()
        return body
    r = Refund(tenant_id=tenant_id, order_id=order.id, payment_intent_id=pi.id,
     amount_minor=data.amount_minor,
        currency=data.currency.upper(), status='COMPLETED', provider_refund_id=result.provider_id)
    db.add(r)
    db.flush()
    if refunded_now + data.amount_minor == captured_now:
        pi.status = 'REFUNDED'
        order.payment_status = 'REFUNDED'
    outbox(db, tenant_id, 'refund', r.id, 'refund.created', {'refund_id': r.id,
        'amount_minor': r.amount_minor, 'tenant_id': tenant_id})
    outbox(db, tenant_id, 'refund', r.id, 'refund.completed', {'refund_id': r.id,
        'amount_minor': r.amount_minor, 'tenant_id': tenant_id})
    body = json_model(r)
    complete_payment_operation(op, body, provider_reference=result.provider_id)
    db.commit()
    return body

@router.post('/payments/{payment_id}/void')
def void_payment(payment_id: str, tenant_id: str, user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('finance.manage')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    assert_permission(tenant_id, user, db, 'finance.manage')
    pi = db.query(PaymentIntent).filter_by(id=payment_id, tenant_id=tenant_id).first()
    if not pi:
        raise not_found('Payment intent not found')
    key = idempotency_key or 'auto:void:' + pi.id
    op, state = begin_payment_operation(db, tenant_id, pi.id, 'VOID', key,
        amount_minor=pi.amount_minor, currency=pi.currency,
        request_hash=body_hash({'payment_intent_id': pi.id, 'operation_type': 'VOID',
            'amount_minor': pi.amount_minor, 'currency': pi.currency.upper()}))
    if state == 'COMPLETED':
        return op.response_body
    if state == 'IN_PROGRESS':
        raise AppError(409, 'PAYMENT_OPERATION_IN_PROGRESS',
            'Another payment operation is already in progress for this payment')
    pi = db.query(PaymentIntent).filter_by(id=pi.id, tenant_id=tenant_id).with_for_update().first()
    captured = db.query(PaymentCapture).filter_by(payment_intent_id=pi.id,
     tenant_id=tenant_id).with_entities(func.coalesce(func.sum(PaymentCapture.amount_minor),
        0)).scalar() or 0
    if captured > 0:
        fail_payment_operation(op, 'PAYMENT_ALREADY_CAPTURED')
        db.commit()
        raise AppError(409, 'PAYMENT_ALREADY_CAPTURED', 'A captured payment cannot be voided')
    if pi.status in {'VOIDED', 'CANCELED'}:
        body = json_model(pi)
        complete_payment_operation(op, body)
        db.commit()
        return body
    if not pi.provider_payment_id:
        fail_payment_operation(op, 'PROVIDER_INTENT_MISSING')
        db.commit()
        raise AppError(409, 'PROVIDER_INTENT_MISSING', 'Provider payment intent is missing')
    attempt = PaymentAttempt(tenant_id=tenant_id, payment_intent_id=pi.id,
        provider_attempt_id='void_' + op.id, status='VOID_PENDING')
    db.add(attempt)
    op.status = 'PROVIDER_PENDING'
    db.flush()
    db.commit()
    try:
        result = get_payment_provider(pi.provider).void(pi.provider_payment_id,
            idempotency_key=op.idempotency_key)
    except AppError as exc:
        db.rollback()
        db.query(PaymentAttempt).filter_by(id=attempt.id,
            tenant_id=tenant_id).update({'status': 'FAILED', 'error_code': exc.code})
        db.query(PaymentOperation).filter_by(id=op.id,
         tenant_id=tenant_id).update({'status': 'FAILED',
            'error_code': exc.code, 'completed_at': datetime.now(timezone.utc)})
        db.commit()
        raise
    if not result.provider_id:
        db.rollback()
        db.query(PaymentOperation).filter_by(id=op.id, tenant_id=tenant_id).update({
            'status': 'FAILED',
            'error_code': 'PROVIDER_VOID_REFERENCE_MISSING',
            'completed_at': datetime.now(timezone.utc)})
        db.query(PaymentAttempt).filter_by(id=attempt.id,
            tenant_id=tenant_id).update({'status': 'FAILED', 'error_code': 'PROVIDER_VOID_REFERENCE_MISSING'})
        db.commit()
        raise AppError(502, 'PROVIDER_VOID_REFERENCE_MISSING',
            'Payment provider did not return a void reference; reconciliation required')
    db.query(PaymentAttempt).filter_by(id=attempt.id,
        tenant_id=tenant_id).update({'status': 'VOIDED', 'provider_attempt_id': result.provider_id})
    pi = db.query(PaymentIntent).filter_by(id=pi.id, tenant_id=tenant_id).with_for_update().first()
    pi.status = 'VOIDED'
    if pi.order_id:
        order = db.query(Order).filter_by(id=pi.order_id, tenant_id=tenant_id).first()
        if order:
            order.payment_status = 'VOIDED'
    outbox(db, tenant_id, 'payment_intent', pi.id, 'payment.voided', {'payment_intent_id': pi.id,
        'provider_id': result.provider_id, 'tenant_id': tenant_id})
    body = json_model(pi)
    complete_payment_operation(op, body, result.provider_id)
    db.commit()
    return body
