"""Merchant onboarding checklist routes: status, complete-step — plus the
step definitions and sync helper they depend on.

Extracted out of app/routes/v1.py (Phase 3, step 20). _merchant_payment_ready
is used by other route groups still in v1.py, so it stays there and is
imported here.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user
from app.core.errors import AppError
from app.models.domain import *
from app.core.serialization import json_model
from app.routes.v1 import tenant_scope, _merchant_payment_ready

router = APIRouter(prefix='/v1')

ONBOARDING_STEPS = [('store_profile', 'Store profile'), ('first_product', 'First product'),
 ('shipping_methods', 'Shipping carrier and shipping offer'),
 ('payment_account',
 'Payment account'),
 ('billing_plan',
    'Billing plan'), ('store_domain', 'Store domain'), ('store_published', 'Store published')]

def _ensure_onboarding_rows(db, tenant_id: str):
    rows = db.query(MerchantOnboardingStep).filter_by(tenant_id=tenant_id).all()
    existing = {r.step_key for r in rows}
    for key, _label in ONBOARDING_STEPS:
        if key not in existing:
            db.add(MerchantOnboardingStep(tenant_id=tenant_id, step_key=key, status='PENDING',
                metadata={}))
    db.flush()

def _sync_onboarding(db, tenant_id: str):
    _ensure_onboarding_rows(db, tenant_id)
    tenant = db.query(Tenant).filter_by(id=tenant_id).first()
    checks = {'store_profile': bool(tenant and tenant.name and tenant.slug),
     'first_product': db.query(Product).filter_by(tenant_id=tenant_id,
     deleted_at=None).first() is not None,
     'shipping_methods': db.query(ShippingMethod).filter_by(tenant_id=tenant_id, is_active=True).first() is not None,
     'payment_account': _merchant_payment_ready(db, tenant_id),
     'billing_plan': db.query(Subscription).filter(Subscription.tenant_id == tenant_id,
     Subscription.status == 'active').first() is not None,
     'store_domain': db.query(Domain).filter_by(tenant_id=tenant_id).filter(Domain.verified_at.is_not(None)).first() is not None,
     'store_published': db.query(Storefront).filter_by(tenant_id=tenant_id,
        status='PUBLISHED').first() is not None}
    for key, complete in checks.items():
        row = db.query(MerchantOnboardingStep).filter_by(tenant_id=tenant_id, step_key=key).first()
        if complete and row.status != 'COMPLETED':
            row.status = 'COMPLETED'
            row.completed_at = datetime.now(timezone.utc)
        elif not complete and row.status == 'COMPLETED':
            row.status = 'PENDING'
            row.completed_at = None
    db.flush()
    return checks

@router.get('/onboarding/status')
def onboarding_status(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    checks = _sync_onboarding(db, tenant_id)
    rows = db.query(MerchantOnboardingStep).filter_by(tenant_id=tenant_id).order_by(MerchantOnboardingStep.created_at.asc()).all()
    db.commit()
    completed = sum((1 for r in rows if r.status == 'COMPLETED'))
    blockers = [r.step_key for r in rows if r.status != 'COMPLETED']
    return {'completed': completed, 'total': len(rows),
     'percent': round(completed / len(rows) * 100) if rows else 0,
        'blockers': blockers, 'evidence': checks, 'steps': [json_model(r) for r in rows]}

@router.post('/onboarding/complete/{step_key}')
def complete_onboarding_step(step_key: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    checks = _sync_onboarding(db, tenant_id)
    if step_key not in {k for k, _ in ONBOARDING_STEPS}:
        raise AppError(400, 'ONBOARDING_STEP_INVALID', 'Unknown onboarding step')
    if not checks.get(step_key):
        raise AppError(409, 'ONBOARDING_EVIDENCE_REQUIRED',
            'This step can only complete when the corresponding platform state is actually satisfied')
    row = db.query(MerchantOnboardingStep).filter_by(tenant_id=tenant_id, step_key=step_key).first()
    db.commit()
    return json_model(row)
