"""Privacy/GDPR-style compliance routes: privacy center, consent record/list,
subject-access request submit/list/export, and platform compliance-officer
routes (KYC access grants, privacy incidents, cross-border transfer register).

Extracted out of app/routes/v1.py (Phase 3, step 37) via exact programmatic
text extraction, verified byte-for-byte identical against the source before
removal — same rigor as the payments and Google-OAuth extractions.
_tenant_membership_or_403 is a shared helper used elsewhere in v1.py, so it
stays there and is imported here.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, current_platform_compliance_officer
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.services.privacy import (privacy_profile, record_consent_event, jurisdiction_for_country,
    submit_privacy_request, create_privacy_access_grant, revoke_privacy_access_grant,
    open_privacy_incident, update_privacy_incident, privacy_export_payload)
from app.services.core import audit
from app.routes.v1 import _tenant_membership_or_403

router = APIRouter(prefix='/v1')


@router.get('/privacy/center')
def privacy_center(tenant_id: str | None = None, user=Depends(current_user), db: DBSession=Depends(get_db)):
    if tenant_id:
        _tenant_membership_or_403(tenant_id,user,db)
    return privacy_profile(db, user.id, tenant_id)

@router.post('/privacy/consents')
def privacy_consent(tenant_id: str | None = None, data: dict = None, request: Request = None, user=Depends(current_user), db: DBSession=Depends(get_db)):
    data=data or {}
    if tenant_id:
        _tenant_membership_or_403(tenant_id,user,db)
    country=str(data.get('country_code') or '').upper() or None
    jurisdiction=str(data.get('jurisdiction') or jurisdiction_for_country(country))
    categories=data.get('categories')
    if not isinstance(categories,dict):
        raise AppError(400,'PRIVACY_CONSENT_REQUIRED','Consent categories are required')
    # California Global Privacy Control (GPC) and equivalent jurisdictional opt-out signals
    # are enforced as a privacy choice for optional advertising/analytics processing.
    if request and request.headers.get('Sec-GPC') == '1':
        categories = dict(categories)
        categories['marketing'] = False
        categories['analytics'] = False
        categories['personalization'] = False
    policy_version=str(data.get('policy_version') or 'privacy-v1')
    action=str(data.get('action') or 'UPDATE').upper()
    row=record_consent_event(db,tenant_id=tenant_id,user_id=user.id,customer_id=None,subject_type='USER',subject_id=user.id,jurisdiction=jurisdiction,policy_version=policy_version,action=action,categories=categories,lawful_basis=data.get('lawful_basis'),source='privacy_center',ip=request.client.host if request and request.client else None,user_agent=request.headers.get('user-agent') if request else None)
    db.commit()
    return {'ok':True,'consent_id':row.id,'jurisdiction':jurisdiction,'categories':row.categories}

@router.get('/privacy/consents')
def privacy_consents(tenant_id: str | None = None, user=Depends(current_user), db: DBSession=Depends(get_db)):
    if tenant_id:
        _tenant_membership_or_403(tenant_id,user,db)
    q=db.query(PrivacyConsentEvent).filter_by(user_id=user.id).order_by(PrivacyConsentEvent.created_at.desc()).limit(100).all()
    return {'items':[{'id':r.id,'action':r.action,'jurisdiction':r.jurisdiction,'policy_version':r.policy_version,'categories':r.categories,'created_at':r.created_at.isoformat()} for r in q]}

@router.post('/privacy/requests')
def privacy_request(data: dict, tenant_id: str | None = None, user=Depends(current_user), db: DBSession=Depends(get_db)):
    if tenant_id:
        _tenant_membership_or_403(tenant_id,user,db)
    req=submit_privacy_request(db,tenant_id=tenant_id,user_id=user.id,customer_id=None,request_type=str(data.get('request_type') or ''),jurisdiction=str(data.get('jurisdiction') or jurisdiction_for_country(data.get('country_code'))))
    db.commit()
    return {'request':{'id':req.id,'type':req.request_type,'status':req.status,'jurisdiction':req.jurisdiction,'requested_at':req.requested_at.isoformat(),'due_at':req.due_at.isoformat() if req.due_at else None}}

@router.get('/privacy/requests')
def privacy_requests(tenant_id: str | None = None, user=Depends(current_user), db: DBSession=Depends(get_db)):
    if tenant_id:
        _tenant_membership_or_403(tenant_id,user,db)
    rows=db.query(PrivacyRequest).filter_by(user_id=user.id).order_by(PrivacyRequest.requested_at.desc()).limit(100).all()
    return {'items':[{'id':r.id,'type':r.request_type,'status':r.status,'jurisdiction':r.jurisdiction,'requested_at':r.requested_at.isoformat(),'due_at':r.due_at.isoformat() if r.due_at else None,'resolved_at':r.resolved_at.isoformat() if r.resolved_at else None} for r in rows]}

@router.post('/platform/compliance/kyc-access')
def platform_create_kyc_access_grant(
    data: dict, request: Request,
    admin=Depends(current_platform_compliance_officer),
    db: DBSession=Depends(get_db),
):
    row=create_privacy_access_grant(
        db, tenant_id=str(data.get('tenant_id') or ''),
        verification_id=str(data.get('verification_id') or ''),
        case_id=str(data.get('case_id') or ''), requester_user_id=admin.user_id,
        purpose=str(data.get('purpose') or ''), ticket_ref=str(data.get('ticket_ref') or ''),
        provider_access_reference=(str(data.get('provider_access_reference'))
            if data.get('provider_access_reference') else None),
        ip=request.client.host if request and request.client else None,
        ttl_minutes=int(data.get('ttl_minutes') or 15),
    )
    db.commit()
    return {'id':row.id,'status':row.status,'granted_at':row.granted_at.isoformat(),'expires_at':row.expires_at.isoformat(),'verification_id':row.verification_id,'case_id':row.case_id,'provider_access_reference':'PRESENT' if row.provider_access_reference else None}

@router.post('/platform/compliance/kyc-access/{grant_id}/revoke')
def platform_revoke_kyc_access(grant_id: str, admin=Depends(current_platform_compliance_officer), db: DBSession=Depends(get_db)):
    row=revoke_privacy_access_grant(db, grant_id=grant_id, requester_user_id=admin.user_id)
    db.commit()
    return {'ok':True,'id':row.id,'status':row.status,'revoked_at':row.revoked_at.isoformat()}

@router.post('/platform/privacy/incidents')
def platform_open_privacy_incident(
    data: dict, admin=Depends(current_platform_compliance_officer),
    db: DBSession=Depends(get_db),
):
    row=open_privacy_incident(
        db, jurisdiction=str(data.get('jurisdiction') or 'GLOBAL-BASELINE'),
        severity=str(data.get('severity') or 'MEDIUM'),
        data_categories=data.get('data_categories') or [],
        affected_subjects_estimate=data.get('affected_subjects_estimate'),
        owner_user_id=admin.user_id,
    )
    db.commit()
    return {'id':row.id,'status':row.status,'jurisdiction':row.jurisdiction,'severity':row.severity,'detected_at':row.detected_at.isoformat(),'authority_due_at':row.authority_due_at.isoformat() if row.authority_due_at else None}

@router.get('/privacy/data-export/{request_id}')
def privacy_data_export(request_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    row=db.query(PrivacyRequest).filter_by(id=request_id,user_id=user.id,request_type='PORTABILITY').first()
    if not row:
        raise not_found('Privacy export request not found')
    if row.status != 'READY':
        raise AppError(409,'PRIVACY_EXPORT_NOT_READY','Data export is not ready')
    import json
    payload=json.dumps(privacy_export_payload(db,user_id=user.id),ensure_ascii=False,indent=2)
    return Response(content=payload,media_type='application/json',headers={'Content-Disposition':f'attachment; filename="rilmo-privacy-export-{user.id}.json"','Cache-Control':'no-store'})

@router.post('/platform/privacy/requests/{request_id}/ready')
def platform_mark_privacy_export_ready(request_id: str, admin=Depends(current_platform_compliance_officer), db: DBSession=Depends(get_db)):
    row=db.query(PrivacyRequest).filter_by(id=request_id,request_type='PORTABILITY').first()
    if not row:
        raise not_found('Privacy export request not found')
    row.status='READY'; row.data_export_ready_at=datetime.now(timezone.utc)
    audit(db,row.tenant_id,admin.user_id,'privacy.export.ready','PrivacyRequest',row.id,after={'status':'READY'})
    db.commit()
    return {'ok':True,'request_id':row.id,'status':row.status,'ready_at':row.data_export_ready_at.isoformat()}

@router.post('/platform/privacy/incidents/{incident_id}')
def platform_update_privacy_incident(incident_id: str, data: dict, admin=Depends(current_platform_compliance_officer), db: DBSession=Depends(get_db)):
    row=update_privacy_incident(db,incident_id=incident_id,actor_user_id=admin.user_id,status=data.get('status'),containment_notes=data.get('containment_notes'),notification_decision=data.get('notification_decision'),affected_subjects_estimate=data.get('affected_subjects_estimate'))
    db.commit()
    return {'id':row.id,'status':row.status,'severity':row.severity,'jurisdiction':row.jurisdiction,'assessed_at':row.assessed_at.isoformat() if row.assessed_at else None,'authority_due_at':row.authority_due_at.isoformat() if row.authority_due_at else None,'notification_decision':row.notification_decision,'notification_at':row.notification_at.isoformat() if row.notification_at else None}

@router.post('/platform/privacy/transfer-routes')
def platform_register_privacy_transfer_route(data: dict, admin=Depends(current_platform_compliance_officer), db: DBSession=Depends(get_db)):
    from app.models.domain import PrivacyTransferRegister
    mechanism=str(data.get('mechanism') or '').strip()
    processor=str(data.get('processor_name') or '').strip()
    country=str(data.get('destination_country') or '').upper().strip()
    categories=data.get('data_categories') or []
    purpose=str(data.get('purpose') or '').strip()
    if not processor or not country or len(country)!=2 or not mechanism or not purpose or not isinstance(categories,list):
        raise AppError(400,'PRIVACY_TRANSFER_INPUT_INVALID','processor_name, destination_country, mechanism, purpose and data_categories are required')
    mechanism_lower=mechanism.lower()
    requires_signed_contract=mechanism_lower in {'standard_contract','kvkk_standard_contract','binding_corporate_rules'}
    contract_ref=str(data.get('contract_reference') or '').strip() or None
    signed_at=data.get('signed_at')
    signatory_ref=str(data.get('signatory_authority_reference') or '').strip() or None
    if requires_signed_contract and (not contract_ref or not signed_at or not signatory_ref):
        raise AppError(409,'PRIVACY_TRANSFER_EVIDENCE_REQUIRED','Signed contract date, contract reference and signatory authority evidence are required for this transfer mechanism')
    from datetime import datetime, timezone
    def parse_dt(value):
        if not value: return None
        return datetime.fromisoformat(str(value).replace('Z','+00:00'))
    row=PrivacyTransferRegister(
        processor_name=processor,
        role=str(data.get('role') or 'PROCESSOR').upper(),
        destination_country=country,
        mechanism=mechanism,
        data_categories=categories,
        purpose=purpose,
        contract_reference=contract_ref,
        contract_type=(
            str(data.get('contract_type')).strip()
            if data.get('contract_type')
            else None
        ),
        signed_at=parse_dt(signed_at),
        signatory_authority_reference=signatory_ref,
        regulatory_notification_reference=(
            str(data.get('regulatory_notification_reference')).strip()
            if data.get('regulatory_notification_reference')
            else None
        ),
        regulatory_notified_at=parse_dt(data.get('regulatory_notified_at')),
        approval_status=(
            'APPROVED'
            if (
                not requires_signed_contract
                or (contract_ref and signed_at and signatory_ref)
            )
            else 'PENDING_REVIEW'
        ),
        reviewed_at=datetime.now(timezone.utc),
        active=bool(data.get('active',True)),
    )
    db.add(row)
    db.flush()
    audit(
        db,
        None,
        admin.user_id,
        'privacy.transfer_route.registered',
        'PrivacyTransferRegister',
        row.id,
        after={
            'processor_name':row.processor_name,
            'destination_country':row.destination_country,
            'mechanism':row.mechanism,
            'approval_status':row.approval_status,
        },
    )
    db.commit()
    return {
        'id':row.id,
        'processor_name':row.processor_name,
        'destination_country':row.destination_country,
        'mechanism':row.mechanism,
        'approval_status':row.approval_status,
    }

@router.get('/platform/privacy/transfer-routes')
def platform_list_privacy_transfer_routes(admin=Depends(current_platform_compliance_officer), db: DBSession=Depends(get_db)):
    from app.models.domain import PrivacyTransferRegister
    rows=db.query(PrivacyTransferRegister).order_by(PrivacyTransferRegister.processor_name.asc(),PrivacyTransferRegister.destination_country.asc()).all()
    return {
        'items':[
            {
                'id':r.id,
                'processor_name':r.processor_name,
                'role':r.role,
                'destination_country':r.destination_country,
                'mechanism':r.mechanism,
                'data_categories':r.data_categories,
                'purpose':r.purpose,
                'contract_reference':r.contract_reference,
                'contract_type':r.contract_type,
                'signed_at':r.signed_at.isoformat() if r.signed_at else None,
                'signatory_authority_reference_present':bool(r.signatory_authority_reference),
                'regulatory_notification_reference_present':bool(r.regulatory_notification_reference),
                'regulatory_notified_at':(
                    r.regulatory_notified_at.isoformat()
                    if r.regulatory_notified_at
                    else None
                ),
                'approval_status':r.approval_status,
                'active':r.active,
                'reviewed_at':r.reviewed_at.isoformat() if r.reviewed_at else None,
            }
            for r in rows
        ]
    }
