"""Notification-template CRUD and notification-send routes.

Extracted out of app/routes/v1.py (Phase 3, step 10).
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import audit, outbox, require_entitlement
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.get('/notification-templates')
def list_notification_templates(tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    return {'items': [json_model(x) for x in db.query(NotificationTemplate).filter_by(tenant_id=tenant_id).order_by(NotificationTemplate.code.asc()).all()]}

@router.post('/notification-templates')
def create_notification_template(tenant_id: str, data: NotificationTemplateIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    if data.channel not in {'email', 'sms', 'webhook'}:
        raise AppError(400, 'NOTIFICATION_CHANNEL_UNSUPPORTED', 'Unsupported notification channel')
    row = NotificationTemplate(tenant_id=tenant_id, code=data.code.strip(), channel=data.channel,
        locale=data.locale, subject=data.subject, body=data.body, active=data.active)
    db.add(row)
    db.flush()
    audit(db, tenant_id, user.id, 'notification_template.create', 'notification_template', row.id,
        after={'code': row.code})
    db.commit()
    return json_model(row)

@router.post('/notifications/send')
def send_notification(tenant_id: str, data: NotificationSendIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    if data.channel == 'sms':
        quota = require_entitlement(db, tenant_id, 'sms_monthly')
        month_start = datetime.now(timezone.utc).replace(day=1,hour=0,minute=0,second=0,microsecond=0)
        used = db.query(NotificationDelivery).filter(NotificationDelivery.tenant_id == tenant_id,
            NotificationDelivery.channel == 'sms', NotificationDelivery.created_at >= month_start).count()
        allowed = int(quota.value_integer or 0)
        if allowed != -1 and used >= allowed:
            raise AppError(402,'PLAN_LIMIT_REACHED','Monthly SMS allowance has been reached')
    template = db.query(NotificationTemplate).filter_by(id=data.template_id, tenant_id=tenant_id,
        active=True).first() if data.template_id else None
    if data.template_id and (not template):
        raise not_found('Notification template not found')
    existing = db.query(NotificationDelivery).filter_by(tenant_id=tenant_id,
        idempotency_key=data.idempotency_key).first()
    if existing:
        return json_model(existing)
    row = NotificationDelivery(tenant_id=tenant_id, template_id=template.id if template else None,
     channel=data.channel,
     recipient=data.recipient,
        status='QUEUED', idempotency_key=data.idempotency_key, payload=data.payload)
    db.add(row)
    db.flush()
    outbox(db, tenant_id, 'notification_delivery', row.id, 'notification.send.queued',
        {'notification_delivery_id': row.id, 'tenant_id': tenant_id})
    db.commit()
    return json_model(row)
