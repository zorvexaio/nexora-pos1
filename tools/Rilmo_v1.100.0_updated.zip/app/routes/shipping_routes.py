"""Shipping carrier/method CRUD routes: supported carriers, create, patch,
delete, list.

Extracted out of app/routes/v1.py (Phase 3, step 21). SUPPORTED_SHIPPING_CARRIERS
and _shipping_public_view are also used by cart/checkout routes still in
v1.py, so they stay there and are imported here.
"""
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.routes.v1 import tenant_scope, require_if_match, SUPPORTED_SHIPPING_CARRIERS, _validate_shipping_offer, _shipping_public_view

router = APIRouter(prefix='/v1')


@router.get('/shipping-carriers')
def shipping_carriers(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    methods = db.query(ShippingMethod).filter_by(tenant_id=tenant_id).all()
    selected = {m.carrier_code for m in methods if m.is_active}
    return {'supported': [{'code': code, 'name': name, 'selected': code in selected} for code, name in SUPPORTED_SHIPPING_CARRIERS.items()]}

@router.post('/shipping-methods')
def shipping(tenant_id: str, data: ShippingIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    code = _validate_shipping_offer(data)
    x = ShippingMethod(tenant_id=tenant_id, name=data.name, carrier_code=code,
        service_code=data.service_code, amount_minor=data.amount_minor, currency=data.currency.upper(),
        free_shipping=data.free_shipping, free_shipping_threshold_minor=data.free_shipping_threshold_minor,
        offer_label=data.offer_label, estimated_days_min=data.estimated_days_min,
        estimated_days_max=data.estimated_days_max)
    db.add(x)
    db.commit()
    return json_model(x) | {'carrier_name': SUPPORTED_SHIPPING_CARRIERS[code]}

@router.patch('/shipping-methods/{shipping_id}')
def patch_shipping(shipping_id: str, tenant_id: str, data: ShippingIn,
 if_match: str | None=Header(default=None,
 alias='If-Match'),
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    x = db.query(ShippingMethod).filter_by(id=shipping_id, tenant_id=tenant_id).first()
    if not x:
        raise not_found('Shipping method not found')
    require_if_match(x, if_match)
    code = _validate_shipping_offer(data)
    x.name = data.name
    x.carrier_code = code
    x.service_code = data.service_code
    x.amount_minor = data.amount_minor
    x.currency = data.currency.upper()
    x.free_shipping = data.free_shipping
    x.free_shipping_threshold_minor = data.free_shipping_threshold_minor
    x.offer_label = data.offer_label
    x.estimated_days_min = data.estimated_days_min
    x.estimated_days_max = data.estimated_days_max
    x.version = int(x.version or 1) + 1
    db.commit()
    return json_model(x) | {'carrier_name': SUPPORTED_SHIPPING_CARRIERS[code]}

@router.delete('/shipping-methods/{shipping_id}')
def delete_shipping(shipping_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    x = db.query(ShippingMethod).filter_by(id=shipping_id, tenant_id=tenant_id).first()
    if not x:
        raise not_found('Shipping method not found')
    x.is_active = False
    db.commit()
    return {'ok': True}

@router.get('/shipping-methods')
def list_shipping_methods(tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    rows = db.query(ShippingMethod).filter_by(tenant_id=tenant_id).order_by(ShippingMethod.name.asc()).all()
    return {'items': [json_model(x) | {'carrier_name': SUPPORTED_SHIPPING_CARRIERS.get(x.carrier_code, x.carrier_code)} for x in rows]}

@router.post('/shipping/quote')
def shipping_quote(tenant_id: str, data: ShippingQuoteIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.read'))):
    tenant_scope(tenant_id, user, db)
    methods = db.query(ShippingMethod).filter_by(tenant_id=tenant_id, is_active=True,
        currency=data.currency.upper()).all()
    rates = []
    subtotal_minor = int(getattr(data, 'subtotal_minor', 0) or 0)
    for m in methods:
        rates.append(_shipping_public_view(m, subtotal_minor))
    if not rates:
        raise AppError(404, 'NO_SHIPPING_RATES',
            'No shipping methods are available for this currency')
    return rates
