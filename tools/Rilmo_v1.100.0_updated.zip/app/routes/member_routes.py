"""Tenant staff/membership routes: list, add, patch role/status, remove.

Extracted out of app/routes/v1.py (Phase 3, step 16).
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found, forbidden
from app.models.domain import *
from app.core.serialization import json_model
from app.services.core import audit
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.get('/members')
def members(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('staff.manage'))):
    tenant_scope(tenant_id, user, db)
    return [json_model(m) | {'user': json_model(db.get(User,
        m.user_id))} for m in db.query(TenantMembership).filter_by(tenant_id=tenant_id).all()]

@router.post('/members')
def add_member(tenant_id: str, data: dict, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('staff.manage'))):
    membership = tenant_scope(tenant_id, user, db)
    target = db.query(User).filter(func.lower(User.email) == str(data.get('email',
        '')).lower()).first()
    if not target:
        raise not_found('User not found')
    role = data.get('role', 'staff')
    if role not in {'owner', 'admin', 'staff', 'viewer'}:
        raise AppError(400, 'ROLE_INVALID', 'Invalid role')
    # staff.manage must not become a privilege-escalation primitive. Only an
    # existing owner may grant owner/admin; admin may manage staff/viewer.
    if role in {'owner', 'admin'} and membership.role != 'owner':
        raise forbidden('Only the tenant owner may grant owner or admin roles')
    if db.query(TenantMembership).filter_by(tenant_id=tenant_id, user_id=target.id).first():
        raise AppError(409, 'MEMBER_EXISTS', 'Member already exists')
    m = TenantMembership(tenant_id=tenant_id, user_id=target.id, role=role, status='ACTIVE')
    db.add(m)
    db.flush()
    audit(db, tenant_id, user.id, 'member.create', 'membership', m.id, after={'user_id': target.id,
        'role': role})
    db.commit()
    return json_model(m)

@router.patch('/members/{member_id}')
def patch_member(member_id: str, tenant_id: str, data: dict, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('staff.manage'))):
    membership = tenant_scope(tenant_id, user, db)
    m = db.query(TenantMembership).filter_by(id=member_id, tenant_id=tenant_id).first()
    if not m:
        raise not_found('Member not found')
    if m.user_id == user.id and data.get('role') in {'viewer'}:
        raise AppError(409, 'OWNER_LOCKOUT',
            'You cannot demote yourself to a role without staff management')
    if 'role' in data:
        if data['role'] not in {'owner', 'admin', 'staff', 'viewer'}:
            raise AppError(400, 'ROLE_INVALID', 'Invalid role')
        target_role = data['role']
        if target_role in {'owner', 'admin'} and membership.role != 'owner':
            raise forbidden('Only the tenant owner may grant owner or admin roles')
        if m.role == 'owner' and membership.role != 'owner':
            raise forbidden('Only the tenant owner may modify the owner membership')
        if m.user_id == user.id and target_role != membership.role and membership.role != 'owner':
            raise forbidden('Only the tenant owner may change their own elevated role')
        m.role = target_role
    if 'status' in data and data['status'] in {'ACTIVE', 'SUSPENDED'}:
        m.status = data['status']
    audit(db, tenant_id, user.id, 'member.update', 'membership', m.id, after=data)
    db.commit()
    return json_model(m)

@router.delete('/members/{member_id}')
def delete_member(member_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('staff.manage'))):
    tenant_scope(tenant_id, user, db)
    m = db.query(TenantMembership).filter_by(id=member_id, tenant_id=tenant_id).first()
    if not m:
        raise not_found('Member not found')
    if m.user_id == user.id:
        raise AppError(409, 'SELF_REMOVE_FORBIDDEN', 'You cannot remove yourself')
    m.status = 'SUSPENDED'
    audit(db, tenant_id, user.id, 'member.delete', 'membership', m.id,
        after={'status': 'SUSPENDED'})
    db.commit()
    return {'ok': True}
