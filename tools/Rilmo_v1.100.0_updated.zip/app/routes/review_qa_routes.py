"""Product review & Q&A routes: submit review, submit question, moderate
review, answer question, list reviews, list questions.

Extracted out of app/routes/v1.py (Phase 3, step 15).

Bug fix while moving: list_questions() queried the legacy `Question` table,
but create_question() (the POST /questions handler) always writes to the
separate `ReviewQuestion` table (used by moderate/answer too). Those two
models are backed by different tables (`questions` vs `review_questions`),
so GET /questions could never show a question a merchant had actually
received — it would always come back empty. No test covered this endpoint,
so it went unnoticed. Fixed by querying ReviewQuestion, matching every other
handler in this file.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import outbox
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.post('/reviews')
def review(tenant_id: str, data: ReviewIn, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    c = db.query(Customer).filter_by(tenant_id=tenant_id, email=user.email).first()
    p = db.query(Product).filter_by(id=data.product_id, tenant_id=tenant_id,
        deleted_at=None).first()
    order = db.query(Order).filter_by(id=data.order_id, tenant_id=tenant_id,
        status='DELIVERED').first()
    if not c:
        c = Customer(tenant_id=tenant_id, email=user.email)
        db.add(c)
        db.flush()
    if not p or not order:
        raise AppError(409, 'VERIFIED_PURCHASE_REQUIRED',
            'Reviews require a delivered order for this product')
    product_variant_ids = [x.variant_id for x in db.query(OrderItem).filter_by(order_id=order.id,
        tenant_id=tenant_id).all()]
    if not db.query(ProductVariant).filter(ProductVariant.tenant_id == tenant_id,
        ProductVariant.id.in_(product_variant_ids), ProductVariant.product_id == p.id).first():
        raise AppError(409, 'PRODUCT_NOT_IN_ORDER',
            'The delivered order does not contain this product')
    if db.query(Review).filter_by(tenant_id=tenant_id, order_id=order.id, product_id=p.id,
        customer_id=c.id).first():
        raise AppError(409, 'REVIEW_EXISTS', 'A review already exists for this order and product')
    r = Review(tenant_id=tenant_id, product_id=p.id, order_id=order.id, customer_id=c.id,
        rating=data.rating, body=data.body)
    db.add(r)
    db.flush()
    outbox(db, tenant_id, 'review', r.id, 'review.submitted', {'review_id': r.id,
        'tenant_id': tenant_id})
    db.commit()
    return json_model(r)

@router.post('/questions')
def question(tenant_id: str, data: QuestionIn, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    c = db.query(Customer).filter_by(tenant_id=tenant_id,
        email=user.email).first() or Customer(tenant_id=tenant_id, email=user.email)
    db.add(c)
    db.flush()
    p = db.query(Product).filter_by(id=data.product_id, tenant_id=tenant_id,
        deleted_at=None).first()
    if not p:
        raise not_found('Product not found')
    q = ReviewQuestion(tenant_id=tenant_id, product_id=p.id, customer_id=c.id, body=data.body)
    db.add(q)
    db.flush()
    outbox(db, tenant_id, 'review_question', q.id, 'question.submitted', {'question_id': q.id,
        'tenant_id': tenant_id})
    db.commit()
    return json_model(q)

@router.patch('/reviews/{review_id}/moderate')
def moderate_review(review_id: str, tenant_id: str, data: dict, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    r = db.query(Review).filter_by(id=review_id, tenant_id=tenant_id).first()
    if not r:
        raise not_found('Review not found')
    status = data.get('status', 'APPROVED')
    if status not in {'PENDING', 'APPROVED', 'REJECTED'}:
        raise AppError(400, 'REVIEW_STATUS_INVALID', 'Invalid review status')
    r.status = status
    outbox(db, tenant_id, 'review', r.id, 'review.moderated', {'review_id': r.id, 'status': status,
        'tenant_id': tenant_id})
    db.commit()
    return json_model(r)

@router.post('/questions/{question_id}/answers')
def answer_question(question_id: str, tenant_id: str, data: AnswerIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    q = db.query(ReviewQuestion).filter_by(id=question_id, tenant_id=tenant_id).first()
    if not q:
        raise not_found('Question not found')
    a = ReviewAnswer(tenant_id=tenant_id, question_id=q.id, answered_by_user_id=user.id,
        body=data.body)
    db.add(a)
    db.flush()
    outbox(db, tenant_id, 'review_question', q.id, 'question.answered', {'question_id': q.id,
        'answer_id': a.id, 'tenant_id': tenant_id})
    q.status = 'answered'
    db.commit()
    return json_model(a)

@router.get('/reviews')
def list_reviews(tenant_id: str, status: str | None=None, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    q = db.query(Review).filter_by(tenant_id=tenant_id)
    if status:
        q = q.filter_by(status=status)
    rows = q.order_by(Review.id.desc()).limit(100).all()
    return {'items': [json_model(x) for x in rows]}

@router.get('/questions')
def list_questions(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    rows = db.query(ReviewQuestion).filter_by(tenant_id=tenant_id).order_by(ReviewQuestion.id.desc()).limit(100).all()
    return {'items': [json_model(x) for x in rows]}
