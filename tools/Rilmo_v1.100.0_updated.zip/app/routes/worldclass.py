from datetime import datetime, timezone, timedelta
import hashlib, json, uuid, secrets, re
from fastapi import APIRouter, Depends, Request, Header, Response
from fastapi.responses import JSONResponse, PlainTextResponse
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func, and_
from sqlalchemy.exc import IntegrityError
from app.core.database import get_db, set_tenant_context
from app.core.auth import current_user, tenant_user, current_platform_admin, current_platform_compliance_officer
from app.core.errors import AppError, forbidden, not_found
from app.core.serialization import json_model
from app.models.domain import *
from app.services.worldclass import stable_variant, storefront_metrics, catalog_for_agent, compute_feed
from app.services.core import audit, enforce_rate_limit, idem, finalize_idem, body_hash, outbox
from app.services.platform_ecosystem import validate_steps, execute_workflow, app_rating_summary
from app.services.global_readiness import seed_default_market_profiles, readiness_summary, require_market_ready, APP_STORE_POLICY
from app.core.security import token_hash

router = APIRouter(prefix='/v1')


def _uid() -> str:
    return uuid.uuid4().hex


@router.get('/public/payment/installation-policy')
def public_installment_policy(currency: str='TRY'):
    s=__import__('app.core.config', fromlist=['get_settings']).get_settings()
    return {'currency':str(currency or 'TRY').upper()[:3],'same_price_only':bool(s.CARD_INSTALLMENT_SAME_PRICE_ONLY),'max_installments':int(s.CARD_INSTALLMENT_MAX_COUNT),'price_delta_minor':0,'customer_price_equals_base_price':True,'interest_or_markup_by_rilmo':False}


@router.get('/public/app-store/payment-policy')
def public_app_store_payment_policy(platform: str, market_key: str='GLOBAL', sku_category: str='physical_goods'):
    platform_key=str(platform or '').strip().lower()
    market=str(market_key or 'GLOBAL').strip().upper()[:80]
    sku=str(sku_category or 'physical_goods').strip().lower()
    if platform_key not in APP_STORE_POLICY or sku not in APP_STORE_POLICY[platform_key]:
        raise AppError(400,'APP_STORE_POLICY_INVALID','Unsupported platform or SKU category')
    rule=APP_STORE_POLICY[platform_key][sku]
    return {'platform':platform_key,'market_key':market,'sku_category':sku,'payment_method':rule['payment_method'],'allowed':bool(rule['allowed']),'policy_reference':rule['reference']}


@router.get('/platform/global-readiness')
def platform_global_readiness(user=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    seed_default_market_profiles(db, _uid, lambda: datetime.now(timezone.utc))
    markets = readiness_summary(db)
    return {'markets': markets, 'status': 'READY' if all(x['ready'] for x in markets) else 'EXTERNAL_EVIDENCE_REQUIRED'}

@router.post('/platform/global-readiness/evidence')
def platform_global_readiness_evidence(data: dict, user=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    from app.models.domain import GlobalLaunchEvidence
    from datetime import datetime, timezone
    market=str(data.get('market_key') or '').upper(); code=str(data.get('requirement_code') or '').strip(); status=str(data.get('status') or 'MISSING').upper()
    if not market or not code or status not in {'MISSING','PLANNED','VERIFIED','EXPIRED'}:
        raise AppError(400,'GLOBAL_EVIDENCE_INVALID','market_key, requirement_code and supported status are required')
    row=db.query(GlobalLaunchEvidence).filter_by(market_key=market,requirement_code=code).first()
    if not row:
        row=GlobalLaunchEvidence(id=uuid.uuid4().hex,market_key=market,requirement_code=code,created_at=datetime.now(timezone.utc),updated_at=datetime.now(timezone.utc)); db.add(row)
    row.status=status; row.evidence_ref=data.get('evidence_ref'); row.source_url=data.get('source_url'); row.notes=data.get('notes'); row.reviewer_user_id=user.id; row.verified_at=datetime.now(timezone.utc) if status=='VERIFIED' else None; row.expires_at=datetime.fromisoformat(data['expires_at']) if data.get('expires_at') else None; row.updated_at=datetime.now(timezone.utc)
    db.commit(); audit(db,None,user.id,'platform.global_evidence.updated','global_launch_evidence',row.id,after={'market_key':market,'requirement_code':code,'status':status}); db.commit()
    return json_model(row)

@router.get('/public/legal/jurisdiction')
def public_legal_jurisdiction(country_code: str, db: DBSession = Depends(get_db)):
    from app.services.privacy import jurisdiction_for_country
    from app.services.legal_compliance import policy_for
    code=str(country_code or '').upper()[:2]
    jurisdiction=jurisdiction_for_country(code)
    row=db.query(JurisdictionCompliancePolicy).filter_by(jurisdiction=jurisdiction, policy_version='2026-08-20').first()
    return {'country_code':code,'jurisdiction':jurisdiction,'policy':(json_model(row) if row else policy_for(jurisdiction)),'legal_notice_required':True}

@router.get('/public/storefront/{hostname}/trader')
def public_trader_information(hostname: str, db: DBSession = Depends(get_db)):
    _, _, tenant = _public_storefront(hostname, db)
    trace=db.query(MerchantMarketplaceTraceability).filter_by(tenant_id=tenant.id).first()
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant.id).first()
    return {'merchant_id':tenant.id,'merchant_name':tenant.name,'legal_name':profile.legal_name if profile else tenant.name,
            'country_code':profile.country_code if profile else None,
            'business_type':profile.business_type if profile else None,
            'trade_register_name':trace.trade_register_name if trace else None,
            'trade_register_number':trace.trade_register_number if trace else None,
            'verified':bool(trace and trace.verified_at)}

@router.post('/public/dsa/notice')
def public_dsa_notice(data: dict, request: Request, db: DBSession = Depends(get_db)):
    from app.models.domain import DSAComplianceCase
    content_type=str(data.get('content_type') or '').strip().upper()
    content_id=str(data.get('content_id') or '').strip()
    reason=str(data.get('reason_code') or '').strip().upper()
    description=str(data.get('description') or '').strip()
    if content_type not in {'PRODUCT','STORE','REVIEW','QUESTION','OTHER'} or not content_id or not reason or len(description) < 10 or len(description) > 5000:
        raise AppError(400,'DSA_NOTICE_INVALID','content_type, content_id, reason_code and a bounded description are required')
    email=str(data.get('reporter_email') or '').strip().lower() or None
    row=DSAComplianceCase(id=_uid(),tenant_id=None,reporter_email=email,content_type=content_type,content_id=content_id,
        jurisdiction=str(data.get('jurisdiction') or 'EU-DSA').upper(),reason_code=reason,description=description,status='SUBMITTED',
        created_at=datetime.now(timezone.utc),updated_at=datetime.now(timezone.utc))
    db.add(row); db.flush(); audit(db,None,None,'dsa.notice.submitted','DSAComplianceCase',row.id,after={'content_type':content_type,'reason_code':reason})
    db.commit()
    return {'id':row.id,'status':row.status,'appeal_available':False,'notice':'Your report was received and will be reviewed.'}

@router.post('/public/dsa/notice/{case_id}/appeal')
def public_dsa_appeal(case_id: str, data: dict, db: DBSession = Depends(get_db)):
    from app.models.domain import DSAComplianceCase
    row=db.query(DSAComplianceCase).filter_by(id=case_id).first()
    if not row: raise not_found('DSA case not found')
    if row.status not in {'DECIDED','CLOSED'}: raise AppError(409,'DSA_APPEAL_NOT_READY','An appeal can be submitted after a decision')
    row.appeal_status='SUBMITTED'; row.updated_at=datetime.now(timezone.utc)
    audit(db,None,None,'dsa.notice.appeal.submitted','DSAComplianceCase',row.id,after={'appeal_status':row.appeal_status})
    db.commit(); return {'id':row.id,'appeal_status':row.appeal_status}

@router.get('/platform/legal/jurisdiction-policies')
def platform_legal_jurisdiction_policies(user=Depends(current_platform_admin), db: DBSession = Depends(get_db)):
    from app.services.legal_compliance import JURISDICTION_DEFAULTS
    return {'engineering_baseline':'2026-08-20','items':[{'jurisdiction':k,**v} for k,v in JURISDICTION_DEFAULTS.items()]}

@router.get('/platform/privacy/processing-activities')
def platform_privacy_processing_activities(user=Depends(current_platform_compliance_officer), db: DBSession = Depends(get_db)):
    from app.models.domain import PrivacyProcessingActivity
    return {'items':[json_model(x) for x in db.query(PrivacyProcessingActivity).order_by(PrivacyProcessingActivity.activity_key.asc()).all()]}

@router.post('/platform/dsa/cases/{case_id}/decision')
def platform_dsa_decision(case_id: str, data: dict, admin=Depends(current_platform_compliance_officer), db: DBSession = Depends(get_db)):
    row=db.query(DSAComplianceCase).filter_by(id=case_id).first()
    if not row: raise not_found('DSA case not found')
    decision=str(data.get('decision') or '').upper()
    if decision not in {'REMOVE','RESTRICT','NO_ACTION','ESCALATE'}: raise AppError(400,'DSA_DECISION_INVALID','Unsupported DSA decision')
    row.status='DECIDED'; row.decision=decision; row.decision_reason=str(data.get('decision_reason') or '')[:5000]; row.updated_at=datetime.now(timezone.utc)
    audit(db,None,admin.user_id,'dsa.case.decided','DSAComplianceCase',row.id,after={'decision':decision})
    db.commit(); return {'id':row.id,'status':row.status,'decision':row.decision,'appeal_available':True}

@router.get('/platform/app-store-policies')
def platform_app_store_policies(user=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    from app.models.domain import AppStoreDistributionPolicy
    seed_default_market_profiles(db, uid, datetime.now)
    rows=db.query(AppStoreDistributionPolicy).all()
    return {'items':[json_model(x) for x in rows]}

@router.post('/merchant/marketplace-traceability')
def update_marketplace_traceability(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'settings.manage')
    from app.models.domain import MerchantMarketplaceTraceability
    row=db.query(MerchantMarketplaceTraceability).filter_by(tenant_id=tenant_id).first()
    if not row:
        row=MerchantMarketplaceTraceability(id=uid(),tenant_id=tenant_id,created_at=datetime.now(timezone.utc),updated_at=datetime.now(timezone.utc)); db.add(row)
    row.trade_register_name=str(data.get('trade_register_name') or '').strip() or None
    row.trade_register_number=str(data.get('trade_register_number') or '').strip() or None
    row.payout_account_reference=str(data.get('payout_account_reference') or '').strip() or None
    row.seller_self_certification=bool(data.get('seller_self_certification',False))
    row.updated_at=datetime.now(timezone.utc)
    db.commit(); return json_model(row)

def _tenant(tenant_id, user, db):
    m = tenant_user(tenant_id, user, db); set_tenant_context(db, tenant_id); return m

def _perm(tenant_id, user, db, perm):
    m=_tenant(tenant_id,user,db)
    defaults={'owner':{'*'},'admin':{'*'},'staff':{'products.read','products.write','orders.read','orders.manage','inventory.read','inventory.write','finance.read','customers.read','settings.manage','apps.manage'},'viewer':{'products.read','orders.read','inventory.read'}}
    rows={r.permission for r in db.query(RolePermission).filter_by(role=m.role).all()}
    allowed=rows or defaults.get(m.role,set())
    if '*' not in allowed and perm not in allowed: raise forbidden('Permission denied')
    return m

@router.get('/b2b/companies')
def b2b_companies(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'orders.read')
    rows=db.query(B2BCompany).filter_by(tenant_id=tenant_id).order_by(B2BCompany.created_at.desc()).limit(250).all()
    return {'items':[json_model(x) for x in rows]}

@router.post('/b2b/companies')
def b2b_company(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'orders.manage')
    code=str(data.get('external_code') or '').strip(); name=str(data.get('name') or '').strip()
    if not code or not name: raise AppError(400,'B2B_COMPANY_INVALID','name and external_code are required')
    if db.query(B2BCompany).filter_by(tenant_id=tenant_id, external_code=code).first(): raise AppError(409,'B2B_COMPANY_EXISTS','Company code already exists')
    row=B2BCompany(tenant_id=tenant_id,name=name,external_code=code,currency=str(data.get('currency') or 'USD').upper()[:3],payment_terms_days=max(0,int(data.get('payment_terms_days') or 0)),credit_limit_minor=max(0,int(data.get('credit_limit_minor') or 0)))
    db.add(row); db.commit(); audit(db,tenant_id,user.id,'b2b.company.created','b2b_company',row.id,after={'external_code':code}); db.commit()
    return json_model(row)

@router.post('/b2b/companies/{company_id}/contacts')
def b2b_contact(company_id: str, tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'orders.manage'); c=db.query(B2BCompany).filter_by(id=company_id,tenant_id=tenant_id).first()
    if not c: raise not_found('B2B company not found')
    email=str(data.get('email') or '').strip().lower(); name=str(data.get('name') or '').strip()
    if '@' not in email: raise AppError(400,'EMAIL_INVALID','Valid email required')
    row=B2BCompanyContact(tenant_id=tenant_id,company_id=c.id,email=email,name=name or None,role=str(data.get('role') or 'BUYER').upper())
    db.add(row); db.commit(); return json_model(row)

@router.post('/b2b/catalogs')
def b2b_catalog(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'products.write')
    code=str(data.get('code') or '').strip(); name=str(data.get('name') or '').strip()
    if not code or not name: raise AppError(400,'B2B_CATALOG_INVALID','code and name are required')
    row=B2BCatalog(tenant_id=tenant_id,code=code,name=name,currency=str(data.get('currency') or 'USD').upper()[:3]); db.add(row); db.commit()
    for item in data.get('items') or []:
        variant=db.query(ProductVariant).join(Product,Product.id==ProductVariant.product_id).filter(ProductVariant.id==item.get('variant_id'),Product.tenant_id==tenant_id).first()
        if not variant: continue
        db.add(B2BCatalogItem(tenant_id=tenant_id,catalog_id=row.id,variant_id=variant.id,price_minor=item.get('price_minor'),min_quantity=max(1,int(item.get('min_quantity') or 1)),max_quantity=item.get('max_quantity'),discount_bps=max(0,min(10000,int(item.get('discount_bps') or 0)))))
    db.commit(); return json_model(row)

@router.post('/b2b/catalogs/{catalog_id}/assign')
def b2b_assign(catalog_id: str, tenant_id: str, company_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'orders.manage')
    if not db.query(B2BCatalog).filter_by(id=catalog_id,tenant_id=tenant_id).first() or not db.query(B2BCompany).filter_by(id=company_id,tenant_id=tenant_id).first(): raise not_found('B2B resource not found')
    row=B2BCatalogAssignment(tenant_id=tenant_id,company_id=company_id,catalog_id=catalog_id); db.add(row); db.commit(); return json_model(row)

@router.get('/b2b/catalogs/{catalog_id}/prices/{variant_id}')
def b2b_price(catalog_id: str, variant_id: str, tenant_id: str, quantity: int=1, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'products.read')
    item=db.query(B2BCatalogItem).filter_by(tenant_id=tenant_id,catalog_id=catalog_id,variant_id=variant_id).first()
    variant=db.query(ProductVariant).filter_by(tenant_id=tenant_id,id=variant_id).first()
    if not item or not variant: raise not_found('B2B catalog price not found')
    q=max(1,int(quantity));
    if q < int(item.min_quantity or 1): raise AppError(422,'B2B_MIN_QUANTITY','Quantity is below catalog minimum')
    if item.max_quantity is not None and q > int(item.max_quantity): raise AppError(422,'B2B_MAX_QUANTITY','Quantity exceeds catalog maximum')
    base=int(item.price_minor if item.price_minor is not None else variant.price_amount_minor)
    price=max(0, base - (base * int(item.discount_bps or 0) // 10000))
    return {'catalog_id':catalog_id,'variant_id':variant_id,'quantity':q,'unit_price_minor':price,'currency':variant.currency,'discount_bps':int(item.discount_bps or 0)}

@router.get('/pos/locations')
def pos_locations(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'orders.read'); return {'items':[json_model(x) for x in db.query(POSLocation).filter_by(tenant_id=tenant_id).all()]}

@router.post('/pos/locations')
def pos_location(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'inventory.write'); code=str(data.get('code') or '').strip(); name=str(data.get('name') or '').strip()
    if not code or not name: raise AppError(400,'POS_LOCATION_INVALID','code and name are required')
    row=POSLocation(tenant_id=tenant_id,code=code,name=name,address=data.get('address')) ; db.add(row); db.commit(); return json_model(row)

@router.post('/pos/registers')
def pos_register(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'inventory.write'); loc=db.query(POSLocation).filter_by(id=data.get('location_id'),tenant_id=tenant_id).first()
    if not loc: raise not_found('POS location not found')
    row=POSRegister(tenant_id=tenant_id,location_id=loc.id,register_code=str(data.get('register_code') or '').strip(),name=str(data.get('name') or '').strip(),device_public_key=data.get('device_public_key')); db.add(row); db.commit(); return json_model(row)

@router.post('/pos/sessions/open')
def pos_open(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'orders.manage'); reg=db.query(POSRegister).filter_by(id=data.get('register_id'),tenant_id=tenant_id,status='ACTIVE').with_for_update().first()
    if not reg: raise not_found('POS register not found')
    existing=db.query(POSSession).filter_by(tenant_id=tenant_id,register_id=reg.id,status='OPEN').first()
    if existing: raise AppError(409,'POS_SESSION_EXISTS','Register already has an open session')
    row=POSSession(tenant_id=tenant_id,register_id=reg.id,opened_by_user_id=user.id,opening_cash_minor=max(0,int(data.get('opening_cash_minor') or 0)),expected_cash_minor=max(0,int(data.get('opening_cash_minor') or 0))); db.add(row); db.commit(); return json_model(row)

@router.post('/pos/sessions/{session_id}/sales')
def pos_sale(session_id: str, tenant_id: str, data: dict, idempotency_key: str | None = Header(default=None, alias='Idempotency-Key'), user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'orders.manage')
    if not idempotency_key:
        raise AppError(428,'POS_IDEMPOTENCY_REQUIRED','Idempotency-Key is required for POS sales')
    idem_rec, idem_ok = idem(db, tenant_id, user.id, f'pos.sale:{session_id}', idempotency_key, body_hash(data))
    if not idem_ok:
        raise AppError(409,'IDEMPOTENCY_MISMATCH','Same idempotency key used with a different POS sale')
    if idem_rec and idem_rec.status == 'COMPLETED':
        return idem_rec.response_body or {}
    session=db.query(POSSession).filter_by(id=session_id,tenant_id=tenant_id,status='OPEN').with_for_update().first()
    if not session: raise not_found('POS session not found')
    items=data.get('items') or []
    if not items: raise AppError(400,'POS_SALE_EMPTY','At least one item is required')
    register=db.query(POSRegister).filter_by(id=session.register_id,tenant_id=tenant_id,status='ACTIVE').first()
    if not register: raise not_found('POS register not found')
    location=db.query(POSLocation).filter_by(id=register.location_id,tenant_id=tenant_id,status='ACTIVE').first()
    if not location or not location.inventory_location_id:
        raise AppError(409,'POS_INVENTORY_LOCATION_REQUIRED','POS location must be linked to an inventory location')
    order_number=f"POS-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:8].upper()}"
    currency=str(data.get('currency') or 'USD').upper()[:3]
    customer_id=data.get('customer_id')
    if customer_id:
        customer=db.query(Customer).filter_by(id=str(customer_id),tenant_id=tenant_id).first()
        if not customer:
            raise not_found('POS customer not found')
    order=Order(tenant_id=tenant_id,order_number=order_number,status='CONFIRMED',payment_status='PAID',fulfillment_status='FULFILLED',currency=currency,subtotal_minor=0,discount_minor=0,shipping_minor=0,tax_minor=0,fee_minor=0,total_minor=0,customer_id=customer_id)
    db.add(order); db.flush(); total=0
    for raw in items:
        variant=db.query(ProductVariant).filter_by(id=raw.get('variant_id'),tenant_id=tenant_id,status='ACTIVE').first()
        if not variant: raise not_found('POS product variant not found')
        product=db.query(Product).filter_by(id=variant.product_id,tenant_id=tenant_id,deleted_at=None).first()
        if not product: raise not_found('POS product not found')
        if variant.currency != currency:
            raise AppError(409,'POS_CURRENCY_MISMATCH','POS sale currency must match every variant currency')
        try:
            qty=int(raw.get('quantity'))
        except (TypeError, ValueError):
            raise AppError(422,'POS_QUANTITY_INVALID','Quantity must be a positive integer')
        if qty <= 0:
            raise AppError(422,'POS_QUANTITY_INVALID','Quantity must be a positive integer')
        inv=db.query(InventoryItem).filter_by(tenant_id=tenant_id,variant_id=variant.id,location_id=location.inventory_location_id).with_for_update().first()
        if product.product_type == 'PHYSICAL' and not inv:
            raise AppError(409,'POS_INVENTORY_RECORD_MISSING','Physical POS product has no inventory record at this location')
        if inv and int(inv.available or 0) < qty:
            raise AppError(409,'POS_INSUFFICIENT_STOCK','Insufficient stock')
        unit=int(variant.price_amount_minor); line=unit*qty; total+=line
        db.add(OrderItem(tenant_id=tenant_id,order_id=order.id,variant_id=variant.id,sku_snapshot=variant.sku,title_snapshot=product.title,quantity=qty,unit_price_minor=unit,cost_amount_minor=variant.cost_amount_minor,discount_minor=0,tax_minor=0,total_minor=line,currency=currency))
        if inv:
            inv.on_hand-=qty; inv.available-=qty; inv.version+=1
    order.subtotal_minor=total; order.total_minor=total
    db.add(POSOrderLink(tenant_id=tenant_id,order_id=order.id,pos_session_id=session.id,channel='POS')); session.expected_cash_minor += 0
    body={'order_id':order.id,'order_number':order.order_number,'total_minor':total,'currency':currency,'payment_status':order.payment_status}
    finalize_idem(idem_rec, body, 200)
    db.commit(); audit(db,tenant_id,user.id,'pos.sale.created','order',order.id,after={'total_minor':total,'pos_session_id':session.id}); db.commit()
    return body

@router.post('/pos/sessions/{session_id}/close')
def pos_close(session_id: str, tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'orders.manage'); row=db.query(POSSession).filter_by(id=session_id,tenant_id=tenant_id,status='OPEN').with_for_update().first()
    if not row: raise not_found('POS session not found')
    row.closing_cash_minor=max(0,int(data.get('closing_cash_minor') or 0)); row.status='CLOSED'; row.closed_at=datetime.now(timezone.utc); db.commit(); return json_model(row)

@router.get('/analytics/executive')
def analytics_executive(tenant_id: str, days: int=30, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'finance.read'); days=max(1,min(days,90)); metrics=storefront_metrics(db,tenant_id,days)
    orders=db.query(Order).filter(Order.tenant_id==tenant_id,Order.status.notin_(['DRAFT','CANCELLED'])).order_by(Order.total_minor.desc()).limit(10).all()
    return {'metrics':metrics,'top_orders':[json_model(x) for x in orders],'generated_at':datetime.now(timezone.utc).isoformat()}

@router.get('/analytics/profitability')
def analytics_profitability(tenant_id: str, days: int = 30, user=Depends(current_user), db: DBSession=Depends(get_db)):
    """Merchant-grade merchandise profitability using immutable order cost snapshots."""
    _perm(tenant_id, user, db, 'finance.read')
    try:
        window_days = max(1, min(365, int(days)))
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'ANALYTICS_WINDOW_INVALID', 'days must be an integer') from exc
    start = datetime.now(timezone.utc) - timedelta(days=window_days)
    orders = (db.query(Order).filter(Order.tenant_id == tenant_id,
        Order.created_at >= start, Order.status.notin_(['DRAFT', 'CANCELLED'])).all())
    order_ids = [o.id for o in orders]
    items = []
    if order_ids:
        items = db.query(OrderItem).filter(OrderItem.tenant_id == tenant_id,
            OrderItem.order_id.in_(order_ids)).all()
    merchandise_revenue = sum(int(i.total_minor or 0) for i in items)
    known_cogs = sum(int(i.cost_amount_minor or 0) * int(i.quantity or 0) for i in items if i.cost_amount_minor is not None)
    units = sum(int(i.quantity or 0) for i in items)
    missing_cost_units = sum(int(i.quantity or 0) for i in items if i.cost_amount_minor is None)
    known_gross_profit = merchandise_revenue - known_cogs
    complete = missing_cost_units == 0
    return {
        'window_days': window_days,
        'orders': len(orders),
        'units': units,
        'merchandise_revenue_minor': merchandise_revenue,
        'known_cogs_minor': known_cogs,
        # Never present an incomplete margin as a definitive merchant profit.
        'gross_profit_minor': known_gross_profit if complete else None,
        'known_gross_profit_minor': known_gross_profit,
        'gross_margin_bps': int(known_gross_profit * 10000 / merchandise_revenue) if complete and merchandise_revenue else (10000 if complete and units == 0 else None),
        'cost_complete': complete,
        'missing_cost_units': missing_cost_units,
        'cost_coverage_bps': int((units - missing_cost_units) * 10000 / units) if units else 10000,
        'currency_note': 'Amounts are reported in the order-item currencies; aggregate only within a single currency.',
    }



@router.get('/analytics/pricing-intelligence')
def analytics_pricing_intelligence(tenant_id: str, target_margin_bps: int = 2000, user=Depends(current_user), db: DBSession=Depends(get_db)):
    """Catalog pricing health without mutating prices.

    Computes a target minimum price from the immutable catalog cost snapshot and
    flags products that are already below cost, below the merchant's target
    gross margin, or missing cost data. Currency totals remain bucketed.
    """
    _perm(tenant_id, user, db, 'finance.read')
    try:
        margin = int(target_margin_bps)
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'PRICING_MARGIN_INVALID', 'target_margin_bps must be an integer') from exc
    if not 0 <= margin <= 10000:
        raise AppError(422, 'PRICING_MARGIN_INVALID', 'target_margin_bps must be between 0 and 10000')

    rows = (db.query(ProductVariant, Product)
        .join(Product, Product.id == ProductVariant.product_id)
        .filter(ProductVariant.tenant_id == tenant_id,
                Product.tenant_id == tenant_id,
                Product.deleted_at.is_(None),
                ProductVariant.status == 'ACTIVE')
        .order_by(ProductVariant.currency, ProductVariant.id).all())

    items = []
    currencies = {}
    for variant, product in rows:
        cur = str(variant.currency or 'XXX').upper()
        bucket = currencies.setdefault(cur, {'variants': 0, 'healthy': 0, 'under_cost': 0,
                                             'below_target': 0, 'missing_cost': 0})
        bucket['variants'] += 1
        price = int(variant.price_amount_minor or 0)
        cost = None if variant.cost_amount_minor is None else int(variant.cost_amount_minor)
        if cost is None:
            status = 'MISSING_COST'
            bucket['missing_cost'] += 1
            recommended = None
            margin_bps = None
            gap = None
        else:
            recommended = (cost * 10000 + (10000 - margin) - 1) // (10000 - margin) if margin < 10000 else None
            margin_bps = int(max(0, (price - cost) * 10000 / price)) if price > 0 else 0
            if price < cost:
                status = 'UNDER_COST'; bucket['under_cost'] += 1
            elif recommended is not None and price < recommended:
                status = 'BELOW_TARGET_MARGIN'; bucket['below_target'] += 1
            else:
                status = 'HEALTHY'; bucket['healthy'] += 1
            gap = max(0, int(recommended) - price) if recommended is not None else None
        items.append({'variant_id': variant.id, 'product_id': product.id, 'sku': variant.sku,
                      'title': product.title, 'currency': cur, 'price_minor': price,
                      'cost_minor': cost, 'target_margin_bps': margin,
                      'current_margin_bps': margin_bps, 'recommended_min_price_minor': recommended,
                      'gap_to_target_minor': gap, 'status': status})
    alerts = sorted(
        [x for x in items if x['status'] in {'UNDER_COST', 'BELOW_TARGET_MARGIN', 'MISSING_COST'}],
        key=lambda x: {'UNDER_COST': 0, 'BELOW_TARGET_MARGIN': 1, 'MISSING_COST': 2}[x['status']])
    return {'target_margin_bps': margin, 'currencies': currencies, 'items': items, 'alerts': alerts,
            'integrity': {'cross_currency_aggregation': False, 'prices_read_only': True,
                          'missing_cost_is_not_invented': True}}

@router.get('/analytics/command-center')
def analytics_command_center(tenant_id: str, days: int = 30, user=Depends(current_user), db: DBSession=Depends(get_db)):
    """Merchant operating cockpit: actionable economics, operations and customer signals.

    Aggregates money by currency instead of silently mixing currencies, and treats
    missing historical cost as unknown rather than inventing profit.
    """
    _perm(tenant_id, user, db, 'finance.read')
    try:
        window_days = max(1, min(365, int(days)))
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'ANALYTICS_WINDOW_INVALID', 'days must be an integer') from exc
    now = datetime.now(timezone.utc)
    start = now - timedelta(days=window_days)
    orders = (db.query(Order)
        .filter(Order.tenant_id == tenant_id, Order.created_at >= start,
                Order.status.notin_(['DRAFT', 'CANCELLED']))
        .all())
    order_ids = [o.id for o in orders]
    items = (db.query(OrderItem).filter(OrderItem.tenant_id == tenant_id,
        OrderItem.order_id.in_(order_ids)).all()) if order_ids else []

    by_currency = {}
    product_rollup = {}
    for order in orders:
        cur = str(order.currency or 'XXX').upper()
        bucket = by_currency.setdefault(cur, {'revenue_minor': 0, 'orders': 0, 'refunded_minor': 0})
        bucket['revenue_minor'] += int(order.total_minor or 0)
        bucket['orders'] += 1
    refunds = (db.query(Refund).filter(Refund.tenant_id == tenant_id,
        Refund.created_at >= start, Refund.status.in_(['SUCCEEDED', 'COMPLETED'])).all())
    for refund in refunds:
        cur = str(refund.currency or 'XXX').upper()
        by_currency.setdefault(cur, {'revenue_minor': 0, 'orders': 0, 'refunded_minor': 0})['refunded_minor'] += int(refund.amount_minor or 0)

    known_cost_units = 0
    total_units = 0
    for item in items:
        qty = int(item.quantity or 0)
        total_units += qty
        cur = str(item.currency or 'XXX').upper()
        bucket = by_currency.setdefault(cur, {'revenue_minor': 0, 'orders': 0, 'refunded_minor': 0})
        bucket.setdefault('known_cogs_minor', 0)
        if item.cost_amount_minor is not None:
            known_cost_units += qty
            bucket['known_cogs_minor'] += int(item.cost_amount_minor) * qty
        key = item.variant_id or item.sku_snapshot
        row = product_rollup.setdefault(key, {'variant_id': item.variant_id, 'sku': item.sku_snapshot,
            'title': item.title_snapshot, 'currency': cur, 'units': 0, 'revenue_minor': 0,
            'known_cogs_minor': 0, 'missing_cost_units': 0})
        row['units'] += qty
        row['revenue_minor'] += int(item.total_minor or 0)
        if item.cost_amount_minor is None:
            row['missing_cost_units'] += qty
        else:
            row['known_cogs_minor'] += int(item.cost_amount_minor) * qty

    for bucket in by_currency.values():
        bucket.setdefault('known_cogs_minor', 0)
        bucket['net_revenue_minor'] = bucket['revenue_minor'] - bucket['refunded_minor']
        bucket['gross_profit_minor'] = bucket['revenue_minor'] - bucket['known_cogs_minor']
        bucket['cost_complete'] = True
    # Cost completeness is evaluated per currency, not globally across currencies.
    for cur, bucket in by_currency.items():
        currency_items = [i for i in items if str(i.currency or 'XXX').upper() == cur]
        bucket['missing_cost_units'] = sum(int(i.quantity or 0) for i in currency_items if i.cost_amount_minor is None)
        bucket['cost_complete'] = bucket['missing_cost_units'] == 0
        if not bucket['cost_complete']:
            bucket['gross_profit_minor'] = None
        bucket['gross_margin_bps'] = (int((bucket['revenue_minor'] - bucket['known_cogs_minor']) * 10000 / bucket['revenue_minor'])
            if bucket['cost_complete'] and bucket['revenue_minor'] else None)
        bucket['aov_minor'] = int(bucket['revenue_minor'] / bucket['orders']) if bucket['orders'] else 0

    inventory_rows = db.query(InventoryItem).filter_by(tenant_id=tenant_id).all()
    out_of_stock = sum(1 for x in inventory_rows if int(x.available or 0) <= 0)
    low_stock = sum(1 for x in inventory_rows if 0 < int(x.available or 0) <= 5)
    fulfillment_backlog = db.query(func.count(Order.id)).filter(
        Order.tenant_id == tenant_id, Order.status.notin_(['DRAFT', 'CANCELLED']),
        Order.fulfillment_status.in_(['UNFULFILLED', 'PROCESSING'])).scalar() or 0
    risk_review = db.query(func.count(Order.id)).filter(
        Order.tenant_id == tenant_id, Order.created_at >= start,
        Order.risk_status.in_(['REVIEW', 'HIGH', 'MANUAL_REVIEW'])).scalar() or 0
    customers_total = db.query(func.count(Customer.id)).filter(Customer.tenant_id == tenant_id).scalar() or 0
    new_customers = db.query(func.count(Customer.id)).filter(Customer.tenant_id == tenant_id,
        Customer.created_at >= start).scalar() or 0
    top_products = sorted(product_rollup.values(), key=lambda x: (x['revenue_minor'], x['units']), reverse=True)[:10]
    for row in top_products:
        row['gross_profit_minor'] = (row['revenue_minor'] - row['known_cogs_minor']) if row['missing_cost_units'] == 0 else None

    actions = []
    if out_of_stock:
        actions.append({'code': 'RESTOCK_OUT_OF_STOCK', 'priority': 'HIGH', 'count': out_of_stock,
            'message': 'Restock variants that currently cannot be sold.'})
    if low_stock:
        actions.append({'code': 'REVIEW_LOW_STOCK', 'priority': 'MEDIUM', 'count': low_stock,
            'message': 'Review low-stock variants before they become unavailable.'})
    if total_units and known_cost_units < total_units:
        actions.append({'code': 'COMPLETE_PRODUCT_COSTS', 'priority': 'HIGH',
            'missing_cost_units': total_units - known_cost_units,
            'message': 'Complete product costs to make gross-profit reporting definitive.'})
    if fulfillment_backlog:
        actions.append({'code': 'CLEAR_FULFILLMENT_BACKLOG', 'priority': 'HIGH', 'count': int(fulfillment_backlog),
            'message': 'Orders are awaiting fulfillment.'})
    if risk_review:
        actions.append({'code': 'REVIEW_RISK_ORDERS', 'priority': 'HIGH', 'count': int(risk_review),
            'message': 'Risk-scored orders require merchant review.'})
    if not actions:
        actions.append({'code': 'HEALTHY_OPERATIONS', 'priority': 'INFO', 'message': 'No critical operational action was detected in this window.'})

    return {
        'window_days': window_days,
        'generated_at': now.isoformat(),
        'currencies': by_currency,
        'operations': {'out_of_stock': out_of_stock, 'low_stock_le_5': low_stock,
            'fulfillment_backlog': int(fulfillment_backlog), 'risk_review': int(risk_review)},
        'customers': {'total': int(customers_total), 'new_in_window': int(new_customers)},
        'top_products': top_products,
        'actions': actions,
        'integrity': {'currency_safe': True, 'profit_unknown_when_cost_missing': True},
    }


@router.get('/analytics/customer-intelligence')
def analytics_customer_intelligence(tenant_id: str, days: int = 365, user=Depends(current_user), db: DBSession=Depends(get_db)):
    """Customer 360/RFM intelligence with currency-safe monetary buckets.

    The endpoint deliberately avoids inventing cross-currency LTV. Monetary
    rankings are grouped by currency, while behavioral segments are currency
    agnostic. Refunds are applied only from successful/completed refunds.
    """
    _perm(tenant_id, user, db, 'customers.read')
    try:
        window_days = max(30, min(3650, int(days)))
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'CUSTOMER_INTELLIGENCE_WINDOW_INVALID', 'days must be an integer') from exc

    now = datetime.now(timezone.utc)
    start = now - timedelta(days=window_days)
    rows = (db.query(
        Customer.id.label('customer_id'), Customer.email.label('email'),
        Customer.first_name.label('first_name'), Customer.last_name.label('last_name'),
        func.count(Order.id).label('order_count'),
        func.max(Order.created_at).label('last_order_at'),
        func.min(Order.created_at).label('first_order_at'),
        func.sum(Order.total_minor).label('gross_spend_minor'),
        Order.currency.label('currency'),
    ).join(Order, and_(Order.customer_id == Customer.id, Order.tenant_id == tenant_id))
      .filter(Customer.tenant_id == tenant_id,
              Order.created_at >= start,
              Order.status.notin_(['DRAFT', 'CANCELLED']))
      .group_by(Customer.id, Customer.email, Customer.first_name, Customer.last_name, Order.currency)
      .all())

    refund_rows = (db.query(
        Refund.order_id.label('order_id'), Refund.currency.label('refund_currency'), func.sum(Refund.amount_minor).label('refund_minor')
    ).filter(Refund.tenant_id == tenant_id,
             Refund.created_at >= start,
             Refund.status.in_(['SUCCEEDED', 'COMPLETED']))
      .group_by(Refund.order_id).all())
    refund_by_order = {(str(r.order_id), str(r.refund_currency or 'XXX').upper()): int(r.refund_minor or 0) for r in refund_rows}

    # Fetch order ids once so successful refunds can be allocated to the
    # customer's currency bucket without ever mixing currencies.
    customer_orders = (db.query(Order.id, Order.customer_id, Order.currency)
        .filter(Order.tenant_id == tenant_id, Order.created_at >= start,
                Order.status.notin_(['DRAFT', 'CANCELLED']), Order.customer_id.isnot(None)).all())
    refund_by_customer_currency = {}
    refund_currency_mismatches = 0
    for order_id, customer_id, currency in customer_orders:
        cur = str(currency or 'XXX').upper()
        amount = refund_by_order.get((str(order_id), cur), 0)
        if any(k[0] == str(order_id) and k[1] != cur for k in refund_by_order):
            refund_currency_mismatches += 1
        if amount:
            key = (str(customer_id), str(currency or 'XXX').upper())
            refund_by_customer_currency[key] = refund_by_customer_currency.get(key, 0) + amount

    segments = {'CHAMPION': 0, 'LOYAL': 0, 'PROMISING': 0, 'AT_RISK': 0, 'HIBERNATING': 0}
    by_currency = {}
    customers = []
    for row in rows:
        cur = str(row.currency or 'XXX').upper()
        count = int(row.order_count or 0)
        gross = int(row.gross_spend_minor or 0)
        refunded = int(refund_by_customer_currency.get((str(row.customer_id), cur), 0))
        net = max(0, gross - refunded)
        last = row.last_order_at
        if last is None:
            continue
        last_utc = last if last.tzinfo else last.replace(tzinfo=timezone.utc)
        recency_days = max(0, (now - last_utc).days)
        # Deterministic RFM-style segmentation; no opaque AI decision is used.
        if count >= 5 and recency_days <= 30:
            segment = 'CHAMPION'
        elif count >= 3 and recency_days <= 90:
            segment = 'LOYAL'
        elif count >= 2 and recency_days <= 120:
            segment = 'PROMISING'
        elif recency_days <= 180:
            segment = 'AT_RISK'
        else:
            segment = 'HIBERNATING'
        segments[segment] += 1
        bucket = by_currency.setdefault(cur, {'customers': 0, 'orders': 0, 'net_revenue_minor': 0,
                                               'repeat_customers': 0})
        bucket['customers'] += 1
        bucket['orders'] += count
        bucket['net_revenue_minor'] += net
        if count >= 2:
            bucket['repeat_customers'] += 1
        customers.append({
            'customer_id': row.customer_id,
            'email': row.email,
            'name': ' '.join(x for x in [row.first_name, row.last_name] if x).strip() or None,
            'currency': cur,
            'orders': count,
            'gross_spend_minor': gross,
            'refunded_minor': refunded,
            'net_spend_minor': net,
            'first_order_at': row.first_order_at.isoformat() if row.first_order_at else None,
            'last_order_at': last_utc.isoformat(),
            'recency_days': recency_days,
            'segment': segment,
        })

    customers.sort(key=lambda x: (x['net_spend_minor'], x['orders']), reverse=True)
    total_with_orders = len(customers)
    repeat = sum(1 for x in customers if x['orders'] >= 2)
    return {
        'window_days': window_days,
        'generated_at': now.isoformat(),
        'segments': segments,
        'customers_with_orders': total_with_orders,
        'repeat_customer_rate_bps': int(repeat * 10000 / total_with_orders) if total_with_orders else 0,
        'by_currency': by_currency,
        'top_customers': customers[:25],
        'integrity': {
            'currency_safe': True,
            'refunds_applied_to_matching_order_currency': True,
            'segmentation_deterministic': True,
            'cross_currency_ltv_not_computed': True,
            'refund_currency_mismatches_excluded': refund_currency_mismatches,
        },
    }

@router.get('/analytics/revenue-intelligence')
def analytics_revenue_intelligence(tenant_id: str, days: int = 30, user=Depends(current_user), db: DBSession=Depends(get_db)):
    """Currency-safe revenue intelligence with period-over-period signals.

    Revenue is derived from successful captures minus successful refunds and is
    never aggregated across currencies.  Growth percentages are calculated
    only inside the same currency bucket and against the immediately preceding
    window of equal length.
    """
    _perm(tenant_id, user, db, 'analytics.read')
    try:
        window_days = max(7, min(365, int(days)))
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'REVENUE_INTELLIGENCE_WINDOW_INVALID', 'days must be an integer') from exc
    now = datetime.now(timezone.utc)
    start = now - timedelta(days=window_days)
    previous_start = start - timedelta(days=window_days)

    def buckets(begin, end):
        captures = (db.query(PaymentCapture.currency, func.coalesce(func.sum(PaymentCapture.amount_minor), 0).label('amount'))
            .filter(PaymentCapture.tenant_id == tenant_id,
                    PaymentCapture.created_at >= begin, PaymentCapture.created_at < end)
            .group_by(PaymentCapture.currency).all())
        refunds = (db.query(Refund.currency, func.coalesce(func.sum(Refund.amount_minor), 0).label('amount'))
            .filter(Refund.tenant_id == tenant_id,
                    Refund.created_at >= begin, Refund.created_at < end,
                    Refund.status.in_(['SUCCEEDED', 'COMPLETED']))
            .group_by(Refund.currency).all())
        out = {}
        for currency, amount in captures:
            cur = str(currency or 'XXX').upper()
            out.setdefault(cur, {'captured_minor': 0, 'refunded_minor': 0})['captured_minor'] += int(amount or 0)
        for currency, amount in refunds:
            cur = str(currency or 'XXX').upper()
            out.setdefault(cur, {'captured_minor': 0, 'refunded_minor': 0})['refunded_minor'] += int(amount or 0)
        for cur, b in out.items():
            b['net_revenue_minor'] = max(0, b['captured_minor'] - b['refunded_minor'])
        return out

    current = buckets(start, now)
    previous = buckets(previous_start, start)
    currencies = sorted(set(current) | set(previous))
    result = {}
    for cur in currencies:
        c = current.get(cur, {'captured_minor': 0, 'refunded_minor': 0, 'net_revenue_minor': 0})
        p = previous.get(cur, {'captured_minor': 0, 'refunded_minor': 0, 'net_revenue_minor': 0})
        old = int(p['net_revenue_minor'])
        new = int(c['net_revenue_minor'])
        growth_bps = None if old == 0 else int(((new - old) * 10000) / old)
        refund_rate_bps = int(c['refunded_minor'] * 10000 / c['captured_minor']) if c['captured_minor'] else 0
        result[cur] = {**c, 'previous_net_revenue_minor': old,
                       'growth_bps': growth_bps, 'refund_rate_bps': refund_rate_bps}

    signals = []
    for cur, b in result.items():
        if b['growth_bps'] is not None and b['growth_bps'] <= -2000:
            signals.append({'code': 'REVENUE_DECLINE', 'priority': 'HIGH', 'currency': cur,
                            'growth_bps': b['growth_bps']})
        if b['refund_rate_bps'] >= 1000:
            signals.append({'code': 'REFUND_PRESSURE', 'priority': 'HIGH', 'currency': cur,
                            'refund_rate_bps': b['refund_rate_bps']})
    if not signals:
        signals.append({'code': 'REVENUE_HEALTHY', 'priority': 'INFO',
                        'message': 'No material revenue or refund warning was detected.'})
    return {'window_days': window_days, 'generated_at': now.isoformat(), 'currencies': result,
            'signals': signals,
            'integrity': {'currency_safe': True, 'growth_compared_only_with_same_currency': True,
                          'refunds_only_successful_or_completed': True,
                          'cross_currency_totals_not_computed': True}}


@router.get('/analytics/merchant-decision-engine')
def analytics_merchant_decision_engine(tenant_id: str, days: int = 30, target_margin_bps: int = 2000,
                                      user=Depends(current_user), db: DBSession=Depends(get_db)):
    """Rank merchant actions by deterministic business impact.

    This endpoint is intentionally read-only. It composes existing intelligence
    layers and turns observations into a prioritized action queue without
    silently changing prices, inventory, orders, customers, or payments.
    """
    _perm(tenant_id, user, db, 'analytics.read')
    try:
        window_days = max(7, min(365, int(days)))
        margin = int(target_margin_bps)
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'DECISION_ENGINE_INPUT_INVALID', 'days and target_margin_bps must be integers') from exc
    if not 0 <= margin <= 10000:
        raise AppError(422, 'DECISION_ENGINE_MARGIN_INVALID', 'target_margin_bps must be between 0 and 10000')

    revenue = analytics_revenue_intelligence(tenant_id, window_days, user, db)
    pricing = analytics_pricing_intelligence(tenant_id, margin, user, db)
    command = analytics_command_center(tenant_id, window_days, user, db)
    customer = analytics_customer_intelligence(tenant_id, max(30, window_days), user, db)

    decisions = []
    seq = 0
    def add(code, priority, impact_minor=0, currency=None, evidence=None, action=None, confidence='HIGH'):
        nonlocal seq
        seq += 1
        decisions.append({
            'id': f'D{seq:04d}', 'code': code, 'priority': priority,
            'impact_minor': max(0, int(impact_minor or 0)), 'currency': currency,
            'confidence': confidence, 'evidence': evidence or [],
            'recommended_action': action,
        })

    for alert in pricing.get('alerts', []):
        if alert['status'] == 'UNDER_COST':
            gap = int(alert.get('gap_to_target_minor') or 0)
            add('PROTECT_UNIT_MARGIN', 'CRITICAL', gap, alert['currency'],
                [{'type': 'pricing', 'variant_id': alert['variant_id'], 'status': alert['status'],
                  'current_price_minor': alert['price_minor'], 'cost_minor': alert['cost_minor']}],
                'Review price before the next sale; Rilmo does not auto-change the price.')
        elif alert['status'] == 'BELOW_TARGET_MARGIN':
            add('REVIEW_LOW_MARGIN', 'HIGH', int(alert.get('gap_to_target_minor') or 0), alert['currency'],
                [{'type': 'pricing', 'variant_id': alert['variant_id'], 'gap_to_target_minor': alert['gap_to_target_minor']}],
                'Review price, supplier cost, discounting, or target margin.')
        elif alert['status'] == 'MISSING_COST':
            add('COMPLETE_COST_BASIS', 'HIGH', 0, alert['currency'],
                [{'type': 'pricing', 'variant_id': alert['variant_id']}],
                'Add a verified unit cost so profitability decisions become definitive.')

    for cur, signal in revenue.get('currencies', {}).items():
        growth = signal.get('growth_bps')
        if growth is not None and growth <= -2000:
            add('RECOVER_REVENUE_DECLINE', 'HIGH', abs(int(signal.get('net_revenue_minor') or 0)), cur,
                [{'type': 'revenue', 'growth_bps': growth, 'net_revenue_minor': signal.get('net_revenue_minor', 0)}],
                'Inspect conversion, traffic, top products, and checkout failures before increasing spend.')
        if int(signal.get('refund_rate_bps') or 0) >= 1000:
            add('REDUCE_REFUND_PRESSURE', 'HIGH', int(signal.get('refunded_minor') or 0), cur,
                [{'type': 'revenue', 'refund_rate_bps': signal.get('refund_rate_bps', 0)}],
                'Review refund reasons, affected SKUs, fulfillment quality, and product expectations.')

    ops = command.get('operations', {})
    if int(ops.get('out_of_stock') or 0):
        add('RESTOCK_OUT_OF_STOCK', 'CRITICAL', 0, None,
            [{'type': 'inventory', 'out_of_stock': ops['out_of_stock']}],
            'Restock sellable variants or disable unavailable offers.')
    if int(ops.get('fulfillment_backlog') or 0):
        add('CLEAR_FULFILLMENT_BACKLOG', 'HIGH', 0, None,
            [{'type': 'operations', 'fulfillment_backlog': ops['fulfillment_backlog']}],
            'Resolve the oldest fulfillment blockers before acquiring more demand.')
    if int(ops.get('risk_review') or 0):
        add('REVIEW_RISK_QUEUE', 'HIGH', 0, None,
            [{'type': 'risk', 'review_count': ops['risk_review']}],
            'Review risk-scored orders before fulfillment or capture.')

    at_risk = int(customer.get('segments', {}).get('AT_RISK', 0))
    if at_risk:
        add('RETAIN_AT_RISK_CUSTOMERS', 'MEDIUM', 0, None,
            [{'type': 'customer', 'at_risk_customers': at_risk,
              'repeat_customer_rate_bps': customer.get('repeat_customer_rate_bps', 0)}],
            'Launch a measured retention campaign; do not issue blanket discounts.')

    decisions.sort(key=lambda x: ({'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'INFO': 3}[x['priority']], -x['impact_minor'], x['code']))
    for idx, row in enumerate(decisions, 1):
        row['rank'] = idx
    if not decisions:
        add('OPERATIONS_HEALTHY', 'INFO', 0, None, [], 'Continue monitoring the next decision window.')

    return {
        'window_days': window_days, 'target_margin_bps': margin,
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'decisions': decisions,
        'source_layers': ['pricing-intelligence', 'revenue-intelligence', 'command-center', 'customer-intelligence'],
        'integrity': {
            'read_only': True, 'deterministic': True, 'cross_currency_impact_not_aggregated': True,
            'no_automatic_price_mutation': True, 'no_automatic_payment_mutation': True,
            'no_automatic_inventory_mutation': True,
        },
    }


@router.get('/merchant-decisions/actions')
def merchant_decision_actions_list(tenant_id: str, status: str | None = None, limit: int = 100,
                                  user=Depends(current_user), db: DBSession = Depends(get_db)):
    _perm(tenant_id, user, db, 'analytics.read')
    limit = max(1, min(250, int(limit or 100)))
    q = db.query(MerchantDecisionAction).filter_by(tenant_id=tenant_id)
    if status:
        normalized = str(status).upper().strip()
        if normalized not in {'OPEN', 'ACCEPTED', 'DISMISSED', 'COMPLETED'}:
            raise AppError(422, 'DECISION_ACTION_STATUS_INVALID', 'Unsupported decision action status')
        q = q.filter(MerchantDecisionAction.status == normalized)
    rows = q.order_by(MerchantDecisionAction.created_at.desc(), MerchantDecisionAction.id.desc()).limit(limit).all()
    return {'actions': [json_model(row) for row in rows], 'count': len(rows)}


@router.post('/merchant-decisions/actions')
def merchant_decision_action_create(tenant_id: str, data: dict,
                                    user=Depends(current_user), db: DBSession = Depends(get_db)):
    _perm(tenant_id, user, db, 'analytics.read')
    key = str(data.get('decision_key') or '').strip()
    code = str(data.get('decision_code') or '').strip().upper()
    priority = str(data.get('priority') or 'MEDIUM').strip().upper()
    confidence = str(data.get('confidence') or 'HIGH').strip().upper()
    currency = str(data.get('currency') or '').strip().upper()[:3] or None
    if not key or len(key) > 240 or not code or len(code) > 100:
        raise AppError(422, 'DECISION_ACTION_INPUT_INVALID', 'decision_key and decision_code are required')
    if priority not in {'CRITICAL', 'HIGH', 'MEDIUM', 'INFO'}:
        raise AppError(422, 'DECISION_ACTION_PRIORITY_INVALID', 'Unsupported priority')
    if confidence not in {'HIGH', 'MEDIUM', 'LOW'}:
        raise AppError(422, 'DECISION_ACTION_CONFIDENCE_INVALID', 'Unsupported confidence')
    try:
        expected = int(data.get('expected_impact_minor') or 0)
    except (TypeError, ValueError) as exc:
        raise AppError(422, 'DECISION_ACTION_IMPACT_INVALID', 'expected_impact_minor must be an integer') from exc
    if expected < 0:
        raise AppError(422, 'DECISION_ACTION_IMPACT_INVALID', 'expected_impact_minor cannot be negative')
    evidence = data.get('evidence') or []
    if not isinstance(evidence, list) or len(evidence) > 50:
        raise AppError(422, 'DECISION_ACTION_EVIDENCE_INVALID', 'evidence must be a list of at most 50 items')
    row = MerchantDecisionAction(tenant_id=tenant_id, decision_key=key, decision_code=code,
        priority=priority, status='OPEN', currency=currency, expected_impact_minor=expected,
        confidence=confidence, evidence=evidence, recommended_action=str(data.get('recommended_action') or '')[:5000] or None,
        created_by_user_id=user.id, updated_at=datetime.now(timezone.utc))
    try:
        with db.begin_nested():
            db.add(row)
            db.flush()
    except IntegrityError:
        row = db.query(MerchantDecisionAction).filter_by(tenant_id=tenant_id, decision_key=key).first()
        if not row:
            raise AppError(409, 'DECISION_ACTION_CREATE_RACE', 'Decision action could not be created safely')
        return json_model(row)
    audit(db, tenant_id, user.id, 'merchant.decision_action.created', 'MerchantDecisionAction', row.id,
          after={'decision_code': code, 'decision_key': key, 'expected_impact_minor': expected, 'status': row.status})
    db.commit()
    return json_model(row)


@router.patch('/merchant-decisions/actions/{action_id}')
def merchant_decision_action_update(action_id: str, tenant_id: str, data: dict,
                                   user=Depends(current_user), db: DBSession = Depends(get_db)):
    _perm(tenant_id, user, db, 'analytics.read')
    row = db.query(MerchantDecisionAction).filter_by(tenant_id=tenant_id, id=action_id).with_for_update().first()
    if not row:
        raise not_found('Decision action not found')
    requested = str(data.get('status') or '').strip().upper()
    transitions = {
        'OPEN': {'ACCEPTED', 'DISMISSED'},
        'ACCEPTED': {'COMPLETED', 'DISMISSED'},
        'DISMISSED': set(),
        'COMPLETED': set(),
    }
    if requested and requested != row.status:
        if requested not in transitions.get(row.status, set()):
            raise AppError(409, 'DECISION_ACTION_TRANSITION_INVALID', f'Cannot move action from {row.status} to {requested}')
        row.status = requested
        if requested == 'ACCEPTED':
            row.accepted_at = datetime.now(timezone.utc)
        elif requested == 'COMPLETED':
            row.completed_at = datetime.now(timezone.utc)
            row.completed_by_user_id = user.id
    if 'outcome_note' in data:
        row.outcome_note = str(data.get('outcome_note') or '')[:5000] or None
    if 'actual_impact_minor' in data:
        try:
            actual = int(data.get('actual_impact_minor'))
        except (TypeError, ValueError) as exc:
            raise AppError(422, 'DECISION_ACTION_OUTCOME_INVALID', 'actual_impact_minor must be an integer') from exc
        if row.currency is None:
            raise AppError(422, 'DECISION_ACTION_CURRENCY_REQUIRED', 'A currency is required before recording actual impact')
        row.actual_impact_minor = actual
    row.updated_at = datetime.now(timezone.utc)
    audit(db, tenant_id, user.id, 'merchant.decision_action.updated', 'MerchantDecisionAction', row.id,
          after={'status': row.status, 'actual_impact_minor': row.actual_impact_minor, 'outcome_note': row.outcome_note})
    db.commit()
    return json_model(row)


@router.post('/experiments')
def experiment_create(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'storefront.write'); variants=data.get('variants') or []
    if not variants or sum(max(0,int(x.get('weight_bps',0))) for x in variants)>10000: raise AppError(400,'EXPERIMENT_INVALID','Weighted variants must total at most 10000 bps')
    row=CommerceExperiment(tenant_id=tenant_id,key=str(data.get('key') or '').strip(),name=str(data.get('name') or '').strip(),status='DRAFT',traffic_bps=max(0,min(10000,int(data.get('traffic_bps') or 10000))),variants=variants,target_metric=str(data.get('target_metric') or 'conversion_rate')); db.add(row); db.commit(); return json_model(row)

@router.post('/experiments/{experiment_id}/assign')
def experiment_assign(experiment_id: str, tenant_id: str, subject_key: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'storefront.read'); ex=db.query(CommerceExperiment).filter_by(id=experiment_id,tenant_id=tenant_id).first()
    if not ex: raise not_found('Experiment not found')
    if ex.status!='ACTIVE': return {'variant':(ex.variants[0].get('key') if ex.variants else 'control'),'active':False}
    row=db.query(CommerceExperimentAssignment).filter_by(tenant_id=tenant_id,experiment_id=ex.id,subject_key=subject_key).first()
    if row: return json_model(row)
    key=f'{tenant_id}:{ex.id}:{subject_key}'; v=stable_variant(key,ex.variants,ex.traffic_bps); row=CommerceExperimentAssignment(tenant_id=tenant_id,experiment_id=ex.id,subject_key=subject_key,variant_key=v); db.add(row); db.commit(); return json_model(row)

@router.post('/experiments/{experiment_id}/observe')
def experiment_observe(experiment_id: str, tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'storefront.write')
    ex=db.query(CommerceExperiment).filter_by(id=experiment_id,tenant_id=tenant_id).first()
    if not ex: raise not_found('Experiment not found')
    subject_key=str(data.get('subject_key') or '').strip()
    metric_key=str(data.get('metric_key') or ex.target_metric or '').strip().lower()
    if not subject_key or len(subject_key)>160 or not metric_key or len(metric_key)>80:
        raise AppError(422,'EXPERIMENT_OBSERVATION_INVALID','subject_key and metric_key are required and bounded')
    assignment=db.query(CommerceExperimentAssignment).filter_by(tenant_id=tenant_id,experiment_id=ex.id,subject_key=subject_key).first()
    if not assignment: raise AppError(409,'EXPERIMENT_ASSIGNMENT_REQUIRED','Observation requires an existing experiment assignment')
    existing=db.query(CommerceExperimentObservation).filter_by(tenant_id=tenant_id,experiment_id=ex.id,subject_key=subject_key,metric_key=metric_key).first()
    if existing: return {'observation':json_model(existing),'duplicate':True}
    try:
        value=float(data.get('value_numeric',1))
    except (TypeError,ValueError) as exc:
        raise AppError(422,'EXPERIMENT_VALUE_INVALID','value_numeric must be numeric') from exc
    if value < 0 or value > 10**12: raise AppError(422,'EXPERIMENT_VALUE_INVALID','value_numeric is out of bounds')
    value_minor=data.get('value_minor')
    if value_minor is not None:
        try: value_minor=int(value_minor)
        except (TypeError,ValueError) as exc: raise AppError(422,'EXPERIMENT_VALUE_INVALID','value_minor must be an integer') from exc
        currency=str(data.get('currency') or '').upper()
        if len(currency)!=3: raise AppError(422,'EXPERIMENT_CURRENCY_REQUIRED','A 3-letter currency is required with value_minor')
    else:
        currency=None
    row=CommerceExperimentObservation(tenant_id=tenant_id,experiment_id=ex.id,assignment_id=assignment.id,subject_key=assignment.subject_key,variant_key=assignment.variant_key,metric_key=metric_key,value_numeric=value,value_minor=value_minor,currency=currency,occurred_at=datetime.now(timezone.utc),metadata_json=data.get('metadata') or {})
    db.add(row)
    try:
        db.commit()
    except IntegrityError:
        db.rollback(); existing=db.query(CommerceExperimentObservation).filter_by(tenant_id=tenant_id,experiment_id=ex.id,subject_key=subject_key,metric_key=metric_key).first()
        if not existing: raise
        return {'observation':json_model(existing),'duplicate':True}
    audit(db,tenant_id,user.id,'commerce.experiment.observed','CommerceExperimentObservation',row.id,after={'experiment_id':ex.id,'variant_key':row.variant_key,'metric_key':metric_key,'value_numeric':value})
    db.commit()
    return {'observation':json_model(row),'duplicate':False}

@router.get('/experiments/{experiment_id}/results')
def experiment_results(experiment_id: str, tenant_id: str, days: int=30, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'storefront.read')
    ex=db.query(CommerceExperiment).filter_by(id=experiment_id,tenant_id=tenant_id).first()
    if not ex: raise not_found('Experiment not found')
    try: window_days=max(1,min(365,int(days)))
    except (TypeError,ValueError) as exc: raise AppError(422,'ANALYTICS_WINDOW_INVALID','days must be an integer') from exc
    since=datetime.now(timezone.utc)-timedelta(days=window_days)
    rows=db.query(CommerceExperimentAssignment.variant_key,func.count(CommerceExperimentAssignment.id)).filter_by(tenant_id=tenant_id,experiment_id=ex.id).group_by(CommerceExperimentAssignment.variant_key).all()
    assigned={str(k):int(v or 0) for k,v in rows}
    obs=db.query(CommerceExperimentObservation).filter_by(tenant_id=tenant_id,experiment_id=ex.id).filter(CommerceExperimentObservation.occurred_at>=since).all()
    metrics={}
    for row in obs:
        key=str(row.metric_key); bucket=metrics.setdefault(key,{})
        v=bucket.setdefault(row.variant_key,{'assigned':assigned.get(row.variant_key,0),'observers':0,'value_sum':0.0,'value_minor_sum':0,'currencies':set()})
        v['observers']+=1; v['value_sum']+=float(row.value_numeric or 0)
        if row.value_minor is not None: v['value_minor_sum']+=int(row.value_minor); v['currencies'].add(row.currency)
    serial={}
    for metric,buckets in metrics.items():
        serial[metric]={}
        for variant,val in buckets.items():
            assigned_n=max(0,int(val['assigned'])); observers=int(val['observers'])
            serial[metric][variant]={**val,'conversion_rate_bps':int(observers*10000/assigned_n) if assigned_n else 0,'avg_value':(val['value_sum']/observers if observers else 0),'currencies':sorted(x for x in val['currencies'] if x)}
    return {'experiment':json_model(ex),'window_days':window_days,'assignments':assigned,'metrics':serial}

@router.get('/product-feeds')
def feeds(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'products.read')
    return {'items':[json_model(x) for x in db.query(ProductFeed).filter_by(tenant_id=tenant_id).all()]}

@router.post('/product-feeds')
def create_feed(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'products.write'); row=ProductFeed(tenant_id=tenant_id,channel=str(data.get('channel') or 'ai').lower(),locale=str(data.get('locale') or 'en')[:20],country_code=str(data.get('country_code') or 'US').upper()[:2],config=data.get('config') or {}); db.add(row); db.commit(); return json_model(row)

@router.post('/product-feeds/{feed_id}/generate')
def generate_feed(feed_id: str, tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'products.write'); feed=db.query(ProductFeed).filter_by(id=feed_id,tenant_id=tenant_id).first()
    if not feed: raise not_found('Product feed not found')
    items=compute_feed(db,feed); feed.last_generated_at=datetime.now(timezone.utc); feed.last_item_count=len(items); db.commit(); return {'feed_id':feed.id,'channel':feed.channel,'item_count':len(items),'items':items}

@router.patch('/experiments/{experiment_id}/status')
def experiment_status(experiment_id: str, tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'storefront.write')
    ex=db.query(CommerceExperiment).filter_by(id=experiment_id,tenant_id=tenant_id).first()
    if not ex: raise not_found('Experiment not found')
    status=str(data.get('status') or '').upper()
    if status not in {'DRAFT','ACTIVE','PAUSED','COMPLETED'}: raise AppError(400,'EXPERIMENT_STATUS_INVALID','Unsupported experiment status')
    ex.status=status; ex.updated_at=datetime.now(timezone.utc); db.commit(); return json_model(ex)

@router.get('/public/storefront/{hostname}/experiments/{key}/assignment')
def public_experiment_assignment(hostname: str, key: str, subject_key: str, db: DBSession=Depends(get_db)):
    tenant=_public_tenant(hostname,db)
    ex=db.query(CommerceExperiment).filter_by(tenant_id=tenant.id,key=key).first()
    if not ex or ex.status != 'ACTIVE': return {'active':False,'variant':'control'}
    row=db.query(CommerceExperimentAssignment).filter_by(tenant_id=tenant.id,experiment_id=ex.id,subject_key=subject_key).first()
    if row: return {'active':True,'variant':row.variant_key}
    variant=stable_variant(f'{tenant.id}:{ex.id}:{subject_key}',ex.variants,ex.traffic_bps)
    row=CommerceExperimentAssignment(tenant_id=tenant.id,experiment_id=ex.id,subject_key=subject_key,variant_key=variant); db.add(row); db.commit()
    return {'active':True,'variant':variant}

@router.get('/analytics/ai-discoverability')
def ai_discoverability(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id,user,db,'products.read')
    products=db.query(Product).filter_by(tenant_id=tenant_id,deleted_at=None).limit(1000).all()
    scores=[]
    for p in products:
        score=0; reasons=[]
        if p.title and len(p.title)>=10: score+=20
        else: reasons.append('title_too_short')
        if p.description and len(p.description)>=80: score+=20
        else: reasons.append('description_missing_or_short')
        seo=db.query(ProductSEO).filter_by(tenant_id=tenant_id,product_id=p.id).first()
        if seo and seo.meta_title: score+=15
        else: reasons.append('meta_title_missing')
        if seo and seo.meta_description: score+=15
        else: reasons.append('meta_description_missing')
        tr=db.query(ProductTranslation).filter_by(tenant_id=tenant_id,product_id=p.id).count()
        if tr>=2: score+=15
        elif tr==1: score+=7
        else: reasons.append('multilingual_content_missing')
        variants=db.query(ProductVariant).filter_by(tenant_id=tenant_id,product_id=p.id,status='ACTIVE').count()
        if variants: score+=15
        else: reasons.append('active_variant_missing')
        scores.append({'product_id':p.id,'score':score,'reasons':reasons})
    avg=round(sum(x['score'] for x in scores)/len(scores),1) if scores else 0
    return {'score':avg,'products':len(scores),'items':scores[:200],'generated_at':datetime.now(timezone.utc).isoformat()}

def _public_tenant(hostname: str, db):
    row = db.query(Domain, Tenant).join(Tenant, Tenant.id == Domain.tenant_id).filter(
        func.lower(Domain.hostname) == hostname.lower(), Domain.verified_at.is_not(None), Tenant.status == 'ACTIVE').first()
    if not row:
        raise not_found('Public storefront not found')
    return row[1]

@router.get('/public/storefront/{hostname}/feed/{channel}.json')
def public_product_feed(hostname: str, channel: str, country_code: str='US', locale: str='en', db: DBSession=Depends(get_db)):
    tenant=_public_tenant(hostname,db)
    allowed={'ai','google','meta','marketplace','shopping'}
    if channel not in allowed: raise AppError(404,'FEED_CHANNEL_NOT_FOUND','Unknown feed channel')
    items=catalog_for_agent(db,tenant.id,country_code,locale,250)
    return {'channel':channel,'version':'1.0','merchant':{'id':tenant.id,'name':tenant.name},'country_code':country_code,'locale':locale,'items':items,'generated_at':datetime.now(timezone.utc).isoformat()}

@router.get('/public/storefront/{hostname}/agentic/catalog')
def agentic_catalog(hostname: str, country_code: str='US', locale: str='en', limit: int=100, db: DBSession=Depends(get_db)):
    tenant=_public_tenant(hostname,db)
    items=catalog_for_agent(db,tenant.id,country_code,locale,limit); return {'version':'2026-04-08','merchant':{'id':tenant.id,'name':tenant.name},'catalog':items}

@router.get('/public/storefront/{hostname}/ucp/profile')
def ucp_profile(hostname: str, request: Request, response: Response, db: DBSession=Depends(get_db)):
    tenant=_public_tenant(hostname,db); base=str(request.base_url).rstrip('/')
    response.headers['Cache-Control'] = 'public, max-age=300'
    return {
        'ucp': {
            'version': '2026-04-08',
            'services': {
                'dev.ucp.shopping': [{
                    'version': '2026-04-08',
                    'spec': 'https://ucp.dev/2026-04-08/specification/overview',
                    'transport': 'rest',
                    'schema':'https://ucp.dev/2026-04-08/services/shopping/rest.openapi.json',
                    'endpoint': f'{base}/v1/public/storefront/{hostname}/ucp',
                }]
            },
            'capabilities': {
                'dev.ucp.shopping.checkout': [{
                    'version': '2026-04-08',
                    'spec': 'https://ucp.dev/2026-04-08/specification/checkout',
                    'schema': 'https://ucp.dev/2026-04-08/schemas/shopping/checkout.json',
                }],
                'dev.ucp.shopping.fulfillment': [{
                    'version': '2026-04-08',
                    'spec': 'https://ucp.dev/2026-04-08/specification/fulfillment',
                    'schema': 'https://ucp.dev/2026-04-08/schemas/shopping/fulfillment.json',
                    'extends':'dev.ucp.shopping.checkout',
                }],
            },
        },
        'merchant': {'id': tenant.id, 'name': tenant.name},
        'keys': [],
    }

def _ucp_checkout_response(row):
    expires_at = row.created_at + __import__('datetime').timedelta(hours=6)
    return {
        'ucp': {
            'version': '2026-04-08',
            'capabilities': {
                'dev.ucp.shopping.checkout': [{'version': '2026-04-08'}],
                'dev.ucp.shopping.fulfillment': [{'version': '2026-04-08'}],
            },
        },
        'id': row.external_session_id,
        'status': row.status.lower() if row.status != 'OPEN' else 'incomplete',
        'currency': row.currency,
        'line_items': row.line_items,
        'totals': {'subtotal_minor': row.subtotal_minor, 'total_minor': row.total_minor},
        'buyer': row.buyer,
        'links': [
            {'type': 'privacy_policy', 'url': f'{__import__('app.core.config', fromlist=['get_settings']).get_settings().PUBLIC_BASE_URL.rstrip("/")}/privacy'},
            {'type': 'terms_of_service', 'url': f'{__import__('app.core.config', fromlist=['get_settings']).get_settings().PUBLIC_BASE_URL.rstrip("/")}/terms'},
        ],
        'expires_at': expires_at.isoformat(),
    }

@router.post('/public/storefront/{hostname}/ucp/checkouts')
def ucp_checkout(hostname: str, data: dict, db: DBSession=Depends(get_db)):
    tenant=_public_tenant(hostname,db)
    external=str(data.get('external_session_id') or '').strip()
    if not external:
        raise AppError(400,'UCP_EXTERNAL_SESSION_REQUIRED','external_session_id is required for idempotent checkout creation')
    existing=db.query(UCPCheckoutSession).filter_by(tenant_id=tenant.id,external_session_id=external).first()
    if existing:
        return _ucp_checkout_response(existing)
    items=data.get('line_items') or []
    if not items: raise AppError(400,'UCP_CHECKOUT_EMPTY','At least one line item is required')
    total=0; normalized=[]
    for item in items:
        variant_id=str(item.get('variant_id') or '').strip()
        if not variant_id:
            raise AppError(422,'UCP_VARIANT_REQUIRED','variant_id is required for every line item')
        variant=db.query(ProductVariant).filter_by(id=variant_id,tenant_id=tenant.id,status='ACTIVE').first()
        if not variant:
            raise not_found('UCP product variant not found')
        q=max(1,int(item.get('quantity') or 1))
        unit=int(variant.price_amount_minor)
        total+=q*unit
        normalized.append({'id':variant.id,'variant_id':variant.id,'quantity':q,'unit_price_minor':unit,'currency':variant.currency})
    currency = str(data.get('currency') or (normalized[0]['currency'] if normalized else 'USD')).upper()[:3]
    if any(line['currency'] != currency for line in normalized):
        raise AppError(422,'UCP_CURRENCY_MISMATCH','All checkout variants must use the requested currency')
    row = UCPCheckoutSession(
        tenant_id=tenant.id,
        external_session_id=external,
        status='OPEN',
        currency=currency,
        line_items=normalized,
        subtotal_minor=total,
        total_minor=total,
        buyer=data.get('buyer'),
        metadata_json=data.get('metadata') or {},
    )
    db.add(row)
    db.add(UCPEvent(
        tenant_id=tenant.id,
        event_id=f'checkout:{external}:created',
        event_type='checkout.created',
        payload_hash=hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest(),
        payload={'external_session_id': external},
    ))
    db.commit()
    return _ucp_checkout_response(row)

@router.post('/public/storefront/{hostname}/ucp/checkouts/{external_session_id}/complete')
def ucp_complete(hostname: str, external_session_id: str, data: dict | None = None, agent_client_id: str | None = None, authorization: str | None = Header(default=None, alias='Authorization'), ucp_agent: str | None = Header(default=None, alias='UCP-Agent'), idempotency_key: str | None = Header(default=None, alias='Idempotency-Key'), db: DBSession=Depends(get_db)):
    tenant=_public_tenant(hostname,db)
    row=(db.query(UCPCheckoutSession)
        .filter_by(tenant_id=tenant.id, external_session_id=external_session_id)
        .with_for_update()
        .first())
    if not row: raise not_found('Checkout session not found')
    data = data or {}
    settings = __import__('app.core.config', fromlist=['get_settings']).get_settings()
    payment_intent_id = str(data.get('payment_intent_id') or '').strip()
    environment = str(getattr(settings, 'ENVIRONMENT', '')).lower()
    is_local_mock = environment == 'test' or (environment == 'development' and bool(getattr(settings, 'ALLOW_LOCAL_MOCK_PAYMENTS', False)))
    if str(row.status).upper() != 'COMPLETED' and not is_local_mock:
        if not payment_intent_id:
            raise AppError(402, 'UCP_PAYMENT_REQUIRED', 'A captured payment_intent_id is required before UCP checkout completion')
        pi = db.query(PaymentIntent).filter_by(id=payment_intent_id, tenant_id=tenant.id).first()
        if not pi:
            raise not_found('Payment intent not found')
        if pi.ucp_checkout_session_id != row.id:
            raise AppError(409, 'UCP_PAYMENT_CHECKOUT_MISMATCH', 'Payment intent is not bound to this checkout session')
        if int(pi.amount_minor) != int(row.total_minor):
            raise AppError(409, 'UCP_PAYMENT_AMOUNT_MISMATCH', 'Payment intent amount does not exactly match checkout total')
        if str(pi.currency).upper() != str(row.currency).upper():
            raise AppError(422, 'UCP_PAYMENT_CURRENCY_MISMATCH', 'Payment currency does not match checkout currency')
        captured_minor = int(db.query(func.coalesce(func.sum(PaymentCapture.amount_minor), 0)).filter_by(tenant_id=tenant.id, payment_intent_id=pi.id, currency=pi.currency).scalar() or 0)
        if captured_minor < int(row.total_minor):
            raise AppError(402, 'UCP_PAYMENT_NOT_CAPTURED', 'Checkout cannot complete until captured funds cover the checkout total')
    if agent_client_id:
        if not idempotency_key:
            raise AppError(428,'AGENT_IDEMPOTENCY_REQUIRED','Idempotency-Key is required for agent checkout completion')
        if not ucp_agent:
            raise AppError(401, 'UCP_AGENT_HEADER_REQUIRED', 'UCP-Agent header is required for agentic UCP requests')
        match = re.fullmatch(r'\s*profile="([^"]+)"\s*', ucp_agent)
        if not match:
            raise AppError(400, 'UCP_AGENT_HEADER_INVALID', 'UCP-Agent header must use profile="<https-url>" syntax')
        profile_uri = match.group(1)
        if not profile_uri.startswith('https://'):
            raise AppError(400, 'UCP_AGENT_PROFILE_INVALID', 'UCP-Agent profile URI must use HTTPS')
        expected_profile_uri = f'https://{hostname}/.well-known/agent/{agent_client_id}.json'
        if profile_uri.rstrip('/') != expected_profile_uri.rstrip('/'):
            raise AppError(403, 'UCP_AGENT_PROFILE_MISMATCH', 'UCP-Agent profile does not match the requested agent client')
        if not authorization or not authorization.lower().startswith('bearer '):
            raise AppError(401, 'UCP_AGENT_AUTH_REQUIRED', 'Bearer agent credential is required for agentic UCP requests')
        agent_secret = authorization.split(' ', 1)[1].strip()
        from app.services.global_control_plane import authorize_agent_action
        req_hash=hashlib.sha256(json.dumps({'external_session_id':external_session_id, 'profile_uri':profile_uri}, sort_keys=True).encode()).hexdigest()
        profile, _audit = authorize_agent_action(db, tenant.id, agent_client_id, agent_secret, 'checkout.complete', 'ucp_checkout_session', row.id, req_hash, idempotency_key)
        allowed_currencies = set(profile.allowed_currencies or [])
        if allowed_currencies and row.currency not in allowed_currencies:
            raise AppError(403, 'AGENT_CURRENCY_DENIED', 'Agent is not authorized for this checkout currency')
        if profile.max_checkout_total_minor is not None and int(row.total_minor) > int(profile.max_checkout_total_minor):
            raise AppError(403, 'AGENT_SPEND_LIMIT_EXCEEDED', 'Agent checkout exceeds its configured spend limit')
        buyer = row.buyer or {}
        buyer_country = str(buyer.get('country_code') or buyer.get('country') or '').upper()
        allowed_countries = set(profile.allowed_countries or [])
        if allowed_countries and buyer_country not in allowed_countries:
            raise AppError(403, 'AGENT_COUNTRY_DENIED', 'Agent is not authorized for the buyer country')
    if row.status=='COMPLETED':
        db.commit()
        return _ucp_checkout_response(row)
    row.status='COMPLETED'; row.updated_at=datetime.now(timezone.utc)
    db.add(UCPEvent(tenant_id=tenant.id,event_id=f'checkout:{external_session_id}:completed',event_type='checkout.completed',payload_hash=hashlib.sha256(external_session_id.encode()).hexdigest(),payload={'external_session_id':external_session_id,'agent_client_id':agent_client_id}))
    db.commit(); return _ucp_checkout_response(row)


@router.get('/public/apps/catalog')
def public_app_catalog(category: str | None = None, country_code: str | None = None, locale: str | None = None, limit: int = 50, db: DBSession = Depends(get_db)):
    q = db.query(AppDefinition, AppListing).join(AppListing, AppListing.app_id == AppDefinition.id).filter(AppDefinition.status == 'APPROVED', AppListing.status == 'PUBLISHED')
    if category:
        q = q.filter(AppListing.category == category)
    rows = q.order_by(AppListing.featured.desc(), AppDefinition.created_at.desc()).limit(max(1, min(limit, 100))).all()
    items = []
    for app_def, listing in rows:
        countries = {str(x).upper() for x in (listing.supported_countries or [])}
        locales = set(listing.supported_locales or [])
        if country_code and countries and country_code.upper() not in countries:
            continue
        if locale and locales and locale not in locales:
            continue
        items.append({
            'id': app_def.id,
            'name': app_def.name,
            'slug': app_def.slug,
            'publisher_name': app_def.publisher_name,
            'category': listing.category,
            'description': listing.description,
            'icon_url': listing.icon_url,
            'pricing_model': listing.pricing_model,
            'monthly_price_minor': listing.monthly_price_minor,
            'currency': listing.currency,
            'featured': listing.featured,
            **app_rating_summary(db, app_def.id),
        })
    return {'items': items, 'count': len(items)}

@router.post('/apps/{app_id}/listing')
def upsert_app_listing(app_id: str, data: dict, admin=Depends(current_platform_admin), db: DBSession = Depends(get_db)):
    app_def = db.get(AppDefinition, app_id)
    if not app_def:
        raise not_found('App not found')
    listing = db.query(AppListing).filter_by(app_id=app_id).first()
    if not listing:
        listing = AppListing(app_id=app_id)
        db.add(listing)
    listing.category = str(data.get('category') or 'GENERAL')[:80]
    listing.description = str(data.get('description') or '')[:5000]
    listing.icon_url = str(data.get('icon_url') or '')[:1000] or None
    listing.pricing_model = str(data.get('pricing_model') or 'FREE').upper()[:32]
    listing.monthly_price_minor = max(0, int(data.get('monthly_price_minor') or 0))
    listing.currency = str(data.get('currency') or 'USD').upper()[:3]
    listing.supported_locales = list(data.get('supported_locales') or [])[:50]
    listing.supported_countries = [str(x).upper()[:2] for x in list(data.get('supported_countries') or [])[:100]]
    listing.featured = bool(data.get('featured', False))
    if bool(data.get('publish', False)):
        if app_def.status != 'APPROVED':
            raise AppError(409, 'APP_NOT_APPROVED', 'Only approved apps can be published')
        listing.status = 'PUBLISHED'
        listing.published_at = listing.published_at or datetime.now(timezone.utc)
    else:
        listing.status = 'DRAFT'
    listing.updated_at = datetime.now(timezone.utc)
    db.commit()
    return json_model(listing)

@router.post('/apps/{app_id}/reviews')
def review_app(app_id: str, tenant_id: str, data: dict, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _perm(tenant_id, user, db, 'apps.manage')
    app_def = db.query(AppDefinition).filter_by(id=app_id, status='APPROVED').first()
    if not app_def:
        raise not_found('Approved app not found')
    inst = db.query(AppInstallation).filter_by(tenant_id=tenant_id, app_id=app_id, status='ACTIVE').first()
    if not inst:
        raise AppError(403, 'APP_REVIEW_REQUIRES_INSTALL', 'Install the app before reviewing it')
    rating = max(1, min(5, int(data.get('rating') or 0)))
    review = db.query(AppReview).filter_by(app_id=app_id, tenant_id=tenant_id).first()
    if not review:
        review = AppReview(app_id=app_id, tenant_id=tenant_id, rating=rating, title=str(data.get('title') or '')[:160] or None, body=str(data.get('body') or '')[:5000] or None, verified_installation=True)
        db.add(review)
    else:
        review.rating = rating
        review.title = str(data.get('title') or '')[:160] or None
        review.body = str(data.get('body') or '')[:5000] or None
        review.updated_at = datetime.now(timezone.utc)
    db.commit()
    return json_model(review)

@router.post('/workflows/{workflow_id}/execute')
def execute_workflow_route(workflow_id: str, tenant_id: str, data: dict, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _perm(tenant_id, user, db, 'settings.manage')
    workflow = db.query(WorkflowDefinition).filter_by(id=workflow_id, tenant_id=tenant_id, enabled=True).first()
    if not workflow:
        raise not_found('Enabled workflow not found')
    validate_steps(workflow.steps or [])
    run = WorkflowRun(tenant_id=tenant_id, workflow_id=workflow.id, trigger_event=workflow.trigger_event, status='QUEUED', input_payload=data.get('input_payload') or {}, output_payload={})
    db.add(run)
    db.flush()
    execute_workflow(db, workflow, run, actor_id=user.id)
    db.commit()
    return json_model(run)

@router.get('/workflows/{workflow_id}/runs/{run_id}/steps')
def workflow_run_steps(workflow_id: str, run_id: str, tenant_id: str, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _perm(tenant_id, user, db, 'settings.manage')
    workflow = db.query(WorkflowDefinition).filter_by(id=workflow_id, tenant_id=tenant_id).first()
    if not workflow:
        raise not_found('Workflow not found')
    run = db.query(WorkflowRun).filter_by(id=run_id, workflow_id=workflow.id, tenant_id=tenant_id).first()
    if not run:
        raise not_found('Workflow run not found')
    rows = db.query(WorkflowStepRun).filter_by(workflow_run_id=run.id, tenant_id=tenant_id).order_by(WorkflowStepRun.position.asc()).all()
    return {'items': [json_model(row) for row in rows]}

@router.get('/commerce/events/schemas')
def event_schemas(db: DBSession = Depends(get_db)):
    rows = db.query(CommerceEventSchema).filter_by(status='ACTIVE').order_by(CommerceEventSchema.event_type, CommerceEventSchema.schema_version.desc()).limit(250).all()
    return {'items': [json_model(row) for row in rows]}

# v1.51 Global Control Plane
@router.post('/agents')
def create_agent(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id, user, db, 'apps.manage')
    from app.services.global_control_plane import validate_agent_scopes
    client_id = str(data.get('client_id') or '').strip()
    slug = str(data.get('slug') or '').strip().lower()
    name = str(data.get('name') or '').strip()
    if not client_id or not slug or not name:
        raise AppError(422, 'AGENT_PROFILE_INVALID', 'client_id, slug and name are required')
    if db.query(AgentProfile).filter_by(tenant_id=tenant_id, client_id=client_id).first():
        raise AppError(409, 'AGENT_EXISTS', 'Agent client_id already exists')
    scopes = validate_agent_scopes(data.get('scopes'))
    client_secret = secrets.token_urlsafe(36)
    row = AgentProfile(tenant_id=tenant_id, client_id=client_id, client_secret_hash=token_hash(client_secret), slug=slug, name=name, scopes=scopes,
        allowed_countries=[str(x).upper() for x in (data.get('allowed_countries') or [])],
        require_confirmation=bool(data.get('require_confirmation', False)),
        max_checkout_total_minor=(max(0, int(data.get('max_checkout_total_minor'))) if data.get('max_checkout_total_minor') is not None else None),
        allowed_currencies=[str(x).upper()[:3] for x in (data.get('allowed_currencies') or []) if str(x).strip()],
        rate_limit_per_minute=max(1, min(10000, int(data.get('rate_limit_per_minute') or 120))))
    db.add(row); db.flush()
    audit(db, tenant_id, user.id, 'agent.profile.created', 'agent_profile', row.id,
        after={'client_id': row.client_id, 'scopes': row.scopes})
    outbox(db, tenant_id, 'agent_profile', row.id, 'agent.profile.created', {'agent_profile_id': row.id, 'scopes': row.scopes})
    db.commit()
    payload = json_model(row)
    payload['client_secret'] = client_secret
    payload['warning'] = 'Store this client_secret securely; it is returned only once.'
    return payload

@router.get('/agents')
def list_agents(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id, user, db, 'apps.manage')
    return {'items': [json_model(x) for x in db.query(AgentProfile).filter_by(tenant_id=tenant_id).order_by(AgentProfile.created_at.desc()).all()]}

@router.post('/agents/{agent_id}/rotate-secret')
def rotate_agent_secret(agent_id: str, tenant_id: str, user=Depends(current_user), db: DBSession = Depends(get_db)):
    _perm(tenant_id, user, db, 'apps.manage')
    row = db.query(AgentProfile).filter_by(id=agent_id, tenant_id=tenant_id, status='ACTIVE').first()
    if not row:
        raise not_found('Agent profile not found')
    client_secret = secrets.token_urlsafe(36)
    row.client_secret_hash = token_hash(client_secret)
    audit(db, tenant_id, user.id, 'agent.profile.secret_rotated', 'agent_profile', row.id, after={'client_id': row.client_id})
    db.commit()
    return {'agent_client_id': row.client_id, 'client_secret': client_secret, 'warning': 'Store this client_secret securely; it is returned only once.'}

@router.get('/public/storefront/{hostname}/.well-known/agent/{client_id}.json', include_in_schema=False)
def public_agent_profile(hostname: str, client_id: str, db: DBSession = Depends(get_db)):
    tenant = _public_tenant(hostname, db)
    row = db.query(AgentProfile).filter_by(tenant_id=tenant.id, client_id=client_id, status='ACTIVE').first()
    if not row:
        raise not_found('Agent profile not found')
    return {'profile': f'https://{hostname}/.well-known/agent/{row.client_id}.json', 'agent_client_id': row.client_id, 'name': row.name, 'scopes': row.scopes}

@router.get('/public/storefront/{hostname}/agent-policy')
def public_agent_policy(hostname: str, client_id: str, db: DBSession=Depends(get_db)):
    tenant = _public_tenant(hostname, db)
    row = db.query(AgentProfile).filter_by(tenant_id=tenant.id, client_id=client_id, status='ACTIVE').first()
    if not row:
        raise not_found('Agent profile not found')
    return {'merchant_id': tenant.id, 'agent_client_id': row.client_id, 'scopes': row.scopes,
            'allowed_countries': row.allowed_countries, 'allowed_currencies': row.allowed_currencies,
            'max_checkout_total_minor': row.max_checkout_total_minor,
            'require_confirmation': row.require_confirmation,
            'rate_limit_per_minute': row.rate_limit_per_minute}

@router.put('/governance/region-policy')
def set_region_policy(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id, user, db, 'settings.manage')
    from app.services.global_control_plane import validate_region_policy, ensure_region_policy
    home, allowed, mode = validate_region_policy(data.get('home_region'), data.get('allowed_regions'), data.get('residency_mode'), bool(data.get('cross_border_transfer_allowed', False)), data.get('transfer_basis'))
    row = ensure_region_policy(db, tenant_id)
    row.home_region = home; row.allowed_regions = allowed; row.residency_mode = mode
    row.cross_border_transfer_allowed = bool(data.get('cross_border_transfer_allowed', False))
    row.transfer_basis = data.get('transfer_basis')
    row.approved_at = datetime.now(timezone.utc); row.approved_by = user.id
    row.updated_at = datetime.now(timezone.utc)
    audit(db, tenant_id, user.id, 'region_policy.updated', 'tenant_region_policy', row.id,
        after={'home_region': home, 'allowed_regions': allowed, 'residency_mode': mode, 'cross_border_transfer_allowed': row.cross_border_transfer_allowed})
    db.commit()
    return json_model(row)

@router.get('/governance/region-policy')
def get_region_policy(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id, user, db, 'settings.manage')
    from app.services.global_control_plane import ensure_region_policy
    row = ensure_region_policy(db, tenant_id); db.commit()
    return json_model(row)

@router.post('/finance/reconciliation/run')
def reconcile_finance(tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id, user, db, 'finance.read')
    from datetime import datetime, timezone
    from app.services.global_control_plane import run_financial_reconciliation
    try:
        period_start = datetime.fromisoformat(str(data.get('period_start')).replace('Z', '+00:00'))
        period_end = datetime.fromisoformat(str(data.get('period_end')).replace('Z', '+00:00'))
    except (TypeError, ValueError):
        raise AppError(422, 'RECONCILIATION_PERIOD_INVALID', 'Valid ISO period_start and period_end are required')
    if period_end <= period_start:
        raise AppError(422, 'RECONCILIATION_PERIOD_INVALID', 'period_end must be after period_start')
    cur = str(data.get('currency') or 'USD').upper()
    row = run_financial_reconciliation(db, tenant_id, period_start, period_end, cur)
    audit(db, tenant_id, user.id, 'finance.reconciliation.completed', 'financial_reconciliation_run', row.id,
        after={'status': row.status, 'delta_minor': row.delta_minor, 'mismatch_count': row.mismatch_count})
    db.commit()
    return json_model(row)

@router.get('/finance/reconciliation/{run_id}')
def get_reconciliation(run_id: str, tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id, user, db, 'finance.read')
    row = db.query(FinancialReconciliationRun).filter_by(id=run_id, tenant_id=tenant_id).first()
    if not row:
        raise not_found('Reconciliation run not found')
    mismatches = db.query(FinancialReconciliationMismatch).filter_by(reconciliation_run_id=row.id, tenant_id=tenant_id).order_by(FinancialReconciliationMismatch.created_at.asc()).all()
    return {'run': json_model(row), 'mismatches': [json_model(x) for x in mismatches]}

# v1.53 Digital Product Passport
@router.put('/products/{product_id}/digital-passport')
def upsert_product_passport(product_id: str, tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id, user, db, 'products.write')
    product = db.query(Product).filter_by(id=product_id, tenant_id=tenant_id).first()
    if not product:
        raise not_found('Product not found')
    allowed_status = {'DRAFT', 'PUBLISHED', 'SUSPENDED'}
    status = str(data.get('status') or 'DRAFT').upper()
    if status not in allowed_status:
        raise AppError(422, 'DPP_STATUS_INVALID', 'Invalid digital product passport status')
    origin = str(data.get('origin_country') or '').upper().strip() or None
    if origin and (len(origin) != 2 or not origin.isalpha()):
        raise AppError(422, 'DPP_COUNTRY_INVALID', 'origin_country must be ISO alpha-2')
    passport = db.query(ProductPassport).filter_by(tenant_id=tenant_id, product_id=product_id).first()
    now = datetime.now(timezone.utc)
    registry_status = str(data.get('registry_status') or 'NOT_REGISTERED').upper()
    if registry_status not in {'NOT_REGISTERED', 'TESTING', 'REGISTERED', 'SUSPENDED'}:
        raise AppError(422, 'DPP_REGISTRY_STATUS_INVALID', 'Invalid DPP registry status')
    identifier_scheme = str(data.get('identifier_scheme') or '')[:80] or None
    unique_product_identifier = str(data.get('unique_product_identifier') or '')[:255] or None
    data_carrier = str(data.get('data_carrier') or '')[:80] or None
    if status == 'PUBLISHED' and not unique_product_identifier:
        raise AppError(422, 'DPP_IDENTIFIER_REQUIRED', 'A published DPP requires a unique product identifier')
    manufacturer_name = str(data.get('manufacturer_name') or '')[:255] or None
    manufacturer_address = str(data.get('manufacturer_address') or '')[:4000] or None
    manufacturer_contact = str(data.get('manufacturer_contact') or '')[:320] or None
    responsible_person_name = str(data.get('responsible_person_name') or '')[:255] or None
    responsible_person_address = str(data.get('responsible_person_address') or '')[:4000] or None
    responsible_person_contact = str(data.get('responsible_person_contact') or '')[:320] or None
    economic_operator_role = str(data.get('economic_operator_role') or '')[:80] or None
    product_identifier = str(data.get('product_identifier') or unique_product_identifier or '')[:255] or None
    safety_warnings = list(data.get('safety_warnings') or [])[:50]
    recall_information = dict(data.get('recall_information') or {})
    if status == 'PUBLISHED' and not manufacturer_name:
        raise AppError(422, 'DPP_MANUFACTURER_REQUIRED', 'A published DPP requires a manufacturer/economic-operator name')
    snapshot_fields = {
        'scheme': str(data.get('scheme') or 'Rilmo-DPP-1')[:80],
        'conformance_profile': str(data.get('conformance_profile') or 'ESPR-DPP-2026')[:120],
        'identifier_scheme': identifier_scheme,
        'unique_product_identifier': unique_product_identifier,
        'data_carrier': data_carrier,
        'registry_status': registry_status,
        'registry_reference': str(data.get('registry_reference') or '')[:255] or None,
        'status': status,
        'origin_country': origin,
        'manufacturer_name': manufacturer_name,
        'manufacturer_address': manufacturer_address,
        'manufacturer_contact': manufacturer_contact,
        'responsible_person_name': responsible_person_name,
        'responsible_person_address': responsible_person_address,
        'responsible_person_contact': responsible_person_contact,
        'economic_operator_role': economic_operator_role,
        'product_identifier': product_identifier,
        'safety_warnings': safety_warnings,
        'recall_information': recall_information,
        'materials': list(data.get('materials') or [])[:100],
        'certifications': list(data.get('certifications') or [])[:100],
        'compliance_claims': list(data.get('compliance_claims') or [])[:100],
        'circularity': dict(data.get('circularity') or {}),
        'sustainability': dict(data.get('sustainability') or {}),
        'public_data': dict(data.get('public_data') or {}),
        'effective_at': data.get('effective_at'),
        'expires_at': data.get('expires_at'),
    }
    if len(json.dumps(snapshot_fields, ensure_ascii=False, separators=(',', ':'))) > 65536:
        raise AppError(413, 'DPP_PAYLOAD_TOO_LARGE', 'Digital product passport payload exceeds 64 KiB')
    if not passport:
        passport = ProductPassport(tenant_id=tenant_id, product_id=product_id,
            public_token=uuid.uuid4().hex + uuid.uuid4().hex, version=1)
        db.add(passport); db.flush()
    else:
        passport.version += 1
    passport.scheme = snapshot_fields['scheme']
    passport.conformance_profile = snapshot_fields['conformance_profile']
    passport.identifier_scheme = snapshot_fields['identifier_scheme']
    passport.unique_product_identifier = snapshot_fields['unique_product_identifier']
    passport.data_carrier = snapshot_fields['data_carrier']
    passport.registry_status = snapshot_fields['registry_status']
    passport.registry_reference = snapshot_fields['registry_reference']
    passport.status = status
    passport.origin_country = snapshot_fields['origin_country']
    passport.manufacturer_name = snapshot_fields['manufacturer_name']
    passport.manufacturer_address = snapshot_fields['manufacturer_address']
    passport.manufacturer_contact = snapshot_fields['manufacturer_contact']
    passport.responsible_person_name = snapshot_fields['responsible_person_name']
    passport.responsible_person_address = snapshot_fields['responsible_person_address']
    passport.responsible_person_contact = snapshot_fields['responsible_person_contact']
    passport.economic_operator_role = snapshot_fields['economic_operator_role']
    passport.product_identifier = snapshot_fields['product_identifier']
    passport.safety_warnings = snapshot_fields['safety_warnings']
    passport.recall_information = snapshot_fields['recall_information']
    passport.materials = snapshot_fields['materials']
    passport.certifications = snapshot_fields['certifications']
    passport.compliance_claims = snapshot_fields['compliance_claims']
    passport.circularity = snapshot_fields['circularity']
    passport.sustainability = snapshot_fields['sustainability']
    passport.public_data = snapshot_fields['public_data']
    passport.effective_at = datetime.fromisoformat(snapshot_fields['effective_at'].replace('Z', '+00:00')) if snapshot_fields['effective_at'] else passport.effective_at
    passport.expires_at = datetime.fromisoformat(snapshot_fields['expires_at'].replace('Z', '+00:00')) if snapshot_fields['expires_at'] else None
    passport.updated_at = now
    db.add(ProductPassportRevision(tenant_id=tenant_id, product_passport_id=passport.id,
        version=passport.version, snapshot=snapshot_fields,
        change_reason=str(data.get('change_reason') or 'update')[:255], actor_id=user.id))
    audit(db, tenant_id, user.id, 'product.passport.updated', 'product_passport', passport.id,
        after={'product_id': product_id, 'version': passport.version, 'status': passport.status, 'scheme': passport.scheme, 'registry_status': passport.registry_status})
    db.commit()
    safe = json_model(passport)
    safe['public_url_template'] = f'/v1/public/storefront/{{hostname}}/products/{product.slug}/digital-passport/{passport.public_token}'
    return {'passport': safe, 'public_url_template': safe['public_url_template']}

@router.get('/products/{product_id}/digital-passport')
def get_product_passport(product_id: str, tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id, user, db, 'products.read')
    row = db.query(ProductPassport).filter_by(tenant_id=tenant_id, product_id=product_id).first()
    if not row:
        raise not_found('Digital product passport not found')
    return {'passport': json_model(row), 'revisions': [json_model(x) for x in db.query(ProductPassportRevision).filter_by(tenant_id=tenant_id, product_passport_id=row.id).order_by(ProductPassportRevision.version.desc()).limit(50).all()]}

@router.get('/public/storefront/{hostname}/products/{slug}/digital-passport/{public_token}')
def public_product_passport(hostname: str, slug: str, public_token: str, request: Request, db: DBSession=Depends(get_db)):
    client_host = getattr(request.client, 'host', 'unknown') if request.client else 'unknown'
    enforce_rate_limit(db, f'dpp:public:{hostname.lower()}:{client_host}', 120, 60)
    tenant = _public_tenant(hostname, db)
    product = db.query(Product).filter_by(tenant_id=tenant.id, slug=slug, deleted_at=None).first()
    if not product:
        raise not_found('Product not found')
    row = db.query(ProductPassport).filter_by(tenant_id=tenant.id, product_id=product.id, public_token=public_token, status='PUBLISHED').first()
    if not row:
        raise not_found('Digital product passport not found')
    return {
        'scheme': row.scheme,
        'conformance_profile': row.conformance_profile,
        'identifier_scheme': row.identifier_scheme,
        'unique_product_identifier': row.unique_product_identifier,
        'data_carrier': row.data_carrier,
        'registry_status': row.registry_status,
        'registry_reference': row.registry_reference,
        'passport_id': row.id,
        'version': row.version,
        'product': {'id': product.id, 'slug': product.slug, 'title': product.title},
        'origin_country': row.origin_country,
        'manufacturer_name': row.manufacturer_name,
        'manufacturer_address': row.manufacturer_address,
        'manufacturer_contact': row.manufacturer_contact,
        'responsible_person_name': row.responsible_person_name,
        'responsible_person_address': row.responsible_person_address,
        'responsible_person_contact': row.responsible_person_contact,
        'economic_operator_role': row.economic_operator_role,
        'product_identifier': row.product_identifier,
        'safety_warnings': row.safety_warnings,
        'recall_information': row.recall_information,
        'materials': row.materials,
        'certifications': row.certifications,
        'compliance_claims': row.compliance_claims,
        'circularity': row.circularity,
        'sustainability': row.sustainability,
        'public_data': row.public_data,
        'effective_at': row.effective_at.isoformat() if row.effective_at else None,
        'expires_at': row.expires_at.isoformat() if row.expires_at else None,
    }

@router.get('/platform/control-plane/health')
def control_plane_health(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _perm(tenant_id, user, db, 'settings.manage')
    return {
        'region_policy': db.query(TenantRegionPolicy).filter_by(tenant_id=tenant_id).first() is not None,
        'active_agents': db.query(AgentProfile).filter_by(tenant_id=tenant_id, status='ACTIVE').count(),
        'pending_outbox': db.query(OutboxEvent).filter_by(tenant_id=tenant_id, status='PENDING').count(),
        'dead_letters': db.query(DeadLetterEvent).filter_by(tenant_id=tenant_id).count(),
        'latest_reconciliation': json_model(db.query(FinancialReconciliationRun).filter_by(tenant_id=tenant_id).order_by(FinancialReconciliationRun.created_at.desc()).first()) if db.query(FinancialReconciliationRun).filter_by(tenant_id=tenant_id).count() else None,
    }

# temporary import marker
