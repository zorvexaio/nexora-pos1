"""Payment provider webhooks: Paddle (SaaS billing), iyzico, PayTR (merchant
checkout payments). Includes their shared amount-parsing and
ledger-capture-recording helpers.

RECOVERY NOTE: this file was reconstructed after a Phase-3 tooling mistake
briefly dropped these functions from the working tree during an unrelated
cleanup pass. Nothing here is new or rewritten — every line was extracted
programmatically from the pristine original upload and verified
byte-for-byte identical to it before being written here, so the webhook
logic itself is guaranteed unchanged.

provider_credentials and transition are shared helpers used by other route
groups (payments, orders), so they stay defined/imported from v1.py /
services rather than duplicated.
"""
import hmac, uuid, hashlib, logging
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Form, Request
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func
from app.core.database import get_db, set_tenant_context
from app.core.errors import AppError
from app.core.config import get_settings
from app.models.domain import *
from app.core.serialization import json_model
from app.services.core import (outbox, body_hash, post_split_ledger_entry, claim_webhook_event,
    quarantine_provider_ingest_event, resolve_provider_tenant)
from app.services.order_state import transition
from app.routes.v1 import provider_credentials

logger = logging.getLogger('unified_commerce')

router = APIRouter(prefix='/v1')


def _amount_minor(value):
    from decimal import Decimal, ROUND_HALF_UP
    return int((Decimal(str(value)) * Decimal('100')).quantize(Decimal('1'),
        rounding=ROUND_HALF_UP))

def _resolve_provider_payment(db, provider: str, payload: dict):
    meta = payload.get('meta') if isinstance(payload.get('meta'), dict) else {}
    order = payload.get('order') if isinstance(payload.get('order'), dict) else {}
    provider_payment_id = str(payload.get('id') or payload.get('payment_id') or payload.get('order_id') or '')
    pi = db.query(PaymentIntent).filter_by(provider=provider,
        provider_payment_id=provider_payment_id).with_for_update().first() if provider_payment_id else None
    tenant_id = pi.tenant_id if pi else meta.get('tenant_id')
    order_ref = meta.get('order_id') or order.get('reference_id') or payload.get('order_reference_id')
    if not pi and order_ref:
        pi = db.query(PaymentIntent).filter_by(provider=provider,
            order_id=str(order_ref)).with_for_update().first()
        if pi:
            tenant_id = pi.tenant_id
    return (pi, tenant_id)

@router.post('/webhooks/paddle')
async def paddle_webhook(request: Request, db: DBSession=Depends(get_db)):
    settings=get_settings(); body=await request.body()
    if len(body)>settings.MAX_WEBHOOK_BYTES: raise AppError(413,'WEBHOOK_TOO_LARGE','Webhook payload too large')
    signature=request.headers.get('Paddle-Signature','')
    if not settings.PADDLE_WEBHOOK_SECRET or not signature:
        raise AppError(400,'WEBHOOK_SIGNATURE','Invalid Paddle webhook signature')
    parts={}
    for chunk in signature.split(';'):
        k,_,v=chunk.partition('='); parts.setdefault(k,v)
    try:
        ts=int(parts['ts']); provided=parts['h1'];
        if abs(int(datetime.now(timezone.utc).timestamp())-ts)>settings.WEBHOOK_TOLERANCE_SECONDS: raise ValueError('stale')
        expected=hmac.new(settings.PADDLE_WEBHOOK_SECRET.encode(), f'{ts}:'.encode()+body, __import__('hashlib').sha256).hexdigest()
        if not hmac.compare_digest(expected,provided): raise ValueError('mismatch')
    except Exception as exc:
        raise AppError(400,'WEBHOOK_SIGNATURE','Invalid Paddle webhook signature') from exc
    try: payload=__import__('json').loads(body)
    except Exception as exc: raise AppError(400,'WEBHOOK_JSON','Invalid webhook JSON') from exc
    event_id=str(payload.get('event_id') or payload.get('notification_id') or payload.get('id') or '')
    event_type=str(payload.get('event_type') or payload.get('type') or 'unknown')
    data=payload.get('data') or {}
    claimed_tenant_id=(data.get('custom_data') or {}).get('tenant_id') if isinstance(data,dict) else None
    sub_id=str(data.get('id') or '')
    bound_tenant_id=resolve_provider_tenant(db, provider='paddle', external_id=sub_id) if sub_id else None
    if claimed_tenant_id and bound_tenant_id and str(claimed_tenant_id) != str(bound_tenant_id):
        raise AppError(409, 'PROVIDER_REFERENCE_TENANT_CONFLICT', 'Paddle subscription reference is bound to a different tenant')
    tenant_id=claimed_tenant_id or bound_tenant_id
    if not event_id: raise AppError(400,'WEBHOOK_EVENT_ID','Paddle event id required')
    if tenant_id:
        set_tenant_context(db,tenant_id)
    else:
        # Never perform an unscoped tenant-table lookup under FORCE RLS.
        # Preserve the verified payload in the platform quarantine table until a
        # trusted reference mapping or operator action resolves its tenant.
        _, fresh = quarantine_provider_ingest_event(db, provider='paddle', provider_event_id=event_id,
            event_type=event_type, payload_hash=__import__('hashlib').sha256(body).hexdigest(), payload=payload)
        db.commit()
        return {'ok': True, 'status': 'quarantined', 'duplicate': not fresh}
    existing_event, is_new = claim_webhook_event(db, provider='paddle', provider_event_id=event_id, tenant_id=tenant_id, event_type=event_type, payload_hash=__import__('hashlib').sha256(body).hexdigest(), payload=payload)
    if not is_new:
        return {'ok': True, 'duplicate': True}
    sub=db.query(Subscription).filter_by(tenant_id=tenant_id, provider_subscription_id=sub_id).first() if sub_id else None
    if tenant_id and event_type.startswith('subscription.') and sub:
        status=str(data.get('status') or '').lower(); sub.status='active' if status in {'active','trialing'} else ('past_due' if status=='past_due' else 'canceled')
        if data.get('next_billed_at'):
            try:
                sub.current_period_end = datetime.fromisoformat(str(data['next_billed_at']).replace('Z','+00:00'))
            except (TypeError, ValueError) as exc:
                raw_value = str(data['next_billed_at'])
                logger.warning(
                    'paddle_subscription_period_parse_failed provider=paddle event_id=%s tenant_id=%s value_type=%s value_len=%d value_sha256=%s',
                    event_id, tenant_id or 'unknown', type(data['next_billed_at']).__name__, len(raw_value), hashlib.sha256(raw_value.encode('utf-8', 'replace')).hexdigest(),
                    exc_info=False,
                )
        if sub.status=='active':
            db.query(Entitlement).filter_by(tenant_id=tenant_id).delete(synchronize_session=False); db.query(TenantEntitlement).filter_by(tenant_id=tenant_id).delete(synchronize_session=False)
            for f in db.query(PlanFeature).filter_by(plan_version_id=sub.plan_version_id).all():
                db.add(Entitlement(tenant_id=tenant_id,feature_key=f.feature_key,value_type=f.value_type,value_boolean=f.value_boolean,value_integer=f.value_integer,version=1))
                db.add(TenantEntitlement(tenant_id=tenant_id,feature_key=f.feature_key,value_type=f.value_type,value_boolean=f.value_boolean,value_integer=f.value_integer,source_subscription_id=sub.id))
        else:
            db.query(Entitlement).filter_by(tenant_id=tenant_id).delete(synchronize_session=False); db.query(TenantEntitlement).filter_by(tenant_id=tenant_id).delete(synchronize_session=False)
    existing_event.status='PROCESSED'; existing_event.processed_at=datetime.now(timezone.utc); db.commit(); return {'ok':True}

def _record_provider_capture(db, pi, *, tenant_id: str, provider_capture_id: str, amount_minor: int, currency: str, provider: str):
    """Materialize an externally-confirmed provider capture into our financial ledger.

    Provider webhooks are authoritative only after signature + immutable intent checks.
    Once accepted, our own capture row and ledger must be created as well; otherwise a
    later manual/automated capture could double-charge the provider or leave finance
    reporting inconsistent with the payment state.
    """
    existing = db.query(PaymentCapture).filter_by(tenant_id=tenant_id, provider_capture_id=provider_capture_id).first() if provider_capture_id else None
    if existing:
        if existing.payment_intent_id != pi.id or int(existing.amount_minor) != int(amount_minor) or str(existing.currency).upper() != str(currency).upper():
            raise AppError(409, 'PROVIDER_CAPTURE_REUSED', 'Provider capture id is already bound to a different payment')
        # A replayed provider capture must be observationally idempotent. Replaying
        # a partial capture must never promote the payment to CAPTURED. Recompute the
        # aggregate from durable capture rows and derive the state from the invariant.
        captured_total = db.query(PaymentCapture).filter_by(
            payment_intent_id=pi.id, tenant_id=tenant_id
        ).with_entities(func.coalesce(func.sum(PaymentCapture.amount_minor), 0)).scalar() or 0
        if int(captured_total) > int(pi.amount_minor):
            raise AppError(500, 'CAPTURE_TOTAL_CORRUPTED', 'Recorded provider captures exceed the payment intent amount')
        pi.status = 'CAPTURED' if int(captured_total) == int(pi.amount_minor) else 'PARTIALLY_CAPTURED'
        if pi.order_id and pi.status == 'CAPTURED':
            order = db.query(Order).filter_by(id=pi.order_id, tenant_id=tenant_id).first()
            if order:
                order.payment_status = 'CAPTURED'
        return existing
    captured = db.query(PaymentCapture).filter_by(payment_intent_id=pi.id, tenant_id=tenant_id).with_entities(func.coalesce(func.sum(PaymentCapture.amount_minor), 0)).scalar() or 0
    if int(captured) + int(amount_minor) > int(pi.amount_minor):
        raise AppError(409, 'CAPTURE_TOTAL_EXCEEDED', 'Provider capture exceeds the authorized payment amount')
    cap = PaymentCapture(tenant_id=tenant_id, payment_intent_id=pi.id, amount_minor=int(amount_minor), currency=str(currency).upper(), provider_capture_id=provider_capture_id)
    db.add(cap)
    db.flush()
    pi.status = 'CAPTURED' if int(captured) + int(amount_minor) == int(pi.amount_minor) else 'PARTIALLY_CAPTURED'

    cash = db.query(LedgerAccount).filter_by(tenant_id=tenant_id, code='cash').with_for_update().first()
    revenue = db.query(LedgerAccount).filter_by(tenant_id=tenant_id, code='sales_revenue').with_for_update().first()
    if not cash:
        cash = LedgerAccount(tenant_id=tenant_id, code='cash', name='Cash', account_type='ASSET', currency=str(currency).upper())
        db.add(cash)
    if not revenue:
        revenue = LedgerAccount(tenant_id=tenant_id, code='sales_revenue', name='Sales Revenue', account_type='REVENUE', currency=str(currency).upper())
        db.add(revenue)
    db.flush()
    post_split_ledger_entry(db, tenant_id, str(currency).upper(), 'merchant_sale', pi.id, cash, [(revenue, int(amount_minor))])
    if pi.order_id:
        order = db.query(Order).filter_by(id=pi.order_id, tenant_id=tenant_id).first()
        if order and pi.status == 'CAPTURED':
            order.payment_status = 'CAPTURED'
            if order.status not in {'CONFIRMED','FULFILLED','CANCELED','REFUNDED'}:
                old_state = transition(order, 'CONFIRMED')
                db.add(OrderStatusHistory(tenant_id=tenant_id, order_id=order.id, from_state=old_state, to_state='CONFIRMED', actor_id=None, reason=f'{provider}_payment_captured'))
            outbox(db, tenant_id, 'order', order.id, 'order.confirmed', {'order_id': order.id, 'tenant_id': tenant_id, 'provider': provider})
    outbox(db, tenant_id, 'payment_intent', pi.id, 'payment.captured', {'payment_intent_id': pi.id, 'tenant_id': tenant_id, 'provider': provider, 'amount_minor': int(amount_minor), 'currency': str(currency).upper()})
    return cap

@router.post('/webhooks/iyzico')
async def iyzico_webhook(request: Request, db: DBSession=Depends(get_db)):
    import json, hashlib, hmac
    try:
        body_dict = await request.json()
    except Exception:
        body_dict = {}
    event_type = body_dict.get('iyziEventType', 'PAYMENT_API') if body_dict else 'PAYMENT_API'
    payment_id = str(body_dict.get('paymentId') or body_dict.get('payment_id') or '')
    conversation = str(body_dict.get('paymentConversationId') or body_dict.get('conversationId') or '')
    status = str(body_dict.get('status') or '')
    tenant_id = resolve_provider_tenant(db, provider='iyzico', external_id=conversation) or resolve_provider_tenant(db, provider='iyzico', external_id=payment_id)
    if not tenant_id:
        _, fresh = quarantine_provider_ingest_event(db, provider='iyzico',
            provider_event_id=payment_id or uuid.uuid4().hex, event_type=event_type,
            payload_hash=body_hash(body_dict), payload=body_dict)
        db.commit()
        return {'ok': True, 'status': 'quarantined', 'duplicate': not fresh}
    # Bind the verified routing decision before touching any tenant-scoped table.
    # With PostgreSQL FORCE RLS, provider credentials are tenant data and cannot be
    # queried merely by knowing a tenant id; the database session must carry the
    # same tenant context that will govern all subsequent payment queries.
    set_tenant_context(db, tenant_id)
    secret = provider_credentials(tenant_id, 'iyzico',
        db).get('secret_key') or get_settings().IYZICO_SECRET_KEY
    sig = request.headers.get('X-IYZ-SIGNATURE-V3', '')
    expected = hmac.new(secret.encode(),
     (secret + event_type + payment_id + conversation + status).encode(),
        __import__('hashlib').sha256).hexdigest()
    if not sig or not hmac.compare_digest(expected, sig):
        raise AppError(401, 'WEBHOOK_SIGNATURE_INVALID', 'Invalid iyzico webhook signature')
    eid = payment_id or uuid.uuid4().hex
    webhook_event, is_new = claim_webhook_event(db, provider='iyzico', provider_event_id=eid, tenant_id=tenant_id, event_type=event_type, payload_hash=body_hash(body_dict), payload=body_dict)
    if not is_new:
        return {'ok': True, 'duplicate': True}
    if status.upper() in {'SUCCESS', 'SUCCESSFUL'}:
        pi = db.query(PaymentIntent).filter_by(tenant_id=tenant_id,
            provider='iyzico').filter((PaymentIntent.provider_payment_id == payment_id) | (PaymentIntent.provider_payment_id == conversation)).with_for_update().first()
        if pi:
            # Never finalize a payment solely because a signed callback says SUCCESS.
            # Provider callbacks are authenticated transport messages, but the amount
            # and currency still have to match our immutable intent exactly.
            amount_candidates = [
                body_dict.get('paidPrice'), body_dict.get('paid_price'),
                body_dict.get('price'), body_dict.get('totalAmount'),
                body_dict.get('total_amount'), body_dict.get('amount'),
            ]
            callback_amount = next((x for x in amount_candidates if x not in (None, '')), None)
            callback_currency = str(body_dict.get('currency') or body_dict.get('currencyCode') or '').upper()
            if callback_amount is None:
                raise AppError(409, 'WEBHOOK_AMOUNT_REQUIRED',
                    'Authenticated iyzico success callback did not include a verifiable amount')
            try:
                callback_minor = _amount_minor(callback_amount)
            except (TypeError, ValueError, ArithmeticError) as exc:
                raise AppError(400, 'WEBHOOK_AMOUNT_INVALID', 'Invalid iyzico callback amount') from exc
            if callback_minor != int(pi.amount_minor):
                raise AppError(409, 'WEBHOOK_AMOUNT_MISMATCH',
                    'iyzico callback amount does not match the payment intent')
            if callback_currency and callback_currency != str(pi.currency).upper():
                raise AppError(409, 'WEBHOOK_CURRENCY_MISMATCH',
                    'iyzico callback currency does not match the payment intent')
            _record_provider_capture(db, pi, tenant_id=tenant_id,
                provider_capture_id=payment_id or conversation or f'iyzico:{eid}',
                amount_minor=int(pi.amount_minor), currency=pi.currency, provider='iyzico')
    webhook_event.status='PROCESSED'; webhook_event.processed_at=datetime.now(timezone.utc)
    db.commit()
    return {'ok': True}

@router.post('/webhooks/paytr')
def paytr_webhook(merchant_oid: str=Form(...), status: str=Form(...), total_amount: str=Form(...),
    hash: str=Form(...), db: DBSession=Depends(get_db)):
    tenant_id = resolve_provider_tenant(db, provider='paytr', external_id=merchant_oid)
    if not tenant_id:
        return 'OK'
    set_tenant_context(db, tenant_id)
    pi = db.query(PaymentIntent).filter_by(tenant_id=tenant_id, provider='paytr',
        provider_payment_id=merchant_oid).first()
    if not pi:
        return 'OK'
    creds = provider_credentials(tenant_id, 'paytr', db)
    if not creds:
        raise AppError(503, 'PAYTR_NOT_CONFIGURED', 'PayTR credentials are not configured')
    provider = __import__('app.services.payment_providers',
     fromlist=['PayTRProvider']).PayTRProvider(merchant_id=str(creds['merchant_id']),
        merchant_key=str(creds['merchant_key']), merchant_salt=str(creds['merchant_salt']))
    if not provider.verify_callback(merchant_oid=merchant_oid, status=status,
        total_amount=total_amount, provided_hash=hash):
        raise AppError(401, 'WEBHOOK_SIGNATURE_INVALID', 'Invalid PayTR callback signature')
    eid = f'{merchant_oid}:{status}:{total_amount}'
    webhook_payload={'merchant_oid': merchant_oid, 'status': status, 'total_amount': total_amount}
    webhook_event, is_new = claim_webhook_event(db, provider='paytr', provider_event_id=eid, tenant_id=pi.tenant_id, event_type='payment.callback', payload_hash=body_hash(webhook_payload), payload=webhook_payload)
    if not is_new:
        return 'OK'
    if status.lower() == 'success':
        # PayTR signs total_amount; still reject a validly signed callback if the
        # amount differs from the server-side payment intent.
        try:
            callback_minor = _amount_minor(total_amount)
        except (TypeError, ValueError, ArithmeticError) as exc:
            raise AppError(400, 'WEBHOOK_AMOUNT_INVALID', 'Invalid PayTR callback amount') from exc
        if callback_minor != int(pi.amount_minor):
            raise AppError(409, 'WEBHOOK_AMOUNT_MISMATCH',
                'PayTR callback amount does not match the payment intent')
        _record_provider_capture(db, pi, tenant_id=pi.tenant_id,
            provider_capture_id=f'paytr:{merchant_oid}:{status}:{total_amount}',
            amount_minor=int(pi.amount_minor), currency=pi.currency, provider='paytr')
    else:
        # Provider callbacks can arrive late or out of order. A signed failure
        # notification must never downgrade a payment that we have already
        # captured (or partially captured) and ledgered.
        if pi.status not in {'CAPTURED', 'PARTIALLY_CAPTURED', 'REFUNDED', 'VOIDED'}:
            pi.status = 'FAILED'
    webhook_event.status='PROCESSED'; webhook_event.processed_at=datetime.now(timezone.utc)
    db.commit()
    return 'OK'
