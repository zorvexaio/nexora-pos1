"""Small standalone routes that don't belong to a bigger domain: product
search, sales analytics, commerce settings, public runtime config, and the
health/readiness probes used by orchestration.

Extracted out of app/routes/v1.py (Phase 3, step 26).
"""
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func
from fastapi import APIRouter, Depends
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.config import get_settings
from app.models.domain import *
from app.core.serialization import json_model
from app.services.core import require_entitlement
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.get('/search')
def search_products(tenant_id: str, q: str='', user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    term = q.strip()[:120]
    query = db.query(Product).filter_by(tenant_id=tenant_id, status='ACTIVE', deleted_at=None)
    if term:
        like = f'%{term}%'
        query = query.filter(Product.title.ilike(like) | Product.slug.ilike(like) | Product.description.ilike(like))
    rows = query.order_by(Product.created_at.desc()).limit(50).all()
    return {'query': term, 'results': [json_model(x) for x in rows]}

@router.get('/analytics/sales')
def sales_analytics(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    require_entitlement(db, tenant_id, 'advanced_analytics')
    captured = db.query(func.coalesce(func.sum(PaymentCapture.amount_minor),
        0)).filter(PaymentCapture.tenant_id == tenant_id).scalar() or 0
    refunded = db.query(func.coalesce(func.sum(Refund.amount_minor),
     0)).filter(Refund.tenant_id == tenant_id,
        Refund.status.in_(['SUCCEEDED', 'COMPLETED'])).scalar() or 0
    orders = db.query(func.count(Order.id)).filter(Order.tenant_id == tenant_id).scalar() or 0
    customers = db.query(func.count(Customer.id)).filter(Customer.tenant_id == tenant_id).scalar() or 0
    return {'captured_minor': int(captured), 'refunded_minor': int(refunded),
        'net_minor': int(captured - refunded), 'orders': int(orders), 'customers': int(customers)}

@router.get('/settings/commerce')
def commerce_settings(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    t = db.get(Tenant, tenant_id)
    s = db.query(Storefront).filter_by(tenant_id=tenant_id).first()
    return {'tenant': json_model(t) if t else None, 'storefront': json_model(s) if s else None,
     'features': {'guest_checkout': True,
     'rtl': True,
        'multicurrency': True, 'reviews': True, 'qa': True, 'inventory': True, 'billing': True}}

@router.get('/dashboard/summary')
def dashboard_summary(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('finance.read'))):
    tenant_scope(tenant_id, user, db)
    orders_q = db.query(Order).filter_by(tenant_id=tenant_id)
    products_q = db.query(Product).filter(Product.tenant_id == tenant_id,
        Product.deleted_at.is_(None))
    inventory_q = db.query(InventoryItem).filter_by(tenant_id=tenant_id)
    paid_minor = int(db.query(func.coalesce(func.sum(PaymentCapture.amount_minor),
        0)).filter_by(tenant_id=tenant_id).scalar() or 0)
    refunded_minor = int(db.query(func.coalesce(func.sum(Refund.amount_minor),
        0)).filter_by(tenant_id=tenant_id).scalar() or 0)
    low_stock = 0
    for row in inventory_q.all():
        if int(row.available or 0) <= 0:
            low_stock += 1
    return {'products': products_q.count(), 'orders': orders_q.count(),
     'open_orders': orders_q.filter(Order.status.in_(['PENDING_PAYMENT',
     'CONFIRMED',
     'PROCESSING',
     'SHIPPED'])).count(),
     'customers': db.query(Customer).filter_by(tenant_id=tenant_id).count(),
     'inventory_items': inventory_q.count(),
     'out_of_stock': low_stock,
     'captured_minor': paid_minor,
        'refunded_minor': refunded_minor, 'net_captured_minor': max(0, paid_minor - refunded_minor)}

@router.get('/public/config')
def public_config():
    s = get_settings()
    provider = 'mock' if (s.ENVIRONMENT == 'test' or (s.ENVIRONMENT == 'development' and s.ALLOW_LOCAL_MOCK_PAYMENTS)) else 'iyzico'
    return {'payment_provider': provider, 'supported_merchant_providers':['iyzico','paytr','cod'],
     'supported_locales': ['ar',
        'en', 'tr', 'fr', 'de', 'es', 'pt', 'it', 'ru', 'zh', 'ja', 'ko', 'hi']}

@router.get('/health')
def health():
    return {'status': 'healthy', 'version': get_settings().APP_VERSION}

@router.get('/ready')
def ready(db: DBSession=Depends(get_db)):
    checks = {}
    settings = get_settings()
    try:
        db.execute(__import__('sqlalchemy').text('SELECT 1'))
        checks['database'] = True
    except Exception:
        checks['database'] = False
    if settings.ENVIRONMENT in {'production', 'staging'}:
        try:
            from app.core.runtime import assert_migration_head
            assert_migration_head(db)
            checks['migration'] = True
        except Exception:
            checks['migration'] = False
    else:
        checks['migration'] = True
    if settings.REDIS_URL:
        try:
            import redis as _redis
            _redis.Redis.from_url(settings.REDIS_URL, socket_timeout=settings.REDIS_SOCKET_TIMEOUT_SECONDS).ping()
            checks['redis'] = True
        except Exception:
            checks['redis'] = False
    else:
        checks['redis'] = settings.ENVIRONMENT != 'production'

    if settings.ENVIRONMENT == 'production':
        # Readiness must reflect dependencies required to safely accept writes,
        # not merely whether the Python process is alive. These checks are
        # intentionally bounded and fail closed.
        try:
            from app.services.storage import get_object_store
            store = get_object_store()
            store.client.head_bucket(Bucket=store.bucket)
            checks['object_storage'] = True
        except Exception:
            checks['object_storage'] = False
        try:
            import socket
            with socket.create_connection((settings.CLAMAV_HOST, settings.CLAMAV_PORT), timeout=settings.CLAMAV_TIMEOUT_SECONDS) as sock:
                sock.sendall(b'PING\x00')
                checks['malware_scanner'] = sock.recv(16).startswith(b'PONG')
        except Exception:
            checks['malware_scanner'] = False
    ready_flag = all(checks.values())
    from fastapi import HTTPException
    if not ready_flag:
        raise HTTPException(status_code=503, detail={'status':'not_ready','checks':checks})
    return {'status': 'ready', 'checks': checks, 'version': settings.APP_VERSION}
