"""Cart routes: create, add item, get, patch item, delete item, merge.

Extracted out of app/routes/v1.py (Phase 3, step 28). assert_cart_owner and
idem_start are shared helpers also used by checkout/payments code still in
v1.py, so they stay there and are imported here. commerce_actor/guest_cart
were always defined in app.core.guest, imported directly (unchanged).
"""
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Header, Request, Response
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import optional_user, current_user
from app.core.guest import commerce_actor, guest_cart
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import finalize_idem
from app.routes.v1 import tenant_scope, assert_cart_owner, idem_start

router = APIRouter(prefix='/v1')


@router.post('/cart')
def create_cart(tenant_id: str, request: Request, response: Response, user=Depends(optional_user),
    db: DBSession=Depends(get_db)):
    actor, guest = commerce_actor(request, response, db, tenant_id)
    if user is not None:
        actor = user
    if actor is None:
        cart, _ = guest_cart(request, response, db, tenant_id)
    else:
        if not getattr(actor, 'is_customer', False):
            tenant_scope(tenant_id, actor, db)
        t = db.get(Tenant, tenant_id)
        customer = db.query(Customer).filter_by(tenant_id=tenant_id, email=actor.email).first()
        if not customer:
            customer = Customer(tenant_id=tenant_id, email=actor.email)
            db.add(customer)
            db.flush()
        cart = Cart(tenant_id=tenant_id, currency=t.default_currency, status='OPEN',
            customer_id=customer.id, expires_at=datetime.now(timezone.utc) + timedelta(days=30))
        db.add(cart)
        db.flush()
    db.commit()
    return json_model(cart)

@router.post('/cart/items')
def add_cart_item(tenant_id: str, cart_id: str, data: CartItemIn, request: Request,
    response: Response, user=Depends(optional_user), db: DBSession=Depends(get_db)):
    actor, guest = commerce_actor(request, response, db, tenant_id)
    if user is not None:
        actor = user
    c = db.query(Cart).filter_by(id=cart_id, tenant_id=tenant_id, status='OPEN').first()
    if actor is None:
        if not guest or not c or c.guest_session_id != guest.id:
            from app.core.errors import forbidden
            raise forbidden('Guest cart access denied')
    else:
        if not getattr(actor, 'is_customer', False):
            tenant_scope(tenant_id, actor, db)
        assert_cart_owner(c, actor, guest, db)
    v = db.query(ProductVariant).filter_by(id=data.variant_id, tenant_id=tenant_id,
        status='ACTIVE').first()
    if not c or not v:
        raise not_found('Cart or variant not found')
    item = db.query(CartItem).filter_by(cart_id=c.id, tenant_id=tenant_id, variant_id=v.id).first()
    if item:
        item.quantity += data.quantity
    else:
        db.add(CartItem(tenant_id=tenant_id, cart_id=c.id, variant_id=v.id, quantity=data.quantity,
            unit_price_minor=v.price_amount_minor, currency=v.currency))
    c.version += 1
    c.updated_at = datetime.now(timezone.utc)
    db.commit()
    return {'cart_id': c.id, 'version': c.version}

@router.get('/cart')
def get_cart(tenant_id: str, request: Request, response: Response, cart_id: str | None=None,
    user=Depends(optional_user), db: DBSession=Depends(get_db)):
    actor, guest = commerce_actor(request, response, db, tenant_id)
    if user is not None:
        actor = user
    if actor is not None and not getattr(actor, 'is_customer', False):
        tenant_scope(tenant_id, actor, db)
    if actor is None:
        c = db.query(Cart).filter_by(tenant_id=tenant_id, guest_session_id=guest.id,
            status='OPEN').first()
    else:
        customer = db.query(Customer).filter_by(tenant_id=tenant_id, email=actor.email).first()
        q = db.query(Cart).filter_by(tenant_id=tenant_id, status='OPEN',
            customer_id=customer.id if customer else '')
        c = q.filter_by(id=cart_id).first() if cart_id else q.order_by(Cart.updated_at.desc()).first()
    if not c:
        return {'cart': None, 'items': []}
    rendered_items = []
    for i in db.query(CartItem).filter_by(tenant_id=tenant_id, cart_id=c.id).all():
        body = json_model(i)
        v = db.query(ProductVariant).filter_by(id=i.variant_id, tenant_id=tenant_id).first()
        p = db.query(Product).filter_by(id=v.product_id, tenant_id=tenant_id).first() if v else None
        body['title'] = p.title if p else (v.sku if v else i.variant_id)
        body['sku'] = v.sku if v else None
        rendered_items.append(body)
    return {'cart': json_model(c), 'items': rendered_items}

@router.patch('/cart/items/{item_id}')
def patch_cart_item(item_id: str, tenant_id: str, data: dict, request: Request, response: Response,
    user=Depends(optional_user), db: DBSession=Depends(get_db)):
    actor, guest = commerce_actor(request, response, db, tenant_id)
    if user is not None:
        actor = user
    if actor and not getattr(actor, 'is_customer', False):
        tenant_scope(tenant_id, actor, db)
    item = db.query(CartItem).filter_by(id=item_id, tenant_id=tenant_id).first()
    if not item:
        raise not_found('Cart item not found')
    quantity = int(data.get('quantity', 0))
    if quantity <= 0:
        raise AppError(400, 'QUANTITY_INVALID', 'Quantity must be positive')
    c = db.get(Cart, item.cart_id)
    assert_cart_owner(c, actor, guest, db)
    item.quantity = quantity
    c.version += 1
    c.updated_at = datetime.now(timezone.utc)
    db.commit()
    return json_model(item)

@router.delete('/cart/items/{item_id}')
def delete_cart_item(item_id: str, tenant_id: str, request: Request, response: Response,
    user=Depends(optional_user), db: DBSession=Depends(get_db)):
    actor, guest = commerce_actor(request, response, db, tenant_id)
    if user is not None:
        actor = user
    if actor and not getattr(actor, 'is_customer', False):
        tenant_scope(tenant_id, actor, db)
    item = db.query(CartItem).filter_by(id=item_id, tenant_id=tenant_id).first()
    if not item:
        raise not_found('Cart item not found')
    c = db.get(Cart, item.cart_id)
    assert_cart_owner(c, actor, guest, db)
    db.delete(item)
    c.version += 1
    c.updated_at = datetime.now(timezone.utc)
    db.commit()
    return {'ok': True}

@router.post('/cart/merge')
def merge_cart(tenant_id: str, target_cart_id: str, source_cart_id: str, user=Depends(current_user),
 db: DBSession=Depends(get_db),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    rec = idem_start(db, tenant_id, user.id, 'POST /v1/cart/merge', idempotency_key,
        {'target_cart_id': target_cart_id, 'source_cart_id': source_cart_id})
    if rec and rec.status == 'COMPLETED':
        return rec.response_body
    target = db.query(Cart).filter_by(id=target_cart_id, tenant_id=tenant_id, status='OPEN').first()
    source = db.query(Cart).filter_by(id=source_cart_id, tenant_id=tenant_id, status='OPEN').first()
    if not target or not source:
        raise not_found('Cart not found')
    assert_cart_owner(target, user, None, db)
    assert_cart_owner(source, user, None, db)
    if target.id == source.id:
        return json_model(target)
    for si in db.query(CartItem).filter_by(tenant_id=tenant_id, cart_id=source.id).all():
        ti = db.query(CartItem).filter_by(tenant_id=tenant_id, cart_id=target.id,
            variant_id=si.variant_id).first()
        if ti:
            ti.quantity += si.quantity
        else:
            db.add(CartItem(tenant_id=tenant_id, cart_id=target.id, variant_id=si.variant_id,
                quantity=si.quantity, unit_price_minor=si.unit_price_minor, currency=si.currency))
    source.status = 'MERGED'
    target.version += 1
    body = json_model(target)
    finalize_idem(rec, body, 200)
    db.commit()
    return body
