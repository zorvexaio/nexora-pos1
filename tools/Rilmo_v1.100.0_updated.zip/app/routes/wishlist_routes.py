"""Customer wishlist routes: create, add item, remove item.

Extracted out of app/routes/v1.py (Phase 3, step 18).

Bug fix while moving: add_wishlist() and delete_wishlist_item() looked up
`db.query(Wishlist).filter_by(tenant_id=tenant_id).first()` — scoped only by
tenant, not by the acting customer. In a store with more than one customer,
whichever wishlist row happened to be first for that tenant was the one
items got added to or removed from, regardless of who was making the
request. create_wishlist() (right above them) does this correctly, deriving
the Customer from user.email and matching wishlist to that customer_id — the
other two handlers just didn't follow the same pattern. No test covers two
distinct customers in the same tenant, so it went unnoticed. Fixed by
resolving the customer the same way create_wishlist() does and scoping both
lookups to customer_id.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.auth import current_user
from app.core.database import get_db
from app.core.errors import not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import outbox
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


def _customer_wishlist(db, tenant_id, user):
    c = db.query(Customer).filter_by(tenant_id=tenant_id, email=user.email).first()
    if not c:
        return None
    return db.query(Wishlist).filter_by(tenant_id=tenant_id, customer_id=c.id).first()

@router.post('/wishlist')
def create_wishlist(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    c = db.query(Customer).filter_by(tenant_id=tenant_id, email=user.email).first()
    if not c:
        c = Customer(tenant_id=tenant_id, email=user.email)
        db.add(c)
        db.flush()
    w = db.query(Wishlist).filter_by(tenant_id=tenant_id, customer_id=c.id).first()
    if not w:
        w = Wishlist(tenant_id=tenant_id, customer_id=c.id)
        db.add(w)
        db.flush()
    db.commit()
    return json_model(w)

@router.post('/wishlist/items')
def add_wishlist(tenant_id: str, data: WishlistIn, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    w = _customer_wishlist(db, tenant_id, user)
    p = db.query(Product).filter_by(id=data.product_id, tenant_id=tenant_id).first()
    if not w or not p:
        raise not_found('Wishlist/product not found')
    if db.query(WishlistItem).filter_by(tenant_id=tenant_id, wishlist_id=w.id,
        product_id=p.id).first():
        return {'ok': True, 'duplicate': True}
    item = WishlistItem(tenant_id=tenant_id, wishlist_id=w.id, product_id=p.id)
    db.add(item)
    db.flush()
    outbox(db, tenant_id, 'wishlist', w.id, 'wishlist.item_added', {'wishlist_id': w.id,
        'product_id': p.id, 'tenant_id': tenant_id})
    db.commit()
    return {'ok': True}

@router.delete('/wishlist/items/{product_id}')
def delete_wishlist_item(product_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    w = _customer_wishlist(db, tenant_id, user)
    if not w:
        raise not_found('Wishlist not found')
    item = db.query(WishlistItem).filter_by(tenant_id=tenant_id, wishlist_id=w.id,
        product_id=product_id).first()
    if not item:
        raise not_found('Wishlist item not found')
    db.delete(item)
    outbox(db, tenant_id, 'wishlist', w.id, 'wishlist.item_removed', {'product_id': product_id,
        'tenant_id': tenant_id})
    db.commit()
    return {'ok': True}
