"""SaaS billing routes: list plans (platform-admin), create initial
subscription, get current subscription, list entitlements.

Extracted out of app/routes/v1.py (Phase 3, step 25). _merchant_gate,
idem_start are shared helpers used by other route groups still in v1.py, so
they stay there and are imported here. change-plan/cancel/subscribe (a
second, later /subscription/subscribe endpoint) are a separate, later step —
they weren't contiguous with this block.
"""
import uuid
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission, current_platform_admin, assert_permission
from app.core.errors import AppError, not_found
from app.core.config import get_settings
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import outbox, finalize_idem, bind_provider_tenant
from app.services.payment_providers import PaddleBillingProvider
from app.routes.v1 import tenant_scope, idem_start, _merchant_gate, _tenant_membership_or_403
router = APIRouter(prefix='/v1')


@router.get('/plans')
def plans(admin=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    return [json_model(p) for p in db.query(Plan).filter_by(is_active=True).all()]

@router.post('/subscriptions')
def subscribe(tenant_id: str, data: PlanSubIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('billing.manage')), idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    # Route dependencies are skipped when this handler is called internally.
    # Preserve the dedicated billing permission at the canonical boundary.
    assert_permission(tenant_id, user, db, 'billing.manage')
    tenant_scope(tenant_id,user,db)
    if get_settings().ENVIRONMENT == 'production' and get_settings().REQUIRE_MERCHANT_PROFILE:
        _merchant_gate(db, tenant_id, user)
    payload=data.model_dump() if hasattr(data,'model_dump') else data.__dict__
    rec=idem_start(db,tenant_id,user.id,'POST /v1/subscriptions',idempotency_key,payload)
    if rec and rec.status=='COMPLETED': return rec.response_body
    pv=db.get(PlanVersion,data.plan_version_id)
    if not pv or not pv.is_current: raise not_found('Current plan version not found')
    old=db.query(Subscription).filter_by(tenant_id=tenant_id,status='active').first()
    if old and old.plan_version_id==pv.id: return json_model(old)
    pp=db.query(PlanPrice).filter_by(plan_version_id=pv.id,billing_interval='month').order_by(PlanPrice.created_at.desc()).first()
    if not pp: raise AppError(409,'PLAN_PRICE_REQUIRED','Monthly plan price is required')
    billing_provider=get_settings().BILLING_PROVIDER
    if billing_provider not in {'paddle','mock'}: raise AppError(503,'BILLING_PROVIDER_UNSUPPORTED','SaaS billing requires Paddle')
    discount_amount=0
    code=(data.billing_discount_code or '').strip().upper() or None
    if code:
        d=db.query(PlatformBillingDiscount).filter_by(code=code,status='ACTIVE').with_for_update().first(); now_dt=datetime.now(timezone.utc)
        if not d or (d.starts_at and d.starts_at>now_dt) or (d.ends_at and d.ends_at<=now_dt) or (d.usage_limit is not None and d.usage_count>=d.usage_limit): raise AppError(400,'BILLING_DISCOUNT_INVALID','Billing discount is invalid or inactive')
        if d.plan_id and d.plan_id!=pv.plan_id: raise AppError(400,'BILLING_DISCOUNT_PLAN_MISMATCH','Discount does not apply to this plan')
        discount_amount=int(d.value_minor or 0) if d.discount_type=='FIXED' else int(pp.amount_minor_units*int(d.percentage_bps or 0)//10000); discount_amount=max(0,min(pp.amount_minor_units,discount_amount)); d.usage_count+=1
    bc=db.query(BillingCustomer).filter_by(tenant_id=tenant_id).first()
    if not bc: bc=BillingCustomer(tenant_id=tenant_id,email=user.email); db.add(bc); db.flush()
    provider_customer_id=bc.provider_customer_id; provider_subscription_id=None; period_end=None; checkout_url=None; status='pending'
    if billing_provider=='paddle' and get_settings().PADDLE_API_KEY:
        provider=PaddleBillingProvider()
        if not provider_customer_id:
            pc=provider.customer(user.email,tenant_id,user.display_name,idempotency_key or bc.id); provider_customer_id=pc['id']; bc.provider_customer_id=provider_customer_id
        if not pp.provider_price_id: raise AppError(409,'PROVIDER_PRICE_REQUIRED','Paddle price ID is required for this plan')
        paddle_discount=None
        if discount_amount:
            if d.discount_type=='PERCENTAGE':
                paddle_discount={'type':'percentage','amount':str((int(d.percentage_bps or 0))/100),'recur':True,'description':f'SaaS discount {d.code}'}
            else:
                paddle_discount={'type':'flat','amount':f'{discount_amount/100:.2f}','recur':True,'description':f'SaaS discount {d.code}'}
        tx=provider.checkout_transaction(customer_id=provider_customer_id,price_id=pp.provider_price_id,currency=pp.currency,custom_data={'tenant_id':tenant_id,'plan_version_id':pv.id,'discount_code':code,'discount_minor':discount_amount},discount=paddle_discount,idem=idempotency_key or pv.id)
        provider_subscription_id=tx.get('subscription_id'); checkout_url=(tx.get('checkout') or {}).get('url') if isinstance(tx,dict) else None
    else:
        status='active'; provider_subscription_id='mock_sub_'+uuid.uuid4().hex; period_end=datetime.now(timezone.utc)+timedelta(days=30)
    if old: old.status='superseded'
    sub=Subscription(tenant_id=tenant_id,plan_version_id=pv.id,status=status,billing_provider=billing_provider,provider_customer_id=provider_customer_id,provider_subscription_id=provider_subscription_id,current_period_end=period_end)
    db.add(sub); db.flush()
    bind_provider_tenant(db, provider=billing_provider, external_id=provider_subscription_id, tenant_id=tenant_id)
    if status=='active':
        db.query(Entitlement).filter_by(tenant_id=tenant_id).delete(synchronize_session=False); db.query(TenantEntitlement).filter_by(tenant_id=tenant_id).delete(synchronize_session=False)
        for f in db.query(PlanFeature).filter_by(plan_version_id=pv.id).all():
            db.add(Entitlement(tenant_id=tenant_id,feature_key=f.feature_key,value_type=f.value_type,value_boolean=f.value_boolean,value_integer=f.value_integer,version=1))
            db.add(TenantEntitlement(tenant_id=tenant_id,feature_key=f.feature_key,value_type=f.value_type,value_boolean=f.value_boolean,value_integer=f.value_integer,source_subscription_id=sub.id))
    db.add(SubscriptionItem(subscription_id=sub.id,plan_price_id=pp.id,quantity=1))
    outbox(db,tenant_id,'subscription',sub.id,'subscription.created',{'subscription_id':sub.id,'billing_provider':billing_provider,'tenant_id':tenant_id})
    body=json_model(sub); body['checkout_url']=checkout_url; body['plan_amount_minor']=pp.amount_minor_units; body['discount_minor']=discount_amount
    finalize_idem(rec,body,200); db.commit(); return body

@router.get('/subscription')
def subscription(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('billing.manage'))):
    tenant_scope(tenant_id, user, db)
    s = db.query(Subscription).filter_by(tenant_id=tenant_id, status='active').first()
    return json_model(s) if s else {'subscription': None}

@router.get('/entitlements')
def entitlements(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    return [json_model(x) for x in db.query(Entitlement).filter_by(tenant_id=tenant_id).all()]

@router.get('/finance/reconciliation')
def finance_reconciliation(tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('finance.read'))):
    from sqlalchemy import func
    tenant_scope(tenant_id, user, db)
    rows = db.query(PaymentIntent).filter_by(tenant_id=tenant_id).all()
    result = []
    for pi in rows:
        captured = db.query(PaymentCapture).filter_by(tenant_id=tenant_id,
         payment_intent_id=pi.id).with_entities(func.coalesce(func.sum(PaymentCapture.amount_minor),
            0)).scalar() or 0
        refunded = db.query(Refund).filter_by(tenant_id=tenant_id,
         payment_intent_id=pi.id).with_entities(func.coalesce(func.sum(Refund.amount_minor),
            0)).scalar() or 0
        result.append({'payment_intent_id': pi.id, 'amount_minor': pi.amount_minor,
         'captured_minor': captured,
         'refunded_minor': refunded,
            'currency': pi.currency, 'balanced': captured >= 0 and refunded <= captured})
    return result

@router.post('/subscription/change-plan')
def change_plan(tenant_id: str, data: PlanSubIn, user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('billing.manage')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    # Keep this compatibility endpoint on the same real billing state machine as
    # /subscriptions.  The previous implementation mutated subscriptions and
    # entitlements directly, which could activate a paid plan without creating
    # the corresponding Paddle transaction/provider state.
    return subscribe(tenant_id=tenant_id, data=data, user=user, db=db, idempotency_key=idempotency_key)

@router.post('/subscription/cancel')
def cancel_subscription(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
 _=Depends(require_permission('billing.manage')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    s = db.query(Subscription).filter_by(tenant_id=tenant_id, status='active').first()
    if not s:
        return {'subscription': None}
    if s.provider_subscription_id and s.billing_provider=='paddle' and get_settings().PADDLE_API_KEY:
        PaddleBillingProvider().cancel(s.provider_subscription_id,idempotency_key or s.id)
    s.status = 'canceled'
    db.query(Entitlement).filter_by(tenant_id=tenant_id).delete(synchronize_session=False)
    outbox(db, tenant_id, 'subscription', s.id, 'subscription.cancelled', {'subscription_id': s.id,
        'tenant_id': tenant_id})
    db.commit()
    return json_model(s)

@router.post('/admin/billing-discounts')
def admin_create_billing_discount(data: dict, admin=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    code=str(data.get('code','')).strip().upper()
    if not code: raise AppError(400,'BILLING_DISCOUNT_INVALID','Discount code is required')
    if db.query(PlatformBillingDiscount).filter_by(code=code).first(): raise AppError(409,'BILLING_DISCOUNT_EXISTS','Discount code already exists')
    typ=str(data.get('discount_type','PERCENTAGE')).upper()
    if typ not in {'PERCENTAGE','FIXED'}: raise AppError(400,'BILLING_DISCOUNT_TYPE','Unsupported discount type')
    d=PlatformBillingDiscount(code=code,plan_id=data.get('plan_id'),discount_type=typ,value_minor=data.get('value_minor'),percentage_bps=data.get('percentage_bps'),usage_limit=data.get('usage_limit'),starts_at=data.get('starts_at'),ends_at=data.get('ends_at'));
    if typ=='PERCENTAGE' and not (0<=int(d.percentage_bps or 0)<=10000): raise AppError(400,'BILLING_DISCOUNT_VALUE','Percentage must be 0..10000 bps')
    db.add(d); db.commit(); return json_model(d)

@router.post('/admin/plans')
def admin_create_plan(data: dict, admin=Depends(current_platform_admin),
 db: DBSession=Depends(get_db),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    code = str(data.get('code', '')).strip().lower()
    name = str(data.get('name', '')).strip()
    if not code or not name:
        raise AppError(400, 'PLAN_INVALID', 'Plan code and name are required')
    if db.query(Plan).filter_by(code=code).first():
        raise AppError(409, 'PLAN_EXISTS', 'Plan already exists')
    p = Plan(code=code, name=name, is_active=True)
    db.add(p)
    db.flush()
    v = PlanVersion(plan_id=p.id, version=1, is_current=True,
        provider_price_id=data.get('provider_price_id'))
    db.add(v)
    db.flush()
    for f in data.get('features', []):
        db.add(PlanFeature(plan_version_id=v.id, feature_key=f['key'], value_type=f.get('type',
            'integer'), value_boolean=f.get('boolean'), value_integer=f.get('integer')))
    db.commit()
    return {'plan': json_model(p), 'version': json_model(v)}

@router.patch('/admin/plans/{plan_id}')
def admin_patch_plan(plan_id: str, data: dict, admin=Depends(current_platform_admin),
 db: DBSession=Depends(get_db),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    p = db.get(Plan, plan_id)
    if not p:
        raise not_found('Plan not found')
    if 'name' in data:
        p.name = str(data['name'])
    if 'is_active' in data:
        p.is_active = bool(data['is_active'])
    db.commit()
    return json_model(p)

@router.post('/admin/plans/{plan_id}/publish-version')
def admin_publish_plan_version(plan_id: str, data: dict, admin=Depends(current_platform_admin),
    db: DBSession=Depends(get_db)):
    p = db.get(Plan, plan_id)
    if not p:
        raise not_found('Plan not found')
    version = int(data.get('version', 0))
    v = db.query(PlanVersion).filter_by(plan_id=plan_id, version=version).first()
    if not v:
        raise not_found('Plan version not found')
    db.query(PlanVersion).filter_by(plan_id=plan_id).update({'is_current': False})
    v.is_current = True
    db.commit()
    return json_model(v)

@router.get('/public/plans')
def public_plans(db: DBSession=Depends(get_db)):
    plans=[]
    for plan in db.query(Plan).filter_by(is_active=True).order_by(Plan.name.asc()).all():
        pv=db.query(PlanVersion).filter_by(plan_id=plan.id,is_current=True).first()
        if not pv: continue
        price=db.query(PlanPrice).filter_by(plan_version_id=pv.id,billing_interval='month').order_by(PlanPrice.created_at.desc()).first()
        features=db.query(PlanFeature).filter_by(plan_version_id=pv.id).order_by(PlanFeature.feature_key.asc()).all()
        plans.append({'id':pv.id,'code':plan.code,'name':plan.name,'price':({'amount_minor':price.amount_minor_units,'currency':price.currency,'interval':price.billing_interval} if price else None),'features':[{'key':f.feature_key,'type':f.value_type,'boolean':f.value_boolean,'integer':f.value_integer} for f in features]})
    return {'plans':plans,'currency':'USD'}

@router.post('/subscription/subscribe')
def subscribe_after_verification(tenant_id: str, data: PlanSubIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('billing.manage')), idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    _tenant_membership_or_403(tenant_id, user, db)
    _merchant_gate(db, tenant_id, user)
    # Keep this compatibility route on the same real billing implementation as /subscriptions.
    # Do not create synthetic provider IDs or a second pending-subscription state machine.
    return subscribe(tenant_id=tenant_id, data=data, user=user, db=db, idempotency_key=idempotency_key)
