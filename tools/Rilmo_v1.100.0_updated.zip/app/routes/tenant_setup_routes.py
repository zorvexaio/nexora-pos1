"""Tenant CRUD, storefront get/patch/publish, and custom-domain
provision/list/verify routes — the core store-setup flow a merchant walks
through before going live.

Extracted out of app/routes/v1.py (Phase 3, step 7). _merchant_gate is used
by other route groups still in v1.py (subscription flow), so it stays there
and is imported here rather than duplicated.
"""
import hmac
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db, set_tenant_context
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.core.config import get_settings
from app.core.serialization import json_model
from app.models.domain import *
from app.schemas.api import *
from app.security.policy import normalize_hostname, verification_txt_name, verify_dns_txt
from app.core.security import random_token, token_hash, hmac_sha256
from app.services.core import audit, outbox, body_hash
from app.routes.v1 import tenant_scope, require_if_match, _merchant_gate

router = APIRouter(prefix='/v1')


@router.post('/tenants')
def create_tenant(data: TenantIn, user=Depends(current_user), db: DBSession=Depends(get_db),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    payload = data.model_dump() if hasattr(data, 'model_dump') else data.__dict__
    endpoint = 'POST /v1/tenants'
    platform_rec = None
    if idempotency_key:
        platform_rec = db.query(PlatformIdempotencyKey).filter_by(actor_id=user.id,
            endpoint=endpoint, key=idempotency_key).first()
        ph = body_hash(payload)
        if platform_rec and platform_rec.request_hash != ph:
            raise AppError(409, 'IDEMPOTENCY_MISMATCH',
                'Same idempotency key used with a different request')
        if platform_rec and platform_rec.status == 'COMPLETED':
            return platform_rec.response_body
        if not platform_rec:
            platform_rec = PlatformIdempotencyKey(actor_id=user.id, endpoint=endpoint,
             key=idempotency_key,
             request_hash=ph,
                status='IN_PROGRESS', expires_at=datetime.now(timezone.utc) + timedelta(days=2))
            db.add(platform_rec)
            db.flush()
    existing = db.query(Tenant).filter_by(slug=data.slug).first()
    if existing:
        raise AppError(409, 'SLUG_EXISTS', 'Tenant slug exists')
    t = Tenant(slug=data.slug, name=data.name, default_currency=data.default_currency.upper(),
        default_locale=data.default_locale)
    db.add(t)
    db.flush()
    set_tenant_context(db, t.id)
    db.add(TenantMembership(tenant_id=t.id, user_id=user.id, role='owner'))
    sf = Storefront(tenant_id=t.id, name=data.name, slug='default',
        default_locale=data.default_locale, default_currency=data.default_currency.upper())
    db.add(sf)
    db.flush()
    audit(db, t.id, user.id, 'tenant.create', 'tenant', t.id, after={'slug': t.slug})
    outbox(db, t.id, 'tenant', t.id, 'tenant.created', {'tenant_id': t.id})
    outbox(db, t.id, 'storefront', sf.id, 'storefront.created', {'storefront_id': sf.id,
        'tenant_id': t.id})
    db.commit()
    return json_model(t)

@router.get('/tenants/{tenant_id}')
def get_tenant(tenant_id, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    t = db.get(Tenant, tenant_id)
    return json_model(t) if t else not_found('Tenant not found')

@router.patch('/tenants/{tenant_id}')
def patch_tenant(tenant_id: str, data: dict, if_match: str | None=Header(default=None,
 alias='If-Match'),
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    t = db.get(Tenant, tenant_id)
    if not t:
        raise not_found('Tenant not found')
    require_if_match(t, if_match)
    for k in ['name', 'default_currency', 'default_locale']:
        if k in data:
            setattr(t, k, data[k])
    audit(db, tenant_id, user.id, 'tenant.update', 'tenant', t.id, after=data)
    db.commit()
    return json_model(t)

@router.get('/storefront')
def storefront(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    s = db.query(Storefront).filter_by(tenant_id=tenant_id).first()
    return json_model(s)

@router.patch('/storefront')
def patch_storefront(tenant_id: str, data: dict, if_match: str | None=Header(default=None,
 alias='If-Match'),
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    s = db.query(Storefront).filter_by(tenant_id=tenant_id).first()
    if not s:
        raise not_found('Storefront not found')
    require_if_match(s, if_match)
    for k in ['name', 'default_locale', 'default_currency']:
        if k in data:
            setattr(s, k, data[k])
    db.commit()
    return json_model(s)

@router.post('/domains/provision')
def provision_domain(tenant_id: str, data: DomainIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    h = normalize_hostname(data.hostname)
    reserved = {'www', 'api', 'admin', 'app', 'cdn', 'mail', 'ftp', 'ns1', 'ns2'}
    if h.split('.')[0] in reserved:
        raise AppError(400, 'RESERVED_HOSTNAME', 'Hostname is reserved')
    if db.query(Domain).filter_by(hostname=h).first():
        raise AppError(409, 'DOMAIN_EXISTS', 'Hostname already used')
    srow = db.query(Storefront).filter_by(tenant_id=tenant_id).first()
    if not srow:
        raise not_found('Storefront not found')
    raw = random_token(24)
    d = Domain(tenant_id=tenant_id, storefront_id=srow.id, hostname=h,
     verification_token_hash=token_hash(raw),
     verification_expires_at=datetime.now(timezone.utc) + timedelta(hours=24),
        verification_method='DNS_TXT', verified_hostname=None, verification_version=1)
    db.add(d)
    db.flush()
    audit(db, tenant_id, user.id, 'domain.provision', 'domain', d.id, after={'hostname': h,
        'verification_method': 'DNS_TXT'})
    outbox(db, tenant_id, 'domain', d.id, 'domain.provisioned', {'domain_id': d.id, 'hostname': h,
        'tenant_id': tenant_id})
    db.commit()
    return {'domain': json_model(d), 'verification': {'method': 'DNS_TXT', 'record_type': 'TXT',
     'record_name': verification_txt_name(h,
     get_settings().DOMAIN_VERIFICATION_TXT_PREFIX),
        'record_value': raw, 'expires_at': d.verification_expires_at}, 'verification_token': raw}

@router.get('/domains')
def domains(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    return [json_model(d) for d in db.query(Domain).filter_by(tenant_id=tenant_id).all()]

@router.post('/domains/{domain_id}/verify')
def verify_domain(domain_id: str, token: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    d = db.query(Domain).filter_by(id=domain_id, tenant_id=tenant_id).first()
    if not d:
        raise not_found('Domain not found')
    now = datetime.now(timezone.utc)
    exp = d.verification_expires_at
    if exp and exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    if not d.verification_token_hash or not exp or exp <= now or (not hmac.compare_digest(token_hash(token),
        d.verification_token_hash)):
        raise AppError(400, 'DOMAIN_VERIFICATION_FAILED', 'Invalid or expired verification token')
    mode = get_settings().DOMAIN_VERIFICATION_MODE
    if mode == 'dns' and (not verify_dns_txt(d.hostname, token,
     prefix=get_settings().DOMAIN_VERIFICATION_TXT_PREFIX,
        timeout=get_settings().DOMAIN_VERIFICATION_TIMEOUT_SECONDS)):
        raise AppError(400, 'DOMAIN_DNS_PROOF_REQUIRED',
            'Publish the verification TXT record before activating this domain')
    d.verified_at = now
    d.verified_hostname = d.hostname
    d.verification_token_hash = None
    d.verification_expires_at = None
    d.verification_version = int(d.verification_version or 1) + 1
    audit(db, tenant_id, user.id, 'domain.verify', 'domain', d.id, after={'verified': True,
        'method': d.verification_method})
    db.commit()
    return json_model(d)

@router.post('/storefront/publish')
def publish_storefront(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    t = db.get(Tenant, tenant_id)
    s = db.query(Storefront).filter_by(tenant_id=tenant_id).first()
    product = db.query(Product).filter_by(tenant_id=tenant_id, deleted_at=None,
        status='ACTIVE').first()
    domain = db.query(Domain).filter_by(tenant_id=tenant_id).first()
    shipping_method = db.query(ShippingMethod).filter_by(tenant_id=tenant_id, is_active=True).first()
    if not t or not s:
        raise not_found('Storefront not found')
    _merchant_gate(db, tenant_id, user)
    active_sub = db.query(Subscription).filter_by(tenant_id=tenant_id, status='active').first()
    if not product or not domain or (not domain.verified_at) or (not active_sub) or not shipping_method:
        raise AppError(400, 'PUBLISH_PREREQUISITES',
            'Active product, verified domain, active subscription, and at least one shipping method are required')
    t.status = 'ACTIVE'
    s.status = 'PUBLISHED'
    audit(db, tenant_id, user.id, 'storefront.publish', 'storefront', s.id,
        after={'status': 'PUBLISHED'})
    outbox(db, tenant_id, 'storefront', s.id, 'storefront.published', {'storefront_id': s.id,
        'tenant_id': tenant_id})
    outbox(db, tenant_id, 'tenant', t.id, 'tenant.activated', {'tenant_id': tenant_id})
    db.commit()
    return json_model(s)

@router.post('/storefront/preview-token')
def storefront_preview_token(tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    sf = db.query(Storefront).filter_by(tenant_id=tenant_id).first()
    if not sf:
        raise not_found('Storefront not found')
    import base64, json, time
    payload = {'tenant_id': tenant_id, 'storefront_id': sf.id, 'scope': 'storefront_preview',
        'exp': int(time.time()) + 900}
    raw = base64.urlsafe_b64encode(json.dumps(payload, separators=(',',
        ':')).encode()).decode().rstrip('=')
    sig = hmac_sha256(raw.encode(), get_settings().SECRET_KEY)
    return {'preview_token': raw + '.' + sig, 'expires_in': 900}
