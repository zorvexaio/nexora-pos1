"""Checkout: cart -> order conversion, with coupon, tax, shipping, and
inventory reservation.

Extracted out of app/routes/v1.py (Phase 3, step 34). assert_cart_owner and
idem_start are shared helpers used by other route groups still in v1.py, so
they stay there and are imported here.

Bug fix while moving: when redeeming a coupon, the code looked up the
customer a second time via `db.query(Customer).filter_by(email=user.email)`
instead of reusing the `customer` object already resolved earlier in the
same function (from `data.customer_email` or the acting user's email).
For a guest checkout, `user` is None (guest checkout is optional_user-based),
so this raised an AttributeError as soon as a guest used a coupon code —
guest + coupon is an extremely common real-world combination, but no test
covered it, so it was never caught. Fixed by reusing `customer` directly.
"""
import uuid
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Header, Request, Response
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import optional_user
from app.core.guest import commerce_actor
from app.core.errors import AppError, not_found, forbidden
from app.core.security import token_hash
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import (outbox, finalize_idem, resolve_variant_price_details,
    calculate_coupon_discount, require_entitlement)
from app.routes.v1 import tenant_scope, assert_cart_owner, idem_start

router = APIRouter(prefix='/v1')


@router.post('/checkout')
def checkout(tenant_id: str, data: CheckoutIn, request: Request, response: Response,
 user=Depends(optional_user),
 db: DBSession=Depends(get_db),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    actor, guest = commerce_actor(request, response, db, tenant_id)
    if user is not None:
        actor = user
    if actor is not None and not getattr(actor, 'is_customer', False):
        tenant_scope(tenant_id, actor, db)
    elif actor is None and not guest:
        raise forbidden('Guest session required')
    payload = data.model_dump() if hasattr(data, 'model_dump') else data.__dict__
    rec = idem_start(db, tenant_id, actor.id if actor else None, 'POST /v1/checkout',
        idempotency_key, payload)
    if rec and rec.status == 'COMPLETED':
        return rec.response_body
    c = db.query(Cart).filter_by(id=data.cart_id, tenant_id=tenant_id, status='OPEN').with_for_update().first()
    if not c:
        raise not_found('Cart not found')
    assert_cart_owner(c, actor, guest, db)
    items = db.query(CartItem).filter_by(cart_id=c.id, tenant_id=tenant_id).all()
    if not items:
        raise AppError(400, 'CART_EMPTY', 'Cart is empty')
    subtotal = 0
    variant_rows = []
    for i in items:
        v = db.query(ProductVariant).filter_by(id=i.variant_id, tenant_id=tenant_id,
            status='ACTIVE').first()
        if not v:
            raise AppError(409, 'VARIANT_UNAVAILABLE', 'Cart contains an unavailable variant')
        if v.currency != c.currency or v.currency != i.currency:
            raise AppError(409, 'CURRENCY_MISMATCH', 'Cart currency mismatch')
        pricing = resolve_variant_price_details(db, tenant_id, v)
        effective_price = pricing['selling_price_minor']
        subtotal += i.quantity * effective_price
        variant_rows.append((i, v, pricing))
    discount = 0
    coupon = None
    promotion = None
    if data.coupon_code:
        require_entitlement(db, tenant_id, 'coupons')
        coupon, promotion, discount = calculate_coupon_discount(db, tenant_id, data.coupon_code,
            subtotal, c.currency)
    shipping_minor = 0
    shipping_list_minor = 0
    shipping_discount_minor = 0
    shipping_method = None
    if data.shipping_method_id:
        shipping_method = db.query(ShippingMethod).filter_by(id=data.shipping_method_id, tenant_id=tenant_id,
            is_active=True).first()
        if not shipping_method or shipping_method.currency != c.currency:
            raise AppError(409, 'SHIPPING_METHOD_INVALID',
                'Shipping method is invalid for this cart')
        shipping_list_minor = int(shipping_method.amount_minor)
        qualifies_free = bool(shipping_method.free_shipping and (shipping_method.free_shipping_threshold_minor is None or
            max(0, subtotal - discount) >= int(shipping_method.free_shipping_threshold_minor)))
        shipping_minor = 0 if qualifies_free else shipping_list_minor
        shipping_discount_minor = max(0, shipping_list_minor - shipping_minor)
    elif data.shipping_minor:
        raise AppError(400, 'SHIPPING_NOT_AUTHORITATIVE', 'Use a configured shipping method')
    if data.tax_minor:
        raise AppError(400, 'TAX_NOT_AUTHORITATIVE', 'Tax is calculated from tenant tax rules')
    tax_minor = 0
    if data.shipping_address and data.shipping_address.get('country_code'):
        rate = db.query(TaxRate).filter_by(tenant_id=tenant_id,
         country_code=str(data.shipping_address.get('country_code')).upper(),
            region=data.shipping_address.get('region')).first()
        if not rate and data.shipping_address.get('region'):
            rate = db.query(TaxRate).filter_by(tenant_id=tenant_id,
             country_code=str(data.shipping_address.get('country_code')).upper(),
                region=None).first()
        if rate:
            taxable = max(0, subtotal - discount)
            tax_minor = taxable * int(rate.rate_bps) // 10000
    fee_minor = 0
    total = max(0, subtotal - discount + shipping_minor + tax_minor + fee_minor)
    if total < 0:
        raise AppError(400, 'TOTAL_INVALID', 'Order total cannot be negative')
    email = str(data.customer_email).lower() if data.customer_email else actor.email.lower() if actor else None
    if not email:
        raise AppError(400, 'CUSTOMER_EMAIL_REQUIRED',
            'Customer email is required for guest checkout')
    customer = db.query(Customer).filter_by(tenant_id=tenant_id, email=email).first()
    if not customer:
        customer = Customer(tenant_id=tenant_id, email=email, first_name=data.customer_name)
        db.add(customer)
        db.flush()
    order = Order(tenant_id=tenant_id, order_number='ORD-' + uuid.uuid4().hex[:12].upper(),
     status='PENDING_PAYMENT',
     customer_id=customer.id,
     customer_email_snapshot=email,
     guest_session_id=guest.id if actor is None else None,
     currency=c.currency,
     subtotal_minor=subtotal,
     discount_minor=discount,
        shipping_minor=shipping_minor, shipping_list_minor=shipping_list_minor, shipping_discount_minor=shipping_discount_minor,
        shipping_method_id=shipping_method.id if shipping_method else None,
        shipping_carrier_code=shipping_method.carrier_code if shipping_method else None,
        shipping_service_code=shipping_method.service_code if shipping_method else None,
        tax_minor=tax_minor, fee_minor=fee_minor, total_minor=total)
    db.add(order)
    db.flush()
    affiliate_referral = None
    if data.affiliate_code:
        partner = db.query(AffiliatePartner).filter_by(tenant_id=tenant_id, code=data.affiliate_code.strip().upper(), status='ACTIVE').first()
        if partner:
            visitor = request.cookies.get('live_visitor')
            if visitor:
                affiliate_referral = db.query(AffiliateReferral).filter_by(tenant_id=tenant_id, visitor_key_hash=token_hash(visitor), status='CLICKED', order_id=None).order_by(AffiliateReferral.created_at.desc()).first()
            if affiliate_referral and affiliate_referral.partner_id == partner.id:
                affiliate_referral.order_id = order.id
                affiliate_referral.revenue_minor = total
                affiliate_referral.commission_minor = total * int((db.query(AffiliateProgram).filter_by(tenant_id=tenant_id).first() or AffiliateProgram(commission_bps=0)).commission_bps) // 10000
                affiliate_referral.status = 'PENDING_CONVERSION'
                db.add(AffiliateCommission(tenant_id=tenant_id, partner_id=partner.id, referral_id=affiliate_referral.id, order_id=order.id, amount_minor=affiliate_referral.commission_minor, currency=c.currency))
    if data.shipping_address and data.shipping_address.get('country_code'):
        tc = TaxCalculation(tenant_id=tenant_id, order_id=order.id, currency=c.currency,
            subtotal_minor=max(0, subtotal - discount), tax_total_minor=tax_minor)
        db.add(tc)
        db.flush()
        if tax_minor:
            rate_row = db.query(TaxRate).filter_by(tenant_id=tenant_id,
             country_code=str(data.shipping_address.get('country_code')).upper(),
             region=data.shipping_address.get('region')).first() or db.query(TaxRate).filter_by(tenant_id=tenant_id,
             country_code=str(data.shipping_address.get('country_code')).upper(),
                region=None).first()
            if rate_row:
                db.add(TaxLine(tenant_id=tenant_id, tax_calculation_id=tc.id,
                 taxable_amount_minor=max(0,
                 subtotal - discount),
                    tax_amount_minor=tax_minor, rate_bps=rate_row.rate_bps, currency=c.currency))
    if data.shipping_address:
        a = data.shipping_address
        db.add(OrderAddress(tenant_id=tenant_id, order_id=order.id, type='SHIPPING',
         recipient_name=a.get('recipient_name'),
         phone=a.get('phone'),
         country_code=a.get('country_code',
         ''),
         region=a.get('region'),
         city=a.get('city'),
         postal_code=a.get('postal_code'),
            address_line1=a.get('address_line1', ''), address_line2=a.get('address_line2')))
    for i, v, pricing in variant_rows:
        effective_price = pricing['selling_price_minor']
        prod = db.query(Product).filter_by(id=v.product_id, tenant_id=tenant_id,
            deleted_at=None).first()
        db.add(OrderItem(tenant_id=tenant_id, order_id=order.id, variant_id=v.id,
         sku_snapshot=v.sku,
         title_snapshot=prod.title if prod else '',
         quantity=i.quantity,
         unit_price_minor=pricing['list_price_minor'],
         cost_amount_minor=v.cost_amount_minor,
         discount_minor=i.quantity * pricing['discount_minor'],
            total_minor=i.quantity * effective_price, currency=v.currency))
        if prod and prod.product_type == 'PHYSICAL':
            inv_q = db.query(InventoryItem).filter_by(tenant_id=tenant_id, variant_id=v.id)
            if data.inventory_location_id:
                inv_q = inv_q.filter_by(location_id=data.inventory_location_id)
            else:
                candidates = inv_q.with_entities(InventoryItem.id).limit(2).all()
                if len(candidates) > 1:
                    raise AppError(409, 'INVENTORY_LOCATION_REQUIRED',
                        'Inventory location is required when a variant exists at multiple locations')
            inv = inv_q.order_by(InventoryItem.id).with_for_update().first()
            if not inv:
                raise AppError(409, 'INVENTORY_LOCATION_INVALID' if data.inventory_location_id else 'INVENTORY_INSUFFICIENT',
                    'Inventory item not found at the requested location' if data.inventory_location_id else 'Insufficient inventory')
            if inv.available < i.quantity:
                raise AppError(409, 'INVENTORY_INSUFFICIENT', 'Insufficient inventory')
            inv.available -= i.quantity
            inv.reserved += i.quantity
            inv.version += 1
            db.add(InventoryReservation(tenant_id=tenant_id, inventory_item_id=inv.id,
             order_id=order.id,
             quantity=i.quantity,
                expires_at=datetime.now(timezone.utc) + timedelta(minutes=15), status='ACTIVE'))
    if coupon and promotion:
        coupon.usage_count += 1
        promotion.usage_count += 1
        outbox(db, tenant_id, 'promotion', promotion.id, 'promotion.usage.incremented',
         {'promotion_id': promotion.id,
            'coupon_id': coupon.id, 'order_id': order.id, 'tenant_id': tenant_id})
        db.add(CouponRedemption(tenant_id=tenant_id, coupon_id=coupon.id, promotion_id=promotion.id,
         order_id=order.id,
         customer_id=customer.id,
            idempotency_key=idempotency_key or 'order:' + order.id))
        db.add(DiscountApplication(tenant_id=tenant_id, order_id=order.id,
         promotion_id=promotion.id,
            coupon_id=coupon.id, amount_minor=discount, currency=c.currency))
        outbox(db, tenant_id, 'coupon', coupon.id, 'coupon.redeemed', {'coupon_id': coupon.id,
            'order_id': order.id, 'tenant_id': tenant_id})
    c.status = 'CHECKED_OUT'
    c.version += 1
    c.updated_at = datetime.now(timezone.utc)
    outbox(db, tenant_id, 'order', order.id, 'order.created', {'order_id': order.id,
        'order_number': order.order_number, 'tenant_id': tenant_id})
    body = json_model(order)
    finalize_idem(rec, body, 200)
    db.commit()
    return body
