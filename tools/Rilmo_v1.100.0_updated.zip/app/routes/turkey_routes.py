"""Turkey-market-specific routes: KDV tax profiles, local shipping carrier
configuration.

Extracted out of app/routes/v1.py (Phase 3, step 30).
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError
from app.core.security import encrypt_secret
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.get('/turkey/tax-profiles')
def list_turkey_tax(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    return [json_model(x) for x in db.query(TurkeyTaxProfile).filter_by(tenant_id=tenant_id,
        active=True).all()]

@router.post('/turkey/tax-profiles')
def create_turkey_tax(tenant_id: str, data: TurkeyTaxProfileIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    if data.kdv_bps not in {100, 1000, 2000}:
        raise AppError(400, 'KDV_RATE_UNSUPPORTED',
            'Configured Turkey KDV rate must be one of the currently supported standard profile values (1%, 10%, 20%)')
    row = TurkeyTaxProfile(tenant_id=tenant_id, **data.model_dump())
    db.add(row)
    db.commit()
    return json_model(row)

@router.get('/turkey/shipping-carriers')
def turkey_carriers(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    return {'supported': ['yurtici', 'aras', 'mng', 'ptt'],
     'configured': [json_model(x) for x in db.query(TurkeyCarrierConfig).filter_by(tenant_id=tenant_id,
        status='ACTIVE').all()]}

@router.post('/turkey/shipping-carriers')
def configure_turkey_carrier(tenant_id: str, data: TurkeyCarrierConfigIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    if data.carrier_code.lower() not in {'yurtici', 'aras', 'mng', 'ptt'}:
        raise AppError(400, 'TURKEY_CARRIER_UNSUPPORTED', 'Unsupported Turkish carrier')
    row = db.query(TurkeyCarrierConfig).filter_by(tenant_id=tenant_id,
        carrier_code=data.carrier_code.lower()).first()
    if not row:
        row = TurkeyCarrierConfig(tenant_id=tenant_id, carrier_code=data.carrier_code.lower())
        db.add(row)
        db.flush()
    if data.api_base_url:
        from app.core.network import validate_outbound_url
        validate_outbound_url(data.api_base_url)
    row.api_base_url = data.api_base_url
    row.api_token_encrypted = encrypt_secret(data.api_token) if data.api_token else None
    row.metadata_json = data.metadata
    row.status = 'ACTIVE'
    db.commit()
    return {'id': row.id, 'carrier_code': row.carrier_code, 'status': row.status}
