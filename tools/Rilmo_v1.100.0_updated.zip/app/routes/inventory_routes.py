"""Inventory routes: reserve, adjust, release reservation, list.

Extracted out of app/routes/v1.py (Phase 3, step 22). idem/idem_start are
shared idempotency helpers used by many other route groups still in v1.py,
so they stay there and are imported here.
"""
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.core.serialization import json_model
from app.services.core import outbox, body_hash, finalize_idem
from app.routes.v1 import tenant_scope, idem, idem_start

router = APIRouter(prefix='/v1')


@router.post('/inventory/reservations')
def reserve(tenant_id: str, variant_id: str, quantity: int, order_id: str, location_id: str | None = None,
 user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('inventory.write')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    if quantity <= 0:
        raise AppError(400, 'INVALID_QUANTITY', 'Quantity must be positive')
    idem_payload = {'variant_id': variant_id, 'location_id': location_id, 'quantity': quantity, 'order_id': order_id}
    idempotency_key = idempotency_key or 'auto:inventory-reservation:' + body_hash(idem_payload)
    rec, state = idem(db, tenant_id, user.id, 'POST /v1/inventory/reservations', idempotency_key,
        body_hash(idem_payload))
    if rec and rec.status == 'COMPLETED':
        return rec.response_body
    if rec and rec.status == 'IN_PROGRESS' and not getattr(rec, '_idempotency_fresh', False):
        raise AppError(409, 'IDEMPOTENCY_IN_PROGRESS', 'An identical operation is already in progress')
    item_q = db.query(InventoryItem).filter_by(tenant_id=tenant_id, variant_id=variant_id)
    if location_id:
        item_q = item_q.filter_by(location_id=location_id)
    else:
        candidates = item_q.with_entities(InventoryItem.id).limit(2).all()
        if len(candidates) > 1:
            raise AppError(409, 'INVENTORY_LOCATION_REQUIRED',
                'Inventory location is required when a variant exists at multiple locations')
    item = item_q.order_by(InventoryItem.id).with_for_update().first()
    if not item:
        raise AppError(409, 'INVENTORY_LOCATION_INVALID' if location_id else 'INVENTORY_INSUFFICIENT',
            'Inventory item not found at the requested location' if location_id else 'Insufficient inventory')
    if item.available < quantity:
        raise AppError(409, 'INVENTORY_INSUFFICIENT', 'Insufficient inventory')
    r = InventoryReservation(tenant_id=tenant_id, inventory_item_id=item.id, order_id=order_id,
     quantity=quantity,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=15), status='ACTIVE')
    item.available -= quantity
    item.reserved += quantity
    item.version += 1
    db.add(r)
    db.flush()
    outbox(db, tenant_id, 'inventory', r.id, 'inventory.reserved', {'reservation_id': r.id,
        'tenant_id': tenant_id, 'quantity': quantity})
    body = json_model(r)
    finalize_idem(rec, body, 200)
    db.commit()
    return body

@router.post('/inventory/adjustments')
def adjust_inventory(tenant_id: str, variant_id: str, delta: int, reason: str,
 location_id: str | None = None,
 user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('inventory.write')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    idem_payload = {'variant_id': variant_id, 'location_id': location_id, 'delta': delta, 'reason': reason}
    idempotency_key = idempotency_key or 'auto:inventory-adjustment:' + body_hash(idem_payload)
    rec, state = idem(db, tenant_id, user.id, 'POST /v1/inventory/adjustments', idempotency_key,
        body_hash(idem_payload))
    if rec and rec.status == 'COMPLETED':
        return rec.response_body
    if rec and rec.status == 'IN_PROGRESS' and not getattr(rec, '_idempotency_fresh', False):
        raise AppError(409, 'IDEMPOTENCY_IN_PROGRESS', 'An identical operation is already in progress')
    q = db.query(InventoryItem).filter_by(tenant_id=tenant_id, variant_id=variant_id)
    if location_id:
        q = q.filter_by(location_id=location_id)
    else:
        candidates = q.with_entities(InventoryItem.id).limit(2).all()
        if len(candidates) > 1:
            raise AppError(409, 'INVENTORY_LOCATION_REQUIRED',
                'Location is required when a variant exists at multiple inventory locations')
    item = q.with_for_update().first()
    if not item:
        raise not_found('Inventory item not found')
    if item.on_hand + delta < 0 or item.available + delta < 0:
        raise AppError(409, 'INVENTORY_NEGATIVE', 'Inventory cannot become negative or consume reserved stock')
    item.on_hand += delta
    item.available += delta
    item.version += 1
    adj = InventoryAdjustment(tenant_id=tenant_id, inventory_item_id=item.id, delta=delta,
        reason=reason)
    db.add(adj)
    db.flush()
    outbox(db, tenant_id, 'inventory', adj.id, 'inventory.adjusted', {'adjustment_id': adj.id,
        'tenant_id': tenant_id, 'delta': delta})
    body = json_model(item)
    finalize_idem(rec, body, 200)
    db.commit()
    return body

@router.post('/inventory/reservations/{reservation_id}/release')
def release_reservation(reservation_id: str, tenant_id: str, user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('inventory.write')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    rec = idem_start(db, tenant_id, user.id, 'POST /v1/inventory/reservations/{id}/release',
        idempotency_key, {'reservation_id': reservation_id})
    if rec and rec.status == 'COMPLETED':
        return rec.response_body
    r = db.query(InventoryReservation).filter_by(id=reservation_id,
        tenant_id=tenant_id).with_for_update().first()
    if not r:
        raise not_found('Reservation not found')
    if r.status == 'RELEASED':
        body = json_model(r)
        finalize_idem(rec, body, 200)
        db.commit()
        return body
    inv = db.query(InventoryItem).filter_by(id=r.inventory_item_id,
        tenant_id=tenant_id).with_for_update().first()
    inv.reserved = max(0, inv.reserved - r.quantity)
    inv.available += r.quantity
    inv.version += 1
    r.status = 'RELEASED'
    outbox(db, tenant_id, 'inventory', inv.id, 'inventory.released', {'reservation_id': r.id,
        'tenant_id': tenant_id, 'quantity': r.quantity})
    body = json_model(r)
    finalize_idem(rec, body, 200)
    db.commit()
    return body

@router.get('/inventory')
def list_inventory(tenant_id: str, limit: int=100, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('inventory.read'))):
    tenant_scope(tenant_id, user, db)
    rows = db.query(InventoryItem).filter_by(tenant_id=tenant_id).order_by(InventoryItem.updated_at.desc() if hasattr(InventoryItem,
        'updated_at') else InventoryItem.id).limit(max(1, min(limit, 200))).all()
    return {'items': [json_model(x) for x in rows]}
