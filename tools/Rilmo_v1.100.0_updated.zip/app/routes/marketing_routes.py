"""Loyalty points (earn/redeem/balance), customer marketing preferences, and
marketing automation routes (abandoned-cart scan, catalog feed).

Extracted out of app/routes/v1.py (Phase 3, step 6).

Bug fix while moving: loyalty_earn()/loyalty_redeem() catch IntegrityError on
a concurrent-insert race (two simultaneous requests creating the same
customer's first LoyaltyAccount row), but v1.py never actually imported
IntegrityError anywhere — neither directly nor via any of its wildcard
imports. That name would only resolve at all if some other module happened
to leak it into builtins-like scope, which none of them do; as written, a
real concurrent race would have hit a NameError instead of the intended
retry. No existing test exercises true concurrent inserts here, so it never
surfaced. Fixed by importing it properly in this file.
"""
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from sqlalchemy.exc import IntegrityError
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import body_hash, require_entitlement
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.post('/loyalty/earn')
def loyalty_earn(tenant_id: str, data: LoyaltyEarnIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('customers.write'))):
    tenant_scope(tenant_id, user, db)
    customer = db.query(Customer).filter_by(id=data.customer_id, tenant_id=tenant_id).first()
    if not customer:
        raise not_found('Customer not found')
    request_hash = body_hash({'customer_id': customer.id, 'points': int(data.points), 'reason': data.reason, 'operation': 'earn'})
    existing = db.query(LoyaltyTransaction).filter_by(tenant_id=tenant_id,
        idempotency_key=data.idempotency_key).first()
    if existing:
        legacy_mismatch = (existing.request_hash is None and (
            int(existing.points_delta) != int(data.points) or existing.reason != data.reason or
            db.query(LoyaltyAccount).filter_by(id=existing.loyalty_account_id, tenant_id=tenant_id, customer_id=customer.id).first() is None))
        if legacy_mismatch or (existing.request_hash and existing.request_hash != request_hash):
            raise AppError(409, 'IDEMPOTENCY_MISMATCH', 'Same idempotency key used with a different request')
        return {'account_id': existing.loyalty_account_id, 'points_delta': existing.points_delta,
            'duplicate': True}
    account = db.query(LoyaltyAccount).filter_by(tenant_id=tenant_id,
        customer_id=customer.id).with_for_update().first()
    if not account:
        account = LoyaltyAccount(tenant_id=tenant_id, customer_id=customer.id)
        try:
            with db.begin_nested():
                db.add(account)
                db.flush()
        except IntegrityError:
            account = db.query(LoyaltyAccount).filter_by(tenant_id=tenant_id,
                customer_id=customer.id).with_for_update().first()
            if account is None:
                raise
    # Re-check after acquiring the account lock so concurrent retries cannot double-apply.
    existing = db.query(LoyaltyTransaction).filter_by(tenant_id=tenant_id,
        idempotency_key=data.idempotency_key).first()
    if existing:
        legacy_mismatch = (existing.request_hash is None and (
            int(existing.points_delta) != int(data.points) or existing.reason != data.reason or
            db.query(LoyaltyAccount).filter_by(id=existing.loyalty_account_id, tenant_id=tenant_id, customer_id=customer.id).first() is None))
        if legacy_mismatch or (existing.request_hash and existing.request_hash != request_hash):
            raise AppError(409, 'IDEMPOTENCY_MISMATCH', 'Same idempotency key used with a different request')
        return {'account_id': existing.loyalty_account_id, 'points_delta': existing.points_delta,
            'duplicate': True}
    account.points_balance += data.points
    account.lifetime_earned += data.points
    tx = LoyaltyTransaction(tenant_id=tenant_id, loyalty_account_id=account.id,
        points_delta=data.points, reason=data.reason, idempotency_key=data.idempotency_key,
        request_hash=request_hash)
    db.add(tx)
    db.commit()
    return {'account_id': account.id, 'points_balance': account.points_balance,
        'points_delta': data.points}

@router.post('/loyalty/redeem')
def loyalty_redeem(tenant_id: str, data: LoyaltyRedeemIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('customers.write'))):
    tenant_scope(tenant_id, user, db)
    customer = db.query(Customer).filter_by(id=data.customer_id, tenant_id=tenant_id).first()
    if not customer:
        raise not_found('Customer not found')
    request_hash = body_hash({'customer_id': customer.id, 'points': int(data.points), 'reason': data.reason, 'operation': 'redeem'})
    existing = db.query(LoyaltyTransaction).filter_by(tenant_id=tenant_id,
        idempotency_key=data.idempotency_key).first()
    if existing:
        legacy_mismatch = (existing.request_hash is None and (
            int(existing.points_delta) != -int(data.points) or existing.reason != data.reason or
            db.query(LoyaltyAccount).filter_by(id=existing.loyalty_account_id, tenant_id=tenant_id, customer_id=customer.id).first() is None))
        if legacy_mismatch or (existing.request_hash and existing.request_hash != request_hash):
            raise AppError(409, 'IDEMPOTENCY_MISMATCH', 'Same idempotency key used with a different request')
        return {'account_id': existing.loyalty_account_id, 'points_delta': existing.points_delta,
            'duplicate': True}
    account = db.query(LoyaltyAccount).filter_by(tenant_id=tenant_id,
        customer_id=customer.id).with_for_update().first()
    if not account or account.points_balance < data.points:
        raise AppError(409, 'LOYALTY_INSUFFICIENT', 'Insufficient loyalty points')
    # Re-check after acquiring the account lock so concurrent retries cannot double-apply.
    existing = db.query(LoyaltyTransaction).filter_by(tenant_id=tenant_id,
        idempotency_key=data.idempotency_key).first()
    if existing:
        legacy_mismatch = (existing.request_hash is None and (
            int(existing.points_delta) != -int(data.points) or existing.reason != data.reason or
            db.query(LoyaltyAccount).filter_by(id=existing.loyalty_account_id, tenant_id=tenant_id, customer_id=customer.id).first() is None))
        if legacy_mismatch or (existing.request_hash and existing.request_hash != request_hash):
            raise AppError(409, 'IDEMPOTENCY_MISMATCH', 'Same idempotency key used with a different request')
        return {'account_id': existing.loyalty_account_id, 'points_delta': existing.points_delta,
            'duplicate': True}
    account.points_balance -= data.points
    account.lifetime_redeemed += data.points
    tx = LoyaltyTransaction(tenant_id=tenant_id, loyalty_account_id=account.id,
        points_delta=-data.points, reason=data.reason, idempotency_key=data.idempotency_key,
        request_hash=request_hash)
    db.add(tx)
    db.commit()
    return {'account_id': account.id, 'points_balance': account.points_balance,
        'points_delta': -data.points}

@router.get('/loyalty/{customer_id}')
def loyalty_balance(tenant_id: str, customer_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('customers.read'))):
    tenant_scope(tenant_id, user, db)
    account = db.query(LoyaltyAccount).filter_by(tenant_id=tenant_id,
        customer_id=customer_id).first()
    if not account:
        return {'points_balance': 0, 'lifetime_earned': 0, 'lifetime_redeemed': 0}
    return json_model(account)

@router.put('/customers/{customer_id}/marketing-preferences')
def marketing_preferences(tenant_id: str, customer_id: str, data: MarketingPreferenceIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('customers.write'))):
    tenant_scope(tenant_id, user, db)
    customer = db.query(Customer).filter_by(id=customer_id, tenant_id=tenant_id).first()
    if not customer:
        raise not_found('Customer not found')
    pref = db.query(MarketingPreference).filter_by(tenant_id=tenant_id,
        customer_id=customer_id).first()
    if not pref:
        pref = MarketingPreference(tenant_id=tenant_id, customer_id=customer_id)
        db.add(pref)
    pref.email_marketing = data.email_marketing
    pref.sms_marketing = data.sms_marketing
    pref.whatsapp_marketing = data.whatsapp_marketing
    pref.updated_at = datetime.now(timezone.utc)
    db.commit()
    return json_model(pref)

@router.post('/marketing/abandoned-carts/scan')
def scan_abandoned_carts(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('orders.read'))):
    tenant_scope(tenant_id, user, db)
    require_entitlement(db, tenant_id, 'abandoned_cart')
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=1)
    carts = db.query(Cart).filter(Cart.tenant_id == tenant_id, Cart.status == 'OPEN',
        Cart.updated_at <= cutoff, Cart.expires_at.is_(None)).limit(500).all()
    created = 0
    for cart in carts:
        if not db.query(CartItem).filter_by(tenant_id=tenant_id, cart_id=cart.id).first():
            continue
        if db.query(AbandonedCartCampaign).filter_by(tenant_id=tenant_id, cart_id=cart.id).first():
            continue
        db.add(AbandonedCartCampaign(tenant_id=tenant_id, cart_id=cart.id, status='PENDING',
            scheduled_at=now + timedelta(hours=1)))
        created += 1
    db.commit()
    return {'scheduled': created}

@router.get('/marketing/catalog-feed')
def marketing_catalog_feed(tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.read'))):
    tenant_scope(tenant_id, user, db)
    products = db.query(Product).filter(Product.tenant_id == tenant_id, Product.status == 'ACTIVE',
        Product.deleted_at.is_(None)).limit(10000).all()
    return {'version': 1, 'generated_at': datetime.now(timezone.utc).isoformat(),
     'items': [{'id': p.id,
     'title': p.title,
     'slug': p.slug,
        'description': p.description, 'product_type': p.product_type} for p in products]}
