"""Buyer-protection routes: customer self-service order cancellation (with
automatic void/refund), and the order-issue system (customer opens an issue,
merchant responds/resolves, threaded messages both directions).

Extracted out of app/routes/v1.py (Phase 3, step 38) via exact programmatic
text extraction, verified byte-for-byte identical against the source before
removal. get_payment_provider/provider_credentials/transition/tenant_scope
are shared helpers also used by callers still in v1.py (webhook handlers),
so they stay defined there and are imported here.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func
from app.core.database import get_db
from app.core.auth import current_user, require_permission, assert_permission
from app.core.guest import customer_session_actor
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.payment_providers import get_payment_provider
from app.services.order_state import transition
from app.services.core import audit, outbox
from app.routes.v1 import tenant_scope, provider_credentials

router = APIRouter(prefix='/v1')


@router.post('/customer/orders/{order_id}/cancel')
def customer_cancel_order(order_id: str, tenant_id: str, data: CustomerOrderCancelIn, request: Request, response: Response, db: DBSession=Depends(get_db)):
    actor = customer_session_actor(request, db, tenant_id)
    if actor is None:
        raise AppError(401,'CUSTOMER_LOGIN_REQUIRED','Sign in to cancel an order')
    o = db.query(Order).filter_by(id=order_id, tenant_id=tenant_id, customer_id=actor.customer_id).with_for_update().first()
    if not o:
        raise not_found('Order not found')
    key=data.idempotency_key
    existing=db.query(OrderIssue).filter_by(tenant_id=tenant_id,idempotency_key=key).first()
    if existing:
        return {'status':existing.status,'issue_id':existing.id,'order_status':o.status}
    if o.status not in {'PENDING_PAYMENT','CONFIRMED'}:
        raise AppError(409,'CUSTOMER_CANCEL_WINDOW_CLOSED','The order can no longer be cancelled automatically because the merchant may have started fulfillment')
    old=o.status
    # Payment is either voided before capture or refunded through the provider after capture.
    pi=db.query(PaymentIntent).filter_by(order_id=o.id,tenant_id=tenant_id).order_by(PaymentIntent.created_at.desc()).first()
    captured=int(db.query(func.coalesce(func.sum(PaymentCapture.amount_minor),0)).filter_by(payment_intent_id=pi.id,tenant_id=tenant_id).scalar() or 0) if pi else 0
    refunded=int(db.query(func.coalesce(func.sum(Refund.amount_minor),0)).filter_by(payment_intent_id=pi.id,tenant_id=tenant_id).scalar() or 0) if pi else 0
    if pi and captured > refunded:
        if not pi.provider_payment_id:
            raise AppError(409,'REFUND_UNAVAILABLE','Payment provider has not exposed a refundable payment reference yet')
        refund_amount=captured-refunded
        op_key='customer-cancel:'+key
        result=get_payment_provider(pi.provider, provider_credentials(tenant_id,pi.provider,db)).refund(pi.provider_payment_id, refund_amount, pi.currency, idempotency_key=op_key)
        if not result.provider_id:
            db.rollback()
            raise AppError(502, 'PROVIDER_REFUND_REFERENCE_MISSING',
                'Payment provider did not return a refund reference; reconciliation required')
        existing_refund = db.query(Refund).filter_by(tenant_id=tenant_id, provider_refund_id=result.provider_id).with_for_update().first()
        if existing_refund:
            if (existing_refund.payment_intent_id != pi.id or
                    existing_refund.order_id != o.id or
                    int(existing_refund.amount_minor) != int(refund_amount) or
                    str(existing_refund.currency).upper() != str(pi.currency).upper()):
                db.rollback()
                raise AppError(409, 'PROVIDER_REFUND_REFERENCE_REUSED',
                    'Provider refund reference is already bound to different refund data; reconciliation required')
        else:
            db.add(Refund(tenant_id=tenant_id,order_id=o.id,payment_intent_id=pi.id,amount_minor=refund_amount,currency=pi.currency,status='COMPLETED',provider_refund_id=result.provider_id))
        pi.status='REFUNDED'; o.payment_status='REFUNDED'
    elif pi and captured == 0 and pi.provider_payment_id and pi.status not in {'VOIDED','CANCELED'}:
        get_payment_provider(pi.provider, provider_credentials(tenant_id,pi.provider,db)).void(pi.provider_payment_id,idempotency_key='customer-cancel:'+key)
        pi.status='VOIDED'; o.payment_status='VOIDED'
    old_state=transition(o,'CANCELLED')
    db.add(OrderStatusHistory(tenant_id=tenant_id,order_id=o.id,from_state=old_state,to_state='CANCELLED',actor_id=None,reason='customer_requested'))
    issue=OrderIssue(tenant_id=tenant_id,order_id=o.id,customer_id=actor.customer_id,issue_type='CANCEL_REQUEST',status='RESOLVED',customer_message=data.reason,resolution='REFUND' if captured>refunded else 'CANCELLED',idempotency_key=key)
    db.add(issue)
    outbox(db,tenant_id,'order',o.id,'order.cancelled',{'order_id':o.id,'tenant_id':tenant_id,'customer_requested':True,'refund_status':'COMPLETED' if captured>refunded else 'NOT_REQUIRED'})
    if captured>refunded:
        outbox(db,tenant_id,'order',o.id,'refund.completed',{'order_id':o.id,'tenant_id':tenant_id,'amount_minor':captured-refunded,'reason':'customer_cancel'})
    audit(db,tenant_id,None,'customer.order.cancelled','Order',o.id,after={'from_status':old,'to_status':'CANCELLED','refund_amount_minor':captured-refunded if captured>refunded else 0})
    db.commit()
    return {'status':'REFUNDED' if captured>refunded else 'CANCELLED','issue_id':issue.id,'order_status':o.status,'refund_amount_minor':captured-refunded if captured>refunded else 0}

@router.post('/customer/orders/{order_id}/issues')
def customer_create_order_issue(order_id: str, tenant_id: str, data: OrderIssueCreateIn, request: Request, db: DBSession=Depends(get_db)):
    actor=customer_session_actor(request,db,tenant_id)
    if actor is None: raise AppError(401,'CUSTOMER_LOGIN_REQUIRED','Sign in before opening an order issue')
    order=db.query(Order).filter_by(id=order_id,tenant_id=tenant_id,customer_id=actor.customer_id).first()
    if not order: raise not_found('Order not found')
    existing=db.query(OrderIssue).filter_by(tenant_id=tenant_id,idempotency_key=data.idempotency_key).first()
    if existing: return json_model(existing)
    issue=OrderIssue(tenant_id=tenant_id,order_id=order.id,customer_id=actor.customer_id,issue_type=data.issue_type,status='OPEN',customer_message=data.message,idempotency_key=data.idempotency_key)
    db.add(issue); db.flush()
    audit(db,tenant_id,None,'customer.order.issue.opened','OrderIssue',issue.id,after={'order_id':order.id,'issue_type':data.issue_type})
    outbox(db,tenant_id,'order_issue',issue.id,'customer.order.issue.opened',{'order_id':order.id,'issue_id':issue.id,'issue_type':data.issue_type})
    db.commit(); return json_model(issue)

@router.get('/merchant/order-issues')
def merchant_order_issues(tenant_id: str, status: str | None=None, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('orders.manage'))):
    tenant_scope(tenant_id,user,db)
    q=db.query(OrderIssue).filter_by(tenant_id=tenant_id)
    if status: q=q.filter(OrderIssue.status==status)
    return {'items':[json_model(x) for x in q.order_by(OrderIssue.created_at.desc()).limit(200).all()]}

@router.patch('/merchant/order-issues/{issue_id}')
def merchant_update_order_issue(issue_id: str, tenant_id: str, data: OrderIssueUpdateIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('orders.manage'))):
    tenant_scope(tenant_id,user,db)
    issue=db.query(OrderIssue).filter_by(id=issue_id,tenant_id=tenant_id).with_for_update().first()
    if not issue: raise not_found('Order issue not found')
    if data.message:
        db.add(OrderIssueMessage(tenant_id=tenant_id, issue_id=issue.id, author_type='MERCHANT', author_id=user.id, message=data.message))
        issue.merchant_message=data.message
    if data.action=='ACKNOWLEDGE':
        issue.status='IN_REVIEW'; issue.resolution=None
    elif data.action=='RESOLVE_REFUND':
        # Refund is a financially sensitive capability and must retain its
        # dedicated permission even when invoked through issue resolution.
        # This is an internal route-to-route call, so dependency injection is
        # not enough; explicitly enforce the permission here.
        assert_permission(tenant_id, user, db, 'orders.refund')
        order=db.query(Order).filter_by(id=issue.order_id,tenant_id=tenant_id).first()
        if not order: raise not_found('Order not found')
        pi=db.query(PaymentIntent).filter_by(order_id=order.id,tenant_id=tenant_id).order_by(PaymentIntent.created_at.desc()).first()
        if not pi: raise AppError(409,'REFUND_PAYMENT_NOT_FOUND','No payment exists for this order')
        captured=int(db.query(func.coalesce(func.sum(PaymentCapture.amount_minor),0)).filter_by(payment_intent_id=pi.id,tenant_id=tenant_id).scalar() or 0)
        refunded=int(db.query(func.coalesce(func.sum(Refund.amount_minor),0)).filter_by(payment_intent_id=pi.id,tenant_id=tenant_id).scalar() or 0)
        remaining=max(0,captured-refunded)
        if remaining <= 0:
            raise AppError(409,'REFUND_NOT_AVAILABLE','There is no refundable balance remaining')
        # Reuse canonical refund flow; the issue id is the stable idempotency key.
        from app.routes.payment_routes import refund  # local import avoids a circular import at module load time
        refund_result=refund(tenant_id=tenant_id, data=RefundIn(order_id=order.id,payment_intent_id=pi.id,amount_minor=remaining,currency=pi.currency), user=user, db=db, _=None, idempotency_key='issue-refund:'+issue.id)
        issue.status='RESOLVED'; issue.resolution='REFUND'
        outbox(db,tenant_id,'order_issue',issue.id,'order.issue.refunded',{'issue_id':issue.id,'order_id':issue.order_id,'amount_minor':remaining,'refund':refund_result})
    elif data.action=='RESOLVE_REPLACEMENT':
        issue.status='RESOLVED'; issue.resolution='REPLACEMENT'
    elif data.action=='RESOLVE_REJECT':
        issue.status='RESOLVED'; issue.resolution='REJECTED'
    elif data.action=='ESCALATE':
        issue.status='ESCALATED'; issue.resolution=None
    issue.updated_at=datetime.now(timezone.utc)
    audit(db,tenant_id,user.id,'merchant.order.issue.updated','OrderIssue',issue.id,after={'action':data.action,'resolution':issue.resolution,'status':issue.status})
    outbox(db,tenant_id,'order_issue',issue.id,'merchant.order.issue.updated',{'issue_id':issue.id,'order_id':issue.order_id,'status':issue.status,'resolution':issue.resolution})
    db.commit(); return json_model(issue)


def _order_issue_message_view(msg):
    return {'id': msg.id, 'issue_id': msg.issue_id, 'author_type': msg.author_type, 'message': msg.message, 'created_at': msg.created_at}

@router.get('/customer/orders/{order_id}/issues')
def customer_list_order_issues(order_id: str, tenant_id: str, request: Request, db: DBSession=Depends(get_db)):
    actor=customer_session_actor(request,db,tenant_id)
    if actor is None: raise AppError(401,'CUSTOMER_LOGIN_REQUIRED','Sign in before viewing order issues')
    order=db.query(Order).filter_by(id=order_id,tenant_id=tenant_id,customer_id=actor.customer_id).first()
    if not order: raise not_found('Order not found')
    rows=db.query(OrderIssue).filter_by(order_id=order.id,tenant_id=tenant_id,customer_id=actor.customer_id).order_by(OrderIssue.created_at.desc()).all()
    return {'items':[json_model(x) for x in rows]}

@router.get('/customer/order-issues/{issue_id}/messages')
def customer_order_issue_messages(issue_id: str, tenant_id: str, request: Request, db: DBSession=Depends(get_db)):
    actor=customer_session_actor(request,db,tenant_id)
    if actor is None: raise AppError(401,'CUSTOMER_LOGIN_REQUIRED','Sign in before reading the conversation')
    issue=db.query(OrderIssue).filter_by(id=issue_id,tenant_id=tenant_id,customer_id=actor.customer_id).first()
    if not issue: raise not_found('Order issue not found')
    rows=db.query(OrderIssueMessage).filter_by(issue_id=issue.id,tenant_id=tenant_id).order_by(OrderIssueMessage.created_at.asc()).all()
    return {'items':[_order_issue_message_view(x) for x in rows]}

@router.post('/customer/order-issues/{issue_id}/messages')
def customer_order_issue_message(issue_id: str, tenant_id: str, data: OrderIssueMessageIn, request: Request, db: DBSession=Depends(get_db)):
    actor=customer_session_actor(request,db,tenant_id)
    if actor is None: raise AppError(401,'CUSTOMER_LOGIN_REQUIRED','Sign in before replying to an order issue')
    issue=db.query(OrderIssue).filter_by(id=issue_id,tenant_id=tenant_id,customer_id=actor.customer_id).first()
    if not issue: raise not_found('Order issue not found')
    if issue.status in {'RESOLVED','CLOSED'}: raise AppError(409,'ISSUE_CLOSED','This issue is already resolved')
    if db.query(OrderIssueMessage).filter_by(tenant_id=tenant_id, issue_id=issue.id, author_type='CUSTOMER', author_id=actor.customer_id).filter(OrderIssueMessage.message==data.message).first():
        return {'status':'DUPLICATE'}
    msg=OrderIssueMessage(tenant_id=tenant_id,issue_id=issue.id,author_type='CUSTOMER',author_id=actor.customer_id,message=data.message)
    db.add(msg); issue.updated_at=datetime.now(timezone.utc); issue.status='OPEN' if issue.status=='ESCALATED' else issue.status
    audit(db,tenant_id,None,'customer.order.issue.message.sent','OrderIssue',issue.id,after={'author_type':'CUSTOMER'})
    outbox(db,tenant_id,'order_issue',issue.id,'customer.order.issue.message.sent',{'issue_id':issue.id,'order_id':issue.order_id})
    db.commit(); return _order_issue_message_view(msg)

@router.get('/merchant/order-issues/{issue_id}/messages')
def merchant_order_issue_messages(issue_id: str, tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('orders.manage'))):
    tenant_scope(tenant_id,user,db)
    issue=db.query(OrderIssue).filter_by(id=issue_id,tenant_id=tenant_id).first()
    if not issue: raise not_found('Order issue not found')
    rows=db.query(OrderIssueMessage).filter_by(issue_id=issue.id,tenant_id=tenant_id).order_by(OrderIssueMessage.created_at.asc()).all()
    return {'items':[_order_issue_message_view(x) for x in rows]}

@router.post('/merchant/order-issues/{issue_id}/messages')
def merchant_order_issue_message(issue_id: str, tenant_id: str, data: OrderIssueMessageIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('orders.manage'))):
    tenant_scope(tenant_id,user,db)
    issue=db.query(OrderIssue).filter_by(id=issue_id,tenant_id=tenant_id).first()
    if not issue: raise not_found('Order issue not found')
    if issue.status in {'RESOLVED','CLOSED'}: raise AppError(409,'ISSUE_CLOSED','This issue is already resolved')
    msg=OrderIssueMessage(tenant_id=tenant_id,issue_id=issue.id,author_type='MERCHANT',author_id=user.id,message=data.message)
    db.add(msg); issue.merchant_message=data.message; issue.updated_at=datetime.now(timezone.utc); issue.status='IN_REVIEW' if issue.status=='OPEN' else issue.status
    audit(db,tenant_id,user.id,'merchant.order.issue.message.sent','OrderIssue',issue.id,after={'author_type':'MERCHANT'})
    outbox(db,tenant_id,'order_issue',issue.id,'merchant.order.issue.message.sent',{'issue_id':issue.id,'order_id':issue.order_id})
    db.commit(); return _order_issue_message_view(msg)
