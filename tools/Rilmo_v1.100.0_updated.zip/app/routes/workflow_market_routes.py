"""Automation workflow routes (list/create/run) and market configuration
routes (list/create).

Extracted out of app/routes/v1.py (Phase 3, step 9). idem_start is a shared
idempotency-record helper used by many other route groups still in v1.py, so
it stays defined there and is imported here.
"""
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import outbox, finalize_idem, audit
from app.routes.v1 import tenant_scope, idem_start

router = APIRouter(prefix='/v1')


@router.get('/workflows')
def list_workflows(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    return {'items': [json_model(x) for x in db.query(WorkflowDefinition).filter_by(tenant_id=tenant_id).order_by(WorkflowDefinition.created_at.desc()).all()]}

@router.post('/workflows')
def create_workflow(tenant_id: str, data: WorkflowDefinitionIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    if db.query(WorkflowDefinition).filter_by(tenant_id=tenant_id, slug=data.slug).first():
        raise AppError(409, 'WORKFLOW_EXISTS', 'Workflow slug already exists')
    for step in data.steps:
        if not isinstance(step, dict) or step.get('type') not in {'SEND_EMAIL', 'CREATE_COUPON',
            'WEBHOOK', 'ADD_LOYALTY_POINTS', 'TAG_CUSTOMER'}:
            raise AppError(400, 'WORKFLOW_STEP_UNSUPPORTED', 'Unsupported workflow step')
    w = WorkflowDefinition(tenant_id=tenant_id, slug=data.slug, name=data.name,
        trigger_event=data.trigger_event, enabled=data.enabled, steps=data.steps, version=1)
    db.add(w)
    db.flush()
    outbox(db, tenant_id, 'workflow', w.id, 'workflow.created', {'workflow_id': w.id,
        'tenant_id': tenant_id})
    db.commit()
    return json_model(w)

@router.post('/workflows/{workflow_id}/run')
def run_workflow(workflow_id: str, tenant_id: str, data: WorkflowRunIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    w = db.query(WorkflowDefinition).filter_by(id=workflow_id, tenant_id=tenant_id,
        enabled=True).first()
    if not w:
        raise not_found('Enabled workflow not found')

    payload = {'workflow_id': workflow_id, 'input_payload': data.input_payload}
    idem_rec = idem_start(db, tenant_id, user.id, f'POST /v1/workflows/{workflow_id}/run',
        idempotency_key, payload)
    if idem_rec and idem_rec.status == 'COMPLETED':
        return idem_rec.response_body

    run = WorkflowRun(tenant_id=tenant_id, workflow_id=w.id, trigger_event=w.trigger_event,
        status='QUEUED', input_payload=data.input_payload, output_payload={})
    db.add(run)
    db.flush()
    outbox(db, tenant_id, 'workflow_run', run.id, 'workflow.run.queued',
        {'workflow_run_id': run.id, 'workflow_id': w.id, 'tenant_id': tenant_id},
        dedupe_key=(f'workflow.manual.run.queued:{tenant_id}:{workflow_id}:{idempotency_key}'
                    if idempotency_key else f'workflow.manual.run.queued:{run.id}'))
    body = json_model(run)
    finalize_idem(idem_rec, body, 200)
    db.commit()
    return body

@router.get('/markets')
def list_markets(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    return {'items': [json_model(x) for x in db.query(Market).filter_by(tenant_id=tenant_id).order_by(Market.code.asc()).all()]}

@router.post('/markets')
def create_market(tenant_id: str, data: MarketIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    code = data.code.strip().upper()
    currency = data.currency.strip().upper()
    country = data.country_code.strip().upper()
    locale = data.locale.strip()
    if len(country) != 2 or len(currency) != 3:
        raise AppError(400, 'MARKET_CODE_INVALID', 'country_code/currency must be ISO-style codes')
    if db.query(Market).filter_by(tenant_id=tenant_id, code=code).first():
        raise AppError(409, 'MARKET_EXISTS', 'Market already exists')
    if data.is_default:
        db.query(Market).filter_by(tenant_id=tenant_id,
            is_default=True).update({'is_default': False})
    m = Market(tenant_id=tenant_id, code=code, name=data.name.strip(), country_code=country,
        currency=currency, locale=locale, is_default=data.is_default)
    db.add(m)
    db.flush()
    audit(db, tenant_id, user.id, 'market.create', 'market', m.id, after={'code': code})
    outbox(db, tenant_id, 'market', m.id, 'market.created', {'market_id': m.id,
        'tenant_id': tenant_id, 'code': code})
    db.commit()
    return json_model(m)

@router.post('/markets/{market_id}/prices')
def set_market_price(market_id: str, tenant_id: str, data: MarketPriceIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    m = db.query(Market).filter_by(id=market_id, tenant_id=tenant_id, status='ACTIVE').first()
    if not m:
        raise not_found('Market not found')
    if data.currency.upper() != m.currency:
        raise AppError(409, 'MARKET_CURRENCY_MISMATCH', 'Price currency must match market currency')
    variant = db.query(ProductVariant).filter_by(id=data.variant_id, tenant_id=tenant_id).first()
    if not variant:
        raise not_found('Variant not found')
    existing = db.query(MarketPrice).filter_by(tenant_id=tenant_id, variant_id=variant.id,
        market=m.code, currency=m.currency).first()
    if existing:
        existing.amount_minor = data.amount_minor
        existing.valid_from = datetime.now(timezone.utc)
    else:
        db.add(MarketPrice(tenant_id=tenant_id, variant_id=variant.id, market=m.code,
         currency=m.currency,
            amount_minor=data.amount_minor, valid_from=datetime.now(timezone.utc)))
    db.commit()
    return {'ok': True, 'market': m.code, 'variant_id': variant.id,
        'amount_minor': data.amount_minor, 'currency': m.currency}
