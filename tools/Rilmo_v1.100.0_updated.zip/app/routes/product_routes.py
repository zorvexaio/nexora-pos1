"""Core product routes: list/create/get/patch/delete product, add variant.

Extracted out of app/routes/v1.py (Phase 3, step 2). Note: product-related
endpoints are NOT all contiguous in v1.py — variant patch/delete, discounts,
and translations live ~2,500 lines further down, interleaved with unrelated
domains (orders, carts, etc). Moving those safely requires tracing their own
shared-helper usage first, so this step only moves the contiguous, clearly
self-contained block. The rest is a follow-up step, not done here.

tenant_scope and require_if_match are still defined in v1.py (used by many
other route groups there), so they're imported rather than duplicated.
"""
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import audit, outbox, finalize_idem, body_hash, get_entitlement
from app.routes.v1 import tenant_scope, require_if_match

router = APIRouter(prefix='/v1')


@router.get('/products')
def list_products(tenant_id: str, q: str='', limit: int=50, offset: int=0,
    user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    limit = max(1, min(limit, 100))
    offset = max(0, offset)
    query = db.query(Product).filter_by(tenant_id=tenant_id, deleted_at=None)
    term = q.strip()[:120]
    if term:
        like = f'%{term}%'
        query = query.filter(Product.title.ilike(like) | Product.slug.ilike(like) | Product.description.ilike(like))
    total = query.count()
    rows = query.order_by(Product.created_at.desc()).offset(offset).limit(limit).all()
    items = []
    for p in rows:
        item = json_model(p)
        item['variants'] = [json_model(v) for v in db.query(ProductVariant).filter_by(tenant_id=tenant_id,
            product_id=p.id).all()]
        items.append(item)
    return {'items': items, 'total': total, 'limit': limit, 'offset': offset}

@router.post('/products')
def create_product(tenant_id: str, data: ProductIn, user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('products.write')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    if idempotency_key:
        payload = data.model_dump() if hasattr(data, 'model_dump') else data.__dict__
        rec = db.query(PlatformIdempotencyKey).filter_by(actor_id=user.id,
            endpoint='POST /v1/products', key=idempotency_key).first()
        ph = body_hash(payload)
        if rec and rec.request_hash != ph:
            raise AppError(409, 'IDEMPOTENCY_MISMATCH',
                'Same idempotency key used with a different request')
        if rec and rec.status == 'COMPLETED':
            return rec.response_body
        if not rec:
            rec = PlatformIdempotencyKey(actor_id=user.id, endpoint='POST /v1/products',
             key=idempotency_key,
             request_hash=ph,
                status='IN_PROGRESS', expires_at=datetime.now(timezone.utc) + timedelta(days=2))
            db.add(rec)
            db.flush()
    limit=get_entitlement(db, tenant_id, 'max_products')
    if limit and limit.value_type=='integer' and int(limit.value_integer or 0) != -1:
        active_count=db.query(Product).filter(Product.tenant_id==tenant_id, Product.deleted_at.is_(None)).count()
        if active_count >= int(limit.value_integer or 0):
            raise AppError(402,'PLAN_LIMIT_REACHED','Product limit for the current SaaS plan has been reached')
    sf = db.query(Storefront).filter_by(tenant_id=tenant_id).first()
    p = Product(tenant_id=tenant_id, storefront_id=sf.id if sf else None, slug=data.slug,
     title=data.title,
        description=data.description, status=data.status, product_type=data.product_type)
    db.add(p)
    db.flush()
    audit(db, tenant_id, user.id, 'product.create', 'product', p.id, after=json_model(p))
    outbox(db, tenant_id, 'product', p.id, 'product.created', {'product_id': p.id,
        'tenant_id': tenant_id})
    result = json_model(p)
    if idempotency_key:
        finalize_idem(rec, result, 201)
    db.commit()
    return result

@router.get('/products/{product_id}')
def get_product(product_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    p = db.query(Product).filter_by(id=product_id, tenant_id=tenant_id, deleted_at=None).first()
    return json_model(p) if p else not_found('Product not found')

@router.patch('/products/{product_id}')
def patch_product(product_id: str, tenant_id: str, data: dict,
 if_match: str | None=Header(default=None,
 alias='If-Match'),
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    p = db.query(Product).filter_by(id=product_id, tenant_id=tenant_id, deleted_at=None).first()
    if not p:
        raise not_found('Product not found')
    require_if_match(p, if_match)
    for k in ['title', 'description', 'status', 'slug']:
        if k in data:
            setattr(p, k, data[k])
    if 'storefront_id' in data:
        sf = db.query(Storefront).filter_by(id=data['storefront_id'],
            tenant_id=tenant_id).first() if data['storefront_id'] else None
        if data['storefront_id'] and (not sf):
            raise AppError(400, 'STOREFRONT_INVALID',
                'Storefront belongs to another tenant or does not exist')
        p.storefront_id = sf.id if sf else None
    outbox(db, tenant_id, 'product', p.id, 'product.updated', {'product_id': p.id,
        'tenant_id': tenant_id})
    db.commit()
    return json_model(p)

@router.delete('/products/{product_id}')
def delete_product(product_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    p = db.query(Product).filter_by(id=product_id, tenant_id=tenant_id, deleted_at=None).first()
    if not p:
        raise not_found('Product not found')
    p.deleted_at = datetime.now(timezone.utc)
    outbox(db, tenant_id, 'product', p.id, 'product.deleted', {'product_id': p.id,
        'tenant_id': tenant_id})
    db.commit()
    return {'ok': True}

@router.post('/products/{product_id}/variants')
def add_variant(product_id: str, tenant_id: str, data: VariantIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    p = db.query(Product).filter_by(id=product_id, tenant_id=tenant_id).first()
    if not p:
        raise not_found('Product not found')
    v = ProductVariant(tenant_id=tenant_id, product_id=product_id, sku=data.sku,
        price_amount_minor=data.price_amount_minor, currency=data.currency.upper(), status=data.status)
    db.add(v)
    db.flush()
    outbox(db, tenant_id, 'variant', v.id, 'variant.created', {'variant_id': v.id,
        'product_id': product_id, 'tenant_id': tenant_id})
    loc = db.query(InventoryLocation).filter_by(tenant_id=tenant_id, name='Main').first()
    if not loc:
        loc = InventoryLocation(tenant_id=tenant_id, name='Main', status='ACTIVE')
        db.add(loc)
        db.flush()
    db.add(InventoryItem(tenant_id=tenant_id, variant_id=v.id, location_id=loc.id, on_hand=0,
        reserved=0, committed=0, available=0, version=1))
    db.commit()
    return json_model(v)

@router.patch('/products/{product_id}/variants/{variant_id}')
def patch_variant(product_id: str, variant_id: str, tenant_id: str, data: dict,
 if_match: str | None=Header(default=None,
 alias='If-Match'),
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    v = db.query(ProductVariant).filter_by(id=variant_id, product_id=product_id,
        tenant_id=tenant_id).first()
    if not v:
        raise not_found('Variant not found')
    require_if_match(v, if_match)
    for k in ('sku', 'status'):
        if k in data:
            setattr(v, k, data[k])
    if 'price_amount_minor' in data:
        v.price_amount_minor = max(0, int(data['price_amount_minor']))
    if 'currency' in data:
        v.currency = str(data['currency']).upper()
    v.status = v.status if v.status in {'DRAFT', 'ACTIVE', 'INACTIVE'} else 'ACTIVE'
    outbox(db, tenant_id, 'variant', v.id, 'variant.updated', {'variant_id': v.id,
        'product_id': product_id, 'tenant_id': tenant_id})
    db.commit()
    return json_model(v)

@router.delete('/products/{product_id}/variants/{variant_id}')
def delete_variant(product_id: str, variant_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    v = db.query(ProductVariant).filter_by(id=variant_id, product_id=product_id,
        tenant_id=tenant_id).first()
    if not v:
        raise not_found('Variant not found')
    v.status = 'INACTIVE'
    db.commit()
    return {'ok': True}

@router.post('/products/{product_id}/discount')
def set_product_discount(product_id: str, tenant_id: str, data: dict, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id,user,db); product=db.query(Product).filter_by(id=product_id,tenant_id=tenant_id,deleted_at=None).first()
    if not product: raise not_found('Product not found')
    bps=int(data.get('percentage_bps',0)); variant_id=data.get('variant_id')
    if bps<0 or bps>10000: raise AppError(400,'DISCOUNT_INVALID','Discount percentage must be 0..10000 bps')
    variants=db.query(ProductVariant).filter_by(tenant_id=tenant_id,product_id=product_id).all(); variants=[v for v in variants if not variant_id or v.id==variant_id]
    if not variants: raise not_found('Variant not found')
    for v in variants:
        row=db.query(ProductDiscount).filter_by(tenant_id=tenant_id,variant_id=v.id).first()
        if not row: row=ProductDiscount(tenant_id=tenant_id,variant_id=v.id,percentage_bps=bps); db.add(row)
        row.percentage_bps=bps; row.status='ACTIVE' if bps else 'INACTIVE'; row.starts_at=data.get('starts_at'); row.ends_at=data.get('ends_at')
    db.commit(); return {'product_id':product_id,'variant_ids':[v.id for v in variants],'percentage_bps':bps}

@router.get('/products/{product_id}/translations')
def list_product_translations(product_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    p = db.query(Product).filter_by(id=product_id, tenant_id=tenant_id).first()
    if not p:
        raise not_found('Product not found')
    rows = db.query(ProductTranslation).filter_by(product_id=p.id,
        tenant_id=tenant_id).order_by(ProductTranslation.locale.asc()).all()
    return {'items': [json_model(x) for x in rows]}

@router.put('/products/{product_id}/translations/{locale}')
def upsert_product_translation(product_id: str, locale: str, data: dict, tenant_id: str,
 user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('products.write')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    locale = locale.strip().lower().replace('_', '-')
    if len(locale) < 2 or len(locale) > 20 or (not all((part.isalpha() or part.isdigit() or part == '-' for part in locale.split('-')))):
        raise AppError(400, 'LOCALE_INVALID', 'Invalid locale')
    p = db.query(Product).filter_by(id=product_id, tenant_id=tenant_id).first()
    if not p:
        raise not_found('Product not found')
    row = db.query(ProductTranslation).filter_by(product_id=p.id, tenant_id=tenant_id,
        locale=locale).first()
    if not row:
        existing_locales = {r.locale for r in db.query(ProductTranslation).filter_by(tenant_id=tenant_id, product_id=p.id).all()}
        if locale not in existing_locales:
            limit = get_entitlement(db, tenant_id, 'max_languages')
            if not limit:
                raise AppError(402, 'PLAN_FEATURE_REQUIRED', 'Your plan does not include multilingual products')
            max_languages = int(limit.value_integer or 0)
            if max_languages != -1 and len(existing_locales) >= max_languages:
                raise AppError(402, 'PLAN_LIMIT_REACHED', 'Your plan language limit has been reached')
    if not row:
        row = ProductTranslation(tenant_id=tenant_id, product_id=p.id, locale=locale,
         name=str(data.get('name') or p.title),
         description=data.get('description'),
            seo_title=data.get('seo_title'), seo_description=data.get('seo_description'))
        db.add(row)
    else:
        for k in ('name', 'description', 'seo_title', 'seo_description'):
            if k in data:
                setattr(row, k, data[k])
    db.commit()
    return json_model(row)

@router.delete('/products/{product_id}/translations/{locale}')
def delete_product_translation(product_id: str, locale: str, tenant_id: str,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    row = db.query(ProductTranslation).filter_by(product_id=product_id, tenant_id=tenant_id,
        locale=locale.lower()).first()
    if not row:
        raise not_found('Translation not found')
    db.delete(row)
    db.commit()
    return {'ok': True}
