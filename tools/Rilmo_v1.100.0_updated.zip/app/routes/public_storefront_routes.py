"""Public (unauthenticated) storefront customer-facing API: full catalog for
a hostname, product media proxy, single product detail (with reviews +
recommendations), public shipping-methods, public payment-methods, hybrid
product search. This is exactly what storefront.js on the frontend calls.

Extracted out of app/routes/v1.py (Phase 3, step 33). _shipping_public_view
is used by several route groups still in v1.py (checkout, cart), so it stays
there and is imported here.
"""
import urllib.parse
from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func
from app.core.database import get_db
from app.core.auth import current_user, optional_user
from app.core.errors import AppError, not_found, forbidden
from app.core.security import token_hash
from app.core.config import get_settings
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import resolve_variant_price_details, enforce_rate_limit
from app.routes.v1 import _shipping_public_view, _ensure_trust_score, _tenant_membership_or_403

router = APIRouter(prefix='/v1')


def _resolve_storefront(db, hostname):
    return db.query(Domain, Storefront, Tenant).join(Storefront,
     Storefront.id == Domain.storefront_id).join(Tenant,
        Tenant.id == Domain.tenant_id).filter(func.lower(Domain.hostname) == hostname.lower(), Domain.verified_at.is_not(None)).first()

@router.get('/public/storefront/{hostname}')
def public_storefront(hostname: str, locale: str | None=None, db: DBSession=Depends(get_db)):
    srow = _resolve_storefront(db, hostname)
    if not srow:
        raise not_found('Storefront not found')
    d, s, t = srow
    if t.status == 'SUSPENDED' or s.status == 'SUSPENDED':
        raise AppError(503, 'STORE_SUSPENDED', 'Storefront unavailable')
    if t.status != 'ACTIVE' or s.status != 'PUBLISHED':
        raise not_found('Storefront not found')
    products = db.query(Product).filter(Product.tenant_id == t.id, Product.deleted_at.is_(None),
        Product.status == 'ACTIVE').all()
    locale = (locale or s.default_locale).lower()
    payload = []
    for p in products:
        body = json_model(p)
        tr = db.query(ProductTranslation).filter_by(product_id=p.id, tenant_id=t.id,
            locale=locale).first()
        if tr:
            body['title'] = tr.name
            body['description'] = tr.description
            body['locale'] = locale
        variants = db.query(ProductVariant).filter_by(product_id=p.id, tenant_id=t.id,
            status='ACTIVE').all()
        rendered=[]
        for v in variants:
            vb=json_model(v)
            pricing=resolve_variant_price_details(db,t.id,v)
            vb['list_price_minor']=pricing['list_price_minor']
            vb['discount_minor']=pricing['discount_minor']
            vb['sale_price_minor']=pricing['selling_price_minor']
            vb['discount_bps']=pricing['discount_bps']
            rendered.append(vb)
        body['variants'] = rendered
        media_rows = db.query(ProductMedia, MediaAsset).join(MediaAsset, MediaAsset.id == ProductMedia.media_asset_id).filter(ProductMedia.tenant_id == t.id, ProductMedia.product_id == p.id, MediaAsset.status == 'READY').order_by(ProductMedia.position.asc()).limit(6).all()
        body['media'] = [{'id': asset.id, 'url': f'/v1/public/storefront/{urllib.parse.quote(hostname, safe="")}/media/{asset.id}', 'alt': link.alt_text or asset.alt_text, 'mime_type': asset.mime_type} for link, asset in media_rows]
        payload.append(body)
    shipping_rows = db.query(ShippingMethod).filter_by(tenant_id=t.id, is_active=True, currency=s.default_currency).order_by(ShippingMethod.amount_minor.asc(), ShippingMethod.name.asc()).all()
    return {'tenant': {'id': t.id, 'name': t.name, 'locale': s.default_locale,
     'currency': s.default_currency},
        'storefront': {'id': s.id, 'slug': s.slug, 'status': s.status},
        'shipping_options': [_shipping_public_view(x, 0) for x in shipping_rows],
        'products': payload}

@router.get('/public/storefront/{hostname}/media/{media_id}')
def public_media(hostname: str, media_id: str, db: DBSession=Depends(get_db)):
    srow = _resolve_storefront(db, hostname)
    if not srow:
        raise not_found('Storefront not found')
    d, s, t = srow
    link = db.query(ProductMedia).filter_by(tenant_id=t.id, media_asset_id=media_id).first()
    if not link:
        raise not_found('Media not found')
    p = db.query(Product).filter_by(id=link.product_id, tenant_id=t.id, storefront_id=s.id, status='ACTIVE', deleted_at=None).first()
    asset = db.query(MediaAsset).filter_by(id=media_id, tenant_id=t.id, status='READY').first()
    if not p or not asset:
        raise not_found('Media not found')
    variant = db.query(MediaVariant).filter_by(tenant_id=t.id, media_asset_id=media_id, variant='large').first() or db.query(MediaVariant).filter_by(tenant_id=t.id, media_asset_id=media_id, variant='original').first()
    key = variant.storage_key if variant else asset.storage_key
    from app.services.storage import get_object_store
    try:
        body = get_object_store().get(key)
    except Exception as exc:
        raise AppError(404, 'MEDIA_UNAVAILABLE', 'Media is unavailable') from exc
    return Response(content=body, media_type=(variant.mime_type if variant else asset.mime_type), headers={'Cache-Control':'public, max-age=86400, immutable'})

@router.get('/public/products/{product_id}')
def public_product(product_id: str, hostname: str, locale: str | None=None,
    db: DBSession=Depends(get_db)):
    srow = _resolve_storefront(db, hostname)
    if not srow:
        raise not_found('Storefront not found')
    d, s, t = srow
    if t.status != 'ACTIVE' or s.status != 'PUBLISHED':
        raise not_found('Storefront not found')
    p = db.query(Product).filter_by(id=product_id, tenant_id=t.id, storefront_id=s.id,
        deleted_at=None, status='ACTIVE').first()
    if not p:
        raise not_found('Product not found')
    variants = db.query(ProductVariant).filter_by(product_id=p.id, tenant_id=t.id,
        status='ACTIVE').all()
    locale = (locale or s.default_locale).lower()
    translation = db.query(ProductTranslation).filter_by(product_id=p.id, tenant_id=t.id,
        locale=locale).first()
    product_body = json_model(p)
    if translation:
        product_body['title'] = translation.name
        product_body['description'] = translation.description
        product_body['locale'] = locale
    rendered=[]
    for v in variants:
        vb=json_model(v)
        pricing=resolve_variant_price_details(db,t.id,v)
        vb['list_price_minor']=pricing['list_price_minor']
        vb['discount_minor']=pricing['discount_minor']
        vb['sale_price_minor']=pricing['selling_price_minor']
        vb['discount_bps']=pricing['discount_bps']
        rendered.append(vb)
    reviews = db.query(Review).filter_by(tenant_id=t.id, product_id=p.id, status='APPROVED').all()
    avg_rating = round(sum(int(x.rating) for x in reviews) / len(reviews), 2) if reviews else None
    recommendations = []
    try:
        from app.services.advanced import hybrid_search
        candidates = hybrid_search(t.id, db, p.title, locale, 8)
        recommendations = [json_model(x) for x in candidates if x.id != p.id][:6]
    except Exception:
        recommendations = []
    media_rows = db.query(ProductMedia, MediaAsset).join(MediaAsset, MediaAsset.id == ProductMedia.media_asset_id).filter(ProductMedia.tenant_id == t.id, ProductMedia.product_id == p.id, MediaAsset.status == 'READY').order_by(ProductMedia.position.asc()).all()
    media = [{'id': asset.id, 'url': f'/v1/public/storefront/{urllib.parse.quote(hostname, safe="")}/media/{asset.id}', 'alt': link.alt_text or asset.alt_text, 'mime_type': asset.mime_type} for link, asset in media_rows]
    return {'product': product_body, 'variants': rendered, 'media': media, 'reviews': {'count': len(reviews), 'average': avg_rating, 'items': [json_model(x) for x in reviews[:10]]}, 'recommendations': recommendations}

@router.get('/public/storefront/{hostname}/shipping-methods')
def public_shipping_methods(hostname: str, currency: str | None = None, subtotal_minor: int = 0, db: DBSession=Depends(get_db)):
    srow = _resolve_storefront(db, hostname)
    if not srow:
        raise not_found('Storefront not found')
    d, storefront, tenant = srow
    if tenant.status != 'ACTIVE' or storefront.status != 'PUBLISHED':
        raise not_found('Storefront not found')
    cur = (currency or storefront.default_currency or tenant.default_currency).upper()
    rows = db.query(ShippingMethod).filter_by(tenant_id=tenant.id, is_active=True, currency=cur).order_by(ShippingMethod.amount_minor.asc(), ShippingMethod.name.asc()).all()
    return {'currency': cur, 'items': [_shipping_public_view(x, subtotal_minor) for x in rows]}

@router.get('/public/storefront/{hostname}/payment-methods')
def public_payment_methods(hostname: str, db: DBSession=Depends(get_db)):
    srow = _resolve_storefront(db, hostname)
    if not srow:
        raise not_found('Storefront not found')
    d, s, t = srow
    if t.status != 'ACTIVE' or s.status != 'PUBLISHED':
        raise not_found('Storefront not found')
    accounts = db.query(MerchantPaymentAccount).filter_by(tenant_id=t.id, status='ACTIVE', charges_enabled=True).all()
    methods = [x.provider for x in accounts if x.provider in {'iyzico','paytr'}]
    return {'methods': methods}

@router.get('/public/storefront/{hostname}/search')
def public_search(hostname: str, q: str='', locale: str | None=None, db: DBSession=Depends(get_db)):
    srow = _resolve_storefront(db, hostname)
    if not srow:
        raise not_found('Storefront not found')
    d, s, t = srow
    if t.status != 'ACTIVE' or s.status != 'PUBLISHED':
        raise not_found('Storefront not found')
    locale = (locale or s.default_locale).lower()
    term = q.strip()[:120]
    if not term:
        return {'query': '', 'locale': locale, 'mode': 'hybrid-intent-aware', 'results': []}
    from app.services.advanced import hybrid_search
    rows = hybrid_search(t.id, db, term, locale, 50)
    results = []
    for p in rows:
        body = json_model(p)
        tr = db.query(ProductTranslation).filter_by(product_id=p.id, tenant_id=t.id, locale=locale).first()
        if tr:
            body['title'] = tr.name; body['description'] = tr.description; body['locale'] = locale
        variants = db.query(ProductVariant).filter_by(product_id=p.id, tenant_id=t.id, status='ACTIVE').limit(1).all()
        body['variants'] = [json_model(v) for v in variants]
        results.append(body)
    return {'query': term, 'locale': locale, 'mode': 'hybrid-intent-aware', 'results': results}

@router.get('/public/storefront/{hostname}/trust')
def public_store_trust(hostname: str, db: DBSession=Depends(get_db)):
    srow=db.query(Domain,Storefront,Tenant).join(Storefront,Storefront.id==Domain.storefront_id).join(Tenant,Tenant.id==Domain.tenant_id).filter(func.lower(Domain.hostname)==hostname.lower(),Domain.verified_at.is_not(None)).first()
    if not srow: raise not_found('Storefront not found')
    d,s,t=srow
    if t.status!='ACTIVE' or s.status!='PUBLISHED': raise not_found('Storefront not found')
    score=_ensure_trust_score(db,t.id)
    reviews=db.query(TenantReview).filter_by(tenant_id=t.id,status='APPROVED').order_by(TenantReview.created_at.desc()).limit(12).all()
    db.commit()
    return {'store':{'name':t.name,'hostname':d.hostname},'trust':json_model(score),'reviews':[json_model(x) for x in reviews]}

@router.post('/public/storefront/{hostname}/reports')
def public_store_report(hostname: str, data: StoreReportIn, request: Request, db: DBSession=Depends(get_db), user=Depends(optional_user)):
    srow=db.query(Domain,Storefront,Tenant).join(Storefront,Storefront.id==Domain.storefront_id).join(Tenant,Tenant.id==Domain.tenant_id).filter(func.lower(Domain.hostname)==hostname.lower(),Domain.verified_at.is_not(None)).first()
    if not srow: raise not_found('Storefront not found')
    _d,_s,t=srow
    enforce_rate_limit(db,'abuse-report:'+str(request.client.host if request.client else 'unknown'),5)
    customer=None
    if user and not getattr(user,'is_customer',False):
        customer=db.query(Customer).filter_by(tenant_id=t.id,email=user.email.lower()).first()
    rep=TrustReport(tenant_id=t.id,reporter_customer_id=customer.id if customer else None,reporter_user_id=user.id if user else None,reason=data.reason,details=data.details,evidence_url=data.evidence_url)
    db.add(rep); db.flush()
    open_reports=db.query(TrustReport).filter(TrustReport.tenant_id==t.id,TrustReport.status.in_(['OPEN','UNDER_REVIEW'])).count()
    if open_reports >= get_settings().ABUSE_AUTO_SUSPEND_REPORT_THRESHOLD:
        for pending in db.query(TrustReport).filter(TrustReport.tenant_id==t.id,TrustReport.status=='OPEN').all():
            pending.status='UNDER_REVIEW'
    _ensure_trust_score(db,t.id); db.commit()
    return {'ok':True,'report_id':rep.id,'status':rep.status}

@router.get('/public/storefront/{hostname}/reviews')
def public_store_reviews(hostname: str, db: DBSession=Depends(get_db)):
    srow=db.query(Domain,Storefront,Tenant).join(Storefront,Storefront.id==Domain.storefront_id).join(Tenant,Tenant.id==Domain.tenant_id).filter(func.lower(Domain.hostname)==hostname.lower(),Domain.verified_at.is_not(None)).first()
    if not srow: raise not_found('Storefront not found')
    _d,_s,t=srow
    rows=db.query(TenantReview).filter_by(tenant_id=t.id,status='APPROVED').order_by(TenantReview.created_at.desc()).limit(50).all()
    score=_ensure_trust_score(db,t.id); db.commit()
    return {'average':float(score.rating_average),'count':score.rating_count,'items':[json_model(x) for x in rows]}

@router.post('/store/reviews')
def store_review(tenant_id: str, data: StoreReviewIn, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _tenant_membership_or_403(tenant_id,user,db)
    # Internal merchant account cannot review itself; customer reviews arrive via customer session/public order verification.
    raise AppError(403,'CUSTOMER_ONLY','Store reviews must be submitted from a customer account.')

@router.post('/public/storefront/{hostname}/reviews')
def customer_store_review(hostname: str, data: StoreReviewIn, request: Request, db: DBSession=Depends(get_db)):
    from app.core.guest import customer_session_actor
    srow=db.query(Domain,Storefront,Tenant).join(Storefront,Storefront.id==Domain.storefront_id).join(Tenant,Tenant.id==Domain.tenant_id).filter(func.lower(Domain.hostname)==hostname.lower(),Domain.verified_at.is_not(None)).first()
    if not srow: raise not_found('Storefront not found')
    _d,_s,t=srow
    actor=customer_session_actor(request,db,t.id)
    if actor is None: raise AppError(401,'CUSTOMER_LOGIN_REQUIRED','Sign in to a customer account before reviewing this store')
    customer=db.get(Customer,actor.customer_id)
    if not customer: raise forbidden('Customer account not found')
    if db.query(TenantReview).filter_by(tenant_id=t.id,customer_id=customer.id).first():
        raise AppError(409,'STORE_REVIEW_EXISTS','You already reviewed this store')
    verified_order=None
    if data.order_id:
        verified_order=db.query(Order).filter_by(id=data.order_id,tenant_id=t.id,customer_id=customer.id).first()
        if not verified_order: raise forbidden('Order proof does not match this customer')
    elif get_settings().TRUST_REVIEW_MIN_ORDER_PROOF:
        verified_order=db.query(Order).filter_by(tenant_id=t.id,customer_id=customer.id).filter(Order.status.in_(['PAID','FULFILLED','COMPLETED','DELIVERED'])).order_by(Order.created_at.desc()).first()
        if not verified_order: raise AppError(428,'PURCHASE_PROOF_REQUIRED','A completed order is required to review this store')
    review=TenantReview(tenant_id=t.id,customer_id=customer.id,order_id=verified_order.id if verified_order else None,rating=data.rating,body=data.body,status='PENDING')
    db.add(review); db.commit(); return {'ok':True,'review_id':review.id,'status':review.status}

@router.post('/customer/auth/logout')
def customer_logout(hostname: str, request: Request, response: Response, db: DBSession=Depends(get_db)):
    srow=db.query(Domain,Storefront,Tenant).join(Storefront,Storefront.id==Domain.storefront_id).join(Tenant,Tenant.id==Domain.tenant_id).filter(func.lower(Domain.hostname)==hostname.lower()).first()
    if not srow: raise not_found('Storefront not found')
    raw=request.cookies.get('customer_session')
    if raw:
        row=db.query(CustomerSession).filter_by(tenant_id=srow[2].id,token_hash=token_hash(raw)).first()
        if row: db.delete(row); db.commit()
    response.delete_cookie('customer_session',path='/')
    return {'ok':True}
