"""Tax rate routes: list, create.

Extracted out of app/routes/v1.py (Phase 3, step 19).
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.get('/tax-rates')
def taxes(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    return [json_model(x) for x in db.query(TaxRate).filter_by(tenant_id=tenant_id).all()]

@router.post('/tax-rates')
def create_tax(tenant_id: str, data: TaxIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    tenant_scope(tenant_id, user, db)
    x = TaxRate(tenant_id=tenant_id, **data.model_dump())
    db.add(x)
    db.commit()
    return json_model(x)
