"""Return request routes: merchant decision (approve/reject), execute refund.

Extracted out of app/routes/v1.py (Phase 3, step 24). refund() is the core
payment-refund function, used by several callers still in v1.py (order
refund, this return refund), so it stays there and is imported here.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import outbox
from app.routes.v1 import tenant_scope
from app.routes.payment_routes import refund
router = APIRouter(prefix='/v1')


@router.post('/returns/{return_id}/decision')
def decide_return(return_id: str, tenant_id: str, data: ReturnDecisionIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('orders.manage'))):
    tenant_scope(tenant_id, user, db)
    rr = db.query(ReturnRequest).filter_by(id=return_id,
        tenant_id=tenant_id).with_for_update().first()
    if not rr:
        raise not_found('Return request not found')
    if rr.status != 'REQUESTED':
        raise AppError(409, 'RETURN_STATE_INVALID', 'Return request is not awaiting a decision')
    if data.approved:
        amount = data.approved_amount_minor if data.approved_amount_minor is not None else rr.requested_amount_minor
        if amount <= 0 or amount > rr.requested_amount_minor:
            raise AppError(400, 'RETURN_AMOUNT_INVALID', 'Approved amount is invalid')
        rr.approved_amount_minor = amount
        rr.status = 'APPROVED'
        outbox(db, tenant_id, 'return', rr.id, 'return.approved', {'return_id': rr.id,
            'order_id': rr.order_id, 'amount_minor': amount, 'tenant_id': tenant_id})
    else:
        rr.status = 'REJECTED'
        rr.approved_amount_minor = 0
        outbox(db, tenant_id, 'return', rr.id, 'return.rejected', {'return_id': rr.id,
            'order_id': rr.order_id, 'tenant_id': tenant_id})
    rr.updated_at = datetime.now(timezone.utc)
    db.commit()
    return json_model(rr)

@router.post('/returns/{return_id}/refund')
def execute_return_refund(return_id: str, tenant_id: str, user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('orders.refund')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    rr = db.query(ReturnRequest).filter_by(id=return_id, tenant_id=tenant_id).first()
    if not rr:
        raise not_found('Return request not found')
    if rr.status != 'APPROVED':
        raise AppError(409, 'RETURN_NOT_APPROVED', 'Return request must be approved before refund')
    if not rr.approved_amount_minor:
        raise AppError(409, 'RETURN_AMOUNT_INVALID', 'Approved refund amount is missing')
    pi = db.query(PaymentIntent).filter_by(order_id=rr.order_id,
        tenant_id=tenant_id).order_by(PaymentIntent.created_at.desc()).first()
    if not pi:
        raise not_found('Payment intent not found')
    key = idempotency_key or 'return:' + rr.id
    result = refund(tenant_id=tenant_id, data=RefundIn(order_id=rr.order_id,
     payment_intent_id=pi.id,
     amount_minor=rr.approved_amount_minor,
        currency=rr.currency), user=user, db=db, _=None, idempotency_key=key)
    rr.status = 'REFUNDED'
    rr.provider_refund_id = result.get('provider_refund_id') if isinstance(result, dict) else None
    rr.updated_at = datetime.now(timezone.utc)
    db.commit()
    return {'return': json_model(rr), 'refund': result}

@router.post('/orders/{order_id}/refund')
def order_refund_alias(order_id: str, tenant_id: str, data: RefundIn, user=Depends(current_user),
 db: DBSession=Depends(get_db),
 _=Depends(require_permission('orders.refund')),
    idempotency_key: str | None=Header(default=None, alias='Idempotency-Key')):
    tenant_scope(tenant_id, user, db)
    if data.order_id != order_id:
        raise AppError(409, 'ORDER_ID_MISMATCH', 'Path order does not match refund payload')
    return refund(tenant_id=tenant_id, data=data, user=user, db=db, _=None,
        idempotency_key=idempotency_key)
