"""Product category routes: create, patch, delete, list.

Extracted out of app/routes/v1.py (Phase 3, step 17).
"""
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.core.serialization import json_model
from app.routes.v1 import tenant_scope, require_if_match

router = APIRouter(prefix='/v1')


@router.post('/categories')
def create_category(tenant_id: str, data: dict, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    parent_id = data.get('parent_id')
    if parent_id and (not db.query(Category).filter_by(id=parent_id, tenant_id=tenant_id).first()):
        raise AppError(400, 'CATEGORY_PARENT_INVALID',
            'Parent category belongs to another tenant or does not exist')
    c = Category(tenant_id=tenant_id, slug=data['slug'], name=data['name'], parent_id=parent_id)
    db.add(c)
    db.commit()
    return json_model(c)

@router.patch('/categories/{category_id}')
def patch_category(category_id: str, tenant_id: str, data: dict,
 if_match: str | None=Header(default=None,
 alias='If-Match'),
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    c = db.query(Category).filter_by(id=category_id, tenant_id=tenant_id).first()
    if not c:
        raise not_found('Category not found')
    require_if_match(c, if_match)
    if 'parent_id' in data and data['parent_id'] and (not db.query(Category).filter_by(id=data['parent_id'],
        tenant_id=tenant_id).first()):
        raise AppError(400, 'CATEGORY_PARENT_INVALID',
            'Parent category belongs to another tenant or does not exist')
    for k in ('slug', 'name', 'parent_id'):
        if k in data:
            setattr(c, k, data[k])
    db.commit()
    return json_model(c)

@router.delete('/categories/{category_id}')
def delete_category(category_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    c = db.query(Category).filter_by(id=category_id, tenant_id=tenant_id).first()
    if not c:
        raise not_found('Category not found')
    db.delete(c)
    db.commit()
    return {'ok': True}

@router.get('/categories')
def list_categories(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('products.read'))):
    tenant_scope(tenant_id, user, db)
    return [json_model(x) for x in db.query(Category).filter_by(tenant_id=tenant_id).order_by(Category.name.asc()).all()]
