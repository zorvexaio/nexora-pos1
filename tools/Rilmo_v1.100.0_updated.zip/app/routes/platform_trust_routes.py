"""Platform-admin trust & moderation routes: abuse-report list/decision,
manual identity confirmation gate, tenant suspend/reactivate trust-action,
tenant (store) review list/moderation.

Extracted out of app/routes/v1.py (Phase 3, step 32). _ensure_trust_score is
a shared helper used by other route groups still in v1.py, so it stays there
and is imported here.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, current_platform_admin
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model, audit_event_view
from app.services.core import audit, outbox
from app.services.merchant_trust import recalc_merchant_risk
from app.services.privacy import safe_merchant_profile_view
from app.routes.v1 import _ensure_trust_score

router = APIRouter(prefix='/v1')


@router.get('/platform/abuse-reports')
def platform_abuse_reports(limit: int=100, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(current_platform_admin)):
    rows=db.query(TrustReport).order_by(TrustReport.created_at.desc()).limit(max(1,min(limit,200))).all()
    return {'items':[json_model(x) for x in rows]}

@router.patch('/platform/abuse-reports/{report_id}')
def decide_abuse_report(report_id: str, data: AbuseReportDecisionIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(current_platform_admin)):
    r=db.get(TrustReport,report_id)
    if not r: raise not_found('Report not found')
    r.status=data.action; r.reviewer_note=data.note
    if data.action in {'RESOLVED','REJECTED'}: r.resolved_at=datetime.now(timezone.utc)
    score=_ensure_trust_score(db,r.tenant_id)
    db.commit(); return {'report':json_model(r),'trust':json_model(score)}

@router.patch('/platform/tenants/{tenant_id}/identity')
def platform_verify_merchant_identity(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(current_platform_admin)):
    profile=db.query(MerchantProfile).filter_by(tenant_id=tenant_id).first()
    if not profile: raise not_found('Merchant profile not found')
    if profile.kyc_status != 'VERIFIED':
        raise AppError(409,'KYC_PROVIDER_REQUIRED','Platform administrators cannot bypass external identity verification; use a provider decision or reopen verification.')
    profile.identity_status='VERIFIED'; profile.kyc_verified_at=profile.kyc_verified_at or datetime.now(timezone.utc); profile.payout_hold=False
    recalc_merchant_risk(db,tenant_id); score=_ensure_trust_score(db,tenant_id)
    audit(db,tenant_id,user.id,'merchant.identity.admin.confirm','MerchantProfile',profile.id,after={'kyc_status':profile.kyc_status})
    db.commit()
    return {'profile':safe_merchant_profile_view(profile, viewer_role='viewer', include_private=False),'trust':json_model(score)}

@router.post('/platform/tenants/{tenant_id}/trust-action')
def platform_tenant_trust_action(tenant_id: str, data: SuspendTenantIn, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(current_platform_admin)):
    t=db.get(Tenant,tenant_id)
    if not t: raise not_found('Tenant not found')
    t.status='SUSPENDED' if data.action=='SUSPEND' else 'ACTIVE'
    db.commit(); return {'tenant':json_model(t),'reason':data.reason}

@router.get('/platform/tenant-reviews')
def platform_tenant_reviews(status: str='PENDING', limit: int=100, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(current_platform_admin)):
    q=db.query(TenantReview).order_by(TenantReview.created_at.desc())
    if status:
        q=q.filter(TenantReview.status==status)
    rows=q.limit(max(1,min(limit,200))).all()
    return {'items':[json_model(x) for x in rows]}

@router.patch('/platform/tenant-reviews/{review_id}')
def moderate_tenant_review(review_id: str, action: str, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(current_platform_admin)):
    if action not in {'APPROVED','REJECTED','PENDING'}:
        raise AppError(400,'REVIEW_ACTION_INVALID','Invalid review action')
    review=db.get(TenantReview,review_id)
    if not review:
        raise not_found('Store review not found')
    review.status=action; review.updated_at=datetime.now(timezone.utc)
    score=_ensure_trust_score(db,review.tenant_id); db.commit()
    return {'review':json_model(review),'trust':json_model(score)}

@router.post('/admin/tenants/{tenant_id}/suspend')
def suspend(tenant_id: str, admin=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    t = db.get(Tenant, tenant_id)
    if not t:
        raise not_found('Tenant not found')
    t.status = 'SUSPENDED'
    outbox(db, tenant_id, 'tenant', tenant_id, 'tenant.suspended', {'tenant_id': tenant_id})
    db.commit()
    return json_model(t)

@router.post('/admin/tenants/{tenant_id}/reactivate')
def reactivate(tenant_id: str, admin=Depends(current_platform_admin),
    db: DBSession=Depends(get_db)):
    t = db.get(Tenant, tenant_id)
    if not t:
        raise not_found('Tenant not found')
    t.status = 'ACTIVE'
    outbox(db, tenant_id, 'tenant', tenant_id, 'tenant.reactivated', {'tenant_id': tenant_id})
    db.commit()
    return json_model(t)

@router.get('/admin/audit')
def admin_audit(admin=Depends(current_platform_admin), db: DBSession=Depends(get_db)):
    return [audit_event_view(x) for x in db.query(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(200).all()]
