"""Media asset routes: upload (with malware scan + image variant pipeline),
delete, list.

Extracted out of app/routes/v1.py (Phase 3, step 13). create_media and
delete_media were contiguous; list_media lived ~900 lines further down and is
folded in here since it's the same resource.
"""
import uuid
from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.core.serialization import json_model
from app.services.core import outbox
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.post('/media')
async def create_media(tenant_id: str, request: Request, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    form = await request.form()
    file = form.get('file')
    if not file or not hasattr(file, 'read'):
        raise AppError(400, 'FILE_REQUIRED', 'Multipart field file is required')
    try:
        content = await file.read()
        from app.security.policy import validate_upload
        content_type = file.content_type or 'application/octet-stream'
        try:
            validate_upload(filename=file.filename or 'upload', content_type=content_type,
                size_bytes=len(content), magic=content[:16])
        except ValueError as exc:
            raise AppError(422, 'UPLOAD_INVALID', str(exc)) from exc
        from app.services.malware import scan_bytes
        scan_bytes(content)
        from app.services.storage import get_object_store
        store = get_object_store()
        base = f'{tenant_id}/media/{uuid.uuid4().hex}'
        variants = []
        if content_type.startswith('image/'):
            from app.services.media_pipeline import process_image
            processed = process_image(content)
            for variant, (data, w, h) in processed.items():
                key = f'{base}/{variant}.webp'
                store.put(key, data, 'image/webp')
                variants.append((variant, key, 'image/webp', w, h, len(data)))
            original_data = processed['original'][0]
            original_mime = 'image/webp'
            original_size = len(original_data)
        else:
            key = f'{base}/original'
            store.put(key, content, content_type)
            variants = [('original', key, content_type, None, None, len(content))]
            original_mime = content_type
            original_size = len(content)
        row = MediaAsset(tenant_id=tenant_id,
         storage_key=next(v[1] for v in variants if v[0] == 'original'),
         mime_type=original_mime,
            size_bytes=original_size, status='READY', alt_text=form.get('alt_text'))
        db.add(row)
        db.flush()
        for variant, key, mime, width, height, size in variants:
            db.add(MediaVariant(tenant_id=tenant_id, media_asset_id=row.id, variant=variant,
                storage_key=key, mime_type=mime, width=width, height=height, size_bytes=size))
        outbox(db, tenant_id, 'media_asset', row.id, 'media.created', {'media_asset_id': row.id,
            'tenant_id': tenant_id, 'variants': [x[0] for x in variants]})
        db.commit()
        return json_model(row) | {'variants': [json_model(v) for v in db.query(MediaVariant).filter_by(media_asset_id=row.id,
            tenant_id=tenant_id).all()]}
    finally:
        close = getattr(file, 'close', None)
        if close:
            result = close()
            if hasattr(result, '__await__'):
                await result

@router.delete('/media/{media_id}')
def delete_media(media_id: str, tenant_id: str, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.write'))):
    tenant_scope(tenant_id, user, db)
    row = db.query(MediaAsset).filter_by(id=media_id, tenant_id=tenant_id).first()
    if not row:
        raise not_found('Media not found')
    from app.services.storage import get_object_store
    store = get_object_store()
    for variant in db.query(MediaVariant).filter_by(media_asset_id=row.id,
        tenant_id=tenant_id).all():
        store.delete(variant.storage_key)
        db.delete(variant)
    store.delete(row.storage_key)
    row.status = 'DELETED'
    outbox(db, tenant_id, 'media_asset', row.id, 'media.deleted', {'media_asset_id': row.id,
        'tenant_id': tenant_id})
    db.commit()
    return {'ok': True}

@router.get('/media')
def list_media(tenant_id: str, limit: int=100, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('products.read'))):
    tenant_scope(tenant_id, user, db)
    rows = db.query(MediaAsset).filter_by(tenant_id=tenant_id).order_by(MediaAsset.id.desc()).limit(max(1,
        min(limit, 200))).all()
    return {'items': [json_model(x) for x in rows]}
