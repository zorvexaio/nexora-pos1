"""Storefront theme routes: starter themes, create/list/assign/publish theme,
and the public (unauthenticated) published-theme lookup used by storefronts.

Extracted out of app/routes/v1.py (Phase 3, step 5). STARTER_THEMES was only
referenced by starter_themes() in this same block, so it moved with it rather
than staying behind as an orphaned module-level constant in v1.py.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')

STARTER_THEMES = [{'slug': 'modern', 'name': 'Modern', 'template_key': 'catalog',
 'settings': {'primary': '#111827',
 'accent': '#2563eb',
 'radius': '16px',
 'density': 'comfortable'}},
 {'slug': 'minimal',
 'name': 'Minimal',
 'template_key': 'catalog',
 'settings': {'primary': '#111827',
 'accent': '#111827',
 'radius': '4px',
 'density': 'compact'}},
 {'slug': 'boutique',
 'name': 'Boutique',
 'template_key': 'catalog',
 'settings': {'primary': '#6d3b47',
 'accent': '#b78b7a',
 'radius': '22px',
 'density': 'comfortable'}},
 {'slug': 'gulf',
 'name': 'Gulf Commerce',
 'template_key': 'catalog',
 'settings': {'primary': '#0f766e',
 'accent': '#d4a72c',
 'radius': '12px',
 'density': 'comfortable'}},
 {'slug': 'night',
 'name': 'Night Market',
 'template_key': 'catalog',
    'settings': {'primary': '#f8fafc', 'accent': '#8b5cf6', 'radius': '18px', 'density': 'compact'}}]

@router.get('/themes/starters')
def starter_themes(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    return {'items': STARTER_THEMES}

@router.post('/themes')
def create_theme(tenant_id: str, data: ThemeIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('storefront.write'))):
    tenant_scope(tenant_id, user, db)
    if db.query(Theme).filter_by(tenant_id=tenant_id, slug=data.slug).first():
        raise AppError(409, 'THEME_EXISTS', 'Theme slug already exists')
    theme = Theme(tenant_id=tenant_id, slug=data.slug, name=data.name,
        template_key=data.template_key, settings=data.settings or {})
    db.add(theme)
    db.flush()
    if not db.query(ThemeAssignment).filter_by(tenant_id=tenant_id).first():
        db.add(ThemeAssignment(tenant_id=tenant_id, theme_id=theme.id))
    db.commit()
    return json_model(theme)

@router.get('/themes')
def list_themes(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('storefront.read'))):
    tenant_scope(tenant_id, user, db)
    assignment = db.query(ThemeAssignment).filter_by(tenant_id=tenant_id).first()
    return {'items': [json_model(x) for x in db.query(Theme).filter_by(tenant_id=tenant_id).order_by(Theme.created_at.asc()).all()],
        'active_theme_id': assignment.theme_id if assignment else None}

@router.post('/themes/assign')
def assign_theme(tenant_id: str, data: ThemeAssignIn, user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('storefront.write'))):
    tenant_scope(tenant_id, user, db)
    theme = db.query(Theme).filter_by(id=data.theme_id, tenant_id=tenant_id,
        status='ACTIVE').first()
    if not theme:
        raise not_found('Theme not found')
    a = db.query(ThemeAssignment).filter_by(tenant_id=tenant_id).first()
    if not a:
        a = ThemeAssignment(tenant_id=tenant_id, theme_id=theme.id)
        db.add(a)
    else:
        a.theme_id = theme.id
    db.commit()
    return json_model(a)

@router.post('/themes/publish')
def publish_theme(tenant_id: str, user=Depends(current_user), db: DBSession=Depends(get_db),
    _=Depends(require_permission('storefront.write'))):
    tenant_scope(tenant_id, user, db)
    a = db.query(ThemeAssignment).filter_by(tenant_id=tenant_id).first()
    if not a:
        raise AppError(409, 'THEME_NOT_ASSIGNED', 'Assign a theme before publishing')
    a.published_at = datetime.now(timezone.utc)
    s = db.query(Storefront).filter_by(tenant_id=tenant_id).first()
    if s:
        s.status = 'PUBLISHED'
    db.commit()
    return {'ok': True, 'theme_id': a.theme_id, 'published_at': a.published_at.isoformat()}

@router.get('/public/storefront/{hostname}/theme')
def public_theme(hostname: str, db: DBSession=Depends(get_db)):
    row = db.query(Domain, ThemeAssignment, Theme).join(ThemeAssignment,
     ThemeAssignment.tenant_id == Domain.tenant_id).join(Theme,
     Theme.id == ThemeAssignment.theme_id).filter(func.lower(Domain.hostname) == hostname.lower(),
        Domain.verified_at.is_not(None), ThemeAssignment.published_at.is_not(None)).first()
    if not row:
        raise not_found('Published theme not found')
    d, a, t = row
    return {'theme': {'slug': t.slug, 'name': t.name, 'version': t.version,
        'template_key': t.template_key, 'settings': t.settings}, 'hostname': d.hostname}
