"""Domain routes, part 2: platform subdomain availability/provisioning, and
custom-domain availability/purchase via the registrar. (Provision/list/verify
for verified custom domains already live in tenant_setup_routes.py.)

Extracted out of app/routes/v1.py (Phase 3, step 31). _tenant_membership_or_403
and _merchant_gate are shared helpers used elsewhere in v1.py, so they stay
there and are imported here.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError
from app.core.config import get_settings
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.routes.v1 import _tenant_membership_or_403, _merchant_gate

router = APIRouter(prefix='/v1')


@router.get('/domains/subdomain/availability')
def subdomain_availability(tenant_id: str, slug: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _tenant_membership_or_403(tenant_id,user,db)
    root=(get_settings().PLATFORM_ROOT_DOMAIN or '').strip().lower().rstrip('.')
    import re
    slug=(slug or '').strip().lower()
    if not root:
        return {'available':False,'configured':False,'reason':'PLATFORM_ROOT_DOMAIN_NOT_CONFIGURED'}
    if not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',slug):
        return {'available':False,'configured':True,'reason':'INVALID_SUBDOMAIN'}
    hostname=f'{slug}.{root}'
    exists=db.query(Domain).filter(func.lower(Domain.hostname)==hostname).first()
    return {'available':exists is None,'configured':True,'hostname':hostname,'price_minor':get_settings().DOMAIN_SUBDOMAIN_PRICE_USD_MINOR,'currency':'USD'}

@router.post('/domains/subdomain/provision')
def provision_subdomain(tenant_id: str, slug: str, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('settings.manage'))):
    _tenant_membership_or_403(tenant_id,user,db); _merchant_gate(db,tenant_id,user)
    root=(get_settings().PLATFORM_ROOT_DOMAIN or '').strip().lower().rstrip('.')
    import re
    slug=(slug or '').strip().lower()
    if not root:
        raise AppError(503,'PLATFORM_ROOT_DOMAIN_NOT_CONFIGURED','Platform root domain is not configured')
    if not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',slug):
        raise AppError(400,'INVALID_SUBDOMAIN','Invalid subdomain')
    hostname=f'{slug}.{root}'
    if db.query(Domain).filter(func.lower(Domain.hostname)==hostname).first():
        raise AppError(409,'SUBDOMAIN_UNAVAILABLE','Subdomain is already in use')
    sf=db.query(Storefront).filter_by(tenant_id=tenant_id,status='PUBLISHED').order_by(Storefront.version.desc()).first()
    if not sf:
        raise AppError(428,'STOREFRONT_NOT_PUBLISHED','Publish the storefront before provisioning a subdomain')
    d=Domain(tenant_id=tenant_id,storefront_id=sf.id,hostname=hostname,verified_at=datetime.now(timezone.utc),is_primary=False,verification_method='platform_subdomain',verified_hostname=hostname,verification_version=1)
    db.add(d); db.commit()
    return {'domain':json_model(d),'price_minor':get_settings().DOMAIN_SUBDOMAIN_PRICE_USD_MINOR,'currency':'USD'}

@router.get('/domains/availability')
def domain_availability(tenant_id: str, hostname: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    _tenant_membership_or_403(tenant_id,user,db)
    from app.services.domain_registrar import check_domain
    return check_domain(hostname)

@router.post('/domains/purchase')
def domain_purchase(tenant_id: str, data: DomainPurchaseIn, request: Request, user=Depends(current_user), db: DBSession=Depends(get_db), _=Depends(require_permission('billing.manage'))):
    _tenant_membership_or_403(tenant_id,user,db); _merchant_gate(db,tenant_id,user)
    idem_key=request.headers.get('Idempotency-Key') or ('domain:'+data.hostname.lower())
    existing=db.query(DomainPurchase).filter_by(tenant_id=tenant_id, idempotency_key=idem_key).first()
    if existing: return {'purchase':json_model(existing),'duplicate':True}
    from app.services.domain_registrar import check_domain, register_domain
    check=check_domain(data.hostname)
    if not check.get('registrable'): raise AppError(409,'DOMAIN_UNAVAILABLE','Domain is not available for registration')
    provider_cost=int(check.get('registration_cost_minor') or 0)
    price=get_settings().DOMAIN_PLATFORM_PRICE_USD_MINOR*data.years
    if provider_cost>price: raise AppError(409,'DOMAIN_PRICE_TOO_LOW','Provider cost is higher than the configured platform price')
    pur=DomainPurchase(tenant_id=tenant_id,hostname=data.hostname.lower(),years=data.years,provider=get_settings().DOMAIN_PROVIDER,provider_cost_minor=provider_cost,customer_price_minor=price,currency='USD',status='PENDING_PAYMENT',idempotency_key=idem_key,registrant_snapshot=data.model_dump())
    db.add(pur); db.flush()
    # Never register a domain before payment succeeds. The billing worker/webhook must call the registrar after payment capture.
    db.commit(); return {'purchase':json_model(pur),'domain':None,'requires_external_payment':True,'payment_target':{'domain_purchase_id':pur.id,'amount_minor':pur.customer_price_minor,'currency':pur.currency}}
