"""Support ticket routes: list/create/update.

Extracted out of app/routes/v1.py (Phase 3, step 8).
"""
import secrets
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, require_permission
from app.core.errors import AppError, not_found
from app.models.domain import *
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import audit, outbox
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


@router.get('/support/tickets')
def support_tickets(tenant_id: str, status: str | None=None, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    q = db.query(SupportTicket).filter_by(tenant_id=tenant_id)
    if status:
        q = q.filter(SupportTicket.status == status)
    rows = q.order_by(SupportTicket.created_at.desc()).limit(200).all()
    return {'items': [json_model(x) for x in rows]}

@router.post('/support/tickets')
def create_support_ticket(tenant_id: str, data: SupportTicketIn, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    tenant_scope(tenant_id, user, db)
    prefix = f"TKT-{datetime.now(timezone.utc).strftime('%Y%m%d')}-"
    suffix = secrets.token_hex(4).upper()
    sla_hours = {'LOW': 72, 'NORMAL': 48, 'HIGH': 24, 'URGENT': 4}[data.priority]
    ticket = SupportTicket(tenant_id=tenant_id, ticket_number=f'{prefix}{suffix}',
     subject=data.subject,
     body=data.body,
     priority=data.priority,
     status='OPEN',
     category=data.category,
        requester_user_id=user.id, sla_due_at=datetime.now(timezone.utc) + timedelta(hours=sla_hours))
    db.add(ticket)
    db.flush()
    audit(db, tenant_id, user.id, 'support_ticket.create', 'support_ticket', ticket.id,
        after={'ticket_number': ticket.ticket_number})
    outbox(db, tenant_id, 'support_ticket', ticket.id, 'support.ticket.created',
        {'ticket_id': ticket.id, 'tenant_id': tenant_id})
    db.commit()
    return json_model(ticket)

@router.patch('/support/tickets/{ticket_id}')
def update_support_ticket(ticket_id: str, tenant_id: str, data: SupportTicketUpdateIn,
 user=Depends(current_user),
    db: DBSession=Depends(get_db), _=Depends(require_permission('staff.manage'))):
    tenant_scope(tenant_id, user, db)
    t = db.query(SupportTicket).filter_by(id=ticket_id, tenant_id=tenant_id).first()
    if not t:
        raise not_found('Support ticket not found')
    if data.status:
        t.status = data.status
    if data.priority:
        t.priority = data.priority
    if data.assigned_user_id:
        m = db.query(TenantMembership).filter_by(tenant_id=tenant_id, user_id=data.assigned_user_id,
            status='ACTIVE').first()
        if not m:
            raise AppError(400, 'ASSIGNEE_INVALID', 'Assignee is not an active tenant member')
        t.assigned_user_id = data.assigned_user_id
    t.updated_at = datetime.now(timezone.utc)
    audit(db, tenant_id, user.id, 'support_ticket.update', 'support_ticket', t.id,
        after=data.model_dump(exclude_none=True))
    db.commit()
    return json_model(t)
