"""OAuth 2.0 authorization-code + PKCE flow for third-party app installs:
/oauth/authorize and /oauth/token, plus their two private helpers.

Extracted out of app/routes/v1.py (Phase 3, step 14).
"""
import hashlib, hmac, secrets, urllib.parse, base64
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Form, Request, Response
from sqlalchemy.orm import Session as DBSession
from app.core.database import get_db
from app.core.auth import current_user, assert_permission
from app.core.errors import AppError
from app.core.config import get_settings
from app.core.security import token_hash
from app.models.domain import *
from app.services.core import enforce_rate_limit
from app.routes.v1 import tenant_scope

router = APIRouter(prefix='/v1')


def _app_client(app_def, client_id: str, client_secret: str | None=None):
    if not app_def or app_def.client_id != client_id or app_def.status != 'APPROVED':
        raise AppError(401, 'OAUTH_CLIENT_INVALID', 'Invalid OAuth client')
    if client_secret is not None and (not hmac.compare_digest(token_hash(client_secret),
        app_def.client_secret_hash)):
        raise AppError(401, 'OAUTH_CLIENT_INVALID', 'Invalid OAuth client credentials')

def _oauth_redirect(uri: str, params: dict):
    parsed = urllib.parse.urlsplit(uri)
    q = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    q.update({k: [str(v)] for k, v in params.items()})
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path,
        urllib.parse.urlencode(q, doseq=True), parsed.fragment))

@router.get('/oauth/authorize')
def oauth_authorize(client_id: str, redirect_uri: str, response_type: str='code', scope: str='',
 state: str | None=None,
 code_challenge: str | None=None,
 code_challenge_method: str | None=None,
    tenant_id: str='', user=Depends(current_user), db: DBSession=Depends(get_db)):
    if response_type != 'code' or not state or (not code_challenge) or (code_challenge_method != 'S256'):
        raise AppError(400, 'OAUTH_REQUEST_INVALID',
            'Authorization Code + PKCE (S256) and state are required')
    app_def = db.query(AppDefinition).filter_by(client_id=client_id).first()
    _app_client(app_def, client_id)
    if redirect_uri not in (app_def.redirect_uris or []):
        raise AppError(400, 'OAUTH_REDIRECT_INVALID', 'Redirect URI is not registered')
    tenant_scope(tenant_id, user, db)
    # OAuth authorization changes the tenant's installed-app grant set.
    # Treat it as an app-management operation even when invoked by the OAuth route
    # directly, so ordinary tenant members cannot self-grant broader app scopes.
    assert_permission(tenant_id, user, db, 'apps.manage')
    requested = sorted(set(scope.split()))
    allowed = set(app_def.scopes or [])
    if not requested or not set(requested).issubset(allowed):
        raise AppError(400, 'OAUTH_SCOPE_INVALID', 'Requested scope is not allowed')
    inst = db.query(AppInstallation).filter_by(tenant_id=tenant_id, app_id=app_def.id).with_for_update().first()
    if not inst:
        raw = secrets.token_urlsafe(40)
        inst = AppInstallation(tenant_id=tenant_id, app_id=app_def.id, granted_scopes=requested,
            access_token_hash=token_hash(raw), status='ACTIVE')
        db.add(inst)
        db.flush()
    elif inst.status != 'ACTIVE':
        raise AppError(403, 'APP_REVOKED', 'Application installation is not active')
    else:
        previous_scopes = set(inst.granted_scopes or [])
        requested_scopes = set(requested)
        # Re-authorizing an installation can reduce privileges. Existing bearer
        # and refresh credentials must not retain scopes that the merchant just
        # removed. Revoke them before issuing the new authorization code.
        if previous_scopes != requested_scopes:
            now_reauth = datetime.now(timezone.utc)
            db.query(AppAccessToken).filter_by(installation_id=inst.id,
                tenant_id=tenant_id, revoked_at=None).update(
                {'revoked_at': now_reauth}, synchronize_session=False)
            db.query(AppRefreshToken).filter_by(installation_id=inst.id,
                tenant_id=tenant_id, revoked_at=None).update(
                {'revoked_at': now_reauth}, synchronize_session=False)
        inst.granted_scopes = requested
    raw_code = secrets.token_urlsafe(48)
    now = datetime.now(timezone.utc)
    db.add(AppOAuthAuthorizationCode(app_id=app_def.id, tenant_id=tenant_id, user_id=user.id,
     code_hash=token_hash(raw_code),
     redirect_uri=redirect_uri,
     scopes=requested,
     code_challenge=code_challenge,
        code_challenge_method='S256', expires_at=now + timedelta(minutes=5)))
    db.commit()
    return Response(content='', status_code=302, headers={'Location': _oauth_redirect(redirect_uri,
        {'code': raw_code, 'state': state}), 'Cache-Control': 'no-store', 'Pragma': 'no-cache'})

@router.post('/oauth/token')
def oauth_token(request: Request, grant_type: str=Form(...), client_id: str=Form(...), client_secret: str=Form(...),
 code: str | None=Form(default=None),
 redirect_uri: str | None=Form(default=None),
 code_verifier: str | None=Form(default=None),
    refresh_token: str | None=Form(default=None), db: DBSession=Depends(get_db)):
    settings = get_settings()
    client_ip = request.client.host if request and request.client else 'unknown'
    client_key = hashlib.sha256(client_id.encode()).hexdigest()
    enforce_rate_limit(db, 'oauth:token:ip:' + client_ip, settings.OAUTH_TOKEN_RATE_LIMIT_PER_MINUTE)
    enforce_rate_limit(db, 'oauth:token:client:' + client_key, settings.OAUTH_TOKEN_RATE_LIMIT_PER_MINUTE)
    app_def = db.query(AppDefinition).filter_by(client_id=client_id).first()
    _app_client(app_def, client_id, client_secret)
    now = datetime.now(timezone.utc)
    if grant_type == 'authorization_code':
        if not code or not redirect_uri or (not code_verifier):
            raise AppError(400, 'OAUTH_REQUEST_INVALID',
                'code, redirect_uri and code_verifier are required')
        row = db.query(AppOAuthAuthorizationCode).filter_by(code_hash=token_hash(code),
            app_id=app_def.id).with_for_update().first()
        expires = row.expires_at.replace(tzinfo=timezone.utc) if row and row.expires_at and (row.expires_at.tzinfo is None) else row.expires_at if row else None
        if not row or row.used_at or expires <= now or (row.redirect_uri != redirect_uri):
            raise AppError(400, 'OAUTH_CODE_INVALID', 'Invalid or expired authorization code')
        digest = base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode()).digest()).rstrip(b'=').decode()
        if not hmac.compare_digest(digest, row.code_challenge or ''):
            raise AppError(400, 'OAUTH_PKCE_INVALID', 'PKCE verification failed')
        inst = db.query(AppInstallation).filter_by(id=None).first() if False else db.query(AppInstallation).filter_by(tenant_id=row.tenant_id,
            app_id=app_def.id, status='ACTIVE').first()
        if not inst:
            raise AppError(400, 'OAUTH_INSTALLATION_MISSING', 'Application is not installed')
        access = secrets.token_urlsafe(40)
        refresh = secrets.token_urlsafe(48)
        inst.access_token_hash = token_hash(access)
        db.add(AppAccessToken(tenant_id=row.tenant_id, installation_id=inst.id,
            token_hash=token_hash(access), scopes=row.scopes, expires_at=now + timedelta(hours=1)))
        db.add(AppRefreshToken(tenant_id=row.tenant_id, installation_id=inst.id,
            token_hash=token_hash(refresh), expires_at=now + timedelta(days=90)))
        row.used_at = now
        db.commit()
        return {'access_token': access, 'token_type': 'Bearer', 'expires_in': 3600,
            'refresh_token': refresh, 'scope': ' '.join(row.scopes)}
    if grant_type == 'refresh_token':
        if not refresh_token:
            raise AppError(400, 'OAUTH_REQUEST_INVALID', 'refresh_token is required')
        rt = db.query(AppRefreshToken).filter_by(token_hash=token_hash(refresh_token),
            revoked_at=None).with_for_update().first()
        rt_expires = rt.expires_at.replace(tzinfo=timezone.utc) if rt and rt.expires_at and (rt.expires_at.tzinfo is None) else rt.expires_at if rt else None
        if not rt or rt_expires <= now:
            raise AppError(400, 'OAUTH_REFRESH_INVALID', 'Invalid or expired refresh token')
        inst = db.query(AppInstallation).filter_by(id=rt.installation_id, tenant_id=rt.tenant_id,
            status='ACTIVE').first()
        # Refresh tokens are client-bound credentials. Do not allow an unrelated
        # app client, even with a valid client secret, to redeem another app's
        # refresh token.
        if inst and inst.app_id != app_def.id:
            raise AppError(400, 'OAUTH_REFRESH_CLIENT_MISMATCH',
                'Refresh token was issued to a different application')
        if not inst:
            raise AppError(400, 'OAUTH_INSTALLATION_MISSING',
                'Application installation is not active')
        access = secrets.token_urlsafe(40)
        new_refresh = secrets.token_urlsafe(48)
        db.add(AppAccessToken(tenant_id=rt.tenant_id, installation_id=inst.id,
         token_hash=token_hash(access),
            scopes=inst.granted_scopes, expires_at=now + timedelta(hours=1)))
        rt.revoked_at = now
        db.add(AppRefreshToken(tenant_id=rt.tenant_id, installation_id=inst.id,
            token_hash=token_hash(new_refresh), expires_at=now + timedelta(days=90)))
        db.commit()
        return {'access_token': access, 'token_type': 'Bearer', 'expires_in': 3600,
            'refresh_token': new_refresh, 'scope': ' '.join(inst.granted_scopes)}
    raise AppError(400, 'OAUTH_GRANT_UNSUPPORTED', 'Unsupported grant_type')
