"""Google OAuth: sign-in/register flow, account-linking flow, and the
generic (test-only) identity-link endpoint.

Extracted out of app/routes/v1.py (Phase 3, step 36). Auth-security-critical
code: every function below was copied via exact programmatic text extraction
from the source (not retyped), then verified byte-for-byte identical before
the source was removed from v1.py — the same rigor applied after the
payments extraction incident earlier in this session.
"""
import hmac, secrets, uuid, urllib.parse
from datetime import datetime, timezone, timedelta
import httpx
from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func, update
from app.core.database import get_db, set_tenant_context
from app.core.auth import current_user
from app.core.errors import AppError, not_found
from app.core.security import *
from app.core.config import get_settings
from app.models.domain import *
SessionModel = globals()['Session']
from app.schemas.api import *
from app.core.serialization import json_model
from app.services.core import audit

router = APIRouter(prefix='/v1')


def _consume_oauth_state(db, model, state_id, now, error_code='OAUTH_STATE_REPLAY'):
    result = db.execute(update(model).where(model.id == state_id, model.used_at.is_(None)).values(used_at=now))
    if result.rowcount != 1:
        raise AppError(400, error_code, 'OAuth state has already been consumed')

def _oauth_redirect_uri(provider: str) -> str:
    s = get_settings()
    if provider == 'google':
        return s.GOOGLE_REDIRECT_URI
    raise AppError(400, 'OAUTH_PROVIDER_UNSUPPORTED', 'Unsupported OAuth provider')

@router.get('/auth/google/start')
def google_start(request: Request, response: Response, db: DBSession=Depends(get_db)):
    s = get_settings()
    if not s.GOOGLE_CLIENT_ID or not s.GOOGLE_CLIENT_SECRET:
        raise AppError(503, 'GOOGLE_OAUTH_NOT_CONFIGURED', 'Google OAuth is not configured')
    state = random_token(32)
    nonce = random_token(32)
    now = datetime.now(timezone.utc)
    db.add(OAuthState(provider='google', state_hash=token_hash(state), nonce_hash=token_hash(nonce),
        redirect_uri=s.GOOGLE_REDIRECT_URI, expires_at=now + timedelta(minutes=10), created_at=now))
    db.commit()
    response.set_cookie('oauth_state', state, httponly=True, secure=s.COOKIE_SECURE, samesite='lax',
        max_age=600, path='/')
    response.set_cookie('oauth_nonce', nonce, httponly=True, secure=s.COOKIE_SECURE, samesite='lax',
        max_age=600, path='/')
    params = {'client_id': s.GOOGLE_CLIENT_ID, 'redirect_uri': s.GOOGLE_REDIRECT_URI,
     'response_type': 'code',
     'scope': s.GOOGLE_SCOPES,
        'state': state, 'nonce': nonce, 'access_type': 'online', 'prompt': 'select_account'}
    return {'authorization_url': 'https://accounts.google.com/o/oauth2/v2/auth?' + urllib.parse.urlencode(params)}

@router.get('/auth/google/callback')
def google_callback(code: str, state: str, request: Request, response: Response,
    db: DBSession=Depends(get_db)):
    s = get_settings()
    now = datetime.now(timezone.utc)
    raw_cookie = request.cookies.get('oauth_state')
    if not raw_cookie or not hmac.compare_digest(token_hash(raw_cookie), token_hash(state)):
        raise AppError(400, 'OAUTH_STATE_INVALID', 'Invalid OAuth state')
    raw_nonce = request.cookies.get('oauth_nonce')
    if not raw_nonce:
        raise AppError(400, 'OAUTH_NONCE_MISSING', 'OAuth nonce cookie is missing')
    st = db.query(OAuthState).filter_by(provider='google', state_hash=token_hash(state),
        used_at=None).first()
    if not st or (st.expires_at.replace(tzinfo=timezone.utc) if st.expires_at.tzinfo is None else st.expires_at) <= now:
        raise AppError(400, 'OAUTH_STATE_EXPIRED', 'OAuth state expired')
    if not hmac.compare_digest(token_hash(raw_nonce), st.nonce_hash):
        raise AppError(400, 'OAUTH_NONCE_INVALID', 'Invalid OAuth nonce')
    try:
        r = httpx.post('https://oauth2.googleapis.com/token', trust_env=False, data={'client_id': s.GOOGLE_CLIENT_ID,
         'client_secret': s.GOOGLE_CLIENT_SECRET,
         'code': code,
            'grant_type': 'authorization_code', 'redirect_uri': st.redirect_uri}, timeout=10)
        if r.status_code >= 400:
            raise ValueError('token exchange failed')
        tok = r.json().get('access_token')
        if not tok:
            raise ValueError('missing access token')
        u = httpx.get('https://openidconnect.googleapis.com/v1/userinfo',
            trust_env=False,
            headers={'Authorization': f'Bearer {tok}'}, timeout=10)
        if u.status_code >= 400:
            raise ValueError('userinfo failed')
        info = u.json()
        subject = str(info.get('sub') or '')
        email = str(info.get('email') or '').lower()
        verified = bool(info.get('email_verified'))
        id_token = r.json().get('id_token')
        if not id_token:
            raise ValueError('missing id token')
        import jwt
        jwks_client = jwt.PyJWKClient(s.GOOGLE_JWKS_URL)
        signing_key = jwks_client.get_signing_key_from_jwt(id_token)
        claims = jwt.decode(id_token, signing_key.key, algorithms=['RS256'],
         audience=s.GOOGLE_CLIENT_ID,
            issuer=[x.strip() for x in s.GOOGLE_ISSUERS.split(',') if x.strip()])
        nonce_claim = str(claims.get('nonce') or '')
        expected_nonce_hash = st.nonce_hash
        if not nonce_claim or not hmac.compare_digest(token_hash(nonce_claim), expected_nonce_hash):
            raise ValueError('OAuth nonce mismatch')
        if not claims.get('email_verified'):
            raise ValueError('unverified Google email')
        if str(claims.get('sub')) != subject:
            raise ValueError('identity subject mismatch')
    except AppError:
        raise
    except Exception as exc:
        raise AppError(502, 'GOOGLE_OAUTH_FAILED', 'Unable to complete Google sign-in') from exc
    if not subject or not email or (not verified):
        raise AppError(400, 'GOOGLE_IDENTITY_INVALID',
            'Google account must provide a verified email identity')
    identity = db.query(UserIdentity).filter_by(provider='google', provider_subject=subject).first()
    if identity:
        user = db.get(User, identity.user_id)
    else:
        existing = db.query(User).filter(func.lower(User.email) == email).first()
        if existing:
            raise AppError(409, 'ACCOUNT_LINK_REQUIRED',
                'This email already exists. Sign in first and link Google from account security settings.')
        user = User(email=email, password_hash=hash_password(secrets.token_urlsafe(48)),
            display_name=str(info.get('name') or email.split('@')[0]))
        db.add(user)
        db.flush()
        tenant = Tenant(slug=email.split('@')[0].replace('.',
         '-')[:60] + '-' + uuid.uuid4().hex[:6],
            name=user.display_name or email, status='PROVISIONING')
        db.add(tenant)
        db.flush()
        set_tenant_context(db, tenant.id)
        db.add(TenantMembership(tenant_id=tenant.id, user_id=user.id, role='owner'))
        db.add(Storefront(tenant_id=tenant.id, name=tenant.name, slug='default',
            default_locale=tenant.default_locale, default_currency=tenant.default_currency))
        db.add(UserIdentity(user_id=user.id, provider='google', provider_subject=subject,
            provider_email=email, email_verified_at=now))
    memberships = db.query(TenantMembership).filter_by(user_id=user.id, status='ACTIVE').all()
    for membership in memberships:
        profile = db.query(MerchantProfile).filter_by(tenant_id=membership.tenant_id).first()
        if profile:
            profile.google_verified_at = now
    _consume_oauth_state(db, OAuthState, st.id, now)
    session_token = create_session_token()
    db.add(SessionModel(user_id=user.id, token_hash=token_hash(session_token),
     expires_at=now + timedelta(hours=s.SESSION_TTL_HOURS),
     idle_expires_at=now + timedelta(minutes=s.SESSION_IDLE_TTL_MINUTES),
        absolute_expires_at=now + timedelta(days=s.SESSION_ABSOLUTE_TTL_DAYS), last_seen_at=now))
    db.commit()
    response.delete_cookie('oauth_state')
    response.delete_cookie('oauth_nonce')
    response.set_cookie('session', session_token, httponly=True, secure=s.COOKIE_SECURE,
        samesite='lax', max_age=s.SESSION_TTL_HOURS * 3600)
    response.set_cookie('csrf_token', random_token(24), httponly=False, secure=s.COOKIE_SECURE,
        samesite='lax', max_age=s.SESSION_TTL_HOURS * 3600)
    return {'ok': True, 'access_token': session_token, 'token_type': 'bearer',
        'user': json_model(user)}

@router.get('/auth/google/link/start')
def google_link_start(request: Request, response: Response, user=Depends(current_user),
    db: DBSession=Depends(get_db)):
    s = get_settings()
    if not s.GOOGLE_CLIENT_ID or not s.GOOGLE_CLIENT_SECRET:
        raise AppError(503, 'GOOGLE_OAUTH_NOT_CONFIGURED', 'Google OAuth is not configured')
    state = random_token(32)
    nonce = random_token(32)
    now = datetime.now(timezone.utc)
    db.add(OAuthState(provider='google-link', state_hash=token_hash(state),
     nonce_hash=token_hash(nonce),
     redirect_uri=s.GOOGLE_REDIRECT_URI,
        expires_at=now + timedelta(minutes=10), created_at=now, user_id=user.id))
    db.commit()
    response.set_cookie('oauth_link_state', state, httponly=True, secure=s.COOKIE_SECURE,
        samesite='lax', max_age=600, path='/')
    response.set_cookie('oauth_link_nonce', nonce, httponly=True, secure=s.COOKIE_SECURE,
        samesite='lax', max_age=600, path='/')
    params = {'client_id': s.GOOGLE_CLIENT_ID, 'redirect_uri': s.GOOGLE_REDIRECT_URI,
     'response_type': 'code',
     'scope': s.GOOGLE_SCOPES,
        'state': state, 'nonce': nonce, 'access_type': 'online', 'prompt': 'select_account'}
    return {'authorization_url': 'https://accounts.google.com/o/oauth2/v2/auth?' + urllib.parse.urlencode(params)}

@router.get('/auth/google/link/callback')
def google_link_callback(code: str, state: str, request: Request, response: Response,
    user=Depends(current_user), db: DBSession=Depends(get_db)):
    s = get_settings()
    now = datetime.now(timezone.utc)
    raw_state = request.cookies.get('oauth_link_state')
    raw_nonce = request.cookies.get('oauth_link_nonce')
    if not raw_state or not hmac.compare_digest(token_hash(raw_state),
        token_hash(state)) or (not raw_nonce):
        raise AppError(400, 'OAUTH_LINK_STATE_INVALID', 'Invalid OAuth link state')
    st = db.query(OAuthState).filter_by(provider='google-link', state_hash=token_hash(state),
        used_at=None).first()
    if not st or st.user_id is None or (st.expires_at.replace(tzinfo=timezone.utc) if st.expires_at.tzinfo is None else st.expires_at) <= now:
        raise AppError(400, 'OAUTH_LINK_STATE_EXPIRED', 'OAuth link state expired')
    if st.user_id != user.id:
        raise AppError(403, 'OAUTH_LINK_USER_MISMATCH', 'OAuth link state does not belong to the current user')
    if not hmac.compare_digest(token_hash(raw_nonce), st.nonce_hash):
        raise AppError(400, 'OAUTH_LINK_NONCE_INVALID', 'Invalid OAuth link nonce')
    try:
        r = httpx.post('https://oauth2.googleapis.com/token', trust_env=False, data={'client_id': s.GOOGLE_CLIENT_ID,
         'client_secret': s.GOOGLE_CLIENT_SECRET,
         'code': code,
            'grant_type': 'authorization_code', 'redirect_uri': st.redirect_uri}, timeout=10)
        if r.status_code >= 400:
            raise ValueError('token exchange failed')
        tok = r.json().get('access_token')
        id_token = r.json().get('id_token')
        if not tok or not id_token:
            raise ValueError('missing token')
        info = httpx.get('https://openidconnect.googleapis.com/v1/userinfo',
            trust_env=False,
            headers={'Authorization': f'Bearer {tok}'}, timeout=10).json()
        subject = str(info.get('sub') or '')
        email = str(info.get('email') or '').lower()
        import jwt
        jwks_client = jwt.PyJWKClient(s.GOOGLE_JWKS_URL)
        signing_key = jwks_client.get_signing_key_from_jwt(id_token)
        claims = jwt.decode(id_token, signing_key.key, algorithms=['RS256'],
         audience=s.GOOGLE_CLIENT_ID,
            issuer=[x.strip() for x in s.GOOGLE_ISSUERS.split(',') if x.strip()])
        if not claims.get('email_verified') or str(claims.get('sub')) != subject:
            raise ValueError('identity proof failed')
        if not hmac.compare_digest(token_hash(str(claims.get('nonce') or '')), st.nonce_hash):
            raise AppError(400, 'OAUTH_LINK_NONCE_INVALID', 'Invalid OAuth link nonce')
    except AppError:
        raise
    except Exception as exc:
        raise AppError(502, 'GOOGLE_OAUTH_FAILED', 'Unable to verify Google identity') from exc
    existing = db.query(UserIdentity).filter_by(provider='google', provider_subject=subject).first()
    if existing and existing.user_id != st.user_id:
        raise AppError(409, 'IDENTITY_ALREADY_LINKED',
            'Google identity is already linked to another account')
    user = db.get(User, st.user_id)
    if not user:
        raise not_found('User not found')
    if not existing:
        db.add(UserIdentity(user_id=user.id, provider='google', provider_subject=subject,
            provider_email=email, email_verified_at=now))
    _consume_oauth_state(db, OAuthState, st.id, now, 'OAUTH_LINK_STATE_REPLAY')
    db.commit()
    response.delete_cookie('oauth_link_state')
    response.delete_cookie('oauth_link_nonce')
    return {'ok': True, 'provider': 'google', 'provider_subject': subject}

@router.post('/auth/identities/link')
def link_identity(data: IdentityLinkIn, user=Depends(current_user), db: DBSession=Depends(get_db)):
    if get_settings().ENVIRONMENT != 'test':
        raise AppError(410, 'DIRECT_IDENTITY_LINK_DISABLED',
            'Use the provider OAuth linking flow; client-supplied external identities are not trusted')
    existing = db.query(UserIdentity).filter_by(provider=data.provider,
        provider_subject=data.provider_subject).first()
    if existing and existing.user_id != user.id:
        raise AppError(409, 'IDENTITY_ALREADY_LINKED', 'External identity is already linked')
    if existing:
        return json_model(existing)
    if data.verified and data.provider_email and (str(data.provider_email).lower() == user.email.lower()):
        verified_at = datetime.now(timezone.utc)
    else:
        verified_at = None
    row = UserIdentity(user_id=user.id, provider=data.provider,
     provider_subject=data.provider_subject,
     provider_email=str(data.provider_email).lower() if data.provider_email else None,
        email_verified_at=verified_at)
    db.add(row)
    db.flush()
    audit(db, None, user.id, 'identity.link', 'user_identity', row.id,
        after={'provider': row.provider, 'verified': bool(verified_at)})
    db.commit()
    return json_model(row)
