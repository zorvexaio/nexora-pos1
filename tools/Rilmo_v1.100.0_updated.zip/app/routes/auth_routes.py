"""Authentication routes: register, login, MFA login-verification, logout,
session listing/revocation, /me, and password reset.

Extracted out of app/routes/v1.py (Phase 3, step 1 of the monolith-splitting
plan). This block was fully self-contained — every name it needs is a plain
top-level import, and its one private helper (_establish_session) was only
called from within this same block — so it was safe to move verbatim with no
behavior change. Route paths, methods, and prefixes are unchanged, so no
caller (frontend or test) needed updates.
"""
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session as DBSession
from sqlalchemy import func
from app.core.database import get_db, set_tenant_context
from app.core.security import *
from app.core.auth import current_user
from app.core.errors import AppError, not_found, forbidden
from app.models.domain import *
SessionModel = globals()['Session']
from app.schemas.api import *
from app.core.config import get_settings
from app.core.serialization import json_model
from app.services.core import enforce_rate_limit, ensure_seed
import uuid, hashlib

router = APIRouter(prefix='/v1')


@router.post('/auth/register')
def register(data: RegisterIn, response: Response, request: Request, db: DBSession=Depends(get_db)):
    enforce_rate_limit(db, 'auth:register:' + str(request.client.host), 8)
    if db.query(User).filter(func.lower(User.email) == data.email.lower()).first():
        raise AppError(409, 'EMAIL_EXISTS', 'Email already registered')
    u = User(email=data.email.lower(), password_hash=hash_password(data.password),
        display_name=data.display_name)
    db.add(u)
    db.flush()
    t = Tenant(slug=data.email.split('@')[0].replace('.', '-')[:60] + '-' + uuid.uuid4().hex[:6],
        name=(data.display_name or data.email).strip(), status='PROVISIONING')
    db.add(t)
    db.flush()
    set_tenant_context(db, t.id)
    db.add(TenantMembership(tenant_id=t.id, user_id=u.id, role='owner'))
    db.add(Storefront(tenant_id=t.id, name=t.name, slug='default', default_locale=t.default_locale,
        default_currency=t.default_currency))
    if any([data.phone, data.legal_name, data.country_code, data.city, data.address_line1]):
        db.add(MerchantProfile(tenant_id=t.id, legal_name=data.legal_name or (data.display_name or data.email),
            phone=data.phone or '', country_code=(data.country_code or '').upper(), city=data.city or '',
            address_line1=data.address_line1 or '', identity_status='PENDING'))
    ensure_seed(db)
    tok = create_session_token()
    now = datetime.now(timezone.utc)
    db.add(SessionModel(user_id=u.id, token_hash=token_hash(tok),
     expires_at=now + timedelta(hours=get_settings().SESSION_TTL_HOURS),
     idle_expires_at=now + timedelta(minutes=get_settings().SESSION_IDLE_TTL_MINUTES),
     absolute_expires_at=now + timedelta(days=get_settings().SESSION_ABSOLUTE_TTL_DAYS),
        last_seen_at=now))
    db.commit()
    response.set_cookie('session', tok, httponly=True, secure=get_settings().COOKIE_SECURE,
        samesite='lax', max_age=get_settings().SESSION_TTL_HOURS * 3600)
    response.set_cookie('csrf_token', random_token(24), httponly=False,
     secure=get_settings().COOKIE_SECURE,
        samesite='lax', max_age=get_settings().SESSION_TTL_HOURS * 3600)
    return {'user': json_model(u), 'tenant': json_model(t), 'access_token': tok,
        'token_type': 'bearer'}

@router.post('/auth/login')
def login(data: LoginIn, response: Response, request: Request, db: DBSession=Depends(get_db)):
    client_ip = str(request.client.host if request.client else 'unknown')
    email_key = data.email.lower().strip()
    enforce_rate_limit(db, 'auth:login:ip:' + client_ip, 10)
    enforce_rate_limit(db, 'auth:login:identity:' + hashlib.sha256(email_key.encode()).hexdigest(), 10)
    u = db.query(User).filter(func.lower(User.email) == email_key).first()
    if not u or not verify_password(data.password, u.password_hash):
        raise forbidden('Invalid credentials')
    enabled_mfa = db.query(MFAFactor).filter_by(user_id=u.id, factor_type='TOTP', enabled=True).first()
    if enabled_mfa:
        raw = random_token(40)
        now = datetime.now(timezone.utc)
        db.add(MFALoginChallenge(user_id=u.id, token_hash=token_hash(raw),
            expires_at=now + timedelta(minutes=5)))
        db.commit()
        response.delete_cookie('session')
        response.delete_cookie('csrf_token')
        return {'mfa_required': True, 'challenge': raw, 'expires_in': 300}
    return _establish_session(u, response, db)


def _establish_session(u, response, db):
    tok = create_session_token()
    now = datetime.now(timezone.utc)
    db.add(SessionModel(user_id=u.id, token_hash=token_hash(tok),
        expires_at=now + timedelta(hours=get_settings().SESSION_TTL_HOURS),
        idle_expires_at=now + timedelta(minutes=get_settings().SESSION_IDLE_TTL_MINUTES),
        absolute_expires_at=now + timedelta(days=get_settings().SESSION_ABSOLUTE_TTL_DAYS),
        last_seen_at=now))
    db.commit()
    s = get_settings()
    response.set_cookie('session', tok, httponly=True, secure=s.COOKIE_SECURE,
        samesite='lax', max_age=s.SESSION_TTL_HOURS * 3600)
    response.set_cookie('csrf_token', random_token(24), httponly=False,
        secure=s.COOKIE_SECURE, samesite='lax', max_age=s.SESSION_TTL_HOURS * 3600)
    return {'access_token': tok, 'token_type': 'bearer'}


@router.post('/auth/mfa/verify-login')
def verify_login_mfa(data: MFALoginVerifyIn, response: Response, request: Request,
                     db: DBSession=Depends(get_db)):
    enforce_rate_limit(db, 'auth:mfa:' + str(request.client.host if request.client else 'unknown'), 8)
    challenge = db.query(MFALoginChallenge).filter_by(token_hash=token_hash(data.challenge), used_at=None).with_for_update().first()
    now = datetime.now(timezone.utc)
    challenge_expires = challenge.expires_at.replace(tzinfo=timezone.utc) if challenge and challenge.expires_at.tzinfo is None else (challenge.expires_at if challenge else None)
    if not challenge or challenge_expires <= now:
        raise forbidden('Invalid or expired MFA challenge')
    factor = db.query(MFAFactor).filter_by(user_id=challenge.user_id, factor_type='TOTP', enabled=True).first()
    if not factor or not factor.secret_encrypted:
        raise forbidden('MFA is not configured')
    if not verify_totp(decrypt_secret(factor.secret_encrypted), data.code):
        raise forbidden('Invalid MFA code')
    challenge.used_at = now
    u = db.get(User, challenge.user_id)
    if not u or u.status != 'ACTIVE':
        raise forbidden('User inactive')
    return _establish_session(u, response, db)

@router.post('/auth/logout')
def logout(response: Response, user=Depends(current_user), db: DBSession=Depends(get_db),
    request: Request=None):
    raw = (request.headers.get('Authorization', '').split(' ',
     1)[1] if request and request.headers.get('Authorization',
        '').lower().startswith('bearer ') else None) or (request.cookies.get('session') if request else None)
    if raw:
        s = db.query(SessionModel).filter_by(token_hash=token_hash(raw)).first()
        if s:
            s.revoked_at = datetime.now(timezone.utc)
    db.commit()
    response.delete_cookie('session')
    response.delete_cookie('csrf_token')
    return {'ok': True}

@router.get('/auth/sessions')
def list_sessions(request: Request, user=Depends(current_user), db: DBSession=Depends(get_db)):
    rows = db.query(SessionModel).filter(SessionModel.user_id == user.id,
        SessionModel.revoked_at.is_(None)).order_by(SessionModel.last_seen_at.desc()).all()
    now = datetime.now(timezone.utc)

    def aware(v):
        return v.replace(tzinfo=timezone.utc) if v and v.tzinfo is None else v
    return {'items': [{'id': x.id, 'created_at': x.last_seen_at.isoformat(),
     'expires_at': aware(x.expires_at).isoformat(),
     'idle_expires_at': aware(x.idle_expires_at).isoformat() if x.idle_expires_at else None,
     'last_seen_at': aware(x.last_seen_at).isoformat() if x.last_seen_at else None,
     'current': x.token_hash == token_hash(request.headers.get('Authorization',
     '').split(' ',
     1)[1] if request.headers.get('Authorization',
        '').lower().startswith('bearer ') else request.cookies.get('session') or '')} for x in rows if aware(x.expires_at) > now]}

@router.delete('/auth/sessions/{session_id}')
def revoke_session(session_id: str, user=Depends(current_user), db: DBSession=Depends(get_db)):
    row = db.query(SessionModel).filter_by(id=session_id, user_id=user.id, revoked_at=None).first()
    if not row:
        raise not_found('Session not found')
    row.revoked_at = datetime.now(timezone.utc)
    db.commit()
    return {'ok': True}

@router.get('/me')
def me(user=Depends(current_user), db: DBSession=Depends(get_db)):
    is_platform_admin = db.query(PlatformAdmin).filter(PlatformAdmin.user_id == user.id).first() is not None
    return {'user': json_model(user), 'is_platform_admin': is_platform_admin,
        'memberships': [json_model(m) for m in db.query(TenantMembership).filter_by(user_id=user.id).all()]}

@router.post('/auth/password-reset/request')
def reset_request(data: PasswordResetRequestIn, request: Request, db: DBSession=Depends(get_db)):
    enforce_rate_limit(db, 'auth:reset_request:' + str(request.client.host), 6)
    u = db.query(User).filter(func.lower(User.email) == data.email.lower()).first()
    tok = create_reset_token()
    if u:
        db.add(PasswordResetToken(user_id=u.id, token_hash=token_hash(tok),
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=get_settings().PASSWORD_RESET_TTL_MINUTES)))
        db.commit()
        from app.services.mailer import send_password_reset
        send_password_reset(u.email, tok)
    return {'ok': True}

@router.post('/auth/password-reset/confirm')
def reset_confirm(data: PasswordResetConfirmIn, request: Request, db: DBSession=Depends(get_db)):
    enforce_rate_limit(db, 'auth:reset_confirm:' + str(request.client.host), 10)
    r = db.query(PasswordResetToken).filter_by(token_hash=token_hash(data.token),
        used_at=None).with_for_update().first()
    if r:
        expires_at = r.expires_at.replace(tzinfo=timezone.utc) if r.expires_at.tzinfo is None else r.expires_at
    if not r or expires_at <= datetime.now(timezone.utc):
        raise AppError(400, 'RESET_INVALID', 'Invalid or expired token')
    u = db.get(User, r.user_id)
    u.password_hash = hash_password(data.password)
    r.used_at = datetime.now(timezone.utc)
    db.query(SessionModel).filter_by(user_id=u.id).update({'revoked_at': datetime.now(timezone.utc)})
    db.commit()
    return {'ok': True}
