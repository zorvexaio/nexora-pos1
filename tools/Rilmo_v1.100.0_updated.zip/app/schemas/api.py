from pydantic import BaseModel, Field, EmailStr
from typing import Optional, Dict, Any
from datetime import datetime

class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=12)
    display_name: Optional[str] = None
    phone: Optional[str] = Field(default=None, min_length=7, max_length=32)
    legal_name: Optional[str] = Field(default=None, min_length=2, max_length=255)
    country_code: Optional[str] = Field(default=None, min_length=2, max_length=2)
    city: Optional[str] = Field(default=None, max_length=120)
    address_line1: Optional[str] = Field(default=None, max_length=255)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class MFALoginVerifyIn(BaseModel):
    challenge: str = Field(min_length=20, max_length=512)
    code: str = Field(min_length=6, max_length=32)

class PasswordResetRequestIn(BaseModel):
    email: EmailStr

class PasswordResetConfirmIn(BaseModel):
    token: str
    password: str = Field(min_length=12)

class TenantIn(BaseModel):
    slug: str = Field(min_length=2, max_length=80, pattern='^[a-z0-9-]+$')
    name: str
    default_currency: str = 'USD'
    default_locale: str = 'ar'

class ProductIn(BaseModel):
    slug: str
    title: str
    description: Optional[str] = None
    status: str = 'ACTIVE'
    product_type: str = 'PHYSICAL'

class VariantIn(BaseModel):
    sku: str
    price_amount_minor: int = Field(ge=0)
    currency: str
    status: str = 'ACTIVE'

class CartItemIn(BaseModel):
    variant_id: str
    quantity: int = Field(gt=0)

class CheckoutIn(BaseModel):
    cart_id: str
    customer_email: Optional[EmailStr] = None
    customer_name: Optional[str] = None
    shipping_minor: int = Field(default=0, ge=0)
    tax_minor: int = Field(default=0, ge=0)
    fee_minor: int = Field(default=0, ge=0)
    coupon_code: Optional[str] = None
    shipping_method_id: Optional[str] = None
    shipping_address: Optional[Dict[str, Any]] = None
    inventory_location_id: Optional[str] = Field(default=None, min_length=1, max_length=36)
    affiliate_code: Optional[str] = None

class PaymentIn(BaseModel):
    order_id: Optional[str] = None
    ucp_external_session_id: Optional[str] = Field(default=None, min_length=1, max_length=160)
    domain_purchase_id: Optional[str] = Field(default=None, min_length=1, max_length=36)
    amount_minor: int = Field(gt=0)
    currency: str
    provider: str = 'iyzico'

class RefundIn(BaseModel):
    order_id: str
    payment_intent_id: str
    amount_minor: int = Field(gt=0)
    currency: str

class CustomerOrderCancelIn(BaseModel):
    reason: str = Field(default='customer_requested', min_length=3, max_length=120)
    idempotency_key: str = Field(min_length=8, max_length=200)

class OrderIssueCreateIn(BaseModel):
    issue_type: str = Field(pattern='^(CANCEL_REQUEST|REFUND_REQUEST|RETURN|NOT_RECEIVED|WRONG_ITEM|DAMAGED|OTHER)$')
    message: str = Field(min_length=3, max_length=4000)
    idempotency_key: str = Field(min_length=8, max_length=200)

class OrderIssueMessageIn(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    idempotency_key: str = Field(min_length=8, max_length=200)


class OrderIssueUpdateIn(BaseModel):
    action: str = Field(pattern='^(ACKNOWLEDGE|RESOLVE_REFUND|RESOLVE_REPLACEMENT|RESOLVE_REJECT|ESCALATE)$')
    message: Optional[str] = Field(default=None, max_length=4000)

class DomainIn(BaseModel):
    hostname: str

class ShippingIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    carrier_code: str = Field(default='platform', min_length=2, max_length=40)
    service_code: Optional[str] = Field(default=None, max_length=80)
    amount_minor: int = Field(default=0, ge=0)
    currency: str = Field(min_length=3, max_length=3)
    free_shipping: bool = False
    free_shipping_threshold_minor: Optional[int] = Field(default=None, ge=0)
    offer_label: Optional[str] = Field(default=None, max_length=255)
    estimated_days_min: Optional[int] = Field(default=None, ge=0, le=365)
    estimated_days_max: Optional[int] = Field(default=None, ge=0, le=365)

class TaxIn(BaseModel):
    country_code: str
    rate_bps: int = Field(ge=0, le=10000)
    region: Optional[str] = None
    inclusive: bool = False

class PlanSubIn(BaseModel):
    plan_version_id: str
    billing_discount_code: Optional[str] = None

class ReviewIn(BaseModel):
    product_id: str
    order_id: str
    rating: int = Field(ge=1, le=5)
    body: Optional[str] = None

class QuestionIn(BaseModel):
    product_id: str
    body: str

class AnswerIn(BaseModel):
    body: str

class WishlistIn(BaseModel):
    product_id: str

class IdentityLinkIn(BaseModel):
    provider: str = Field(min_length=2, max_length=50)
    provider_subject: str = Field(min_length=1, max_length=255)
    provider_email: Optional[EmailStr] = None
    verified: bool = False

class AnonymizeIn(BaseModel):
    confirm: bool

class CarrierIn(BaseModel):
    carrier_code: str = Field(min_length=2, max_length=40)
    api_base_url: Optional[str] = None
    api_token: Optional[str] = None

class ShippingQuoteIn(BaseModel):
    subtotal_minor: int = Field(default=0, ge=0)
    origin: Dict[str, Any]
    destination: Dict[str, Any]
    parcels: list[Dict[str, Any]]
    currency: str

class ShipmentCreateIn(BaseModel):
    carrier_code: str
    service_code: Optional[str] = None
    origin: Dict[str, Any]
    destination: Dict[str, Any]
    parcels: list[Dict[str, Any]]

class ZatcaSellerIn(BaseModel):
    vat_number: str = Field(min_length=15, max_length=15)
    city: str
    region: Optional[str] = None
    country_code: str = 'SA'

class ThemeIn(BaseModel):
    slug: str = Field(min_length=2, max_length=100, pattern='^[a-z0-9-]+$')
    name: str = Field(min_length=2, max_length=160)
    template_key: str = 'catalog'
    settings: Dict[str, Any] = {}

class ThemeAssignIn(BaseModel):
    theme_id: str

class LoyaltyEarnIn(BaseModel):
    customer_id: str
    points: int = Field(gt=0)
    reason: str = Field(min_length=2, max_length=120)
    idempotency_key: str = Field(min_length=8, max_length=200)

class LoyaltyRedeemIn(BaseModel):
    customer_id: str
    points: int = Field(gt=0)
    reason: str = Field(min_length=2, max_length=120)
    idempotency_key: str = Field(min_length=8, max_length=200)

class MarketingPreferenceIn(BaseModel):
    email_marketing: bool = False
    sms_marketing: bool = False
    whatsapp_marketing: bool = False

class AppCreateIn(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    slug: str = Field(min_length=2, max_length=100, pattern='^[a-z0-9-]+$')
    redirect_uris: list[str] = Field(min_length=1, max_length=10)
    scopes: list[str] = Field(min_length=1, max_length=30)
    publisher_name: Optional[str] = None

class AppInstallIn(BaseModel):
    app_id: str
    scopes: list[str] = Field(min_length=1, max_length=30)

class AppWebhookIn(BaseModel):
    event_type: str = Field(min_length=3, max_length=120)
    endpoint_url: str = Field(min_length=8, max_length=1000)

class ReturnItemIn(BaseModel):
    order_item_id: str
    quantity: int = Field(gt=0)

class ReturnCreateIn(BaseModel):
    type: str = Field(default='REFUND', pattern='^(REFUND|EXCHANGE)$')
    reason_code: str = Field(min_length=2, max_length=80)
    reason_note: Optional[str] = Field(default=None, max_length=2000)
    items: list[ReturnItemIn] = Field(min_length=1, max_length=100)
    idempotency_key: str = Field(min_length=8, max_length=200)

class ReturnDecisionIn(BaseModel):
    approved: bool
    approved_amount_minor: Optional[int] = Field(default=None, ge=0)
    note: Optional[str] = Field(default=None, max_length=2000)

class SupportTicketIn(BaseModel):
    subject: str = Field(min_length=3, max_length=200)
    body: str = Field(min_length=5, max_length=10000)
    priority: str = Field(default='NORMAL', pattern='^(LOW|NORMAL|HIGH|URGENT)$')
    category: str = Field(default='GENERAL', min_length=2, max_length=50)

class SupportTicketUpdateIn(BaseModel):
    status: str | None = Field(default=None,
        pattern='^(OPEN|IN_PROGRESS|WAITING_ON_CUSTOMER|RESOLVED|CLOSED)$')
    priority: str | None = Field(default=None, pattern='^(LOW|NORMAL|HIGH|URGENT)$')
    assigned_user_id: str | None = None

class WorkflowDefinitionIn(BaseModel):
    slug: str = Field(min_length=2, max_length=120, pattern='^[a-z0-9-]+$')
    name: str = Field(min_length=2, max_length=200)
    trigger_event: str = Field(min_length=3, max_length=120)
    enabled: bool = False
    steps: list[dict[str, Any]] = Field(default_factory=list, max_length=50)

class WorkflowRunIn(BaseModel):
    input_payload: dict[str, Any] = Field(default_factory=dict)

class MarketIn(BaseModel):
    code: str
    name: str
    country_code: str
    currency: str
    locale: str = 'en'
    is_default: bool = False

class MarketPriceIn(BaseModel):
    variant_id: str
    amount_minor: int
    currency: str

class NotificationTemplateIn(BaseModel):
    code: str
    channel: str
    locale: str
    subject: str = ''
    body: str
    active: bool = True

class NotificationSendIn(BaseModel):
    template_id: str | None = None
    channel: str
    recipient: str
    payload: dict[str, Any] = {}
    idempotency_key: str

class APIKeyIn(BaseModel):
    name: str
    scopes: list[str] = []
    expires_at: datetime | None = None

class AIGenerateIn(BaseModel):
    locale: str = 'ar'
    apply: bool = False

class AIAssistantIn(BaseModel):
    question: str = Field(min_length=1, max_length=500)
    locale: str = 'ar'

class WhatsAppConfigIn(BaseModel):
    phone_number_id: str = Field(min_length=3, max_length=120)
    access_token: str = Field(min_length=10)
    verify_token: str = Field(min_length=8, max_length=255)
    business_account_id: str | None = None
    api_version: str = 'v23.0'

class WhatsAppSendIn(BaseModel):
    recipient: str = Field(min_length=8, max_length=40)
    body: str = Field(min_length=1, max_length=4096)

class LandingPageIn(BaseModel):
    slug: str = Field(min_length=2, max_length=120)
    title: str = Field(min_length=2, max_length=200)
    locale: str = 'ar'
    seo_title: str | None = None
    seo_description: str | None = None
    content: dict[str, Any] = {}
    status: str = 'DRAFT'

class AffiliateProgramIn(BaseModel):
    name: str = 'Affiliate Program'
    status: str = 'ACTIVE'
    commission_bps: int = Field(default=1000, ge=0, le=5000)
    cookie_days: int = Field(default=30, ge=1, le=365)
    min_payout_minor: int = Field(default=5000, ge=0)
    currency: str = 'USD'

class AffiliatePartnerIn(BaseModel):
    code: str | None = None
    name: str = Field(min_length=2, max_length=160)
    email: EmailStr

class ImpersonationIn(BaseModel):
    reason: str = Field(min_length=8, max_length=500)

class TurkeyTaxProfileIn(BaseModel):
    code: str = Field(min_length=2, max_length=50)
    name: str = Field(min_length=2, max_length=120)
    kdv_bps: int = Field(ge=0, le=10000)
    inclusive: bool = False

class ProviderAccountConfigIn(BaseModel):
    provider: str = Field(min_length=2, max_length=40)
    credentials: dict[str, Any]

class PayTRCallbackIn(BaseModel):
    merchant_oid: str
    status: str
    total_amount: str
    hash: str

class TurkeyCarrierConfigIn(BaseModel):
    carrier_code: str = Field(min_length=2, max_length=40)
    api_base_url: str | None = None
    api_token: str | None = None
    metadata: dict[str, Any] = {}


class MerchantProfileIn(BaseModel):
    legal_name: str = Field(min_length=2, max_length=255)
    phone: str = Field(min_length=7, max_length=32)
    country_code: str = Field(min_length=2, max_length=2)
    city: str = Field(min_length=2, max_length=120)
    address_line1: str = Field(min_length=3, max_length=255)
    postal_code: Optional[str] = Field(default=None, max_length=30)
    tax_id: Optional[str] = Field(default=None, max_length=120)
    registration_number: Optional[str] = Field(default=None, max_length=160)
    business_registry_country: Optional[str] = Field(default=None, min_length=2, max_length=2)
    beneficial_owner_name: Optional[str] = Field(default=None, max_length=255)
    beneficial_owner_country: Optional[str] = Field(default=None, min_length=2, max_length=2)
    business_type: str = Field(default='individual', max_length=40)

class PhoneVerifyRequestIn(BaseModel):
    phone: str = Field(min_length=7, max_length=32)

class PhoneVerifyConfirmIn(BaseModel):
    code: str = Field(min_length=4, max_length=12)

class StoreReviewIn(BaseModel):
    rating: int = Field(ge=1, le=5)
    body: Optional[str] = Field(default=None, max_length=2000)
    order_id: Optional[str] = None

class StoreReportIn(BaseModel):
    reason: str = Field(min_length=3, max_length=80)
    details: str = Field(min_length=10, max_length=5000)
    evidence_url: Optional[str] = Field(default=None, max_length=1000)

class DomainCheckIn(BaseModel):
    hostname: str = Field(min_length=3, max_length=255)

class DomainPurchaseIn(BaseModel):
    hostname: str = Field(min_length=3, max_length=255)
    years: int = Field(default=1, ge=1, le=10)
    registrant_first_name: str = Field(min_length=2, max_length=80)
    registrant_last_name: str = Field(min_length=2, max_length=80)
    registrant_email: EmailStr
    registrant_phone: str = Field(min_length=7, max_length=32)
    country_code: str = Field(min_length=2, max_length=2)
    city: str = Field(min_length=2, max_length=120)
    address_line1: str = Field(min_length=3, max_length=255)
    postal_code: Optional[str] = Field(default=None, max_length=30)

class SuspendTenantIn(BaseModel):
    action: str = Field(pattern='^(SUSPEND|RESTORE)$')
    reason: str = Field(min_length=5, max_length=500)

class AbuseReportDecisionIn(BaseModel):
    action: str = Field(pattern='^(OPEN|UNDER_REVIEW|RESOLVED|REJECTED)$')
    note: Optional[str] = Field(default=None, max_length=2000)


class MerchantBusinessVerificationSubmitIn(BaseModel):
    verification_method: str = Field(min_length=3, max_length=40)
    evidence_reference: str = Field(min_length=8, max_length=500)
    confirm_truthfulness: bool = True

class MerchantPaymentAccountDecisionIn(BaseModel):
    action: str = Field(pattern='^(APPROVE|REJECT|REVERIFY)$')
    provider_account_id: Optional[str] = Field(default=None, max_length=255)
    requirements_due: Dict[str, Any] = {}
    evidence_reference: str = Field(min_length=8, max_length=500)

class MerchantIdentityStartIn(BaseModel):
    country_code: str = Field(min_length=2, max_length=2)
    full_name: str = Field(min_length=2, max_length=255)
    confirm_terms: bool = False

class MerchantRiskSignalIn(BaseModel):
    event_type: str = Field(min_length=3, max_length=80)
    severity: str = Field(default='WARN', pattern='^(INFO|WARN|HIGH|CRITICAL)$')
    score_delta: int = Field(default=0, ge=-100, le=100)
    metadata: Dict[str, Any] = {}

class MerchantReviewDecisionIn(BaseModel):
    action: str = Field(pattern='^(APPROVE|REJECT|REVERIFY|CLOSE_WITHOUT_ACTION)$')
    note: Optional[str] = Field(default=None, max_length=4000)

class MerchantRiskActionIn(BaseModel):
    action: str = Field(pattern='^(FREEZE|UNFREEZE|HOLD_PAYOUT|RELEASE_PAYOUT|REQUIRE_REVERIFICATION)$')
    reason: str = Field(min_length=3, max_length=500)
